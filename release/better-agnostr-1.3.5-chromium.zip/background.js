(() => {
  // src/background.js
  var api = globalThis.browser ?? globalThis.chrome;
  var BUILD_KEY = "betterAgnostr.glubBuild.v1";
  var SETTINGS_KEY = "betterAgnostr.settings.v1";
  var CACHE_MS = 2 * 60 * 1e3;
  var MAX_STALE_MS = 6 * 60 * 60 * 1e3;
  async function readCache() {
    try {
      const obj = await api.storage.local.get(BUILD_KEY);
      const cached = obj?.[BUILD_KEY];
      if (cached && typeof cached.build === "string") return cached;
    } catch {
    }
    return null;
  }
  async function writeCache(value) {
    try {
      await api.storage.local.set({ [BUILD_KEY]: value });
    } catch {
    }
  }
  async function fetchBuild() {
    const signal = typeof globalThis.AbortSignal?.timeout === "function" ? globalThis.AbortSignal.timeout(8e3) : void 0;
    const res = await fetch("https://glub.chat/", {
      cache: "no-store",
      credentials: "omit",
      redirect: "follow",
      signal,
      headers: { Accept: "text/html,application/xhtml+xml" }
    });
    if (!res.ok) throw new Error(`glub.chat returned HTTP ${res.status}`);
    const html = await res.text();
    const match = html.match(/data-build="([^"]+)"/i) || html.match(/data-build='([^']+)'/i) || html.match(/"build"\s*:\s*"([^"]+)"/i);
    const build = match?.[1]?.trim();
    if (!build || !/^[a-zA-Z0-9._-]{3,64}$/.test(build)) {
      throw new Error("Could not find a build stamp in the glub.chat page.");
    }
    return build;
  }
  async function extensionSettings() {
    try {
      const obj = await api.storage.local.get(SETTINGS_KEY);
      return obj?.[SETTINGS_KEY] || {};
    } catch {
      return {};
    }
  }
  async function extensionEnabled() {
    try {
      const obj = await api.storage.local.get(SETTINGS_KEY);
      return obj?.[SETTINGS_KEY]?.enabled !== false;
    } catch {
      return false;
    }
  }
  var buildInFlight = null;
  async function getGlubBuild({ force = false } = {}) {
    if (buildInFlight) return buildInFlight;
    buildInFlight = (async () => {
      if (!await extensionEnabled()) return { build: "", fetchedAt: 0, disabled: true };
      const cached = await readCache();
      if (!force && (await extensionSettings()).glub?.autoSync === false) {
        return cached ? { build: cached.build, fetchedAt: cached.fetchedAt, cached: true } : { build: "", fetchedAt: 0, disabled: true };
      }
      const age = cached ? Date.now() - Number(cached.fetchedAt || 0) : Infinity;
      if (!force && cached && age < CACHE_MS) {
        return { build: cached.build, fetchedAt: cached.fetchedAt, cached: true };
      }
      try {
        const build = await fetchBuild();
        const value = { build, fetchedAt: Date.now() };
        await writeCache(value);
        return { build, fetchedAt: value.fetchedAt, cached: false };
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        if (cached && age < MAX_STALE_MS) {
          return {
            build: cached.build,
            fetchedAt: cached.fetchedAt,
            cached: true,
            stale: true,
            error: message
          };
        }
        return { build: "", fetchedAt: 0, error: message };
      }
    })();
    try {
      return await buildInFlight;
    } finally {
      buildInFlight = null;
    }
  }
  api.runtime.onMessage.addListener((message, sender) => {
    if (!message || typeof message !== "object") return void 0;
    if (sender?.id && sender.id !== api.runtime.id) return void 0;
    if (message.type === "getGlubBuild") {
      return getGlubBuild({ force: !!message.force }).catch((err) => ({
        build: "",
        fetchedAt: 0,
        error: String(err)
      }));
    }
    if (message.type === "warmGlubBuild") {
      return getGlubBuild({ force: false }).catch(() => null);
    }
    return void 0;
  });
  api.runtime.onInstalled.addListener(() => {
    getGlubBuild({ force: true }).catch(() => {
    });
    try {
      api.alarms.create("betterAgnostr.glubBuild", { periodInMinutes: 10 });
    } catch {
    }
  });
  api.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === "betterAgnostr.glubBuild") {
      getGlubBuild({ force: false }).catch(() => {
      });
    }
  });
  api.runtime.onStartup.addListener(() => {
    try {
      api.alarms.create("betterAgnostr.glubBuild", { periodInMinutes: 10 });
    } catch {
    }
    getGlubBuild({ force: false }).catch(() => {
    });
  });
})();
