(() => {
  // src/ui/panel.css
  var panel_default = ':host {\n  all: initial;\n  position: fixed;\n  inset: 0;\n  z-index: 2147483000;\n  pointer-events: none;\n  direction: inherit;\n  color-scheme: inherit;\n  font-family: var(--font-sans, "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif);\n  font-size: 13px;\n  line-height: 1.45;\n  color: var(--ba-text, #f1f3f7);\n  --ba-bg: var(--bg-canvas, #0b0c0f);\n  --ba-surface: var(--bg-surface, #111318);\n  --ba-elevated: var(--bg-elevated, #171a21);\n  --ba-subtle: var(--bg-subtle, #1f232c);\n  --ba-border: var(--border-default, rgba(255, 255, 255, 0.11));\n  --ba-border-subtle: var(--border-subtle, rgba(255, 255, 255, 0.07));\n  --ba-text: var(--text-primary, #f1f3f7);\n  --ba-text-2: var(--text-secondary, #9ba3b4);\n  --ba-muted: var(--text-muted, #687182);\n  --ba-accent: var(--accent, #3b82f6);\n  --ba-accent-hover: var(--accent-hover, #60a5fa);\n  --ba-accent-soft: var(--accent-soft, rgba(59, 130, 246, 0.14));\n  --ba-ok: var(--status-ok, #22c55e);\n  --ba-warn: var(--status-warn, #f59e0b);\n  --ba-danger: var(--status-danger, #ef4444);\n  --ba-radius: var(--radius-md, 10px);\n  --ba-radius-lg: var(--radius-lg, 12px);\n  --ba-mono: var(--font-mono, "JetBrains Mono", ui-monospace, monospace);\n  --ba-shadow: var(--shadow-lg, 0 18px 48px rgba(0, 0, 0, 0.6));\n  --ba-ease: var(--ease-out, cubic-bezier(0.16, 1, 0.3, 1));\n}\n:host *,\n:host *::before,\n:host *::after {\n  box-sizing: border-box;\n}\nbutton,\ninput,\nselect,\ntextarea {\n  font-family: inherit;\n  font-size: inherit;\n  color: inherit;\n}\nbutton {\n  cursor: pointer;\n}\na {\n  color: var(--ba-accent);\n}\n\n/* --- launcher ------------------------------------------------------------- */\n/* --- backdrop & panel ----------------------------------------------------- */\n.ba-backdrop {\n  position: fixed;\n  inset: 0;\n  background: rgba(2, 3, 6, 0.48);\n  backdrop-filter: blur(2px);\n  opacity: 0;\n  pointer-events: none;\n  transition: opacity 0.2s var(--ba-ease);\n  z-index: 10;\n}\n.ba-backdrop.is-open {\n  opacity: 1;\n  pointer-events: auto;\n}\n.ba-panel {\n  position: fixed;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  width: min(446px, 100vw);\n  display: flex;\n  flex-direction: column;\n  background: color-mix(in srgb, var(--ba-surface) 96%, transparent);\n  border-left: 1px solid var(--ba-border);\n  box-shadow: -20px 0 60px rgba(0, 0, 0, 0.45);\n  transform: translateX(102%);\n  transition: transform 0.26s var(--ba-ease);\n  pointer-events: auto;\n  z-index: 20;\n  overflow: hidden;\n}\n.ba-panel.is-open {\n  transform: translateX(0);\n}\n@media (max-width: 560px) {\n  .ba-panel {\n    width: 100vw;\n    border-left: none;\n  }\n}\n.ba-head {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  padding: 14px 16px 12px;\n  border-bottom: 1px solid var(--ba-border-subtle);\n  background: var(--ba-surface);\n}\n.ba-brand {\n  display: flex;\n  align-items: center;\n  gap: 9px;\n  min-width: 0;\n}\n.ba-mark {\n  width: 30px;\n  height: 30px;\n  border-radius: 9px;\n  display: grid;\n  place-items: center;\n  background: linear-gradient(140deg, color-mix(in srgb, var(--ba-accent) 28%, transparent), transparent);\n  border: 1px solid color-mix(in srgb, var(--ba-accent) 40%, var(--ba-border));\n  color: var(--ba-accent);\n  flex: 0 0 auto;\n  font-size: 15px;\n}\n.ba-brand-copy {\n  min-width: 0;\n}\n.ba-title {\n  margin: 0;\n  font-family: var(--ba-mono);\n  font-size: 12px;\n  font-weight: 700;\n  letter-spacing: 0.1em;\n  text-transform: uppercase;\n  color: var(--ba-text);\n}\n.ba-subtitle {\n  margin-top: 1px;\n  font-family: var(--ba-mono);\n  font-size: 9px;\n  color: var(--ba-muted);\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  max-width: 270px;\n}\n.ba-head-space { flex: 1; }\n.ba-icon-btn {\n  width: 28px;\n  height: 28px;\n  border-radius: 8px;\n  border: 1px solid transparent;\n  background: transparent;\n  color: var(--ba-text-2);\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 14px;\n  line-height: 1;\n}\n.ba-icon-btn:hover {\n  border-color: var(--ba-border);\n  background: var(--bg-hover, rgba(255, 255, 255, 0.045));\n  color: var(--ba-text);\n}\n.ba-status-dot {\n  width: 7px;\n  height: 7px;\n  border-radius: 50%;\n  background: var(--ba-muted);\n  box-shadow: 0 0 0 3px color-mix(in srgb, var(--ba-muted) 15%, transparent);\n  flex: 0 0 auto;\n}\n.ba-status-dot.ok { background: var(--ba-ok); box-shadow: 0 0 0 3px color-mix(in srgb, var(--ba-ok) 15%, transparent); }\n.ba-status-dot.warn { background: var(--ba-warn); box-shadow: 0 0 0 3px color-mix(in srgb, var(--ba-warn) 15%, transparent); }\n.ba-status-dot.err { background: var(--ba-danger); box-shadow: 0 0 0 3px color-mix(in srgb, var(--ba-danger) 15%, transparent); }\n\n/* --- tabs ----------------------------------------------------------------- */\n.ba-tabs {\n  display: flex;\n  gap: 2px;\n  padding: 0 10px;\n  border-bottom: 1px solid var(--ba-border-subtle);\n  overflow-x: auto;\n  scrollbar-width: none;\n  background: var(--ba-surface);\n  flex: 0 0 auto;\n}\n.ba-tabs::-webkit-scrollbar { display: none; }\n.ba-tab {\n  position: relative;\n  padding: 10px 10px 9px;\n  border: none;\n  background: transparent;\n  color: var(--ba-muted);\n  font-family: var(--ba-mono);\n  font-size: 10px;\n  letter-spacing: 0.03em;\n  text-transform: lowercase;\n  white-space: nowrap;\n}\n.ba-tab:hover { color: var(--ba-text-2); }\n.ba-tab.is-active { color: var(--ba-accent); }\n.ba-tab.is-active::after {\n  content: "";\n  position: absolute;\n  left: 8px;\n  right: 8px;\n  bottom: -1px;\n  height: 2px;\n  background: var(--ba-accent);\n  border-radius: 2px;\n}\n.ba-body {\n  flex: 1;\n  overflow-y: auto;\n  padding: 14px 16px 24px;\n  scrollbar-width: thin;\n  scrollbar-color: var(--ba-subtle) transparent;\n}\n.ba-body::-webkit-scrollbar { width: 8px; }\n.ba-body::-webkit-scrollbar-thumb { background: var(--ba-subtle); border-radius: 8px; }\n.ba-pane { display: none; }\n.ba-pane.is-active { display: block; }\n.ba-pane-title {\n  margin: 0 0 2px;\n  font-family: var(--ba-mono);\n  font-size: 10px;\n  font-weight: 700;\n  letter-spacing: 0.08em;\n  text-transform: uppercase;\n  color: var(--ba-text-2);\n}\n.ba-pane-desc {\n  margin: 0 0 12px;\n  color: var(--ba-muted);\n  font-size: 11px;\n  line-height: 1.5;\n}\n.ba-foot {\n  flex: 0 0 auto;\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  padding: 8px 14px;\n  border-top: 1px solid var(--ba-border-subtle);\n  background: var(--ba-bg);\n  font-family: var(--ba-mono);\n  font-size: 9px;\n  color: var(--ba-muted);\n  min-height: 34px;\n  overflow-x: auto;\n  white-space: nowrap;\n  scrollbar-width: none;\n}\n.ba-foot::-webkit-scrollbar { display: none; }\n.ba-foot > * { flex: 0 0 auto; }\n.ba-foot .ba-foot-space { flex: 1; }\n.ba-foot button { color: var(--ba-text-2); }\n\n/* --- cards / form --------------------------------------------------------- */\n.ba-card {\n  border: 1px solid var(--ba-border-subtle);\n  border-radius: var(--ba-radius-lg);\n  background: color-mix(in srgb, var(--ba-elevated) 74%, transparent);\n  padding: 12px;\n  margin-bottom: 12px;\n}\n.ba-card-head {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  margin-bottom: 8px;\n}\n.ba-card-title {\n  font-family: var(--ba-mono);\n  font-size: 10px;\n  font-weight: 700;\n  letter-spacing: 0.07em;\n  text-transform: uppercase;\n  color: var(--ba-text-2);\n}\n.ba-card-sub {\n  font-size: 10.5px;\n  color: var(--ba-muted);\n  margin: -4px 0 10px;\n  line-height: 1.45;\n}\n.ba-row {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  min-height: 30px;\n}\n.ba-row + .ba-row { margin-top: 6px; }\n.ba-row-label {\n  flex: 1;\n  min-width: 0;\n  font-size: 12px;\n  color: var(--ba-text);\n}\n.ba-row-label small {\n  display: block;\n  font-size: 10px;\n  color: var(--ba-muted);\n  line-height: 1.3;\n  margin-top: 1px;\n}\n.ba-grid2 {\n  display: grid;\n  grid-template-columns: 1fr 1fr;\n  gap: 8px;\n}\n.ba-grid3 {\n  display: grid;\n  grid-template-columns: repeat(3, 1fr);\n  gap: 6px;\n}\n.ba-label {\n  display: block;\n  margin: 10px 0 4px;\n  font-family: var(--ba-mono);\n  font-size: 9px;\n  letter-spacing: 0.06em;\n  text-transform: uppercase;\n  color: var(--ba-muted);\n}\n.ba-input,\n.ba-select,\n.ba-textarea {\n  width: 100%;\n  border: 1px solid var(--ba-border);\n  border-radius: 8px;\n  background: var(--bg-input, #14171d);\n  color: var(--ba-text);\n  padding: 7px 8px;\n  font-size: 12px;\n  outline: none;\n  transition: border-color 0.15s ease, box-shadow 0.15s ease;\n}\n.ba-input:focus,\n.ba-select:focus,\n.ba-textarea:focus {\n  border-color: var(--ba-accent);\n  box-shadow: 0 0 0 3px color-mix(in srgb, var(--ba-accent) 16%, transparent);\n}\n.ba-input.mono,\n.ba-textarea.mono {\n  font-family: var(--ba-mono);\n  font-size: 11px;\n}\n.ba-textarea {\n  resize: vertical;\n  min-height: 72px;\n  line-height: 1.5;\n}\n.ba-select {\n  appearance: none;\n  background-image: linear-gradient(45deg, transparent 50%, var(--ba-text-2) 50%), linear-gradient(135deg, var(--ba-text-2) 50%, transparent 50%);\n  background-position: calc(100% - 12px) 50%, calc(100% - 8px) 50%;\n  background-size: 4px 4px, 4px 4px;\n  background-repeat: no-repeat;\n  padding-right: 24px;\n}\n.ba-btn {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  gap: 5px;\n  min-height: 28px;\n  padding: 5px 10px;\n  border: 1px solid var(--ba-border);\n  border-radius: 7px;\n  background: var(--ba-elevated);\n  color: var(--ba-text);\n  font-size: 11px;\n  font-weight: 600;\n  white-space: nowrap;\n}\n.ba-btn:hover {\n  border-color: var(--ba-border-strong, var(--ba-border));\n  background: var(--bg-hover, rgba(255, 255, 255, 0.05));\n}\n.ba-btn.primary {\n  border-color: color-mix(in srgb, var(--ba-accent) 65%, transparent);\n  background: color-mix(in srgb, var(--ba-accent) 22%, var(--ba-elevated));\n  color: #fff;\n}\n.ba-btn.primary:hover {\n  background: color-mix(in srgb, var(--ba-accent) 34%, var(--ba-elevated));\n}\n.ba-btn.danger {\n  border-color: color-mix(in srgb, var(--ba-danger) 50%, var(--ba-border));\n  color: var(--ba-danger);\n}\n.ba-btn.ghost {\n  border-color: transparent;\n  background: transparent;\n  color: var(--ba-text-2);\n}\n.ba-btn.small {\n  min-height: 22px;\n  padding: 2px 6px;\n  font-size: 10px;\n}\n.ba-btn:disabled {\n  opacity: 0.45;\n  cursor: default;\n}\n.ba-chip-row {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 4px;\n}\n.ba-chip {\n  display: inline-flex;\n  align-items: center;\n  gap: 4px;\n  min-height: 22px;\n  padding: 2px 7px;\n  border: 1px solid var(--ba-border-subtle);\n  border-radius: var(--radius-full, 999px);\n  background: var(--ba-elevated);\n  color: var(--ba-text-2);\n  font-family: var(--ba-mono);\n  font-size: 9.5px;\n}\n.ba-chip:hover { border-color: var(--ba-border); color: var(--ba-text); }\n.ba-chip.is-active {\n  border-color: color-mix(in srgb, var(--ba-accent) 55%, var(--ba-border));\n  background: var(--ba-accent-soft);\n  color: var(--ba-accent);\n}\n.ba-toggle {\n  position: relative;\n  flex: 0 0 auto;\n  width: 32px;\n  height: 18px;\n  border-radius: 999px;\n  border: 1px solid var(--ba-border);\n  background: var(--ba-subtle);\n  padding: 0;\n  transition: background 0.15s ease, border-color 0.15s ease;\n}\n.ba-toggle::after {\n  content: "";\n  position: absolute;\n  top: 2px;\n  left: 2px;\n  width: 12px;\n  height: 12px;\n  border-radius: 50%;\n  background: var(--ba-text-2);\n  transition: transform 0.15s var(--ba-ease), background 0.15s ease;\n}\n.ba-toggle.is-on {\n  border-color: color-mix(in srgb, var(--ba-accent) 55%, var(--ba-border));\n  background: color-mix(in srgb, var(--ba-accent) 30%, var(--ba-subtle));\n}\n.ba-toggle.is-on::after {\n  transform: translateX(14px);\n  background: #fff;\n}\n.ba-check {\n  display: inline-flex;\n  align-items: center;\n  gap: 6px;\n  font-size: 11px;\n  color: var(--ba-text-2);\n  cursor: pointer;\n}\n.ba-check input {\n  accent-color: var(--ba-accent);\n  width: 13px;\n  height: 13px;\n  margin: 0;\n}\n.ba-hint {\n  font-size: 10px;\n  color: var(--ba-muted);\n  line-height: 1.45;\n}\n.ba-hint.warn { color: var(--ba-warn); }\n.ba-hint.ok { color: var(--ba-ok); }\n.ba-hint.err { color: var(--ba-danger); }\n.ba-code {\n  font-family: var(--ba-mono);\n  font-size: 10px;\n  color: var(--ba-text-2);\n  background: var(--ba-bg);\n  border: 1px solid var(--ba-border-subtle);\n  border-radius: 5px;\n  padding: 1px 4px;\n  word-break: break-all;\n}\n.ba-divider {\n  height: 1px;\n  background: var(--ba-border-subtle);\n  margin: 12px 0;\n}\n\n/* --- format / flair studio ------------------------------------------------ */\n.ba-code-palette {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 4px;\n  margin-top: 6px;\n}\n.ba-swatch {\n  width: 23px;\n  height: 23px;\n  border-radius: 5px;\n  border: 1px solid rgba(0, 0, 0, 0.45);\n  padding: 0;\n  display: grid;\n  place-items: center;\n  font-family: var(--ba-mono);\n  font-size: 9px;\n  font-weight: 700;\n  color: rgba(0, 0, 0, 0.62);\n}\n.ba-swatch:hover { transform: translateY(-1px); box-shadow: 0 3px 8px rgba(0, 0, 0, 0.35); }\n.ba-format-actions {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 4px;\n  margin-top: 6px;\n}\n.ba-format-actions .ba-btn {\n  min-width: 27px;\n  min-height: 25px;\n  padding: 2px 6px;\n  font-family: var(--ba-mono);\n}\n.ba-flair-grid {\n  display: grid;\n  grid-template-columns: repeat(3, 1fr);\n  gap: 6px;\n  margin-top: 6px;\n}\n.ba-flair-option {\n  position: relative;\n  min-height: 56px;\n  padding: 7px 6px 6px;\n  border: 1px solid var(--ba-border-subtle);\n  border-radius: 9px;\n  background: var(--ba-bg);\n  color: var(--ba-text-2);\n  text-align: left;\n  overflow: hidden;\n  isolation: isolate;\n}\n.ba-flair-option:hover { border-color: var(--ba-border); color: var(--ba-text); }\n.ba-flair-option.is-active {\n  border-color: var(--ba-accent);\n  box-shadow: 0 0 0 2px color-mix(in srgb, var(--ba-accent) 16%, transparent);\n  color: var(--ba-text);\n}\n.ba-flair-option .ba-flair-name {\n  position: relative;\n  z-index: 2;\n  display: block;\n  font-family: var(--ba-mono);\n  font-size: 10px;\n  font-weight: 700;\n}\n.ba-flair-option .ba-flair-desc {\n  position: relative;\n  z-index: 2;\n  display: block;\n  font-size: 8.5px;\n  line-height: 1.25;\n  color: var(--ba-muted);\n  margin-top: 2px;\n}\n.ba-flair-option::before {\n  content: "";\n  position: absolute;\n  inset: 0;\n  z-index: 0;\n  opacity: 0.55;\n  background: var(--ba-flair-tint, linear-gradient(135deg, transparent, rgba(255, 255, 255, 0.05)));\n}\n.ba-flair-option.is-gated .ba-flair-name::after {\n  content: " \xB7 nip05";\n  color: var(--ba-warn);\n  font-size: 8px;\n}\n.ba-preview-wrap {\n  border: 1px solid var(--ba-border-subtle);\n  border-radius: var(--ba-radius-lg);\n  background: var(--ba-bg);\n  padding: 0;\n  overflow: hidden;\n  margin-top: 8px;\n}\n.ba-preview-head {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  padding: 6px 10px;\n  border-bottom: 1px solid var(--ba-border-subtle);\n  font-family: var(--ba-mono);\n  font-size: 9px;\n  color: var(--ba-muted);\n  text-transform: uppercase;\n  letter-spacing: 0.06em;\n}\n.ba-preview-head .ba-preview-build { margin-left: auto; text-transform: none; letter-spacing: 0; }\n.ba-preview-row {\n  position: relative;\n  display: flex;\n  gap: 10px;\n  padding: 10px 12px;\n  min-height: 54px;\n  overflow: hidden;\n  isolation: isolate;\n  background-image: var(--ba-flair-tint);\n}\n.ba-preview-row > .ba-preview-avatar, .ba-preview-row > .ba-preview-main { position: relative; z-index: 1; }\n.ba-preview-avatar {\n  width: 30px;\n  height: 30px;\n  border-radius: 7px;\n  flex: 0 0 auto;\n  object-fit: cover;\n  background: var(--ba-elevated);\n  border: 1px solid var(--ba-border);\n}\n.ba-preview-main { flex: 1; min-width: 0; }\n.ba-preview-line {\n  font-size: 12.5px;\n  line-height: 1.5;\n  word-break: break-word;\n  color: var(--ba-text);\n}\n.ba-preview-line .ba-line-tag {\n  opacity: 0.45;\n  font-size: 0.9em;\n}\n.ba-preview-meta {\n  font-family: var(--ba-mono);\n  font-size: 8.5px;\n  color: var(--ba-muted);\n  margin-bottom: 2px;\n}\n.ba-preview-fx {\n  position: absolute;\n  inset: 0;\n  z-index: 0;\n  pointer-events: none;\n  overflow: hidden;\n}\n.ba-preview-fx i { position: absolute; display: block; font-style: normal; }\n.ba-preview-empty {\n  padding: 10px 12px;\n  color: var(--ba-muted);\n  font-size: 11px;\n}\n\n/* Reuse the page flair keyframes inside the shadow root by redeclaring only the\n   small subset used by the live preview. The page-level effects already work on\n   agnostr rows; the preview uses its own class names to avoid collisions. */\n.ba-preview-row[data-flair="fire"] { --ba-flair-tint: radial-gradient(ellipse at 50% 110%, rgba(255, 94, 25, 0.22), transparent 70%); }\n.ba-preview-row[data-flair="lightning"] { --ba-flair-tint: linear-gradient(110deg, rgba(88, 160, 255, 0.18), transparent 65%); }\n.ba-preview-row[data-flair="stars"] { --ba-flair-tint: radial-gradient(ellipse at 50% 20%, rgba(129, 140, 248, 0.18), transparent 70%); }\n.ba-preview-row[data-flair="rain"] { --ba-flair-tint: linear-gradient(180deg, rgba(56, 189, 248, 0.06), rgba(37, 99, 235, 0.18)); }\n.ba-preview-row[data-flair="plume"] { --ba-flair-tint: linear-gradient(100deg, rgba(167, 139, 250, 0.16), transparent 65%); }\n.ba-preview-row[data-flair="neon"] { --ba-flair-tint: linear-gradient(90deg, rgba(236, 72, 153, 0.15), rgba(34, 211, 238, 0.12)); }\n.ba-preview-row[data-flair="matrix"] { --ba-flair-tint: linear-gradient(180deg, rgba(34, 197, 94, 0.13), transparent); }\n.ba-preview-row[data-flair="sonar"] { --ba-flair-tint: radial-gradient(circle at 20% 50%, rgba(45, 212, 191, 0.16), transparent 55%); }\n.ba-preview-row[data-flair="fireflies"] { --ba-flair-tint: radial-gradient(ellipse at 40% 60%, rgba(250, 204, 21, 0.13), transparent 65%); }\n.ba-preview-row[data-flair="bubbles"] { --ba-flair-tint: linear-gradient(0deg, rgba(34, 211, 238, 0.14), transparent 60%); }\n.ba-preview-row[data-flair="aurora"] { --ba-flair-tint: linear-gradient(110deg, rgba(34, 197, 94, 0.15), rgba(56, 189, 248, 0.1), rgba(168, 85, 247, 0.15)); }\n.ba-preview-row[data-flair="bitcoin"] { --ba-flair-tint: linear-gradient(90deg, rgba(247, 147, 26, 0.15), transparent 65%); }\n.ba-preview-row[data-flair="glitch"] { --ba-flair-tint: linear-gradient(90deg, rgba(239, 68, 68, 0.12), rgba(34, 211, 238, 0.1)); }\n.ba-preview-row[data-flair="sol"] { --ba-flair-tint: radial-gradient(circle at 50% 50%, rgba(250, 204, 21, 0.22), transparent 70%); }\n.ba-preview-row[data-flair="fire"] .ba-preview-fx i {\n  bottom: -6px; left: var(--x); width: 3px; height: 3px; border-radius: 50%;\n  background: #ff9a3c; box-shadow: 0 0 7px #ff5a1f;\n  animation: ba-pv-rise var(--dur, 3.6s) linear infinite; animation-delay: var(--delay, 0s);\n}\n.ba-preview-row[data-flair="stars"] .ba-preview-fx i,\n.ba-preview-row[data-flair="fireflies"] .ba-preview-fx i {\n  top: var(--y); left: var(--x); width: 2px; height: 2px; border-radius: 50%;\n  background: #fef3c7; box-shadow: 0 0 6px #fde68a;\n  animation: ba-pv-twinkle var(--dur, 3.4s) ease-in-out infinite; animation-delay: var(--delay, 0s);\n}\n.ba-preview-row[data-flair="rain"] .ba-preview-fx i {\n  top: -10px; left: var(--x); width: 1px; height: 9px;\n  background: linear-gradient(to bottom, transparent, #7dd3fc);\n  animation: ba-pv-fall var(--dur, 1.5s) linear infinite; animation-delay: var(--delay, 0s);\n}\n.ba-preview-row[data-flair="bubbles"] .ba-preview-fx i {\n  bottom: -6px; left: var(--x); width: 6px; height: 6px; border: 1px solid rgba(165, 243, 252, 0.7); border-radius: 50%;\n  animation: ba-pv-rise var(--dur, 4.2s) linear infinite; animation-delay: var(--delay, 0s);\n}\n.ba-preview-row[data-flair="bitcoin"] .ba-preview-fx i {\n  bottom: -8px; left: var(--x); color: rgba(247, 147, 26, 0.75); font: 600 9px/1 var(--ba-mono);\n  animation: ba-pv-rise var(--dur, 4.8s) linear infinite; animation-delay: var(--delay, 0s);\n}\n.ba-preview-row[data-flair="glitch"] .ba-preview-fx i {\n  left: var(--x); top: var(--y); width: var(--w, 28px); height: 1px;\n  background: linear-gradient(90deg, transparent, rgba(248, 113, 113, 0.8), rgba(34, 211, 238, 0.65), transparent);\n  animation: ba-pv-glitch var(--dur, 3s) steps(1, end) infinite; animation-delay: var(--delay, 0s);\n}\n.ba-preview-row[data-flair="matrix"] .ba-preview-fx i {\n  top: -40%; left: var(--x); color: rgba(74, 222, 128, 0.55);\n  font: 9px/1 var(--ba-mono); writing-mode: vertical-rl; letter-spacing: 1px;\n  animation: ba-pv-matrix var(--dur, 4.2s) linear infinite; animation-delay: var(--delay, 0s);\n}\n.ba-preview-row[data-flair="sonar"] .ba-preview-fx i {\n  top: 50%; left: 18%; width: 14px; height: 14px; margin: -7px 0 0 -7px;\n  border: 1px solid rgba(45, 212, 191, 0.6); border-radius: 50%;\n  animation: ba-pv-sonar var(--dur, 3.6s) ease-out infinite; animation-delay: var(--delay, 0s);\n}\n.ba-preview-row[data-flair="neon"] .ba-preview-fx { border: 1px solid rgba(236, 72, 153, 0.4); animation: ba-pv-neon 3s ease-in-out infinite; }\n.ba-preview-row[data-flair="aurora"] .ba-preview-fx::before {\n  content: ""; position: absolute; inset: -40% -20%;\n  background: conic-gradient(from 140deg at 50% 50%, rgba(34, 197, 94, 0.08), rgba(56, 189, 248, 0.32), rgba(168, 85, 247, 0.24), rgba(34, 197, 94, 0.08));\n  filter: blur(12px); animation: ba-pv-spin 8s linear infinite;\n}\n.ba-preview-row[data-flair="plume"] .ba-preview-fx i {\n  bottom: -10px; left: var(--x); width: 16px; height: 16px; border-radius: 50%;\n  background: rgba(196, 181, 253, 0.2); filter: blur(7px);\n  animation: ba-pv-rise var(--dur, 4.8s) ease-in-out infinite; animation-delay: var(--delay, 0s);\n}\n.ba-preview-row[data-flair="sol"] .ba-preview-fx::before {\n  content: ""; position: absolute; left: 50%; top: 50%; width: 360px; height: 360px; margin: -180px 0 0 -180px;\n  background: repeating-conic-gradient(from 0deg, rgba(250, 204, 21, 0.22) 0deg 4deg, transparent 4deg 12deg);\n  mask-image: radial-gradient(circle, black 0%, transparent 68%); animation: ba-pv-spin 22s linear infinite;\n}\n.ba-preview-row[data-flair="lightning"] .ba-preview-fx::before {\n  content: ""; position: absolute; inset: -20% 10%;\n  background: linear-gradient(115deg, transparent 42%, rgba(147, 197, 253, 0.9) 46%, transparent 48%, transparent 55%, rgba(191, 219, 254, 0.65) 57%, transparent 59%);\n  animation: ba-pv-flash 4s steps(1, end) infinite;\n}\n@keyframes ba-pv-rise {\n  0% { transform: translate3d(0, 0, 0) scale(0.6); opacity: 0; }\n  15% { opacity: 1; }\n  100% { transform: translate3d(var(--drift, 10px), -42px, 0) scale(1.1); opacity: 0; }\n}\n@keyframes ba-pv-twinkle {\n  0%, 100% { opacity: 0.1; transform: scale(0.7); }\n  50% { opacity: 0.95; transform: scale(1.2); }\n}\n@keyframes ba-pv-fall {\n  from { transform: translateY(-8px); opacity: 0; }\n  15% { opacity: 0.7; }\n  to { transform: translateY(54px); opacity: 0; }\n}\n@keyframes ba-pv-glitch {\n  0%, 84%, 100% { opacity: 0; transform: translateX(0); }\n  86% { opacity: 0.8; transform: translateX(6px); }\n  89% { opacity: 0.3; transform: translateX(-4px); }\n  92% { opacity: 0; }\n}\n@keyframes ba-pv-matrix {\n  from { transform: translateY(0); opacity: 0; }\n  12% { opacity: 0.8; }\n  to { transform: translateY(220%); opacity: 0; }\n}\n@keyframes ba-pv-sonar {\n  0% { transform: scale(0.4); opacity: 0; }\n  15% { opacity: 0.8; }\n  100% { transform: scale(9); opacity: 0; }\n}\n@keyframes ba-pv-neon {\n  0%, 100% { opacity: 0.5; }\n  50% { opacity: 1; }\n}\n@keyframes ba-pv-spin { to { transform: rotate(360deg); } }\n@keyframes ba-pv-flash {\n  0%, 82%, 100% { opacity: 0; }\n  84% { opacity: 0.85; }\n  86% { opacity: 0.15; }\n  88% { opacity: 0.7; }\n  91% { opacity: 0; }\n}\n\n/* --- client policy table -------------------------------------------------- */\n.ba-policy {\n  display: grid;\n  gap: 4px;\n  margin-top: 6px;\n}\n.ba-policy-row {\n  display: grid;\n  grid-template-columns: 1fr 110px;\n  gap: 8px;\n  align-items: center;\n  padding: 5px 0;\n  border-bottom: 1px solid var(--ba-border-subtle);\n}\n.ba-policy-row:last-child { border-bottom: none; }\n.ba-policy-label {\n  font-size: 11.5px;\n}\n.ba-policy-label small {\n  display: block;\n  font-family: var(--ba-mono);\n  font-size: 9px;\n  color: var(--ba-muted);\n}\n.ba-policy-row .ba-select {\n  min-height: 26px;\n  padding: 3px 22px 3px 6px;\n  font-size: 10.5px;\n}\n\n/* --- relay inspector ------------------------------------------------------ */\n.ba-relay-controls {\n  display: flex;\n  gap: 6px;\n  margin-bottom: 8px;\n}\n.ba-relay-controls .ba-input { flex: 1; min-width: 0; }\n.ba-relay-list {\n  display: flex;\n  flex-direction: column;\n  gap: 3px;\n  font-family: var(--ba-mono);\n  font-size: 9.5px;\n}\n.ba-log {\n  display: grid;\n  grid-template-columns: 14px 58px 1fr auto;\n  gap: 6px;\n  align-items: center;\n  padding: 4px 6px;\n  border: 1px solid transparent;\n  border-radius: 5px;\n  background: var(--ba-bg);\n  color: var(--ba-text-2);\n  text-align: left;\n  width: 100%;\n  overflow: hidden;\n}\n.ba-log:hover { border-color: var(--ba-border); background: var(--ba-elevated); }\n.ba-log .ba-log-dir { font-weight: 700; }\n.ba-log .ba-log-dir.in { color: var(--ba-ok); }\n.ba-log .ba-log-dir.out { color: var(--ba-accent); }\n.ba-log .ba-log-dir.sys { color: var(--ba-warn); }\n.ba-log .ba-log-dir.blocked { color: var(--ba-danger); }\n.ba-log .ba-log-time { color: var(--ba-muted); font-size: 8.5px; }\n.ba-log .ba-log-summary {\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  color: var(--ba-text-2);\n}\n.ba-log .ba-log-type { color: var(--ba-muted); font-size: 8.5px; text-transform: uppercase; }\n.ba-relay-status {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 5px;\n  margin: 8px 0;\n}\n.ba-relay-pill {\n  font-family: var(--ba-mono);\n  font-size: 8.5px;\n  padding: 2px 6px;\n  border: 1px solid var(--ba-border-subtle);\n  border-radius: 999px;\n  color: var(--ba-muted);\n}\n.ba-relay-pill.ok { color: var(--ba-ok); border-color: color-mix(in srgb, var(--ba-ok) 30%, var(--ba-border)); }\n.ba-relay-pill.err { color: var(--ba-danger); border-color: color-mix(in srgb, var(--ba-danger) 30%, var(--ba-border)); }\n\n/* --- theme ---------------------------------------------------------------- */\n.ba-theme-grid {\n  display: grid;\n  grid-template-columns: 1fr 1fr;\n  gap: 6px;\n}\n.ba-theme-btn {\n  display: flex;\n  flex-direction: column;\n  gap: 5px;\n  padding: 7px;\n  border: 1px solid var(--ba-border-subtle);\n  border-radius: 8px;\n  background: var(--ba-bg);\n  text-align: left;\n}\n.ba-theme-btn.is-active { border-color: var(--ba-accent); box-shadow: 0 0 0 2px color-mix(in srgb, var(--ba-accent) 15%, transparent); }\n.ba-theme-swatch {\n  display: flex;\n  gap: 2px;\n  height: 13px;\n  border-radius: 4px;\n  overflow: hidden;\n}\n.ba-theme-swatch span { flex: 1; }\n.ba-theme-name {\n  font-family: var(--ba-mono);\n  font-size: 9px;\n  color: var(--ba-text-2);\n  text-transform: uppercase;\n  letter-spacing: 0.04em;\n}\n\n/* --- modal ---------------------------------------------------------------- */\n.ba-modal-wrap[hidden] { display: none !important; }\n.ba-modal-wrap {\n  position: fixed;\n  inset: 0;\n  pointer-events: none;\n  z-index: 40;\n}\n.ba-modal-backdrop {\n  position: absolute;\n  inset: 0;\n  background: rgba(2, 3, 6, 0.62);\n  backdrop-filter: blur(3px);\n  opacity: 0;\n  pointer-events: none;\n  transition: opacity 0.18s ease;\n}\n.ba-modal-wrap.is-open { pointer-events: auto; }\n.ba-modal-wrap.is-open .ba-modal-backdrop { opacity: 1; pointer-events: auto; }\n.ba-modal {\n  position: absolute;\n  left: 50%;\n  top: 50%;\n  width: min(900px, calc(100vw - 28px));\n  max-height: min(82vh, 900px);\n  max-height: min(82dvh, 900px);\n  transform: translate(-50%, -48%) scale(0.98);\n  display: flex;\n  flex-direction: column;\n  border: 1px solid var(--ba-border);\n  border-radius: var(--radius-lg, 14px);\n  background: var(--ba-surface);\n  box-shadow: var(--ba-shadow);\n  opacity: 0;\n  pointer-events: none;\n  transition: opacity 0.18s ease, transform 0.2s var(--ba-ease);\n  overflow: hidden;\n}\n.ba-modal-wrap.is-open .ba-modal {\n  opacity: 1;\n  pointer-events: auto;\n  transform: translate(-50%, -50%) scale(1);\n}\n.ba-modal.small { width: min(560px, calc(100vw - 28px)); }\n.ba-modal-head {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  padding: 12px 14px;\n  border-bottom: 1px solid var(--ba-border-subtle);\n  background: var(--ba-surface);\n  flex: 0 0 auto;\n}\n.ba-modal-title {\n  font-family: var(--ba-mono);\n  font-size: 11px;\n  font-weight: 700;\n  letter-spacing: 0.05em;\n  text-transform: uppercase;\n}\n.ba-modal-sub {\n  font-family: var(--ba-mono);\n  font-size: 9px;\n  color: var(--ba-muted);\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n.ba-modal-head .ba-modal-space { flex: 1; }\n.ba-modal-tabs {\n  display: flex;\n  gap: 2px;\n  padding: 0 12px;\n  border-bottom: 1px solid var(--ba-border-subtle);\n  flex: 0 0 auto;\n}\n.ba-modal-tab {\n  padding: 8px 10px;\n  border: none;\n  border-bottom: 2px solid transparent;\n  background: transparent;\n  color: var(--ba-muted);\n  font-family: var(--ba-mono);\n  font-size: 9.5px;\n}\n.ba-modal-tab.is-active { color: var(--ba-accent); border-bottom-color: var(--ba-accent); }\n[data-role="viewer-content"],\n[data-role="review-content"],\n[data-role="action-content"] {\n  display: flex;\n  flex: 1 1 auto;\n  flex-direction: column;\n  min-height: 0;\n  max-height: 100%;\n}\n.ba-modal-body {\n  flex: 1;\n  overflow: auto;\n  overscroll-behavior: contain;\n  -webkit-overflow-scrolling: touch;\n  padding: 12px 14px 18px;\n  min-height: 0;\n}\n.ba-modal-actions {\n  display: flex;\n  gap: 6px;\n  flex-wrap: wrap;\n  padding: 9px 14px;\n  border-top: 1px solid var(--ba-border-subtle);\n  background: var(--ba-bg);\n  flex: 0 0 auto;\n}\n.ba-modal-actions .ba-space { flex: 1; }\n.ba-json {\n  margin: 0;\n  padding: 10px 12px;\n  border: 1px solid var(--ba-border-subtle);\n  border-radius: 8px;\n  background: var(--ba-bg);\n  font-family: var(--ba-mono);\n  font-size: 10.5px;\n  line-height: 1.55;\n  white-space: pre-wrap;\n  word-break: break-word;\n  color: var(--ba-text-2);\n  max-height: 56vh;\n  max-height: 56dvh;\n  overflow: auto;\n}\n.ba-json .j-key { color: #93c5fd; }\n.ba-json .j-str { color: #86efac; }\n.ba-json .j-num { color: #fbbf24; }\n.ba-json .j-bool { color: #f472b6; }\n.ba-json .j-null { color: var(--ba-muted); }\n.ba-tags {\n  width: 100%;\n  border-collapse: collapse;\n  font-family: var(--ba-mono);\n  font-size: 10px;\n}\n.ba-tags th {\n  text-align: left;\n  color: var(--ba-muted);\n  font-weight: 600;\n  padding: 4px 5px;\n  border-bottom: 1px solid var(--ba-border-subtle);\n  font-size: 9px;\n  text-transform: uppercase;\n  letter-spacing: 0.04em;\n}\n.ba-tags td {\n  padding: 4px 5px;\n  border-bottom: 1px solid var(--ba-border-subtle);\n  vertical-align: top;\n  word-break: break-word;\n}\n.ba-tags td:first-child { color: var(--ba-accent); white-space: nowrap; }\n.ba-meta-grid {\n  display: grid;\n  grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));\n  gap: 6px;\n  margin-bottom: 10px;\n}\n.ba-meta-cell {\n  border: 1px solid var(--ba-border-subtle);\n  border-radius: 7px;\n  padding: 6px 8px;\n  background: var(--ba-bg);\n  min-width: 0;\n}\n.ba-meta-k {\n  font-family: var(--ba-mono);\n  font-size: 8px;\n  color: var(--ba-muted);\n  text-transform: uppercase;\n  letter-spacing: 0.05em;\n}\n.ba-meta-v {\n  font-family: var(--ba-mono);\n  font-size: 10px;\n  color: var(--ba-text-2);\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n.ba-warning {\n  border: 1px solid color-mix(in srgb, var(--ba-warn) 35%, var(--ba-border));\n  background: var(--ba-warn-soft, rgba(245, 158, 11, 0.12));\n  color: var(--ba-warn);\n  border-radius: 7px;\n  padding: 8px 10px;\n  font-size: 10.5px;\n  line-height: 1.45;\n  margin-bottom: 10px;\n}\n.ba-warning.ok {\n  border-color: color-mix(in srgb, var(--ba-ok) 35%, var(--ba-border));\n  background: color-mix(in srgb, var(--ba-ok) 10%, transparent);\n  color: var(--ba-ok);\n}\n.ba-warning.err {\n  border-color: color-mix(in srgb, var(--ba-danger) 40%, var(--ba-border));\n  background: var(--status-danger-soft, rgba(239, 68, 68, 0.12));\n  color: var(--ba-danger);\n}\n.ba-review-tag {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  padding: 3px 0;\n  border-bottom: 1px solid var(--ba-border-subtle);\n  font-family: var(--ba-mono);\n  font-size: 9.5px;\n}\n.ba-review-tag .ba-review-name { color: var(--ba-accent); min-width: 62px; }\n.ba-review-tag .ba-review-val {\n  flex: 1;\n  color: var(--ba-text-2);\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n\n/* --- toasts --------------------------------------------------------------- */\n.ba-toasts {\n  position: fixed;\n  right: 16px;\n  bottom: calc(16px + env(safe-area-inset-bottom, 0px));\n  left: auto;\n  transform: none;\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n  z-index: 60;\n  pointer-events: none;\n  width: min(350px, calc(100vw - 32px));\n  max-width: min(350px, calc(100vw - 32px));\n}\n.ba-toast {\n  pointer-events: auto;\n  display: flex;\n  gap: 10px;\n  align-items: flex-start;\n  padding: 10px 12px;\n  border: 1px solid var(--ba-border);\n  border-radius: var(--ba-radius);\n  background: var(--ba-elevated);\n  box-shadow: var(--ba-shadow);\n  animation: ba-toast-in 0.18s var(--ba-ease);\n}\n.ba-toast-icon {\n  display: flex;\n  flex: 0 0 auto;\n  margin-top: 1px;\n  color: var(--ba-accent);\n}\n.ba-toast.success .ba-toast-icon { color: var(--ba-ok); }\n.ba-toast.warning .ba-toast-icon { color: var(--ba-warn); }\n.ba-toast.error .ba-toast-icon { color: var(--ba-danger); }\n.ba-toast-copy { flex: 1; min-width: 0; }\n.ba-toast-title {\n  font-size: 13px;\n  font-weight: 600;\n  color: var(--ba-text);\n}\n.ba-review-content {\n  margin: 0;\n  white-space: pre-wrap;\n  overflow-wrap: anywhere;\n  font-family: var(--ba-mono);\n  font-size: 10px;\n  max-height: 220px;\n  overflow: auto;\n}\n.ba-toast-detail {\n  font-size: 12px;\n  color: var(--ba-text-2);\n  margin-top: 2px;\n  line-height: 1.4;\n}\n@media (max-width: 867px) {\n  .ba-toasts {\n    top: calc(env(safe-area-inset-top, 0px) + 10px);\n    right: 10px;\n    bottom: auto;\n    left: 10px;\n    width: auto;\n    max-width: none;\n    flex-direction: column-reverse;\n  }\n}\n.ba-toast-close {\n  flex: 0 0 auto;\n  width: 24px;\n  height: 24px;\n  margin: -2px -2px 0 auto;\n  border: none;\n  border-radius: 6px;\n  background: transparent;\n  color: var(--ba-muted);\n  cursor: pointer;\n  font: inherit;\n  line-height: 1;\n  padding: 0;\n}\n.ba-toast-close:hover { color: var(--ba-text); }\n@keyframes ba-toast-in {\n  from { opacity: 0; transform: translateY(8px); }\n  to { opacity: 1; transform: translateY(0); }\n}\n\n/* --- misc ----------------------------------------------------------------- */\n.ba-kv {\n  display: flex;\n  justify-content: space-between;\n  gap: 8px;\n  padding: 3px 0;\n  font-family: var(--ba-mono);\n  font-size: 9.5px;\n  border-bottom: 1px solid var(--ba-border-subtle);\n}\n.ba-kv:last-child { border-bottom: none; }\n.ba-kv span:first-child { color: var(--ba-muted); }\n.ba-kv span:last-child { color: var(--ba-text-2); text-align: right; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }\n.ba-scrollbox {\n  max-height: 220px;\n  overflow: auto;\n  border: 1px solid var(--ba-border-subtle);\n  border-radius: 8px;\n  padding: 6px 8px;\n  background: var(--ba-bg);\n}\n.ba-empty {\n  padding: 18px 10px;\n  text-align: center;\n  color: var(--ba-muted);\n  font-size: 11px;\n}\n.ba-linkbtn {\n  border: none;\n  background: transparent;\n  color: var(--ba-accent);\n  font-size: 10px;\n  padding: 0;\n}\n.ba-linkbtn:hover { text-decoration: underline; }\n.ba-visually-hidden {\n  position: absolute !important;\n  width: 1px;\n  height: 1px;\n  padding: 0;\n  margin: -1px;\n  overflow: hidden;\n  clip: rect(0, 0, 0, 0);\n  white-space: nowrap;\n  border: 0;\n}\n@media (prefers-reduced-motion: reduce) {\n  .ba-preview-fx { display: none; }\n  .ba-panel { transition: none; }\n}\n\n/* --- richer studio preview ------------------------------------------------ */\n.ba-preview-row {\n  padding: 14px 13px;\n  min-height: 78px;\n  gap: 11px;\n}\n.ba-preview-avatar {\n  width: 32px;\n  height: 32px;\n}\n.ba-preview-line {\n  font-size: 13.5px;\n}\n.ba-preview-native,\n.ba-preview-template {\n  display: flex;\n  align-items: flex-start;\n  gap: 9px;\n  padding: 7px 12px;\n  border-top: 1px solid var(--ba-border-subtle);\n  font-family: var(--ba-mono);\n  font-size: 9.5px;\n  line-height: 1.45;\n  color: var(--ba-muted);\n  word-break: break-word;\n}\n.ba-preview-native-label,\n.ba-preview-template span:first-child {\n  flex: 0 0 auto;\n  min-width: 48px;\n  color: var(--ba-accent);\n  text-transform: uppercase;\n  letter-spacing: 0.06em;\n  font-size: 8px;\n  padding-top: 1px;\n}\n.ba-preview-native > span:last-child {\n  color: var(--ba-text-2);\n}\n.ba-preview-template code {\n  font-family: inherit;\n  color: var(--ba-muted);\n}\n\n.ba-range {\n  width: 100%;\n  accent-color: var(--ba-accent);\n  margin: 4px 0 0;\n}\n\n:host {\n  --bg: var(--ba-bg);\n  --fg: var(--ba-text);\n  --scanline-color: color-mix(in srgb, var(--ba-text) 7%, transparent);\n}\n\n/* Shared Glub preview (settings + event viewer). */\n:host {\n  --bg: var(--ba-bg);\n  --fg: var(--ba-text);\n  --accent: var(--ba-accent);\n  --bg-canvas: var(--ba-bg);\n  --bg-elevated: var(--ba-elevated);\n  --border-subtle: var(--ba-border-subtle);\n  --border-default: var(--ba-border);\n  --text-primary: var(--ba-text);\n  --text-secondary: var(--ba-text-2);\n  --text-muted: var(--ba-muted);\n  --scanline-color: color-mix(in srgb, var(--ba-text) 7%, transparent);\n}\n.ba-set-preview {\n  border: 1px solid var(--ba-border-subtle);\n  border-radius: 8px;\n  background: var(--ba-bg);\n  overflow: hidden;\n}\n.ba-set-preview-row {\n  position: relative;\n  display: flex;\n  gap: 10px;\n  align-items: flex-start;\n  min-height: 64px;\n  padding: 14px;\n  overflow: hidden;\n  isolation: isolate;\n  background: var(--ba-bg);\n}\n.ba-set-preview-row > .ba-set-preview-avatar,\n.ba-set-preview-row > .ba-set-preview-main {\n  position: relative;\n  z-index: 1;\n}\n.ba-set-preview-avatar {\n  flex: 0 0 auto;\n  width: 30px;\n  height: 30px;\n  border-radius: 7px;\n  object-fit: cover;\n  background: var(--ba-elevated);\n  border: 1px solid var(--ba-border-subtle);\n}\n.ba-set-preview-main { min-width: 0; flex: 1; }\n.ba-set-preview-meta {\n  display: flex;\n  align-items: baseline;\n  gap: 6px;\n  font: 10px/1.3 var(--ba-mono);\n  color: var(--ba-muted);\n  margin-bottom: 3px;\n}\n.ba-set-preview-name { color: var(--ba-text); font-weight: 600; }\n.ba-set-preview-tag { color: var(--ba-muted); }\n.ba-set-preview-line {\n  display: block;\n  font-size: 13px;\n  line-height: 1.5;\n  color: var(--ba-text);\n  word-break: break-word;\n}\n\n/* Keep the viewer action buttons visibly outlined. */\n[data-modal="viewer"] .ba-modal-actions .ba-btn {\n  border: 1px solid color-mix(in srgb, currentColor 22%, transparent) !important;\n  background: color-mix(in srgb, currentColor 6%, transparent) !important;\n}\n[data-modal="viewer"] .ba-modal-actions .ba-btn:hover {\n  border-color: color-mix(in srgb, currentColor 34%, transparent) !important;\n  background: color-mix(in srgb, currentColor 10%, transparent) !important;\n}\n\n/* Native-aligned modal chrome for the event viewer and custom action dialog. */\n:is([data-modal="viewer"], [data-modal="action"]) .ba-modal {\n  width: min(760px, calc(100vw - 32px));\n  border: 1px solid color-mix(in srgb, currentColor 15%, transparent);\n  border-radius: 16px;\n  background: var(--ba-surface);\n  box-shadow: 0 18px 50px rgba(0, 0, 0, 0.45);\n}\n[data-modal="action"] .ba-modal {\n  width: min(520px, calc(100vw - 32px));\n}\n:is([data-modal="viewer"], [data-modal="action"]) .ba-modal-head {\n  padding: 16px 18px;\n  border-bottom: 1px solid color-mix(in srgb, currentColor 10%, transparent);\n}\n:is([data-modal="viewer"], [data-modal="action"]) .ba-modal-title {\n  font-family: inherit;\n  font-size: 15px;\n  font-weight: 700;\n  letter-spacing: 0;\n  text-transform: none;\n  color: var(--ba-text);\n}\n:is([data-modal="viewer"], [data-modal="action"]) .ba-modal-sub {\n  font-family: inherit;\n  font-size: 10.5px;\n  color: var(--ba-muted);\n}\n:is([data-modal="viewer"], [data-modal="action"]) .ba-modal-body {\n  padding: 16px 18px 20px;\n}\n:is([data-modal="viewer"], [data-modal="action"]) .ba-modal-actions {\n  padding: 12px 18px;\n  background: var(--ba-surface);\n  border-top: 1px solid color-mix(in srgb, currentColor 10%, transparent);\n}\n:is([data-modal="viewer"], [data-modal="action"]) .ba-modal-actions .ba-btn {\n  min-height: 32px;\n  padding: 6px 12px;\n  border: 1px solid color-mix(in srgb, currentColor 22%, transparent) !important;\n  border-radius: 8px;\n  background: color-mix(in srgb, currentColor 6%, transparent) !important;\n  color: var(--ba-text);\n  font-size: 11.5px;\n  font-weight: 600;\n}\n:is([data-modal="viewer"], [data-modal="action"]) .ba-modal-actions .ba-btn:hover {\n  border-color: color-mix(in srgb, currentColor 34%, transparent) !important;\n  background: color-mix(in srgb, currentColor 10%, transparent) !important;\n}\n:is([data-modal="viewer"], [data-modal="action"]) .ba-modal-actions .ba-btn.primary {\n  border-color: var(--ba-accent, #3b82f6) !important;\n  background: var(--ba-accent, #3b82f6) !important;\n  color: #fff;\n}\n:is([data-modal="viewer"], [data-modal="action"]) .ba-modal-actions .ba-btn.primary:hover {\n  border-color: var(--ba-accent-hover, #60a5fa) !important;\n  background: var(--ba-accent-hover, #60a5fa) !important;\n}\n:is([data-modal="viewer"], [data-modal="action"]) .ba-input,\n:is([data-modal="viewer"], [data-modal="action"]) .ba-textarea {\n  border: 1px solid color-mix(in srgb, currentColor 18%, transparent);\n  border-radius: 8px;\n  background: color-mix(in srgb, currentColor 5%, transparent);\n  color: var(--ba-text);\n  font-family: inherit;\n  font-size: 12px;\n  padding: 8px 10px;\n}\n:is([data-modal="viewer"], [data-modal="action"]) .ba-label {\n  font-family: inherit;\n  font-size: 11px;\n  font-weight: 600;\n  letter-spacing: 0;\n  text-transform: none;\n  color: var(--ba-text-2);\n}\n:is([data-modal="viewer"], [data-modal="action"]) .ba-card-title {\n  font-family: inherit;\n  font-size: 11px;\n  font-weight: 600;\n  letter-spacing: 0;\n  text-transform: none;\n  color: var(--ba-text-2);\n}\n\n[data-modal="viewer"] .ba-modal-tabs {\n  display: flex;\n  gap: 3px;\n  padding: 8px 14px;\n  border-bottom: 1px solid color-mix(in srgb, currentColor 10%, transparent);\n  background: var(--ba-surface);\n}\n[data-modal="viewer"] .ba-modal-tab {\n  padding: 6px 12px;\n  border: 1px solid transparent;\n  border-radius: 999px;\n  background: transparent;\n  color: var(--ba-text-2);\n  font-family: inherit;\n  font-size: 11.5px;\n  font-weight: 600;\n}\n[data-modal="viewer"] .ba-modal-tab:hover {\n  background: color-mix(in srgb, currentColor 7%, transparent);\n  color: var(--ba-text);\n}\n[data-modal="viewer"] .ba-modal-tab.is-active {\n  border-color: color-mix(in srgb, var(--ba-accent, #3b82f6) 42%, transparent);\n  background: color-mix(in srgb, var(--ba-accent, #3b82f6) 16%, transparent);\n  color: var(--ba-accent, #3b82f6);\n}\n[data-modal="viewer"] .ba-meta-cell {\n  border: 1px solid color-mix(in srgb, currentColor 12%, transparent);\n  border-radius: 8px;\n  background: color-mix(in srgb, currentColor 3%, transparent);\n  padding: 8px 10px;\n}\n[data-modal="viewer"] .ba-meta-k {\n  font-family: inherit;\n  font-size: 9px;\n  letter-spacing: 0.05em;\n}\n[data-modal="viewer"] .ba-meta-v {\n  font-family: var(--ba-mono);\n  font-size: 11px;\n  color: var(--ba-text);\n}\n[data-modal="viewer"] .ba-json {\n  border-radius: 10px;\n  border-color: color-mix(in srgb, currentColor 12%, transparent);\n  background: color-mix(in srgb, currentColor 3%, transparent);\n  font-size: 11px;\n  line-height: 1.6;\n  max-height: 58vh;\n  max-height: 58dvh;\n}\n[data-modal="action"] .ba-card {\n  border-color: color-mix(in srgb, currentColor 12%, transparent);\n  background: color-mix(in srgb, currentColor 4%, transparent);\n}\n[data-modal="action"] .ba-hint {\n  font-size: 10.5px;\n}\n';

  // src/ui/page.css
  var page_default = `/* Page-level styles. Injected into agnostr.com (not the shadow UI). */

/* --- rail button --------------------------------------------------------- */
.ba-rail-slot .ba-rail-tile {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--text-secondary);
}
.ba-rail-slot .ba-rail-tile:hover {
  color: var(--text-primary);
}
.ba-rail-slot .ba-rail-tile.ba-active {
  color: var(--accent);
}
.ba-rail-glyph {
  width: 17px;
  height: 17px;
  display: block;
}

/* --- row action button --------------------------------------------------- */
.ag-msg-act-btn.ba-json-btn {
  font-family: var(--font-mono, ui-monospace, monospace);
  font-size: 10px;
  font-weight: 700;
  letter-spacing: -0.04em;
  padding: 0 3px;
  line-height: 1;
}
.ag-msg-actions .ba-json-btn + .ba-json-btn {
  display: none;
}

.ba-row-json-btn {
  position: absolute;
  top: 3px;
  right: 10px;
  z-index: 7;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 24px;
  height: 24px;
  padding: 0;
  border: 1px solid var(--border-default);
  border-radius: var(--radius-sm, 8px);
  background: var(--bg-elevated);
  color: var(--text-secondary);
  font: 700 10px/1 var(--font-mono, ui-monospace, monospace);
  cursor: pointer;
  opacity: 0;
  pointer-events: none;
  transform: translateY(2px);
  transition: opacity var(--dur-fast, 0.11s) ease, transform var(--dur-fast, 0.11s) ease;
}
.ag-msg-row:hover .ba-row-json-btn,
.ag-msg-row:focus-within .ba-row-json-btn,
.ba-row-json-btn:focus-visible {
  opacity: 1;
  pointer-events: auto;
  transform: translateY(0);
}
.ba-row-json-btn:hover {
  border-color: var(--border-accent);
  color: var(--accent);
}

/* --- glub badge ---------------------------------------------------------- */
.ba-glub-chip {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  height: 16px;
  padding: 0 5px;
  border: 1px solid color-mix(in srgb, var(--accent) 38%, var(--border-default));
  border-radius: var(--radius-full, 9999px);
  background: color-mix(in srgb, var(--accent) 8%, transparent);
  color: var(--accent);
  font: 600 9px/1 var(--font-mono, ui-monospace, monospace);
  text-transform: lowercase;
  letter-spacing: 0.02em;
  cursor: pointer;
  vertical-align: middle;
}
.ba-glub-chip:hover {
  background: var(--accent-soft);
}
.ba-glub-chip.is-stale {
  border-color: color-mix(in srgb, var(--status-warn) 45%, var(--border-default));
  background: var(--status-warn-soft);
  color: var(--status-warn);
}
.ba-glub-chip .ba-glub-spark {
  font-size: 8px;
  transform: translateY(-0.5px);
}

/* --- &-code rich rendering ------------------------------------------------ */
.ba-fmt-obf {
  animation: ba-obf-flicker 1.1s steps(2, end) infinite;
}
.fmtObf[data-obf-static="1"] { animation: none !important; }
@keyframes ba-obf-flicker {
  0%, 100% { opacity: 1; }
  48% { opacity: 1; }
  50% { opacity: 0.45; }
  52% { opacity: 1; }
}
.ba-rich-processed {
  --ba-rich: 1;
}

/* Better Agnostr users get a small plaque next to their name. Client
   identification borders are owned by Agnostr itself. */
.ba-better-name::after {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  height: 15px;
  padding: 0 4px;
  margin-left: 4px;
  border: 1px solid var(--border-subtle);
  border-radius: 4px;
  background: var(--bg-elevated);
  color: var(--text-secondary);
  font: 700 8.5px/1 var(--font-mono);
  letter-spacing: 0.04em;
  vertical-align: middle;
  text-decoration: none;
  pointer-events: none;
  max-width: 14ch;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  -webkit-text-fill-color: currentColor !important;
  text-shadow: none !important;
  animation: none !important;
  background-clip: border-box !important;
  -webkit-background-clip: border-box !important;
}
.ba-better-name::after {
  content: "BA";
  border-color: color-mix(in srgb, var(--accent) 42%, var(--border-default));
  background: var(--accent-soft);
  color: var(--accent);
}
.ag-msg-head .ba-better-name::after { transform: translateY(-1px); }
.ag-peer-modal-name.ba-better-name::after { margin-left: 6px; }

html[data-ba-theme] .ag-set-theme-grid:not(.ba-glub-theme-grid) .ag-set-theme-check {
  display: none !important;
}

.ag-peer-client-pill.ba-client-pill-unknown {
  color: var(--text-secondary);
  background: var(--bg-elevated);
  border-color: var(--border-subtle);
}
.ag-peer-client-pill.ba-client-pill-ba {
  color: var(--accent);
  background: var(--accent-soft);
  border-color: color-mix(in srgb, var(--accent) 40%, var(--border-default));
}

/* --- line template colours inside Agnostr rows --------------------------- */
.ag-msg-row .ag-msg-author.ba-line-name-color:not(.fmtRainbow) {
  color: var(--ba-line-name-color) !important;
}
.ag-msg-author.ba-line-name-bold { font-weight: 700 !important; }
.ag-msg-author.ba-line-name-italic { font-style: italic !important; }
.ag-msg-author.ba-line-name-deco { text-decoration: var(--ba-line-name-deco) !important; }
.ag-msg-row .ag-msg-rich.ba-line-msg-color:not(.fmtRainbow) {
  color: var(--ba-line-msg-color) !important;
}
.ag-msg-rich.ba-line-msg-bold { font-weight: 700 !important; }
.ag-msg-rich.ba-line-msg-italic { font-style: italic !important; }
.ag-msg-rich.ba-line-msg-deco { text-decoration: var(--ba-line-msg-deco) !important; }


/* --- flair --------------------------------------------------------------- */
.ag-msg-row.ba-flair {
  isolation: isolate;
}
.ag-msg-row.ba-flair:not(.ba-flair-static) {
  background-image: var(--ba-flair-tint);
}
.ba-flair-fx {
  position: absolute;
  inset: 0;
  z-index: 0;
  pointer-events: none;
  overflow: hidden;
  opacity: 0.85;
  border-radius: inherit;
}
.ag-msg-row.ba-flair > .ag-msg-gutter,
.ag-msg-row.ba-flair > .ag-msg-content {
  position: relative;
  z-index: 1;
}
.ba-flair-fx i {
  position: absolute;
  display: block;
  font-style: normal;
  pointer-events: none;
}
.ba-flair-static .ba-flair-fx {
  display: none;
}

/* fire */
.ba-flair-fire { --ba-flair-tint: radial-gradient(ellipse at 50% 110%, rgba(255, 94, 25, 0.18), transparent 70%); }
.ba-flair-fire .ba-flair-fx i {
  bottom: -8px;
  left: var(--x);
  width: var(--s, 3px);
  height: var(--s, 3px);
  border-radius: 50%;
  background: #ff9a3c;
  box-shadow: 0 0 7px #ff5a1f;
  animation: ba-fire-rise var(--dur, 3.8s) linear infinite;
  animation-delay: var(--delay, 0s);
}
@keyframes ba-fire-rise {
  0% { transform: translate3d(0, 0, 0) scale(0.7); opacity: 0; }
  15% { opacity: 1; }
  70% { opacity: 0.8; }
  100% { transform: translate3d(var(--drift, 10px), -46px, 0) scale(1.2); opacity: 0; }
}

/* lightning */
.ba-flair-lightning { --ba-flair-tint: linear-gradient(110deg, rgba(88, 160, 255, 0.16), transparent 58%, rgba(160, 120, 255, 0.12)); }
.ba-flair-lightning .ba-flair-fx::before,
.ba-flair-lightning .ba-flair-fx::after {
  content: "";
  position: absolute;
  inset: -20% 10%;
  background: linear-gradient(115deg, transparent 42%, rgba(147, 197, 253, 0.9) 46%, transparent 48%, transparent 55%, rgba(191, 219, 254, 0.65) 57%, transparent 59%);
  opacity: 0;
  animation: ba-lightning 4.6s steps(1, end) infinite;
}
.ba-flair-lightning .ba-flair-fx::after {
  inset: -20% 30% 10% -20%;
  animation-delay: 2.1s;
  transform: scaleX(-1);
}
@keyframes ba-lightning {
  0%, 82%, 100% { opacity: 0; }
  84% { opacity: 0.85; }
  86% { opacity: 0.15; }
  88% { opacity: 0.7; }
  91% { opacity: 0; }
}

/* stars */
.ba-flair-stars { --ba-flair-tint: radial-gradient(ellipse at 50% 20%, rgba(129, 140, 248, 0.15), transparent 70%); }
.ba-flair-stars .ba-flair-fx i {
  top: var(--y);
  left: var(--x);
  width: var(--s, 2px);
  height: var(--s, 2px);
  border-radius: 50%;
  background: #dbeafe;
  box-shadow: 0 0 5px #93c5fd;
  animation: ba-twinkle var(--dur, 4s) ease-in-out infinite;
  animation-delay: var(--delay, 0s);
}
@keyframes ba-twinkle {
  0%, 100% { opacity: 0.1; transform: scale(0.7); }
  45% { opacity: 0.95; transform: scale(1.15); }
}

/* rain */
.ba-flair-rain { --ba-flair-tint: linear-gradient(180deg, rgba(56, 189, 248, 0.05), rgba(37, 99, 235, 0.14)); }
.ba-flair-rain .ba-flair-fx i {
  top: -12px;
  left: var(--x);
  width: 1px;
  height: var(--s, 10px);
  background: linear-gradient(to bottom, transparent, #7dd3fc);
  opacity: 0.5;
  animation: ba-rain-fall var(--dur, 1.7s) linear infinite;
  animation-delay: var(--delay, 0s);
}
@keyframes ba-rain-fall {
  from { transform: translate3d(0, -10px, 0); opacity: 0; }
  12% { opacity: 0.6; }
  to { transform: translate3d(var(--drift, -6px), 70px, 0); opacity: 0; }
}

/* plume */
.ba-flair-plume { --ba-flair-tint: linear-gradient(100deg, rgba(167, 139, 250, 0.14), transparent 60%, rgba(148, 163, 184, 0.12)); }
.ba-flair-plume .ba-flair-fx i {
  bottom: -12px;
  left: var(--x);
  width: var(--s, 18px);
  height: var(--s, 18px);
  border-radius: 50%;
  background: rgba(196, 181, 253, 0.18);
  filter: blur(7px);
  animation: ba-plume-rise var(--dur, 5.2s) ease-in-out infinite;
  animation-delay: var(--delay, 0s);
}
@keyframes ba-plume-rise {
  0% { transform: translate3d(0, 10px, 0) scale(0.5); opacity: 0; }
  25% { opacity: 0.7; }
  100% { transform: translate3d(var(--drift, 18px), -55px, 0) scale(1.5); opacity: 0; }
}

/* neon */
.ba-flair-neon { --ba-flair-tint: linear-gradient(90deg, rgba(236, 72, 153, 0.12), rgba(34, 211, 238, 0.1)); }
.ba-flair-neon .ba-flair-fx {
  border: 1px solid rgba(236, 72, 153, 0.35);
  box-shadow: inset 0 0 18px rgba(236, 72, 153, 0.12), inset 0 0 28px rgba(34, 211, 238, 0.08);
  animation: ba-neon-pulse 3.6s ease-in-out infinite;
}
@keyframes ba-neon-pulse {
  0%, 100% { opacity: 0.55; }
  50% { opacity: 1; }
}

/* matrix */
.ba-flair-matrix { --ba-flair-tint: linear-gradient(180deg, rgba(34, 197, 94, 0.1), transparent); }
.ba-flair-matrix .ba-flair-fx i {
  top: -100%;
  left: var(--x);
  color: rgba(74, 222, 128, 0.5);
  font: 10px/1 var(--font-mono, ui-monospace, monospace);
  writing-mode: vertical-rl;
  text-orientation: upright;
  letter-spacing: 1px;
  text-shadow: 0 0 4px rgba(34, 197, 94, 0.5);
  animation: ba-matrix-fall var(--dur, 4.5s) linear infinite;
  animation-delay: var(--delay, 0s);
}
@keyframes ba-matrix-fall {
  from { transform: translateY(0); opacity: 0; }
  10% { opacity: 0.8; }
  to { transform: translateY(260%); opacity: 0; }
}

/* sonar */
.ba-flair-sonar { --ba-flair-tint: radial-gradient(circle at 20% 50%, rgba(45, 212, 191, 0.13), transparent 50%); }
.ba-flair-sonar .ba-flair-fx i {
  top: 50%;
  left: 14%;
  width: 18px;
  height: 18px;
  margin: -9px 0 0 -9px;
  border: 1px solid rgba(45, 212, 191, 0.55);
  border-radius: 50%;
  animation: ba-sonar-ring var(--dur, 4s) ease-out infinite;
  animation-delay: var(--delay, 0s);
}
@keyframes ba-sonar-ring {
  0% { transform: scale(0.4); opacity: 0; }
  15% { opacity: 0.8; }
  100% { transform: scale(11); opacity: 0; }
}

/* fireflies */
.ba-flair-fireflies { --ba-flair-tint: radial-gradient(ellipse at 40% 60%, rgba(250, 204, 21, 0.1), transparent 65%); }
.ba-flair-fireflies .ba-flair-fx i {
  top: var(--y);
  left: var(--x);
  width: var(--s, 3px);
  height: var(--s, 3px);
  border-radius: 50%;
  background: #fde68a;
  box-shadow: 0 0 8px 2px rgba(253, 230, 138, 0.55);
  animation: ba-firefly-drift var(--dur, 6s) ease-in-out infinite;
  animation-delay: var(--delay, 0s);
}
@keyframes ba-firefly-drift {
  0%, 100% { transform: translate3d(0, 0, 0); opacity: 0.15; }
  30% { opacity: 0.9; }
  50% { transform: translate3d(var(--drift, 18px), -12px, 0); opacity: 0.65; }
  75% { opacity: 0.25; }
}

/* bubbles */
.ba-flair-bubbles { --ba-flair-tint: linear-gradient(0deg, rgba(34, 211, 238, 0.12), transparent 60%); }
.ba-flair-bubbles .ba-flair-fx i {
  bottom: -8px;
  left: var(--x);
  width: var(--s, 6px);
  height: var(--s, 6px);
  border: 1px solid rgba(165, 243, 252, 0.65);
  border-radius: 50%;
  box-shadow: inset 0 0 3px rgba(255, 255, 255, 0.35);
  animation: ba-bubble-rise var(--dur, 4.8s) linear infinite;
  animation-delay: var(--delay, 0s);
}
@keyframes ba-bubble-rise {
  0% { transform: translate3d(0, 0, 0) scale(0.5); opacity: 0; }
  12% { opacity: 0.8; }
  100% { transform: translate3d(var(--drift, 8px), -58px, 0) scale(1.1); opacity: 0; }
}

/* aurora */
.ba-flair-aurora { --ba-flair-tint: linear-gradient(110deg, rgba(34, 197, 94, 0.13), rgba(56, 189, 248, 0.08), rgba(168, 85, 247, 0.12)); }
.ba-flair-aurora .ba-flair-fx::before {
  content: "";
  position: absolute;
  inset: -40% -20%;
  background: conic-gradient(from 140deg at 50% 50%, rgba(34, 197, 94, 0.06), rgba(56, 189, 248, 0.28), rgba(168, 85, 247, 0.2), rgba(34, 197, 94, 0.06));
  filter: blur(14px);
  animation: ba-aurora-flow 9s linear infinite;
}
@keyframes ba-aurora-flow {
  to { transform: rotate(360deg); }
}

/* bitcoin */
.ba-flair-bitcoin { --ba-flair-tint: linear-gradient(90deg, rgba(247, 147, 26, 0.12), transparent 60%, rgba(247, 147, 26, 0.08)); }
.ba-flair-bitcoin .ba-flair-fx i {
  bottom: -10px;
  left: var(--x);
  color: rgba(247, 147, 26, 0.65);
  font: 600 var(--s, 9px)/1 var(--font-mono, ui-monospace, monospace);
  animation: ba-bitcoin-rise var(--dur, 5.5s) linear infinite;
  animation-delay: var(--delay, 0s);
}
@keyframes ba-bitcoin-rise {
  0% { transform: translate3d(0, 0, 0) rotate(0deg); opacity: 0; }
  15% { opacity: 0.8; }
  100% { transform: translate3d(var(--drift, 12px), -52px, 0) rotate(22deg); opacity: 0; }
}

/* glitch */
.ba-flair-glitch { --ba-flair-tint: linear-gradient(90deg, rgba(239, 68, 68, 0.1), rgba(34, 211, 238, 0.08)); }
.ba-flair-glitch .ba-flair-fx i {
  left: var(--x);
  top: var(--y);
  width: var(--w, 30px);
  height: 1px;
  background: linear-gradient(90deg, transparent, rgba(248, 113, 113, 0.75), rgba(34, 211, 238, 0.6), transparent);
  animation: ba-glitch-tear var(--dur, 3.2s) steps(1, end) infinite;
  animation-delay: var(--delay, 0s);
}
@keyframes ba-glitch-tear {
  0%, 86%, 100% { transform: translateX(0); opacity: 0; }
  88% { transform: translateX(8px); opacity: 0.85; }
  90% { transform: translateX(-6px); opacity: 0.4; }
  92% { opacity: 0; }
}

/* sol */
.ba-flair-sol { --ba-flair-tint: radial-gradient(circle at 50% 50%, rgba(250, 204, 21, 0.18), transparent 70%); }
.ba-flair-sol .ba-flair-fx::before {
  content: "";
  position: absolute;
  left: 50%;
  top: 50%;
  width: 440px;
  height: 440px;
  margin: -220px 0 0 -220px;
  background: repeating-conic-gradient(from 0deg, rgba(250, 204, 21, 0.18) 0deg 4deg, transparent 4deg 12deg);
  mask-image: radial-gradient(circle, black 0%, transparent 68%);
  animation: ba-sol-rotate 26s linear infinite;
}
@keyframes ba-sol-rotate {
  to { transform: rotate(360deg); }
}

@media (prefers-reduced-motion: reduce) {
  .ba-flair-fx { display: none; }
  .ba-fmt-obf { animation: none; }
}

/* --- composer formatting toolbar ----------------------------------------- */
.ba-composer-head {
  display: flex;
  align-items: center;
  gap: 5px;
  margin: 0 10px 3px;
}
.ba-composer-toggle {
  flex: 0 0 auto;
  width: 24px;
  height: 21px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border: 1px solid var(--border-subtle);
  border-radius: 6px;
  background: color-mix(in srgb, var(--bg-elevated) 82%, transparent);
  color: var(--text-muted);
  font: 600 10px/1 var(--font-mono, ui-monospace, monospace);
  cursor: pointer;
}
.ba-composer-toggle:hover {
  color: var(--text-primary);
  border-color: var(--border-default);
}
.ba-composer-head .ba-composer-bar {
  flex: 1 1 auto;
  min-width: 0;
  margin: 0;
  padding: 3px 6px;
}
.ba-composer-bar[hidden] { display: none; }
.ba-composer-bar {
  display: flex;
  align-items: center;
  gap: 3px;
  padding: 3px 6px;
  margin: 0 10px 3px;
  border: 1px solid var(--border-subtle);
  border-radius: var(--radius-md, 10px);
  background: color-mix(in srgb, var(--bg-elevated) 82%, transparent);
  font-family: var(--font-mono, ui-monospace, monospace);
  font-size: 10px;
  color: var(--text-muted);
  user-select: none;
  position: relative;
  z-index: 3;
}
.ba-composer-bar button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 22px;
  height: 20px;
  padding: 0 4px;
  border: 1px solid transparent;
  border-radius: 5px;
  background: transparent;
  color: var(--text-secondary);
  font: inherit;
  cursor: pointer;
}
.ba-composer-bar button:hover {
  border-color: var(--border-default);
  background: var(--bg-hover);
  color: var(--text-primary);
}
.ba-composer-bar button.ba-code-active {
  border-color: var(--border-accent);
  color: var(--accent);
}
.ba-composer-bar .ba-bar-spacer { flex: 1; }
.ba-composer-bar .ba-bar-label {
  font-size: 9px;
  letter-spacing: 0.05em;
  text-transform: uppercase;
  color: var(--text-muted);
}
.ba-composer-bar .ba-color-toggle {
  width: 18px;
  min-width: 18px;
  height: 18px;
  border-radius: 50%;
  background: linear-gradient(135deg, #ff6a6a, #ffe45e, #55ff77, #55ffff, #ff77ff);
  border: 1px solid var(--border-strong);
  padding: 0;
}
.ba-color-popover {
  position: absolute;
  left: 6px;
  bottom: calc(100% + 6px);
  z-index: 20;
  display: grid;
  grid-template-columns: repeat(8, 22px);
  gap: 4px;
  padding: 8px;
  border: 1px solid var(--border-default);
  border-radius: var(--radius-md, 10px);
  background: var(--bg-elevated);
  box-shadow: var(--shadow-lg);
}
.ba-color-popover[hidden] {
  display: none;
}
.ba-color-popover button {
  width: 22px;
  min-width: 22px;
  height: 22px;
  padding: 0;
  border-radius: 5px;
  border: 1px solid rgba(0, 0, 0, 0.4);
  font-size: 9px;
  font-weight: 700;
}
.ba-color-popover button:hover {
  transform: scale(1.12);
}
.ba-bar-hint {
  font-size: 9px;
  color: var(--text-muted);
  white-space: nowrap;
}

/* --- hide calls ----------------------------------------------------------- */
html.ba-calls-hidden .ag-header-call-btn,
html.ba-calls-hidden .ag-incoming-call,
html.ba-calls-hidden .ag-incoming-fullscreen,
html.ba-calls-hidden .ag-incoming-ring,
html.ba-calls-hidden .ag-geo-call-banner,
html.ba-calls-hidden .ag-geo-call-join-btn,
html.ba-calls-hidden .ag-rail-voice-dot,
html.ba-calls-hidden .ag-row-call-pill,
html.ba-calls-hidden .ag-call-stage,
html.ba-calls-hidden .ag-call-floating-bar,
html.ba-calls-hidden .ag-call-ringback-banner,
html.ba-calls-hidden .ag-call-ringback-dock,
html.ba-calls-hidden .ag-call-rec-pill,
html.ba-calls-hidden .ag-call-audio-list,
html.ba-calls-hidden .ag-call-audio-strip,
html.ba-calls-hidden .ag-call-audio-wrap,
html.ba-calls-hidden .ag-call-controls,
html.ba-calls-hidden .ag-call-pinned-pill,
html.ba-calls-hidden .ag-call-modal-backdrop,
html.ba-calls-hidden .ag-call-modal-frame,
html.ba-calls-hidden .ag-srv-voice-card,
html.ba-calls-hidden .ag-srv-voice-row,
html.ba-calls-hidden .ag-srv-voice-pill,
html.ba-calls-hidden .ag-srv-voice-room,
html.ba-calls-hidden .ag-srv-voice-roster,
html.ba-calls-hidden .ag-srv-discord-voice-row,
html.ba-calls-hidden .ag-srv-discord-voice-group,
html.ba-calls-hidden .ag-srv-discord-voice-users,
html.ba-calls-hidden button[aria-label^="Start voice call" i],
html.ba-calls-hidden button[aria-label^="Start video call" i],
.ba-call-disabled,
.ag-ctx-item[data-ba-call-disabled="1"] {
  opacity: 0.45 !important;
  cursor: not-allowed !important;
}
html.ba-calls-hidden button[aria-label^="Start call" i],
html.ba-calls-hidden button[aria-label^="Join call" i],
html.ba-calls-hidden button[aria-label^="Answer call" i],
html.ba-calls-hidden button[title^="Start Voice Call" i],
html.ba-calls-hidden button[title^="Start Video Call" i],
html.ba-calls-hidden button[title^="Start Call" i],
html.ba-calls-hidden button[title^="Join Call" i],
html.ba-calls-hidden button[title^="Answer Call" i] {
  display: none !important;
}
html.ba-calls-hidden .ag-sheet-call-card,
html.ba-calls-hidden .ag-sheet-section:has(.ag-sheet-call-card),
html.ba-calls-hidden .ag-sheet-action-btn:has(svg[class*="lucide-phone"]),
html.ba-calls-hidden .ag-sheet-action-btn:has(svg[class*="lucide-video"]),
html.ba-calls-hidden .ag-ctx-item:has(svg[class*="lucide-phone"]),
html.ba-calls-hidden .ag-ctx-item:has(svg[class*="lucide-video"]),
html.ba-calls-hidden .ag-ctx-item[data-ba-call-disabled="1"],
html.ba-calls-hidden button[aria-label*="voice call" i],
html.ba-calls-hidden button[aria-label*="video call" i],
html.ba-calls-hidden button[aria-label*="start call" i],
html.ba-calls-hidden button[aria-label*="join call" i],
html.ba-calls-hidden button[aria-label*="answer call" i],
html.ba-calls-hidden button[aria-label*="leave call" i],
html.ba-calls-hidden button[aria-label*="end call" i],
html.ba-calls-hidden button[title*="voice call" i],
html.ba-calls-hidden button[title*="video call" i],
html.ba-calls-hidden button[title*="start call" i],
html.ba-calls-hidden button[title*="join call" i],
html.ba-calls-hidden button[title*="answer call" i],
html.ba-calls-hidden button[title*="leave call" i],
html.ba-calls-hidden button[title*="end call" i] {
  display: none !important;
}
html.ba-calls-hidden .ag-ctx-item:has(.ag-ctx-item-label) {
  /* Actual removal happens in JS; this is only a fallback. */
}

/* --- Agnostr settings integration --------------------------------------- */
.ba-settings-nav-glyph {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 17px;
  height: 17px;
  color: inherit;
  font-size: 17px;
  line-height: 1;
}
.ba-set-status,
.ba-set-hint {
  font-size: 11px;
  line-height: 1.45;
  color: var(--text-muted);
}
.ba-set-status {
  padding: 7px 9px;
  margin-bottom: 8px;
  border: 1px solid var(--border-subtle);
  border-radius: var(--radius-sm);
  background: var(--bg-canvas);
  font-family: var(--font-mono);
}
.ba-set-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}
.ba-set-label-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}
.ba-set-link {
  border: none;
  background: transparent;
  color: var(--accent);
  font: 600 10.5px/1.2 inherit;
  cursor: pointer;
  padding: 0;
}
.ba-set-link:hover { text-decoration: underline; }
.ba-set-css {
  width: 100%;
  min-height: 92px;
  resize: vertical;
  margin-top: 6px;
  font-family: var(--font-mono);
  font-size: 10.5px;
  line-height: 1.5;
}
.ba-set-hint {
  margin-top: 5px;
}
.ba-set-hint code {
  font-family: var(--font-mono);
  color: var(--text-secondary);
}
.ba-set-select-row {
  display: grid;
  grid-template-columns: 1fr 150px auto;
  align-items: center;
  gap: 7px;
  margin: 6px 0 8px;
  font-size: 12px;
  color: var(--text-secondary);
}
.ba-set-select {
  min-height: 28px;
  padding: 3px 6px;
  font-size: 11px;
}
.ba-set-range-row {
  display: grid;
  grid-template-columns: 1fr 150px;
  align-items: center;
  gap: 8px;
  margin-top: 7px;
  font-size: 12px;
  color: var(--text-secondary);
}
.ba-set-range {
  accent-color: var(--accent);
  width: 100%;
}
.ba-set-inline {
  display: flex;
  gap: 6px;
  align-items: center;
}
.ba-set-build-input {
  flex: 1;
  min-width: 0;
  font-family: var(--font-mono);
  font-size: 11px;
}
.ba-glub-theme-group .ag-set-theme-grid {
  grid-template-columns: repeat(2, minmax(0, 1fr));
}
@media (max-width: 600px) {
  .ba-glub-theme-group .ag-set-theme-grid { grid-template-columns: 1fr; }
  .ba-set-select-row { grid-template-columns: 1fr auto; }
  .ba-set-select { grid-column: 1 / -1; }
}

/* --- consolidated rail / settings cleanup -------------------------------- */
html.ba-hide-locate .ba-locate-hidden,
html.ba-hide-locate button[aria-label^="Locate" i],
html.ba-hide-locate button[title^="Locate" i] {
  display: none !important;
}
.ba-suite-better {
  display: flex;
  align-items: center;
  gap: 6px;
}
.ba-suite-better .ba-suite-spark {
  color: var(--accent);
}

/* --- Better Agnostr settings pane ---------------------------------------- */
.ba-settings-shell {
  display: flex;
  flex-direction: column;
  gap: 10px;
  min-width: 0;
}
.ba-set-tabs {
  display: grid;
  grid-auto-flow: column;
  grid-auto-columns: 1fr;
  gap: 2px;
  padding: 3px;
  border: 1px solid var(--border-subtle);
  border-radius: var(--radius-sm, 8px);
  background: var(--bg-canvas);
  overflow-x: auto;
  scrollbar-width: none;
  margin-bottom: 8px;
}
.ba-set-tabs::-webkit-scrollbar { display: none; }
.ba-set-tab {
  padding: 6px 10px;
  border: 1px solid transparent;
  border-radius: var(--radius-xs, 6px);
  background: transparent;
  color: var(--text-secondary);
  font-family: inherit;
  font-size: 11.5px;
  font-weight: 600;
  white-space: nowrap;
  transition: color 0.12s ease, background-color 0.12s ease, border-color 0.12s ease;
}
.ba-set-tab:hover { color: var(--text-primary); background: var(--bg-hover); }
.ba-set-tab.is-active {
  color: var(--accent);
  background: var(--accent-soft);
  border-color: var(--border-accent);
}
.ba-set-content {
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
}
.ba-set-label-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}
.ba-set-count,
.ba-set-note {
  font-family: var(--font-mono);
  font-size: 9px;
  color: var(--text-muted);
}
.ba-set-row {
  display: grid;
  grid-template-columns: 1fr minmax(120px, 180px) auto;
  gap: 7px;
  align-items: center;
  margin: 6px 0;
  font-size: 12px;
  color: var(--text-secondary);
}
.ba-set-row > span:first-child { min-width: 74px; }
.ba-set-select {
  min-height: 28px;
  padding: 3px 6px;
  font-size: 11px;
}
.ba-set-preview-message-row {
  grid-template-columns: 1fr minmax(180px, 260px);
  margin-bottom: 7px;
}
.ba-set-chips {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin-top: 6px;
}
.ba-set-chip {
  min-height: 27px;
  border: 1px solid var(--border-default);
  border-radius: var(--radius-sm, 8px);
  background: var(--bg-subtle);
  color: var(--text-primary);
  font-family: inherit;
  font-size: 11px;
  font-weight: 600;
  padding: 4px 9px;
  cursor: pointer;
}
.ba-set-chip:hover { border-color: var(--border-strong); background: var(--bg-hover); }
.ba-set-template {
  width: 100%;
  font-family: var(--font-mono);
  font-size: 11px;
  margin-top: 5px;
}
.ba-set-colors {
  display: flex;
  flex-wrap: wrap;
  gap: 3px;
  margin-top: 6px;
}
.ba-set-swatch {
  width: 21px;
  height: 21px;
  padding: 0;
  border: 1px solid rgba(0, 0, 0, 0.45);
  border-radius: 4px;
  font-family: var(--font-mono);
  font-size: 8px;
  font-weight: 700;
  color: rgba(0, 0, 0, 0.64);
  cursor: pointer;
}
.ba-set-swatch:hover { transform: translateY(-1px); }
.ba-set-tools {
  display: flex;
  gap: 3px;
  margin-top: 6px;
}
.ba-set-tool {
  width: 26px;
  height: 26px;
  border: 1px solid var(--border-default);
  border-radius: var(--radius-xs, 6px);
  background: var(--bg-subtle);
  color: var(--text-secondary);
  font-family: inherit;
  font-size: 10.5px;
  font-weight: 600;
  cursor: pointer;
}
.ba-set-tool:hover { border-color: var(--border-strong); color: var(--text-primary); background: var(--bg-hover); }
.ba-set-flairs {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(82px, 1fr));
  gap: 4px;
  margin-top: 5px;
}
.ba-set-flair {
  border: 1px solid var(--border-default);
  border-radius: var(--radius-sm, 8px);
  background: var(--bg-subtle);
  color: var(--text-primary);
  font-family: inherit;
  font-size: 11px;
  font-weight: 600;
  padding: 7px 8px;
  text-align: left;
  cursor: pointer;
  text-transform: capitalize;
}
.ba-set-flair:hover { border-color: var(--border-strong); background: var(--bg-hover); }
.ba-set-flair.active {
  border-color: var(--border-accent);
  color: var(--accent);
  background: var(--accent-soft);
}
.ba-set-flair.gated::after {
  content: " \xB7 nip05";
  color: var(--status-warn);
  font-size: 8px;
}
.ba-set-policies {
  display: grid;
  gap: 2px;
  margin-top: 5px;
}
.ba-set-policy {
  display: grid;
  grid-template-columns: 1fr 110px;
  align-items: center;
  gap: 8px;
  padding: 4px 0;
  border-bottom: 1px solid var(--border-subtle);
  font-size: 11.5px;
  color: var(--text-secondary);
}
.ba-set-policy:last-child { border-bottom: none; }
.ba-set-checks {
  display: flex;
  flex-wrap: wrap;
  gap: 5px 12px;
  margin-top: 5px;
}
.ba-set-check {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  font-size: 10.5px;
  color: var(--text-secondary);
  cursor: pointer;
}
.ba-set-check input { accent-color: var(--accent); margin: 0; }
.ba-set-status {
  font-family: var(--font-mono);
  font-size: 10px;
  color: var(--text-muted);
  background: var(--bg-canvas);
  border: 1px solid var(--border-subtle);
  border-radius: 5px;
  padding: 6px 8px;
  margin: 5px 0;
}
.ba-set-build,
.ba-set-filter {
  width: 100%;
  font-family: var(--font-mono);
  font-size: 11px;
}
.ba-set-filter { margin: 5px 0; }
.ba-set-relay-status {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin: 4px 0;
}
.ba-set-relay {
  font-family: var(--font-mono);
  font-size: 8.5px;
  color: var(--text-muted);
  border: 1px solid var(--border-subtle);
  border-radius: 999px;
  padding: 2px 5px;
}
.ba-set-relay.ok { color: var(--status-ok); border-color: color-mix(in srgb, var(--status-ok) 30%, var(--border-subtle)); }
.ba-set-relay.err { color: var(--status-danger); border-color: color-mix(in srgb, var(--status-danger) 30%, var(--border-subtle)); }
.ba-set-log {
  display: flex;
  flex-direction: column;
  gap: 2px;
  max-height: 280px;
  overflow: auto;
  font-family: var(--font-mono);
}
.ba-set-log-row {
  display: grid;
  grid-template-columns: 14px 58px 1fr auto;
  gap: 5px;
  align-items: center;
  border: 1px solid transparent;
  border-radius: 4px;
  background: var(--bg-canvas);
  color: var(--text-secondary);
  font: 9px/1.3 var(--font-mono);
  text-align: left;
  padding: 3px 5px;
  cursor: pointer;
}
.ba-set-log-row:hover { border-color: var(--border-subtle); }
.ba-set-log-row .in { color: var(--status-ok); }
.ba-set-log-row .out { color: var(--accent); }
.ba-set-log-row .sys { color: var(--status-warn); }
.ba-set-log-row .time { color: var(--text-muted); }
.ba-set-log-row .sum { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.ba-set-log-row .relay { color: var(--text-muted); }
.ba-set-about {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 4px 12px;
  margin-top: 4px;
}
.ba-set-about > div {
  display: flex;
  justify-content: space-between;
  gap: 8px;
  border-bottom: 1px solid var(--border-subtle);
  padding: 3px 0;
  font-family: var(--font-mono);
  font-size: 10px;
  color: var(--text-muted);
}
.ba-set-about strong { color: var(--text-secondary); font-weight: 500; }
.ba-set-range { width: 100%; accent-color: var(--accent); }

/* preview */
.ba-set-preview {
  border: 1px solid var(--border-subtle);
  border-radius: 8px;
  background: var(--bg-canvas);
  overflow: hidden;
  margin-bottom: 5px;
}
.ba-set-preview-head {
  display: flex;
  justify-content: space-between;
  gap: 8px;
  padding: 5px 9px;
  border-bottom: 1px solid var(--border-subtle);
  font: 9px/1.2 var(--font-mono);
  color: var(--text-muted);
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
.ba-set-preview-head .ok { color: var(--status-ok); }
.ba-set-preview-head .warn { color: var(--status-warn); }
.ba-set-preview-row {
  position: relative;
  display: flex;
  gap: 10px;
  align-items: flex-start;
  min-height: 64px;
  padding: 14px;
  overflow: hidden;
  isolation: isolate;
  background: var(--bg-canvas);
}
.ba-set-preview-row > .ba-set-preview-avatar,
.ba-set-preview-row > .ba-set-preview-main {
  position: relative;
  z-index: 1;
}
.ba-set-preview-avatar {
  flex: 0 0 auto;
  width: 30px;
  height: 30px;
  border-radius: 7px;
  object-fit: cover;
  background: var(--bg-elevated);
  border: 1px solid var(--border-subtle);
}
.ba-set-preview-main { min-width: 0; flex: 1; }
.ba-set-preview-meta {
  display: flex;
  align-items: baseline;
  gap: 6px;
  font: 10px/1.3 var(--font-mono);
  color: var(--text-muted);
  margin-bottom: 3px;
}
.ba-set-preview-name {
  color: var(--text-primary);
  font-weight: 600;
}
.ba-set-preview-tag { color: var(--text-muted); }
.ba-set-preview-line {
  display: block;
  font-size: 13px;
  line-height: 1.5;
  color: var(--text-primary);
  word-break: break-word;
}
.ba-set-preview-native {
  padding: 6px 9px;
  border-top: 1px solid var(--border-subtle);
  font: 9.5px/1.4 var(--font-mono);
  color: var(--text-muted);
}
.ba-set-preview-native span {
  color: var(--accent);
  text-transform: uppercase;
  font-size: 8px;
  margin-right: 7px;
}

.ba-set-field {
  display: grid;
  grid-template-columns: 90px 1fr;
  gap: 8px;
  align-items: center;
  margin: 5px 0;
  font-size: 11px;
  color: var(--text-muted);
}
.ba-set-field > input,
.ba-set-field > select { min-width: 0; }

/* Better Agnostr lives in an overlay inside the settings detail body instead of
   replacing React-owned nodes. */
.ag-settings-modal .ag-set-detail-body { position: relative; }
.ba-better-overlay,
.ba-about-overlay {
  position: static;
  inset: auto;
  z-index: auto;
  overflow: visible;
  background: transparent;
  padding: 0 2px 24px;
}
.ba-better-overlay[hidden],
.ba-about-overlay[hidden] { display: none; }
.ag-settings-modal.ba-better-active .ag-set-detail-body > :not([data-ba-better-overlay]),
.ag-settings-modal.ba-about-active .ag-set-detail-body > :not([data-ba-about-overlay]) {
  display: none !important;
}
.ag-settings-modal.ba-about-active .ag-set-detail-title { visibility: hidden; }
.ba-about-pane {
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  padding: 26px 12px 12px;
}
.ba-about-logo {
  width: 104px;
  height: 104px;
  border-radius: 24px;
  background: var(--bg-elevated);
  border: 1px solid var(--border-subtle);
  box-shadow: 0 14px 38px rgba(0, 0, 0, 0.28);
}
.ba-about-name {
  margin-top: 16px;
  font-size: 22px;
  font-weight: 700;
  letter-spacing: 0.02em;
  color: var(--text-primary);
}
.ba-about-version {
  margin-top: 3px;
  font: 600 12px/1.3 var(--font-mono);
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--text-secondary);
}
.ba-about-with {
  margin-top: 5px;
  font-size: 11px;
  color: var(--text-muted);
}
.ba-about-credits {
  display: grid;
  gap: 8px;
  width: 100%;
  max-width: 460px;
  margin-top: 22px;
  text-align: left;
}
.ba-about-credit {
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding: 11px 13px;
  border: 1px solid var(--border-subtle);
  border-radius: var(--radius-md, 10px);
  background: var(--bg-elevated);
  font-size: 11px;
}
.ba-about-credit-name { color: var(--text-primary); font-weight: 600; }
.ba-about-credit-line { color: var(--text-secondary); }
.ba-about-credit a { color: var(--accent); text-decoration: none; width: fit-content; }
.ba-about-credit .ba-about-angel { color: var(--accent); }
.ba-about-credit a:hover { text-decoration: underline; }
.ba-native-group { margin-top: 12px; }
.ba-native-details {
  margin-top: 8px;
  border: 1px solid var(--border-subtle);
  border-radius: var(--radius-sm, 8px);
  padding: 7px 10px;
  background: var(--bg-canvas);
}
.ba-native-details summary {
  cursor: pointer;
  color: var(--text-secondary);
  font-size: 11px;
}
.ba-native-checks {
  display: flex;
  flex-wrap: wrap;
  gap: 7px 14px;
  margin-top: 8px;
}
.ba-native-check {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  font-size: 11px;
  color: var(--text-secondary);
  cursor: pointer;
}
.ba-native-check input { accent-color: var(--accent); }
.ba-native-actions { display: flex; gap: 6px; margin-top: 9px; }
.ba-better-heading {
  font-family: var(--font-mono);
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.05em;
  text-transform: uppercase;
  color: var(--text-primary);
  margin: 0 0 8px;
}
.ag-settings-modal.ba-better-active .ag-set-detail-title { visibility: hidden; }


/* Keep the native right-click menu inside the viewport and scrollable. */
.ag-ctx-menu {
  max-height: calc(100dvh - 24px);
  overflow-y: auto;
  overscroll-behavior: contain;
}


/* --- emoji picker --------------------------------------------------------- */
.ba-emoji-popover {
  position: fixed;
  z-index: 120000;
  display: flex;
  flex-direction: column;
  width: min(300px, calc(100dvw - 20px));
  max-height: min(300px, calc(100dvh - 20px));
  overflow: hidden;
  padding: 6px;
  border: 1px solid var(--border-default);
  border-radius: 10px;
  background: var(--bg-elevated);
  box-shadow: 0 14px 36px rgba(0, 0, 0, 0.4);
}
.ba-emoji-popover[hidden] { display: none; }
.ba-emoji-tabs {
  display: flex;
  flex: 0 0 auto;
  gap: 2px;
  min-height: 31px;
  overflow-x: auto;
  padding-bottom: 5px;
  margin-bottom: 4px;
  border-bottom: 1px solid var(--border-subtle);
  background: var(--bg-elevated);
  position: relative;
  z-index: 1;
  scrollbar-width: none;
}
.ba-emoji-tabs::-webkit-scrollbar { display: none; }
.ba-emoji-tab {
  flex: 0 0 auto;
  width: 28px;
  height: 26px;
  display: grid;
  place-items: center;
  border: 1px solid transparent;
  border-radius: 6px;
  background: transparent;
  font-size: 16px;
  line-height: 1;
  cursor: pointer;
}
.ba-emoji-tab:hover { background: var(--bg-hover); }
.ba-emoji-tab.is-active { border-color: var(--border-accent); background: var(--accent-soft); }
.ba-emoji-grid {
  display: grid;
  flex: 1 1 auto;
  grid-template-columns: repeat(8, 30px);
  gap: 2px;
  overflow-y: auto;
  min-height: 0;
}
.ba-emoji-item {
  width: 30px;
  height: 30px;
  display: grid;
  place-items: center;
  padding: 0;
  border: none;
  border-radius: 6px;
  background: transparent;
  font-size: 19px;
  line-height: 1;
  cursor: pointer;
}
.ba-emoji-item:hover { background: var(--bg-hover); }
.ba-emoji-btn { color: var(--text-secondary); }


/* Normalize the native suite before its first paint so old Map/Search
   utilities and the Chat label never flash. */
.ag-suite-footer {
  grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
}
.ag-suite-footer .ag-suite-util-btn:has(svg[class*="lucide-map"]),
.ag-suite-footer .ag-suite-util-btn:has(svg[class*="lucide-search"]) {
  display: none !important;
}
.ag-suite-card:has(svg[class*="lucide-waves"]) .ag-suite-card-name {
  font-size: 0 !important;
}
.ag-suite-card:has(svg[class*="lucide-waves"]) .ag-suite-card-name::after {
  content: "Chat";
  font-size: 13px;
  font-weight: 650;
  line-height: 1.2;
}
.ba-suite-better {
  min-width: 0;
}
.ba-suite-better svg {
  color: var(--accent);
}
.ba-suite-better span {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.ag-set-notif-row .ba-notif-select {
  width: min(190px, 44%);
  min-width: 132px;
}
.ag-set-notif-row .ba-notif-range {
  width: min(190px, 44%);
  min-width: 132px;
  accent-color: var(--accent);
}
@media (max-width: 600px) {
  .ag-set-notif-row:has(.ba-notif-select),
  .ag-set-notif-row:has(.ba-notif-range) {
    flex-wrap: wrap;
  }
  .ag-set-notif-row .ba-notif-select,
  .ag-set-notif-row .ba-notif-range {
    width: 100%;
    min-width: 0;
  }
}

/* Blocked-user message runs are noise when Better Agnostr is active. */
html.ba-active .ag-blocked-run { display: none !important; }

/* Optional privacy mode: hide per-message clock times. */
html.ba-hide-timestamps .ag-msg-row .ag-msg-time,
html.ba-hide-timestamps .ag-msg-row .ag-msg-gutter-time {
  display: none !important;
}

html.ba-hide-notification-button .ag-notification-shortcut,
html.ba-hide-notification-button [aria-label="Notification options"],
html.ba-hide-notification-button .ag-rail-app-tile:has(svg.lucide-bell),
html.ba-hide-notification-button .ag-mtab-btn[aria-label*="Notification" i] {
  display: none !important;
}

/* Agnostr now places the message action toolbar in the row's flex flow next to
   the text. Restore the previous fixed top-right overlay so it does not move with
   message width, wrapping, or avatars. */
html.ba-active .ag-msg-row > .ag-msg-actions,
html.ba-active .ag-msg-row > .ag-msg-content > .ag-msg-actions {
  position: absolute !important;
  top: -13px !important;
  inset-inline-end: 20px !important;
  bottom: auto !important;
  inset-inline-start: auto !important;
  flex: none !important;
  block-size: auto !important;
  margin: 0 !important;
  align-self: auto !important;
}

@media (max-width: 867px) {
  html.ba-active .ag-msg-row > .ag-msg-actions,
  html.ba-active .ag-msg-row > .ag-msg-content > .ag-msg-actions {
    top: -16px !important;
    inset-inline-end: 12px !important;
  }
}


/* Readable serif fonts have deeper descenders than Agnostr's compact rail
   labels allow. Keep "Agora" and "Agwallet" from clipping their g. */
html.ba-active .ag-rail-app-label,
html.ba-active .ag-mtab-label {
  line-height: 1.35 !important;
  overflow: visible !important;
  padding-block: 1px 2px !important;
  max-width: 58px !important;
}

html.ba-active .ag-rail-app-tile,
html.ba-active .ag-mtab-btn {
  min-height: 50px !important;
}
`;

  // src/ui/glub-flair.css
  var glub_flair_default = `/* The glub.chat rainbow is the default: the original palette, no screen blend,
   and no white glow. Bright is the high-contrast alternative. Both palettes are
   custom properties so the same rule serves page rows and shadow-DOM previews. */
:root,
:host {
	--ba-rainbow-generic: repeating-linear-gradient(
		var(--ba-rainbow-angle, 90deg),
		#ff5555 0%,
		#ffcc00 8%,
		#55ff55 16%,
		#55ffff 24%,
		#5b8dff 32%,
		#c74ddb 40%,
		#ff5555 48%
	);
	--ba-rainbow-flair: var(--ba-rainbow-generic);
	--ba-rainbow-bg: transparent;
	--ba-rainbow-blend: normal;
	--ba-rainbow-shadow: none;
	--ba-rainbow-shadow-flair: none;
	--ba-rainbow-angle: 90deg;
	--ba-rainbow-rain-angle: 180deg;
	--ba-rainbow-rain-size: 100% 26px;
	--ba-rainbow-rain-end: 0 26px;
}

.fmtRainbow {
	background-image: var(--ba-rainbow-generic);
	background-size: 200% 100%;
	background-color: var(--ba-rainbow-bg, transparent);
	background-blend-mode: var(--ba-rainbow-blend, normal);
	-webkit-background-clip: text;
	background-clip: text;
	-webkit-text-fill-color: transparent;
	color: transparent;
	animation: fmtRainbow 6s linear infinite;
	will-change: background-position;
	text-shadow: var(--ba-rainbow-shadow, none);
	text-decoration-color: #ff8fb0;
}

/* Some Chromium builds stop painting a clipped gradient when a descendant span
   has its own fill. Keep every non-emoji descendant transparent so the parent's
   gradient remains the only paint. Emoji are excluded and keep their own colour. */
.fmtRainbow :not(.fmtEmoji),
[data-ba-line-rainbow="1"] :not(.fmtEmoji) {
	-webkit-text-fill-color: transparent;
}
@keyframes fmtRainbow {
	to {
		background-position: 200% 0;
	}
}

/* While a flair is present, never fall back to the generic rainbow palette.
   Each flair's own .fmtRainbow rule below replaces this neutral fill. The fallback
   deliberately stays rainbow rather than a solid colour: while React re-renders a
   row it can briefly strip the flair classes but leave data-ba-flair behind, and a
   solid fallback made the text look as if its colours had reset. */
.flair .fmtRainbow,
[data-ba-flair] .fmtRainbow {
	background-image: var(--ba-rainbow-flair);
	text-shadow: var(--ba-rainbow-shadow-flair, none);
}

/* If React strips the fmtRainbow class while re-rendering a selected row, the
   line-rainbow data attribute usually survives. Keep the gradient visible from
   that attribute until the row is repaired, so selection never flashes plain text. */
.ag-msg-author[data-ba-line-rainbow="1"]:not(.fmtRainbow),
.ag-msg-rich[data-ba-line-rainbow="1"]:not(.fmtRainbow) {
	background-image: var(--ba-rainbow-flair, var(--ba-rainbow-generic));
	background-size: 200% 100%;
	-webkit-background-clip: text;
	background-clip: text;
	-webkit-text-fill-color: transparent;
	color: transparent;
	animation: fmtRainbow 6s linear infinite;
	will-change: background-position;
	text-shadow: var(--ba-rainbow-shadow-flair, none);
	text-decoration-color: #ff90b0;
}

/* Bright rainbow mode. */
html[data-ba-rainbow="bright"],
:host([data-ba-rainbow="bright"]) {
	--ba-rainbow-generic: repeating-linear-gradient(
		var(--ba-rainbow-angle, 90deg),
		#ff6b6b 0%,
		#ffd93d 8%,
		#6bff8f 16%,
		#6bffff 24%,
		#7aa2ff 32%,
		#e879f9 40%,
		#ff6b6b 48%
	);
	--ba-rainbow-flair: repeating-linear-gradient(
		var(--ba-rainbow-angle, 90deg),
		#ff6b6b 0%,
		#ffd93d 8%,
		#6bff8f 16%,
		#6bffff 24%,
		#7aa2ff 32%,
		#e879f9 40%,
		#ff6b6b 48%
	);
	--ba-rainbow-bg: rgba(255, 255, 255, 0.26);
	--ba-rainbow-blend: screen;
	--ba-rainbow-shadow: 0 0 7px rgba(255, 255, 255, 0.5), 0 1px 1px rgba(0, 0, 0, 0.42);
	--ba-rainbow-shadow-flair: 0 0 8px rgba(255, 255, 255, 0.56), 0 1px 1px rgba(0, 0, 0, 0.46);
	--ba-rainbow-angle: 270deg;
	--ba-rainbow-rain-angle: 270deg;
	--ba-rainbow-rain-size: 200% 100%;
	--ba-rainbow-rain-end: 200% 0;
}

.fmtEmoji {
	color: var(--fg);
	-webkit-text-fill-color: var(--fg);
	background: none;
	-webkit-background-clip: border-box;
	background-clip: border-box;
	animation: none;
	text-shadow: none !important;
}

.flair-fire .fmtRainbow {
	background-image: repeating-linear-gradient(
		var(--ba-rainbow-angle, 90deg),
		#ff3d00 0%,
		#ff7a18 8%,
		#ffb057 16%,
		#ffe6a3 24%,
		#ffb057 32%,
		#ff6a00 40%,
		#ff3d00 48%
	);
	animation: fmtEmberText var(--fire-text-dur, 4.4s) linear var(--fire-text-delay, 0s) infinite;
	text-decoration-color: #ffb057;
}

@keyframes fmtEmberText {
	0% {
		background-position: 0 0;
		filter: brightness(0.88) saturate(1);
	}
	9% {
		filter: brightness(1.42) saturate(1.15);
	}
	34% {
		filter: brightness(0.92) saturate(1);
	}
	46% {
		filter: brightness(1.24) saturate(1.1);
	}
	61% {
		filter: brightness(0.85) saturate(0.95);
	}
	72% {
		filter: brightness(1.38) saturate(1.15);
	}
	100% {
		background-position: 200% 0;
		filter: brightness(0.88) saturate(1);
	}
}

.flair-lightning .fmtRainbow {
	background-image: repeating-linear-gradient(
		var(--ba-rainbow-angle, 90deg),
		#00a6ff 0%,
		#3fc9ff 12%,
		#a5ecff 24%,
		#ffffff 33%,
		#3fc9ff 42%,
		#00a6ff 48%
	);
	animation: fmtStormText var(--lit-text-dur, 7s) linear var(--lit-text-delay, 0s) infinite;
	text-decoration-color: #a5ecff;
}

@keyframes fmtStormText {
	0%,
	100% {
		background-position: 0 0;
		filter: brightness(0.62);
	}
	7% {
		filter: brightness(0.62);
	}
	8.5% {
		filter: brightness(1.85);
	}
	10% {
		filter: brightness(0.7);
	}
	11.5% {
		filter: brightness(1.4);
	}
	14%,
	48% {
		filter: brightness(0.62);
	}
	49.5% {
		filter: brightness(2.1);
	}
	51% {
		filter: brightness(0.72);
	}
	52.5% {
		filter: brightness(1.6);
	}
	56% {
		filter: brightness(0.62);
	}
	99.9% {
		background-position: 140% 0;
	}
}

.flair-rain .fmtRainbow {
	
	background-image: linear-gradient(
		var(--ba-rainbow-rain-angle, 180deg),
		#3f7fc4 0%,
		#6fb2e8 23%,
		#c4e7ff 42%,
		#8ecbf2 62%,
		#5595d4 81%,
		#3f7fc4 100%
	);
	background-size: var(--ba-rainbow-rain-size, 100% 26px);
	background-repeat: repeat;
	animation: fmtRainText var(--rain-text-dur, 3.2s) linear var(--rain-text-delay, 0s) infinite;
	text-decoration-color: #a9d6f5;
}

@keyframes fmtRainText {
	0% {
		background-position: 0 0;
		filter: brightness(0.95);
	}
	50% {
		filter: brightness(1.16);
	}
	100% {
		background-position: var(--ba-rainbow-rain-end, 0 26px);
		filter: brightness(0.95);
	}
}

.flair-plume .fmtRainbow {
	background-image: linear-gradient(
		var(--ba-rainbow-angle, 90deg),
		#7e3ff2 0%,
		#a855f7 18%,
		#d8b4fe 34%,
		#fbf5ff 46%,
		#d8b4fe 58%,
		#a855f7 76%,
		#7e3ff2 100%
	);
	background-size: 220% 100%;
	background-repeat: repeat;
	animation: fmtPlumeText var(--plume-text-dur, 6.5s) ease-in-out var(--plume-text-delay, 0s) infinite;
	text-decoration-color: #d8b4fe;
}

@keyframes fmtPlumeText {
	0% {
		background-position: 0 0;
		filter: brightness(0.92);
	}
	50% {
		filter: brightness(1.3);
	}
	100% {
		background-position: 220% 0;
		filter: brightness(0.92);
	}
}

.flair-neon .fmtRainbow {
	background-image: repeating-linear-gradient(
		var(--ba-rainbow-angle, 90deg),
		#55ffff 0%,
		#55ffff 6%,
		#c7ffff 8.5%,
		#ffffff 10%,
		#ffffff 11.4%,
		#c7ffff 13%,
		#55ffff 16%,
		#55ffff 28%,
		#c7ffff 31%,
		#ffffff 33%,
		#ffffff 34.4%,
		#c7ffff 36.5%,
		#55ffff 40%,
		#55ffff 50%
	);
	animation-duration: var(--neon-text-dur, 5.5s);
	animation-delay: var(--neon-text-delay, 0s);
	text-decoration-color: #55ffff;
}

.flair-stars .fmtRainbow {
	background-image: repeating-linear-gradient(
		var(--ba-rainbow-angle, 90deg),
		#ffffff 0%,
		#cfe6ff 8%,
		#a8ccff 16%,
		#f0d2e8 24%,
		#ffffff 32%,
		#bcd8ff 40%,
		#ffffff 48%
	);
	animation-duration: 8s; 
	text-decoration-color: #dbe9ff;
}

.fmtObf {
	opacity: 0.92;
}

@media (prefers-reduced-motion: reduce) {
	
	.fmtRainbow {
		animation: none;
	}
}

.flair {
	position: relative;
	isolation: isolate;
	overflow: hidden;
}

.flair::before,
.flair::after {
	content: "";
	position: absolute;
	pointer-events: none;
	z-index: -1;
}

.line.flair {
	padding: 3px 6px;
	margin: 0 -6px 4px;
	border-radius: 4px;
}

.flairChip {
	display: inline-block;
	padding: 3px 10px;
	border-radius: 4px;
	margin-right: 4px;
	
	min-width: 9ch;
	text-align: center;
	margin-bottom: 5px;
	
	vertical-align: middle;
}

.flair-fire::before {
	inset: 0;
	background: linear-gradient(90deg, rgba(255, 96, 0, 0.24), rgba(255, 150, 40, 0.07) 60%, transparent);
	animation: flairFireGlow var(--fire-glow-dur, 3.4s) ease-in-out var(--fire-glow-delay, 0s) infinite;
}

.flair-fire::after {
	left: var(--ash-left, 20px);
	top: 100%;
	width: 2px;
	height: 2px;
	border-radius: 50%;
	background: #8a7f77;
	box-shadow: var(--ash-field, 40px 0 #6d635c, 96px 0 #b9a89a, 158px 0 #c9762f, 226px 0 #7d726a);
	animation: flairAshRise var(--ash-dur, 5.5s) linear var(--ash-delay, 0s) infinite;
}

.flair-fire > .flairFx {
	inset: 0;
	opacity: 1;
}

.flair-fire .ember {
	position: absolute;
	bottom: -2px;
	left: var(--e-x, 20%);
	width: var(--e-size, 2px);
	height: var(--e-size, 2px);
	border-radius: 50%;
	background: var(--e-tint, #ffb057);
	opacity: 0;
	animation:
		emberRise var(--e-rise, 4s) linear var(--e-rise-delay, 0s) infinite,
		emberSway var(--e-sway, 2s) ease-in-out var(--e-sway-delay, 0s) infinite alternate;
}

@keyframes emberRise {
	0% {
		translate: 0 0;
		opacity: 0;
	}
	6% {
		opacity: var(--e-peak, 0.95);
	}
	48% {
		opacity: calc(var(--e-peak, 0.95) * 0.5);
	}
	66% {
		translate: 0 calc(var(--e-lift, 2.2em) * -1);
		opacity: 0;
	}
	100% {
		translate: 0 calc(var(--e-lift, 2.2em) * -1);
		opacity: 0;
	}
}

.flair-fire .ember.emberShort {
	animation-name: emberRiseShort, emberSway;
}

@keyframes emberRiseShort {
	0% {
		translate: 0 0;
		opacity: 0;
	}
	8% {
		opacity: calc(var(--e-peak, 0.95) * 0.85);
	}
	30% {
		opacity: calc(var(--e-peak, 0.95) * 0.35);
	}
	40% {
		translate: 0 calc(var(--e-lift, 2.2em) * -0.5);
		opacity: 0;
	}
	100% {
		translate: 0 calc(var(--e-lift, 2.2em) * -0.5);
		opacity: 0;
	}
}

@keyframes emberSway {
	from {
		transform: translate3d(calc(var(--e-amp, 6px) * -1), 0, 0);
	}
	to {
		transform: translate3d(var(--e-amp, 6px), 0, 0);
	}
}

@keyframes flairFireGlow {
	0% {
		opacity: var(--fire-glow-low, 0.45);
	}
	9% {
		opacity: var(--fire-glow-peak, 0.95);
	}
	34% {
		opacity: calc(var(--fire-glow-low, 0.45) * 1.25);
	}
	46% {
		opacity: calc(var(--fire-glow-peak, 0.95) * 0.82);
	}
	61% {
		opacity: var(--fire-glow-low, 0.45);
	}
	72% {
		opacity: var(--fire-glow-peak, 0.95);
	}
	100% {
		opacity: var(--fire-glow-low, 0.45);
	}
}

@keyframes flairAshRise {
	0% {
		transform: translate3d(0, 0, 0);
		opacity: 0;
		animation-timing-function: ease-in-out;
	}
	20% {
		opacity: 0.42;
		animation-timing-function: ease-in-out;
	}
	42% {
		transform: translate3d(var(--ash-x1, -4px), -0.5em, 0);
		opacity: 0.32;
		animation-timing-function: ease-in-out;
	}
	60% {
		transform: translate3d(var(--ash-x2, 6px), -0.95em, 0);
		opacity: 0.18;
		animation-timing-function: ease-in-out;
	}
	74% {
		transform: translate3d(var(--ash-x3, -3px), -1.3em, 0);
		opacity: 0;
	}
	100% {
		transform: translate3d(var(--ash-x3, -3px), -1.45em, 0);
		opacity: 0;
	}
}

.flair-lightning::before {
	inset: 0;
	background: linear-gradient(90deg, rgba(90, 150, 255, 0.2), rgba(150, 200, 255, 0.06) 60%, transparent);
	animation: flairStormHaze var(--lit-haze-dur, 6s) ease-in-out var(--lit-haze-delay, 0s) infinite;
}

.flair-lightning::after {
	inset: 0;
	
	background: radial-gradient(
		130% 190% at var(--lit-flash-x, 30%) 50%,
		rgba(226, 240, 255, 0.85),
		rgba(150, 200, 255, 0.28) 42%,
		transparent 74%
	);
	opacity: 0;
	animation: flairStormFlash var(--lit-flash-dur, 9s) linear var(--lit-flash-delay, 0s) infinite;
}

@keyframes flairStormHaze {
	0%,
	100% {
		opacity: 0.45;
	}
	50% {
		opacity: 0.85;
	}
}

@keyframes flairStormFlash {
	0%,
	5% {
		opacity: 0;
	}
	6.5% {
		opacity: var(--lit-flash-peak, 0.3);
	}
	8% {
		opacity: 0.04;
	}
	9.5% {
		opacity: calc(var(--lit-flash-peak, 0.3) * 0.65);
	}
	12%,
	46% {
		opacity: 0;
	}
	47.5% {
		opacity: calc(var(--lit-flash-peak, 0.3) * 1.75);
	}
	49% {
		opacity: 0.06;
	}
	50.5% {
		opacity: calc(var(--lit-flash-peak, 0.3) * 1.2);
	}
	52% {
		opacity: 0.03;
	}
	53.5% {
		opacity: calc(var(--lit-flash-peak, 0.3) * 0.5);
	}
	57%,
	100% {
		opacity: 0;
	}
}

.flair-neon {
	overflow-x: clip;
	overflow-y: visible;
	
	text-shadow: 0 0 7px color-mix(in srgb, var(--neon-halo, #ff5cb0) 38%, transparent);
}

.flair-neon::before {
	inset: 0;
	border: 3px solid var(--neon-lit, #ff2d95);
	border-radius: 6px;
	box-shadow:
		0 0 2px var(--neon-lit, #ff2d95),
		0 0 var(--neon-bloom, 8px) var(--neon-halo, #ff5cb0),
		0 0 calc(var(--neon-bloom, 8px) * 2.6) color-mix(in srgb, var(--neon-halo, #ff5cb0) 34%, transparent),
		inset 0 0 2px var(--neon-lit, #ff2d95),
		inset 0 0 var(--neon-bloom, 8px) color-mix(in srgb, var(--neon-halo, #ff5cb0) 62%, transparent),
		inset 0 0 calc(var(--neon-bloom, 8px) * 4) color-mix(in srgb, var(--neon-lit, #ff2d95) 26%, transparent);
	animation: flairNeonHum var(--neon-hum-dur, 0.9s) linear var(--neon-hum-delay, 0s) infinite;
}

.flair-neon::after {
	inset: 1px;
	border: 1px solid #ffffff;
	border-radius: 5px;
	box-shadow:
		0 0 2px rgba(255, 255, 255, 0.65),
		inset 0 0 2px rgba(255, 255, 255, 0.5);
	animation: flairNeonHum var(--neon-hum-dur, 0.9s) linear var(--neon-hum-delay, 0s) infinite;
}

.line.flair.flair-neon {
	margin-bottom: 12px;
}

.flairScan {
	position: absolute;
	inset: 0;
	z-index: 1;
	pointer-events: none;
	
	border-radius: inherit;
	background: repeating-linear-gradient(
		0deg,
		var(--scanline-color) 0px,
		var(--scanline-color) 1px,
		transparent 1px,
		transparent 3px
	);
}

html.retro .flairScan {
	display: none;
}

.flair-neon .flairScan {
	border-radius: 6px;
}

@keyframes flairNeonHum {
	0% {
		opacity: 0.93;
	}
	13% {
		opacity: 1;
	}
	19% {
		opacity: 0.88;
	}
	34% {
		opacity: 0.99;
	}
	48% {
		opacity: 0.92;
	}
	57% {
		opacity: 1;
	}
	71% {
		opacity: 0.9;
	}
	86% {
		opacity: 0.97;
	}
	100% {
		opacity: 0.93;
	}
}

.line.arrive.flair-neon:not(.flairQuiet)::before,
.line.arrive.flair-neon:not(.flairQuiet)::after {
	animation:
		flairNeonHum var(--neon-hum-dur, 0.9s) linear var(--neon-hum-delay, 0s) infinite,
		flairNeonStrike 1.05s linear 1;
}

@keyframes flairNeonStrike {
	0%,
	6% {
		opacity: 0;
	}
	8% {
		opacity: 1;
	}
	12% {
		opacity: 0.04;
	}
	21% {
		opacity: 0;
	}
	23% {
		opacity: 0.92;
	}
	27% {
		opacity: 0.08;
	}
	34% {
		opacity: 0.88;
	}
	38% {
		opacity: 0.12;
	}
	46% {
		opacity: 1;
	}
	51% {
		opacity: 0.35;
	}
	59% {
		opacity: 1;
	}
	66% {
		opacity: 0.72;
	}
	100% {
		opacity: 1;
	}
}

.flair-neon::before,
.flair-neon::after {
	z-index: -2;
}

.flair-neon > .flairFx {
	inset: 0;
	opacity: 1;
	z-index: -1;
}

.flair-neon .neonDead {
	position: absolute;
	top: var(--neon-dead-top, -9px);
	bottom: var(--neon-dead-bottom, auto);
	left: var(--neon-dead-x, 22%);
	width: var(--neon-dead-w, 24%);
	
	height: 24px;
	background: radial-gradient(ellipse closest-side, var(--bg) 0 45%, transparent 100%);
	opacity: 0;
	animation: flairNeonDead var(--neon-dead-dur, 15s) linear var(--neon-dead-delay, 0s) infinite;
}

@keyframes flairNeonDead {
	0%,
	87.4% {
		opacity: 0;
	}
	87.5% {
		opacity: 1;
	}
	88.1% {
		opacity: 0;
	}
	88.4% {
		opacity: 1;
	}
	89.6% {
		opacity: 1;
	}
	89.9% {
		opacity: 0;
	}
	90.6% {
		opacity: 0.85;
	}
	91% {
		opacity: 0;
	}
	91.4% {
		opacity: 1;
	}
	92.1% {
		opacity: 0;
	}
	100% {
		opacity: 0;
	}
}

.flair-matrix::before {
	inset: 0;
	background: linear-gradient(180deg, rgba(0, 255, 65, 0.15), rgba(0, 255, 65, 0.05) 55%, transparent);
	animation: flairMatrixWash var(--mtx-wash-dur, 6s) ease-in-out var(--mtx-wash-delay, 0s) infinite;
}

.flair-matrix::after {
	left: 0;
	right: 0;
	bottom: -1px;
	height: 9px;
	background: linear-gradient(0deg, rgba(0, 255, 65, 0.3), transparent);
	animation: flairMatrixWash var(--mtx-wash-dur, 6s) ease-in-out var(--mtx-wash-delay, 0s) infinite;
}

@keyframes flairMatrixWash {
	0%,
	100% {
		opacity: calc(var(--mtx-wash-peak, 0.7) * 0.55);
	}
	50% {
		opacity: var(--mtx-wash-peak, 0.7);
	}
}

.flair-matrix > .flairFx {
	inset: 0;
	opacity: 1;
	overflow: hidden;
}

.flair-matrix .mtxCol {
	position: absolute;
	left: var(--m-x, 20%);
	top: 0;
	
	height: 100%;
	display: flex;
	flex-direction: column;
	
	justify-content: flex-end;
	font-size: var(--m-size, 10px);
	line-height: 1;
	
	font-family: "Hiragino Kaku Gothic ProN", "Yu Gothic", "Noto Sans CJK JP", "Noto Sans JP", "MS Gothic", monospace;
	white-space: nowrap;
	opacity: var(--m-op, 0.8);
	
	animation: flairMatrixFall var(--m-fall, 0.9s) steps(8) var(--m-delay, 0s) infinite;
}

.flair-matrix .mtxGlyph,
.flair-matrix .mtxHead {
	display: block;
	width: 1em;
	height: 1em;
	text-align: center;
	overflow: hidden;
}

.flair-matrix .mtxGlyph {
	color: #22ff5e;
	opacity: var(--m-dim, 0.5);
	text-shadow: 0 0 4px rgba(0, 255, 65, 0.5);
}

.flair-matrix .mtxHead {
	color: #eaffef;
	text-shadow:
		0 0 3px rgba(216, 255, 230, 0.9),
		0 0 7px rgba(0, 255, 65, 0.95),
		0 0 14px rgba(0, 255, 65, 0.5);
}

.flair-matrix .mtxReel {
	display: block;
	animation: flairMatrixReel var(--m-reel, 0.8s) steps(5) var(--m-reel-delay, 0s) infinite;
}

.flair-matrix .mtxReel i {
	display: block;
	width: 1em;
	height: 1em;
	font-style: normal;
}

@keyframes flairMatrixReel {
	to {
		transform: translateY(-5em);
	}
}

@keyframes flairMatrixFall {
	0% {
		transform: translateY(-140%);
		opacity: 0;
	}
	9% {
		opacity: var(--m-op, 0.85);
	}
	88% {
		opacity: var(--m-op, 0.85);
	}
	100% {
		transform: translateY(115%);
		opacity: 0;
	}
}

.flair-matrix .fmtRainbow {
	background-image: repeating-linear-gradient(
		var(--ba-rainbow-angle, 90deg),
		#00913a 0%,
		#00ff41 9%,
		#d8ffe6 13%,
		#d8ffe6 14.2%,
		#00ff41 18%,
		#00913a 27%,
		#00913a 33%,
		#00ff41 39%,
		#d8ffe6 42%,
		#d8ffe6 43.2%,
		#00ff41 47%,
		#00913a 54%,
		#00913a 60%
	);
	animation-duration: var(--mtx-text-dur, 5s);
	animation-delay: var(--mtx-text-delay, 0s);
	text-decoration-color: #00ff41;
}

.flair-sonar::before {
	inset: 0;
	
	background:
		radial-gradient(
			circle at var(--son-x, 30%) var(--son-y, 50%),
			rgba(46, 255, 160, 0.3),
			rgba(46, 255, 160, 0.1) 42%,
			transparent 78%
		),
		linear-gradient(rgba(46, 255, 160, 0.075), rgba(46, 255, 160, 0.075));
	opacity: var(--son-wash-peak, 0.75);
	animation: flairSonarWash var(--son-wash-dur, 7s) ease-in-out var(--son-wash-delay, 0s) infinite;
}

@keyframes flairSonarWash {
	0%,
	100% {
		opacity: calc(var(--son-wash-peak, 0.75) * 0.5);
	}
	50% {
		opacity: var(--son-wash-peak, 0.75);
	}
}

.flair-sonar > .flairFx {
	inset: 0;
	opacity: 1;
	overflow: hidden;
}

.flair-sonar .ping {
	position: absolute;
	left: calc(var(--son-x, 30%) - var(--son-reach, 170px) / 2);
	top: calc(var(--son-y, 50%) - var(--son-reach, 170px) / 2);
	width: var(--son-reach, 170px);
	height: var(--son-reach, 170px);
	opacity: 0;
	pointer-events: none;
	/* The wavefront is drawn as vector circles and animated through their radius,
	   not as a border on a transform-scaled box. Scaling a rounded 2px border is
	   what produced the thin cross through the middle of the rings on some frames;
	   animating r keeps every frame a clean circle in both engines. */
	animation: flairSonarPing var(--son-ping, 10s) linear
		calc(var(--son-phase, 0s) - var(--son-ping, 10s) * var(--r-i, 0) * var(--son-gap, 0.09)) infinite;
}

.flair-sonar .ping svg {
	display: block;
	width: 100%;
	height: 100%;
	overflow: visible;
}

.flair-sonar .ping circle {
	fill: none;
	animation: flairSonarRing var(--son-ping, 10s) linear
		calc(var(--son-phase, 0s) - var(--son-ping, 10s) * var(--r-i, 0) * var(--son-gap, 0.09)) infinite;
}

.flair-sonar .pingCore {
	stroke: rgba(125, 255, 194, 0.95);
	--son-stroke-min: 0.1;
	--son-stroke-max: 0.9;
}

.flair-sonar .pingHalo {
	stroke: rgba(46, 255, 160, 0.24);
	--son-stroke-min: 0.5;
	--son-stroke-max: 3.2;
}

@keyframes flairSonarPing {
	0% {
		opacity: 0;
	}
	4% {
		opacity: var(--son-lit, 0.9);
	}
	16% {
		opacity: calc(var(--son-lit, 0.9) * 0.42);
	}
	31% {
		opacity: calc(var(--son-lit, 0.9) * 0.14);
	}
	45%,
	100% {
		opacity: 0;
	}
}

@keyframes flairSonarRing {
	0% {
		r: 5px;
		stroke-width: var(--son-stroke-min, 0.1);
	}
	45%,
	100% {
		r: 50px;
		stroke-width: var(--son-stroke-max, 0.9);
	}
}

.flair-sonar .blip {
	position: absolute;
	left: calc(var(--son-x, 30%) + var(--b-dx, 60px));
	top: calc(var(--son-y, 50%) + var(--b-dy, 0px));
	width: 0;
	height: 0;
	opacity: 0;
}

.flair-sonar .blipDot {
	position: absolute;
	left: -3px;
	top: -3px;
	width: 6px;
	height: 6px;
	border-radius: 50%;
	background: radial-gradient(circle, #ffffff 0%, #b6ffdd 38%, rgba(46, 255, 160, 0) 75%);
	box-shadow:
		0 0 8px rgba(125, 255, 194, 0.9),
		0 0 16px rgba(46, 255, 160, 0.45);
}

.flair-sonar .fmtRainbow {
	background-image: repeating-linear-gradient(
		var(--ba-rainbow-angle, 90deg),
		#f2fff9 0%,
		#f2fff9 0.5%,
		#9dffd2 2%,
		#45f2a8 6%,
		#1cc47c 12%,
		#12a06a 20%,
		#0e8256 30%,
		#0c7049 40%,
		#0c7049 50%
	);
	animation-duration: var(--son-text-dur, 9s);
	animation-delay: var(--son-text-delay, 0s);
	text-decoration-color: #2ee39a;
}

.flair-fireflies::before {
	inset: 0;
	
	background:
		linear-gradient(90deg, rgba(154, 224, 74, 0.26), rgba(126, 196, 66, 0.09) 58%, transparent),
		linear-gradient(rgba(122, 192, 62, 0.07), rgba(122, 192, 62, 0.07));
	opacity: var(--fly-wash-peak, 0.65);
	animation: flairFlyWash var(--fly-wash-dur, 8s) ease-in-out var(--fly-wash-delay, 0s) infinite;
}

@keyframes flairFlyWash {
	0%,
	100% {
		opacity: calc(var(--fly-wash-peak, 0.6) * 0.55);
	}
	50% {
		opacity: var(--fly-wash-peak, 0.6);
	}
}

.flair-fireflies > .flairFx {
	inset: 0;
	opacity: 1;
	overflow: hidden;
}

.flair-fireflies .fly {
	position: absolute;
	left: var(--f-x, 40%);
	top: var(--f-y, 50%);
	width: var(--f-size, 11px);
	height: var(--f-size, 11px);
	
	margin: calc(var(--f-size, 11px) / -2) 0 0 calc(var(--f-size, 11px) / -2);
	border-radius: 50%;
	color: var(--f-tint, #d4ff6a);
	
	background:
		radial-gradient(circle, rgba(255, 255, 250, 0.98) 0%, rgba(255, 255, 250, 0.92) 9%, rgba(255, 255, 250, 0) 30%),
		radial-gradient(circle, currentColor 0%, currentColor 22%, transparent 70%);
	opacity: 0;
	animation:
		flairFlyDrift var(--f-drift, 6s) ease-in-out var(--f-drift-delay, 0s) infinite alternate,
		flairFlyBob var(--f-bob, 4s) ease-in-out var(--f-bob-delay, 0s) infinite alternate,
		flairFlyGlow var(--f-glow, 4.5s) ease-in-out var(--f-glow-delay, 0s) infinite;
}

@keyframes flairFlyDrift {
	from {
		translate: calc(var(--f-ax, 16px) * -1) 0;
	}
	to {
		translate: var(--f-ax, 16px) 0;
	}
}

@keyframes flairFlyBob {
	from {
		transform: translate3d(0, calc(var(--f-ay, 5px) * -1), 0);
	}
	to {
		transform: translate3d(0, var(--f-ay, 5px), 0);
	}
}

@keyframes flairFlyGlow {
	0% {
		opacity: 0;
	}
	11% {
		opacity: calc(var(--f-peak, 0.9) * 0.28);
	}
	21% {
		opacity: var(--f-peak, 0.9);
	}
	27% {
		opacity: calc(var(--f-peak, 0.9) * 0.82);
	}
	40% {
		opacity: calc(var(--f-peak, 0.9) * 0.17);
	}
	52% {
		opacity: 0;
	}
	100% {
		opacity: 0;
	}
}

.flair-fireflies .fmtRainbow {
	background-image: repeating-linear-gradient(
		var(--ba-rainbow-angle, 90deg),
		#4d7a24 0%,
		#7fbf2f 10%,
		#b6f542 20%,
		#e4ff9b 27%,
		#f7ffd6 31%,
		#d4ff6a 36%,
		#8fcc38 46%,
		#4d7a24 56%
	);
	animation-duration: var(--fly-text-dur, 8s);
	animation-delay: var(--fly-text-delay, 0s);
	text-decoration-color: #c8ff5a;
}

.flair-aurora::before {
	left: var(--aur-star-x, 18px);
	top: var(--aur-star-y, 22%);
	width: 2px;
	height: 2px;
	border-radius: 50%;
	background: #ffffff;
	box-shadow: var(--aur-stars, 60px -14px #ffffff, 150px 8px #cfe6ff, 260px -7px #dbe9ff);
	opacity: 0.55;
	animation: flairAuroraStars var(--aur-star-dur, 6s) ease-in-out var(--aur-star-delay, 0s) infinite alternate;
}

/* The sky's ambient wash. Kept very soft and mostly above the text so the bright
   curtains, not a flat rectangle, are what the eye reads. */
.flair-aurora::after {
	inset: -40% -10% -12%;
	background:
		radial-gradient(ellipse at 22% 4%, rgba(71, 255, 178, 0.22), transparent 52%),
		radial-gradient(ellipse at 56% 0%, rgba(72, 218, 255, 0.18), transparent 56%),
		radial-gradient(ellipse at 84% 14%, rgba(156, 118, 255, 0.17), transparent 58%),
		linear-gradient(180deg, rgba(40, 210, 158, 0.09), transparent 54%);
	filter: blur(9px);
	opacity: 0.85;
	animation: flairAuroraGlow var(--aur-glow-dur, 12s) ease-in-out var(--aur-glow-delay, 0s) infinite;
}

.flair-aurora > .flairFx {
	inset: -58% -7% -16%;
	opacity: 1;
	overflow: hidden;
	mix-blend-mode: screen;
	filter: blur(4.5px) saturate(1.3);
	-webkit-mask-image: linear-gradient(180deg, transparent 0%, rgba(0, 0, 0, 0.22) 28%, #000 62%, #000 82%, transparent 100%);
	mask-image: linear-gradient(180deg, transparent 0%, rgba(0, 0, 0, 0.22) 28%, #000 62%, #000 82%, transparent 100%);
}

/* A curtain is three things in one element: a vertical fade (the green crown giving
   way to teal and then violet), a pair of diagonal folds, and fine vertical rays.
   The horizontal mask feathers its edges so no curtain ends in a hard rectangle. */
.flair-aurora .auroraCurtain {
	position: absolute;
	top: var(--c-top, -12%);
	bottom: var(--c-bottom, -6%);
	left: var(--c-x, 0%);
	width: var(--c-w, 24%);
	rotate: var(--c-rot, 0deg);
	transform-origin: 50% 0;
	background-image:
		linear-gradient(
			180deg,
			transparent 0%,
			transparent 18%,
			var(--c-top-color, rgba(80, 255, 190, 0.44)) 34%,
			var(--c-mid-color, rgba(60, 235, 210, 0.26)) 58%,
			var(--c-low-color, rgba(70, 160, 255, 0.16)) 78%,
			transparent 100%
		),
		linear-gradient(
			102deg,
			transparent 10%,
			rgba(218, 255, 235, 0.2) 26%,
			transparent 40%,
			rgba(150, 205, 255, 0.16) 58%,
			transparent 74%
		),
		repeating-linear-gradient(
			93deg,
			transparent 0 var(--c-ray-gap, 13px),
			var(--c-ray-color, rgba(190, 255, 225, 0.26)) calc(var(--c-ray-gap, 13px) + 1px),
			transparent calc(var(--c-ray-gap, 13px) + 3px) calc(var(--c-ray-gap, 13px) * 2)
		);
	background-size: 100% 100%, 100% 100%, 100% 100%;
	background-blend-mode: screen;
	-webkit-mask-image: linear-gradient(90deg, transparent 0%, #000 18%, #000 82%, transparent 100%);
	mask-image: linear-gradient(90deg, transparent 0%, #000 18%, #000 82%, transparent 100%);
	opacity: 0.66;
	clip-path: polygon(2% 0, 98% 0, 92% 100%, 66% 91%, 44% 100%, 16% 93%);
	animation:
		flairAuroraSway var(--aur-sway-dur, 12s) ease-in-out calc(var(--aur-sway-delay, 0s) - var(--c-i, 0) * 1.1s) infinite alternate,
		flairAuroraBreathe var(--aur-curtain-dur, 16s) ease-in-out calc(var(--aur-curtain-delay, 0s) - var(--c-i, 0) * 1.7s) infinite;
}

.flair-aurora .auroraCurtain:nth-child(1) {
	--c-x: -9%;
	--c-w: 35%;
	--c-rot: -4deg;
	--c-top-color: rgba(80, 255, 186, 0.48);
	--c-mid-color: rgba(58, 244, 206, 0.3);
	--c-low-color: rgba(63, 174, 255, 0.17);
	--c-ray-color: rgba(198, 255, 226, 0.3);
}

.flair-aurora .auroraCurtain:nth-child(2) {
	--c-x: 12%;
	--c-w: 27%;
	--c-rot: 2deg;
	--c-top-color: rgba(118, 255, 206, 0.34);
	--c-mid-color: rgba(58, 234, 224, 0.22);
	--c-low-color: rgba(88, 142, 255, 0.14);
	--c-ray-gap: 11px;
}

.flair-aurora .auroraCurtain:nth-child(3) {
	--c-x: 30%;
	--c-w: 32%;
	--c-rot: -2deg;
	--c-top-color: rgba(68, 255, 164, 0.42);
	--c-mid-color: rgba(54, 255, 202, 0.24);
	--c-low-color: rgba(143, 112, 255, 0.16);
	--c-ray-color: rgba(184, 255, 216, 0.24);
	--c-ray-gap: 16px;
}

.flair-aurora .auroraCurtain:nth-child(4) {
	--c-x: 54%;
	--c-w: 26%;
	--c-rot: 3deg;
	--c-top-color: rgba(92, 224, 255, 0.4);
	--c-mid-color: rgba(84, 168, 255, 0.24);
	--c-low-color: rgba(186, 112, 255, 0.17);
	--c-ray-color: rgba(196, 230, 255, 0.26);
	--c-ray-gap: 12px;
}

.flair-aurora .auroraCurtain:nth-child(5) {
	--c-x: 73%;
	--c-w: 32%;
	--c-rot: -3deg;
	--c-top-color: rgba(168, 132, 255, 0.34);
	--c-mid-color: rgba(108, 146, 255, 0.22);
	--c-low-color: rgba(54, 235, 205, 0.14);
	--c-ray-gap: 15px;
}

/* One narrow, brighter fold through the middle of the display. */
.flair-aurora .auroraCurtain:nth-child(6) {
	--c-x: 43%;
	--c-w: 15%;
	--c-top: -20%;
	--c-bottom: -10%;
	--c-rot: 1deg;
	--c-top-color: rgba(190, 255, 218, 0.34);
	--c-mid-color: rgba(116, 255, 226, 0.2);
	--c-low-color: rgba(100, 160, 255, 0.12);
	--c-ray-color: rgba(235, 255, 242, 0.34);
	--c-ray-gap: 8px;
	opacity: 0.56;
}

@keyframes flairAuroraSway {
	from {
		transform: translate3d(-20px, 0, 0) skewX(-4deg) scaleY(0.94);
	}
	to {
		transform: translate3d(24px, 0, 0) skewX(5deg) scaleY(1.08);
	}
}

@keyframes flairAuroraBreathe {
	0%,
	100% {
		opacity: 0.34;
	}
	42% {
		opacity: 0.86;
	}
	68% {
		opacity: 0.52;
	}
}

@keyframes flairAuroraGlow {
	0%,
	100% {
		opacity: 0.44;
	}
	50% {
		opacity: 0.88;
	}
}

@keyframes flairAuroraStars {
	from {
		opacity: 0.28;
		transform: translateY(-2px);
	}
	to {
		opacity: 0.72;
		transform: translateY(2px);
	}
}

.flair-aurora .fmtRainbow {
	background-image: repeating-linear-gradient(
		var(--ba-rainbow-angle, 90deg),
		#1fd98a 0%,
		#3dffa8 8%,
		#7cffd4 15%,
		#2fe6d0 23%,
		#31c7ff 32%,
		#6f9bff 40%,
		#8b6cff 48%,
		#b46cff 55%,
		#6f9bff 63%,
		#2fe6d0 72%,
		#1fd98a 82%
	);
	animation-duration: var(--aur-text-dur, 11s);
	animation-delay: var(--aur-text-delay, 0s);
	text-decoration-color: #7cffd4;
}

.flair-sol::before {
	inset: 0;
	
	background-image:
		radial-gradient(
			145% 190% at -8% 50%,
			rgba(255, 253, 245, 0.92) 0%,
			rgba(255, 250, 231, 0.68) 10%,
			rgba(255, 246, 219, 0.4) 21%,
			rgba(226, 240, 252, 0.22) 38%,
			rgba(190, 222, 246, 0) 68%
		),
		linear-gradient(
			90deg,
			rgba(246, 251, 255, 0.3) 0%,
			rgba(232, 244, 253, 0.2) 26%,
			rgba(118, 176, 224, 0.3) 68%,
			rgba(92, 158, 214, 0.46) 100%
		),
		linear-gradient(rgba(176, 212, 238, 1) 0 0);
	opacity: var(--sol-glare, 0.9);
	animation: flairSolGlow var(--sol-glow-dur, 15s) ease-in-out var(--sol-glow-delay, 0s) infinite;
}

.flair-sol::after {
	inset: 0;
	background-image: radial-gradient(
		34% 132% at -5% 50%,
		rgba(255, 255, 255, 1) 0%,
		rgba(255, 255, 252, 0.94) 14%,
		rgba(255, 251, 234, 0.55) 34%,
		rgba(255, 246, 222, 0) 100%
	);
	
	opacity: 0.8;
	animation: flairSolBloom var(--sol-shim-dur, 7s) ease-in-out var(--sol-shim-delay, 0s) infinite;
}

.flair-sol > .flairFx {
	inset: 0;
	opacity: 1;
}

.flair-sol .ray {
	position: absolute;
	left: var(--r-x, -4%);
	top: var(--r-y, 50%);
	width: var(--r-len, 260px);
	height: var(--r-thick, 14px);
	margin-top: calc(var(--r-thick, 14px) / -2);
	
	transform-origin: 0% 50%;
	rotate: var(--r-ang, 0deg);
	
	background-image: linear-gradient(
		90deg,
		rgba(255, 255, 255, var(--r-peak, 0.85)) 0%,
		rgba(255, 255, 253, var(--r-peak, 0.85)) 34%,
		rgba(255, 252, 240, calc(var(--r-peak, 0.85) * 0.72)) 62%,
		rgba(255, 248, 226, calc(var(--r-peak, 0.85) * 0.3)) 84%,
		transparent 100%
	);
	
	clip-path: polygon(0% 40%, 100% 0%, 100% 100%, 0% 60%);
	
	-webkit-mask-image: linear-gradient(180deg, transparent 0%, rgba(0, 0, 0, 0.65) 26%, #000 50%, rgba(0, 0, 0, 0.65) 74%, transparent 100%);
	mask-image: linear-gradient(180deg, transparent 0%, rgba(0, 0, 0, 0.65) 26%, #000 50%, rgba(0, 0, 0, 0.65) 74%, transparent 100%);
	opacity: 0;
	pointer-events: none;
	animation:
		flairSolRayReach var(--r-reach-dur, 9s) ease-in-out var(--r-reach-delay, 0s) infinite alternate,
		flairSolRayTurn var(--r-turn-dur, 13s) ease-in-out var(--r-turn-delay, 0s) infinite alternate,
		flairSolRayFlare var(--r-flare-dur, 6s) ease-in-out var(--r-flare-delay, 0s) infinite;
}

@keyframes flairSolRayReach {
	from {
		transform: scaleX(var(--r-min, 0.55));
	}
	to {
		transform: scaleX(var(--r-max, 1));
	}
}

@keyframes flairSolRayTurn {
	from {
		rotate: calc(var(--r-ang, 0deg) - var(--r-swing, 4deg));
	}
	to {
		rotate: calc(var(--r-ang, 0deg) + var(--r-swing, 4deg));
	}
}

@keyframes flairSolRayFlare {
	0%,
	100% {
		opacity: 0;
	}
	16% {
		opacity: calc(var(--r-peak, 0.55) * 0.55);
	}
	38% {
		opacity: var(--r-peak, 0.55);
	}
	57% {
		opacity: calc(var(--r-peak, 0.55) * 0.62);
	}
	74% {
		opacity: calc(var(--r-peak, 0.55) * 0.9);
	}
	92% {
		opacity: 0;
	}
}

@keyframes flairSolBloom {
	0%,
	100% {
		opacity: 0.62;
	}
	44% {
		opacity: 0.95;
	}
	72% {
		opacity: 0.74;
	}
}

@keyframes flairSolGlow {
	0%,
	100% {
		opacity: calc(var(--sol-glare, 0.9) * 0.82);
	}
	50% {
		opacity: var(--sol-glare, 0.9);
	}
}

.flair-sol .fmtRainbow {
	background-image: repeating-linear-gradient(
		var(--ba-rainbow-angle, 90deg),
		#ffffff 0%,
		#fffdf6 10%,
		#fff8e4 19%,
		#ffefc6 27%,
		#fff7e0 36%,
		#ffffff 47%,
		#fffefa 57%,
		#fff4d4 68%,
		#fffaea 79%,
		#ffffff 90%
	);
	animation-duration: var(--sol-text-dur, 11s);
	animation-delay: var(--sol-text-delay, 0s);
	text-decoration-color: #fff4d4;
}

.flair-bitcoin {
	
	--cir-core: rgba(255, 212, 105, 0.55);
	--cir-glow: rgba(247, 179, 43, 0.75);
	--cir-halo: rgba(247, 147, 26, 0.4);
}

.flair-bitcoin::before {
	inset: 0;
	background:
		linear-gradient(90deg, rgba(247, 147, 26, 0.12), rgba(8, 8, 10, 0.92) 58%, rgba(255, 212, 105, 0.1)),
		#08080a;
}

.flair-bitcoin > .flairFx {
	inset: 0;
	opacity: 1;
}

.flair-bitcoin .cirSeg {
	position: absolute;
	left: var(--c-x, 0%);
	top: var(--c-y, 6px);
	width: var(--c-w, 10%);
	height: var(--c-h, 1px);
	background: var(--cir-core);
	
	box-shadow:
		0 0 4px var(--cir-glow),
		0 0 12px var(--cir-halo);
	opacity: 0.1;
}

.flair-bitcoin .cirCoinWrap {
	position: absolute;
	right: 6px;
	top: 50%;
	
	height: 84%;
	aspect-ratio: 1;
	transform: translateY(-50%);
	border-radius: 50%;
	box-shadow:
		0 0 6px var(--cir-glow),
		0 0 16px var(--cir-halo);
	opacity: 0.12;
}

.flair-bitcoin .cirCoin {
	display: block;
	width: 100%;
	height: 100%;
	fill: var(--cir-core);
}

.flair-bitcoin.flairQuiet > .flairFx { display: block; opacity: 1; }
.flair-bitcoin.flairQuiet .cirSeg { opacity: 0.3; }
.flair-bitcoin.flairQuiet .cirCoinWrap { opacity: 0.38; }

.flairChip.flair-bitcoin .cirSeg,
.fmtPreviewLine.flair-bitcoin .cirSeg {
	opacity: 0.42;
}

.flairChip.flair-bitcoin .cirCoinWrap,
.fmtPreviewLine.flair-bitcoin .cirCoinWrap {
	opacity: 0.5;
}

.flair-glitch {
	--gl-cyan: #37e8ff;
	--gl-magenta: #ff3ba7;
}

.flair-glitch::before {
	inset: 0;
	background: linear-gradient(90deg, rgba(55, 232, 255, 0.16), rgba(255, 59, 167, 0.07) 46%, rgba(55, 232, 255, 0.13) 100%);
	opacity: var(--gl-wash-peak, 0.75);
	animation: flairGlitchWash var(--gl-wash-dur, 7s) ease-in-out var(--gl-wash-delay, 0s) infinite;
}

.flair-glitch::after {
	inset: 0;
	background: linear-gradient(
		180deg,
		transparent 44%,
		rgba(55, 232, 255, 0.1) 47%,
		rgba(255, 255, 255, 0.16) 50%,
		rgba(255, 59, 167, 0.1) 53%,
		transparent 56%
	);
	animation: flairGlitchTrack var(--gl-track-dur, 9s) linear var(--gl-track-delay, 0s) infinite;
}

.flair-glitch > .flairFx {
	inset: 0;
	opacity: 1;
	visibility: visible;
}

.flairFx .tear {
	position: absolute;
	inset: 0;
	pointer-events: none;
}

.flairFx .tearBand {
	position: absolute;
	inset: 0;
	
	text-shadow:
		1.5px 0 rgba(255, 59, 167, 0.55),
		-1.5px 0 rgba(55, 232, 255, 0.55);
}

.flair-glitch .fmtRainbow {
	background-image: repeating-linear-gradient(var(--ba-rainbow-angle, 90deg), #37e8ff 0%, #b9f4ff 16%, #ff3ba7 34%, #ffd0e8 52%, #37e8ff 74%, #7de6ff 88%, #37e8ff 100%);
	animation-duration: var(--gl-text-dur, 8s);
	animation-delay: var(--gl-text-delay, 0s);
	text-decoration-color: #ff3ba7;
}

.flair-bitcoin .fmtRainbow {
	background-image: repeating-linear-gradient(var(--ba-rainbow-angle, 90deg), #b8791a 0%, #ffd469 22%, #fff0c2 38%, #ffb63d 58%, #a5670f 78%, #b8791a 100%);
	animation-duration: var(--cir-text-dur, 9s);
	animation-delay: var(--cir-text-delay, 0s);
	text-decoration-color: #ffd469;
}

.flair-bubbles::before {
	inset: 0;
	
	background:
		linear-gradient(90deg, rgba(79, 200, 216, 0.22), rgba(110, 232, 234, 0.08) 62%, transparent),
		linear-gradient(rgba(95, 224, 216, 0.06), rgba(95, 224, 216, 0.06));
	opacity: var(--bub-wash-peak, 0.66);
	animation: flairBubWash var(--bub-wash-dur, 10s) ease-in-out var(--bub-wash-delay, 0s) infinite;
}

@keyframes flairBubWash {
	0%,
	100% {
		opacity: calc(var(--bub-wash-peak, 0.66) * 0.62);
	}
	50% {
		opacity: var(--bub-wash-peak, 0.66);
	}
}

.flair-bubbles::after {
	left: var(--fizz-left, 20px);
	top: 100%;
	width: 1px;
	height: 1px;
	border-radius: 50%;
	background: rgba(168, 247, 240, 0.75);
	box-shadow: var(--fizz-field, 44px 0 #7ef0e6, 104px 0 #5fe0d8, 166px 0 #a8f7f0, 232px 0 #4fc8d8);
	opacity: 0.55;
	animation: flairFizzRise var(--fizz-dur, 4.6s) linear var(--fizz-delay, 0s) infinite;
}

@keyframes flairFizzRise {
	0% {
		translate: 0 0;
		opacity: 0;
	}
	14% {
		opacity: 0.5;
	}
	70% {
		translate: var(--fizz-x2, 4px) -1.6em;
		opacity: 0.28;
	}
	100% {
		translate: var(--fizz-x3, 7px) -2.4em;
		opacity: 0;
	}
}

.flair-bubbles > .flairFx {
	inset: 0;
	opacity: 1;
	overflow: hidden;
}

.flair-bubbles .bubble {
	position: absolute;
	bottom: -3px;
	left: var(--b-x, 30%);
	width: var(--b-size, 7px);
	height: var(--b-size, 7px);
	box-sizing: border-box;
	border-radius: 50%;
	color: var(--b-tint, #7ef0e6);
	border: 1px solid currentColor;
	background: radial-gradient(circle at 32% 30%, rgba(255, 255, 255, 0.1), rgba(255, 255, 255, 0.02) 55%, transparent 72%);
	opacity: 0;
	
	animation:
		bubbleRise var(--b-rise, 6s) linear var(--b-rise-delay, 0s) infinite,
		bubbleSway var(--b-sway, 3s) ease-in-out var(--b-sway-delay, 0s) infinite alternate,
		bubbleSwell var(--b-grow-dur, 6s) linear var(--b-rise-delay, 0s) infinite;
}

.flair-bubbles .bubble::before {
	content: "";
	position: absolute;
	left: 18%;
	top: 14%;
	width: 34%;
	height: 34%;
	border-radius: 50%;
	background: rgba(255, 255, 255, 0.85);
}

@keyframes bubbleRise {
	0% {
		translate: 0 0;
		opacity: 0;
	}
	8% {
		opacity: var(--b-peak, 0.8);
	}
	62% {
		opacity: calc(var(--b-peak, 0.8) * 0.72);
	}
	78% {
		translate: 0 calc(var(--b-lift, 2.2em) * -1);
		opacity: 0;
	}
	100% {
		translate: 0 calc(var(--b-lift, 2.2em) * -1);
		opacity: 0;
	}
}

.flair-bubbles .bubble.bubbleShort {
	animation-name: bubbleRiseShort, bubbleSway, bubbleSwell;
}

@keyframes bubbleRiseShort {
	0% {
		translate: 0 0;
		opacity: 0;
	}
	10% {
		opacity: calc(var(--b-peak, 0.8) * 0.85);
	}
	38% {
		opacity: calc(var(--b-peak, 0.8) * 0.4);
	}
	50% {
		translate: 0 calc(var(--b-lift, 2.2em) * -0.45);
		opacity: 0;
	}
	100% {
		translate: 0 calc(var(--b-lift, 2.2em) * -0.45);
		opacity: 0;
	}
}

@keyframes bubbleSway {
	from {
		transform: translate3d(calc(var(--b-amp, 12px) * -1), 0, 0);
	}
	to {
		transform: translate3d(var(--b-amp, 12px), 0, 0);
	}
}

@keyframes bubbleSwell {
	0% {
		scale: 1;
	}
	78% {
		scale: var(--b-grow, 1.18);
	}
	100% {
		scale: var(--b-grow, 1.18);
	}
}

.flair-bubbles .bubblePop {
	position: absolute;
	left: var(--p-x, 50%);
	top: var(--p-y, 25%);
	width: var(--p-size, 8px);
	height: var(--p-size, 8px);
	margin: calc(var(--p-size, 8px) / -2) 0 0 calc(var(--p-size, 8px) / -2);
	box-sizing: border-box;
	border-radius: 50%;
	color: var(--p-tint, #a8f7f0);
	border: 1px solid currentColor;
	opacity: 0;
	pointer-events: none;
}

.flair-bubbles .bubblePop .popRing {
	position: absolute;
	left: 50%;
	top: 50%;
	width: 100%;
	height: 100%;
	margin: -50% 0 0 -50%;
	border-radius: 50%;
	border: 1px solid currentColor;
	opacity: 0;
}

.flair-bubbles .fmtRainbow {
	background-image: repeating-linear-gradient(
		var(--ba-rainbow-angle, 90deg),
		#2f9fb5 0%,
		#4fc8d8 10%,
		#7ef0e6 20%,
		#c9fdfa 28%,
		#eaffff 32%,
		#a8f7f0 38%,
		#5fe0d8 48%,
		#2f9fb5 58%
	);
	animation-duration: var(--bub-text-dur, 9s);
	animation-delay: var(--bub-text-delay, 0s);
	text-decoration-color: #7ef0e6;
}

.flair-stars::before {
	left: var(--star-a-left, 8px);
	top: var(--star-a-top, 32%);
	width: 2px;
	height: 2px;
	border-radius: 50%;
	background: #ffffff;
	box-shadow: var(
		--star-a-field,
		34px -5px #cfe6ff,
		79px 9px #ffffff,
		124px -11px #a8ccff,
		181px 5px #ffffff,
		238px -8px #dbe9ff,
		296px 7px #ffffff,
		351px -4px #bcd8ff
	);
	animation: flairTwinkleA var(--star-a-dur, 2.6s) ease-in-out var(--star-a-delay, 0s) infinite;
}

.flair-stars::after {
	left: var(--star-b-left, 20px);
	top: var(--star-b-top, 62%);
	width: 2px;
	height: 2px;
	border-radius: 50%;
	background: #e9f2ff;
	box-shadow: var(
		--star-b-field,
		47px -12px #ffffff,
		99px 6px #b9d5ff,
		152px -7px #ffffff,
		214px 10px #d6e7ff,
		271px -10px #ffffff
	);
	animation: flairTwinkleB var(--star-b-dur, 3.4s) ease-in-out var(--star-b-delay, 0s) infinite;
}

@keyframes flairTwinkleA {
	0% {
		opacity: 0;
		transform: translate3d(0, 0, 0);
	}
	9% {
		opacity: 1;
	}
	28% {
		opacity: 0.18;
	}
	44% {
		opacity: 0.85;
	}
	49% {
		opacity: 0;
		transform: translate3d(0, 0, 0);
	}
	51% {
		opacity: 0;
		transform: translate3d(var(--star-a-dx, 7px), var(--star-a-dy, -5px), 0);
	}
	63% {
		opacity: 1;
	}
	81% {
		opacity: 0.2;
	}
	92% {
		opacity: 0.7;
	}
	99% {
		opacity: 0;
		transform: translate3d(var(--star-a-dx, 7px), var(--star-a-dy, -5px), 0);
	}
	100% {
		opacity: 0;
		transform: translate3d(0, 0, 0);
	}
}

@keyframes flairTwinkleB {
	0% {
		opacity: 0;
		transform: translate3d(0, 0, 0);
	}
	14% {
		opacity: 0.9;
	}
	33% {
		opacity: 0.15;
	}
	41% {
		opacity: 1;
	}
	47% {
		opacity: 0;
		transform: translate3d(0, 0, 0);
	}
	49% {
		opacity: 0;
		transform: translate3d(var(--star-b-dx, -9px), var(--star-b-dy, 6px), 0);
	}
	58% {
		opacity: 0.75;
	}
	72% {
		opacity: 1;
	}
	88% {
		opacity: 0.22;
	}
	99% {
		opacity: 0;
		transform: translate3d(var(--star-b-dx, -9px), var(--star-b-dy, 6px), 0);
	}
	100% {
		opacity: 0;
		transform: translate3d(0, 0, 0);
	}
}

.flair-rain::before {
	inset: 0;
	background: linear-gradient(90deg, rgba(120, 160, 195, 0.22), rgba(90, 130, 165, 0.07) 60%, transparent);
	animation: flairRainHaze var(--rain-haze-dur, 7s) ease-in-out var(--rain-haze-delay, 0s) infinite;
}

.flair-rain > .flairFx {
	inset: 0;
	opacity: 1;
	container-type: size;
}

.flair-rain .drop {
	position: absolute;
	top: 0;
	left: var(--d-x, 40%);
	width: 1.4px;
	height: var(--d-len, 7px);
	border-radius: 1px;
	background: linear-gradient(180deg, transparent, var(--d-tint, #cfe4f5));
	opacity: 0;
	rotate: var(--d-tilt, 7deg);
	animation: rainFall var(--d-fall, 0.5s) cubic-bezier(0.36, 0, 0.78, 0.34) var(--d-delay, 0s) infinite;
}

.flair-rain .drop::after {
	content: "";
	position: absolute;
	left: 50%;
	
	bottom: calc(var(--d-ring, 9px) * -0.18);
	width: var(--d-ring, 9px);
	height: calc(var(--d-ring, 9px) * 0.36);
	margin-left: calc(var(--d-ring, 9px) / -2);
	border: 1px solid var(--d-tint, #cfe4f5);
	border-radius: 50%;
	rotate: calc(var(--d-tilt, 7deg) * -1);
	opacity: 0;
	animation: rainRipple var(--d-fall, 0.5s) ease-out var(--d-delay, 0s) infinite;
}

@keyframes rainFall {
	0% {
		translate: 0 -12px;
		opacity: 0;
	}
	10% {
		opacity: var(--d-op, 0.8);
	}
	
	80% {
		translate: var(--d-lean, 3px) calc(100cqh - var(--d-len, 7px) - 6px);
		opacity: var(--d-op, 0.8);
	}
	
	87% {
		translate: var(--d-lean, 3px) calc(100cqh - var(--d-len, 7px) - 6px);
		opacity: 0;
	}
	100% {
		translate: var(--d-lean, 3px) calc(100cqh - var(--d-len, 7px) - 6px);
		opacity: 0;
	}
}

@keyframes rainRipple {
	0%,
	80% {
		transform: scale(0.2);
		opacity: 0;
	}
	85% {
		transform: scale(0.55);
		opacity: 0.9;
	}
	100% {
		transform: scale(2.1);
		opacity: 0;
	}
}

@keyframes flairRainHaze {
	0%,
	100% {
		opacity: calc(var(--rain-haze-peak, 0.8) * 0.6);
	}
	50% {
		opacity: var(--rain-haze-peak, 0.8);
	}
}

.flair-plume::before {
	inset: 0;
	background: linear-gradient(90deg, rgba(168, 85, 247, 0.3), rgba(124, 58, 237, 0.1) 20%, transparent 46%);
	transform-origin: left center;
	animation:
		flairPlumeWash var(--plume-wash-dur, 9s) ease-in-out var(--plume-wash-delay, 0s) infinite,
		flairPlumeReach var(--plume-reach-dur, 22s) ease-in-out var(--plume-reach-delay, 0s) infinite;
}

.flair-plume::after {
	inset: 0;
	
	background: linear-gradient(
		180deg,
		rgba(233, 213, 255, 0.3) 0%,
		rgba(240, 224, 255, 0.44) 5%,
		rgba(196, 148, 250, 0.2) 12%,
		rgba(139, 92, 246, 0.05) 22%,
		rgba(124, 58, 237, 0.03) 50%,
		rgba(139, 92, 246, 0.05) 78%,
		rgba(196, 148, 250, 0.21) 88%,
		rgba(240, 224, 255, 0.43) 95%,
		rgba(233, 213, 255, 0.28) 100%
	);
	-webkit-mask-image: linear-gradient(90deg, #000 0%, rgba(0, 0, 0, 0.34) 19%, transparent 47%);
	mask-image: linear-gradient(90deg, #000 0%, rgba(0, 0, 0, 0.34) 19%, transparent 47%);
	
	transform-origin: left center;
	animation:
		flairPlumeLamp var(--plume-lamp-dur, 13s) ease-in-out var(--plume-lamp-delay, 0s) infinite alternate,
		flairPlumeReach var(--plume-reach-dur, 22s) ease-in-out var(--plume-reach-delay, 0s) infinite;
}

.flair-plume > .flairFx {
	inset: 0;
	opacity: 1;
	isolation: isolate; 
	
	animation: flairPlumeWake 900ms ease-out;
	
	transition: opacity 700ms ease, display 700ms allow-discrete;
	
}

.flairChip.flair-plume > .flairFx {
	opacity: 0.5;
}

.flair-plume .puff {
	position: absolute;
	left: var(--p-x, 40%);
	top: var(--p-y, 50%);
	width: var(--p-size, 110px);
	height: var(--p-size, 110px);
	margin: calc(var(--p-size, 110px) / -2) 0 0 calc(var(--p-size, 110px) / -2);
	border-radius: 50%;
	background: radial-gradient(
		circle,
		var(--p-core, #f3e8ff) 0%,
		var(--p-core, #f3e8ff) 5%,
		var(--p-tint, #a855f7) 26%,
		color-mix(in srgb, var(--p-tint, #a855f7) 45%, transparent) 56%,
		transparent 74%
	);
	
	filter: blur(var(--p-blur, 12px));
	mix-blend-mode: screen;
	opacity: var(--p-op, 0.7);
	animation:
		plumeDrift var(--p-drift-dur, 11s) ease-in-out var(--p-drift-delay, 0s) infinite alternate,
		plumeSwell var(--p-swell-dur, 7s) ease-in-out var(--p-swell-delay, 0s) infinite alternate,
		plumeBreathe var(--p-breathe-dur, 8s) ease-in-out var(--p-breathe-delay, 0s) infinite alternate;
}

@keyframes plumeDrift {
	from {
		translate: 0 0;
	}
	to {
		translate: var(--p-dx, 18px) var(--p-dy, 6px);
	}
}

@keyframes plumeSwell {
	from {
		transform: scale(1);
	}
	to {
		transform: scale(var(--p-swell, 1.28));
	}
}

@keyframes plumeBreathe {
	from {
		opacity: calc(var(--p-op, 0.7) * 0.62);
	}
	to {
		opacity: var(--p-op, 0.7);
	}
}

@keyframes flairPlumeWake {
	from {
		opacity: 0;
	}
}

@keyframes flairPlumeWash {
	0%,
	100% {
		opacity: calc(var(--plume-wash-peak, 0.85) * 0.55);
	}
	50% {
		opacity: var(--plume-wash-peak, 0.85);
	}
}

@keyframes flairPlumeLamp {
	from {
		opacity: var(--plume-lamp-low, 0.45);
	}
	to {
		opacity: var(--plume-lamp-peak, 0.9);
	}
}

@keyframes flairPlumeReach {
	0%,
	16% {
		transform: scaleX(var(--plume-reach-min, 0.72));
	}
	26% {
		transform: scaleX(var(--plume-reach-max, 1.15));
	}
	38% {
		transform: scaleX(var(--plume-reach-min, 0.72));
	}
	48% {
		transform: scaleX(calc(var(--plume-reach-max, 1.15) * 0.88));
	}
	
	58% {
		transform: scaleX(var(--plume-reach-far, 2.6));
	}
	68% {
		transform: scaleX(var(--plume-reach-max, 1.15));
	}
	82%,
	100% {
		transform: scaleX(var(--plume-reach-min, 0.72));
	}
}

.flair-plume .mote {
	position: absolute;
	top: var(--m-y, 50%);
	left: var(--m-from, 90%);
	width: var(--m-size, 1.4px);
	height: var(--m-size, 1.4px);
	border-radius: 50%;
	background: var(--m-tint, #e9d5ff);
	box-shadow: 0 0 4px var(--m-tint, #e9d5ff);
	opacity: 0;
	animation: plumeMote var(--m-dur, 7s) linear var(--m-delay, 0s) infinite;
}

@keyframes plumeMote {
	0% {
		left: var(--m-from, 90%);
		translate: 0 0;
		opacity: 0;
	}
	
	18% {
		opacity: var(--m-op, 0.6);
	}
	
	82% {
		opacity: var(--m-op, 0.6);
	}
	100% {
		left: var(--m-to, 12%);
		translate: 0 var(--m-rise, 3px);
		opacity: 0;
	}
}

.flair-plume > .flairFx .surge {
	position: absolute;
	left: var(--ps-x, 50%);
	top: 50%;
	width: 200px;
	height: 200px;
	margin: -100px 0 0 -100px;
	border-radius: 50%;
	background: radial-gradient(
		circle,
		var(--ps-core, #f3e8ff) 0%,
		var(--ps-tint, #a855f7) 30%,
		color-mix(in srgb, var(--ps-tint, #a855f7) 38%, transparent) 55%,
		transparent 74%
	);
	filter: blur(16px);
	mix-blend-mode: screen;
	opacity: 0;
}

.flair-rain > .flairFx .gust {
	position: absolute;
	top: -20%;
	bottom: -20%;
	width: 45%;
	background: linear-gradient(90deg, transparent, rgba(198, 222, 240, 0.22) 45%, rgba(224, 238, 250, 0.3) 60%, transparent);
	rotate: var(--g-tilt, 12deg);
	opacity: 0;
}

.flairFx {
	position: absolute;
	pointer-events: none;
	opacity: 0;
	z-index: -1;
}

.flair-stars > .ba-shooting-star {
	position: absolute;
	left: 0;
	top: 0;
	height: 2px;
	border-radius: 2px;
	background: linear-gradient(90deg, rgba(255, 255, 255, 0), rgba(214, 234, 255, 0.35) 45%, #ffffff 100%);
	box-shadow: 0 0 7px rgba(219, 234, 254, 0.72);
	pointer-events: none;
	z-index: -1;
	opacity: 0;
}

.flair-stars > .flairFx {
	left: 0;
	top: 0;
	width: 44px;
	height: 2px;
	border-radius: 2px;
	background: linear-gradient(90deg, rgba(255, 255, 255, 0) 0%, rgba(214, 234, 255, 0.35) 45%, #ffffff 100%);
}

.flair-lightning > .flairFx {
	inset: 0;
	opacity: 1;
}

.flairFx .strike {
	position: absolute;
	inset: 0;
	opacity: 0;
}

.flairFx .boltFlash {
	position: absolute;
	inset: 0;
	background: radial-gradient(150% 220% at 50% 50%, rgba(240, 248, 255, 0.92), rgba(160, 205, 255, 0.4) 45%, transparent 78%);
}

.flairFx .boltSvg {
	position: absolute;
	inset: 0;
	display: block;
}

.boltGlow {
	fill: none;
	stroke: rgba(150, 200, 255, 0.85);
	stroke-width: 3.4;
	stroke-linejoin: round;
	stroke-linecap: round;
}

.boltCore {
	fill: none;
	stroke: #ffffff;
	stroke-width: 1.2;
	stroke-linejoin: round;
	stroke-linecap: round;
}

.flairQuiet:not(.flair-plume)::before,
.flairQuiet:not(.flair-plume)::after {
	animation: none;
}

.flair-plume.flairQuiet::before,
.flair-plume.flairQuiet::after {
	animation-play-state: paused;
}

.flairQuiet > .flairFx {
	display: none;
}

.flair-plume.flairQuiet > .flairFx {
	opacity: 0;
}

.flair-fire.flairQuiet::after,
.flair-lightning.flairQuiet::after {
	opacity: 0;
}

.flair-neon.flairQuiet::before,
.flair-neon.flairQuiet::after {
	opacity: 1;
}

.flair-lightning.flairQuiet .fmtRainbow,
.flair-fire.flairQuiet .fmtRainbow,
.flair-rain.flairQuiet .fmtRainbow,
.flair-neon.flairQuiet .fmtRainbow,
.flair-plume.flairQuiet .fmtRainbow {
	animation: none;
	filter: brightness(1);
}

.flair-rain.flairQuiet::after {
	opacity: 0.4;
}

.flair-stars.flairQuiet::before,
.flair-stars.flairQuiet::after {
	opacity: 0.55;
	transform: none;
}

.flair-matrix.flairQuiet::before,
.flair-matrix.flairQuiet::after {
	opacity: var(--mtx-wash-peak, 0.7);
}

.flair-sonar.flairQuiet::before {
	opacity: var(--son-wash-peak, 0.75);
}

.flair-aurora.flairQuiet::before,
.flair-aurora.flairQuiet::after,
.flair-aurora.flairQuiet .auroraCurtain {
	animation: none !important;
}

.flair-fireflies.flairQuiet::before {
	opacity: var(--fly-wash-peak, 0.6);
}

@media (prefers-reduced-motion: reduce) {
	
	.flair::before,
	.flair::after {
		animation: none;
	}
	.flair-fire::after,
	.flair-lightning::after,
	
	.flair-bubbles::after,
	
	.flair-glitch::after {
		opacity: 0;
	}
	
	.flair-lightning .fmtRainbow,
	.flair-fire .fmtRainbow,
	.flair-rain .fmtRainbow,
	.flair-neon .fmtRainbow,
	.flair-matrix .fmtRainbow,
	.flair-sonar .fmtRainbow,
	.flair-fireflies .fmtRainbow,
	.flair-bubbles .fmtRainbow,
	.flair-aurora .fmtRainbow,
	.flair-bitcoin .fmtRainbow,
	.flair-glitch .fmtRainbow,
	.flair-plume .fmtRainbow {
		animation: none;
		filter: brightness(1);
	}
	
	.flair-matrix::before,
	.flair-matrix::after {
		opacity: var(--mtx-wash-peak, 0.7);
	}
	
	.flair-sonar::before {
		opacity: var(--son-wash-peak, 0.75);
	}
	.flair-aurora::before,
	.flair-aurora::after,
	.flair-aurora .auroraCurtain {
		animation: none !important;
	}
	
	
	.flair-bitcoin > .flairFx {
		display: block;
	}
	.flair-bitcoin .cirSeg {
		opacity: 0.34;
	}
	.flair-bitcoin .cirCoinWrap {
		opacity: 0.42;
	}
	
	
	.flair-fireflies::before {
		opacity: var(--fly-wash-peak, 0.6);
	}
	
	.flair-neon::before,
	.flair-neon::after,
	.line.arrive.flair-neon:not(.flairQuiet)::before,
	.line.arrive.flair-neon:not(.flairQuiet)::after {
		animation: none;
		opacity: 1;
	}
	.flair-neon .neonDead {
		opacity: 0;
	}
	
	.flair-plume::after {
		opacity: 0.7;
		translate: 0 0;
	}
	
	.flair-rain::after {
		opacity: 0.4;
	}
	.flair-stars::before,
	.flair-stars::after {
		opacity: 0.55;
		transform: none;
	}
	
	.flairFx {
		display: none;
		animation: none;
		transition: none; 
	}
	
	.flair-plume::before,
	.flair-plume::after {
		animation: none;
	}
}

/* --- Better Agnostr adaptation -------------------------------------------------
   Glub rows clip their flair at the row edge. Agnostr's hover action toolbar sits
   above the row (top: -16px), so we clip with a small margin instead of hiding the
   toolbar. */
.ag-msg-row.flair {
  overflow: visible !important;
}
.ag-msg-row.flair::before,
.ag-msg-row.flair::after {
  display: none !important;
  pointer-events: none;
}
.ag-msg-row > .ba-flair-layer {
  position: absolute !important;
  inset: 0 !important;
  display: block;
  overflow: hidden !important;
  pointer-events: none;
  z-index: 0;
  border-radius: inherit;
  /* Soften the top and bottom edge where a row's flair meets the next one. */
  -webkit-mask-image: linear-gradient(to bottom, transparent 0, #000 10px, #000 calc(100% - 10px), transparent 100%);
  mask-image: linear-gradient(to bottom, transparent 0, #000 10px, #000 calc(100% - 10px), transparent 100%);
}

/* Stars need a field that scales with the row instead of two fixed bands. */
.ag-msg-row > .ba-flair-layer.flair-stars {
  -webkit-mask-image: linear-gradient(to bottom, transparent 0, #000 4px, #000 calc(100% - 4px), transparent 100%);
  mask-image: linear-gradient(to bottom, transparent 0, #000 4px, #000 calc(100% - 4px), transparent 100%);
  background-color: #04060d;
  background-image:
    radial-gradient(circle at 14% 22%, #ffffff 0 1px, transparent 1.8px),
    radial-gradient(circle at 58% 68%, #cfe6ff 0 1px, transparent 1.7px),
    radial-gradient(circle at 82% 38%, #ffffff 0 1.2px, transparent 2px),
    radial-gradient(circle at 34% 84%, #a8ccff 0 0.9px, transparent 1.6px),
    radial-gradient(circle at 71% 12%, #dbe9ff 0 0.8px, transparent 1.5px);
  background-size: 137px 113px, 211px 173px, 293px 239px, 367px 307px, 449px 389px;
  background-position: var(--star-bg-x, 0) var(--star-bg-y, 0);
  background-repeat: repeat;
}

.ag-msg-row > .ba-flair-layer.flair-stars::before,
.ag-msg-row > .ba-flair-layer.flair-stars::after {
  z-index: 1;
}

.ag-msg-row > .ba-flair-layer.flair-stars > .flairFx,
.ag-msg-row > .ba-flair-layer.flair-stars > .ba-shooting-star {
  z-index: 2;
}

.ag-msg-row.flair-stars .ag-msg-content,
.ag-msg-row.flair-stars .ag-msg-author,
.ag-msg-row.flair-stars .ag-msg-time {
  color: #eaf2ff !important;
}

.ba-set-preview-row.flair-stars,
.ba-preview-row.flair-stars {
  background-color: #04060d;
  background-image:
    radial-gradient(circle at 14% 22%, #ffffff 0 1px, transparent 1.8px),
    radial-gradient(circle at 58% 68%, #cfe6ff 0 1px, transparent 1.7px),
    radial-gradient(circle at 82% 38%, #ffffff 0 1.2px, transparent 2px),
    radial-gradient(circle at 34% 84%, #a8ccff 0 0.9px, transparent 1.6px);
  background-size: 137px 113px, 211px 173px, 293px 239px, 367px 307px;
}

.ba-set-preview-row.flair-stars::before,
.ba-set-preview-row.flair-stars::after,
.ba-preview-row.flair-stars::before,
.ba-preview-row.flair-stars::after {
  z-index: 0;
}

.ba-set-preview-row.flair-stars > .flairFx,
.ba-preview-row.flair-stars > .flairFx {
  z-index: 1;
}

.ba-set-preview-row.flair-stars .ba-set-preview-name,
.ba-set-preview-row.flair-stars .ba-set-preview-tag,
.ba-set-preview-row.flair-stars .ba-set-preview-line,
.ba-preview-row.flair-stars .ba-preview-name,
.ba-preview-row.flair-stars .ba-preview-tag,
.ba-preview-row.flair-stars .ba-preview-line {
  color: #eaf2ff;
}
.ag-msg-row > .ag-msg-gutter,
.ag-msg-row > .ag-msg-content {
  position: relative;
  z-index: 1;
}
.ba-preview-row.flair {
  overflow: hidden;
}

/* Aliases used by the extracted Glub flair CSS. */
:root {
  --bg: var(--bg-canvas, #000000);
  --fg: var(--text-primary, #ffffff);
  --scanline-color: color-mix(in srgb, var(--text-primary, #ffffff) 7%, transparent);
}
`;

  // src/lib/glub-flair.js
  var FLAIRS = ["fire", "lightning", "stars", "rain", "plume", "neon", "matrix", "sonar", "fireflies", "bubbles", "aurora", "bitcoin", "glitch", "sol"];
  var KNOWN = new Set(FLAIRS);
  var FLAIR_LIMITS = {
    fire: 0,
    lightning: 0,
    stars: 0,
    rain: 0,
    plume: 3,
    // two pseudo-elements animating opacity and nothing else - no blur, no blend, no
    // particles. Cheaper than any of the others, so it starts uncapped like they did.
    neon: 0,
    // The only flair made of TEXT, and it is the node count that earns it a cap
    // rather than blur: a column is a stack of glyph cells plus a strip of them for
    // the head, so one row builds ~110 elements where rain builds ten. Measured at
    // ~20 composited animations per row, which is fine by itself and is not fine
    // twenty rows deep. Capped a little above plume, whose blur is dearer per row.
    matrix: 4,
    // three rings, two pseudo-elements, and every one of them animating nothing but
    // opacity and a scale. No blur, no blend, no glyphs, and a fifth of rain's node
    // count. Starts uncapped, per the rule above.
    sonar: 0,
    // four or five small dots, three composited animations each, and a glow that is a
    // pair of static box-shadows rather than a filter - so it rasterizes once and
    // costs nothing per frame. The cheapest particle flair here.
    fireflies: 0,
    // fire's construction with fire's costs: one element per bubble, three composited
    // animations each, and nothing blurred or blended anywhere. The highlight is a
    // pseudo-element on the bubble, which is a node rather than a frame's work.
    // Starts uncapped, per the rule above.
    bubbles: 0,
    // Six soft curtains plus a blurred layer and a star field. The filter is one
    // rasterized layer per row, so keep the number of simultaneous aurora rows low.
    aurora: 6,
    // The circuit board. Measured at ~50 positioned spans plus one small svg. None of
    // them is blurred,
    // blended or filtered, so what earns the cap is node count rather than paint -
    // the same thing that earns matrix its 4, and this sits a little under matrix.
    //
    // The COST is spiky rather than steady, which is why the cap is not the only
    // guard: a standing board is fifty static divs and no animations at all, and then
    // a surge starts one short opacity animation on each of them at once. The ticker
    // caps how many boards may surge in a tick (CIRCUIT_MAX_PER_TICK); this caps how
    // many may stand.
    bitcoin: 5,
    // Nothing standing at all: between tears a glitch row is two pseudo-elements, the
    // same as aurora. What it costs is entirely in the one-shot, where it briefly
    // clones the row's own content two or three times - and that is bounded by the
    // ticker's per-tick cap rather than by how many rows are up.
    glitch: 0,
    // Two gradient sheets and a handful of soft ellipses. The softness is a
    // radial-gradient background rather than a filter, which is the whole reason this
    // starts uncapped where plume is capped at three: plume's blobs are BLURRED and
    // screen-BLENDED, and both of those words cost a frame's work every frame. A
    // gradient rasterizes once. Nearer fireflies than plume in every way that bills.
    sol: 0
  };
  function flairLimit(raw) {
    const n = flairName(raw);
    return n && FLAIR_LIMITS[n] > 0 ? FLAIR_LIMITS[n] : 0;
  }
  var ALIASES = { plasma: "plume", circuit: "bitcoin" };
  function flairName(raw) {
    const s = String(raw || "").trim().toLowerCase();
    const n = ALIASES[s] || s;
    return KNOWN.has(n) ? n : "";
  }
  function flairClass(raw) {
    const n = flairName(raw);
    return n ? `flair flair-${n}` : "";
  }
  var rnd = (min, max) => min + Math.random() * (max - min);
  var pick = (arr) => arr[Math.random() * arr.length | 0];
  var FX_FLAIRS = /* @__PURE__ */ new Set(["stars", "lightning", "fire", "rain", "plume", "neon", "matrix", "sonar", "fireflies", "bubbles", "aurora", "bitcoin", "glitch", "sol"]);
  function flairHasFx(raw) {
    return FX_FLAIRS.has(flairName(raw));
  }
  function auroraCurtainMarkup() {
    let html = "";
    for (let i = 0; i < 6; i++) {
      html += `<span class="auroraCurtain" style="--c-i:${i}" aria-hidden="true"></span>`;
    }
    return html;
  }
  function flairFxInner(raw) {
    const n = flairName(raw);
    if (n === "aurora") return auroraCurtainMarkup();
    if (n === "fire") return fireEmberMarkup();
    if (n === "rain") return rainDropMarkup();
    if (n === "plume") return plumePuffMarkup();
    if (n === "neon") return `<span class="neonDead"></span>`;
    if (n === "matrix") return matrixColumnMarkup();
    if (n === "sonar") return sonarPingMarkup();
    if (n === "fireflies") return fireflyMarkup();
    if (n === "bubbles") return bubbleMarkup();
    if (n === "bitcoin") return circuitBoardMarkup();
    if (n === "sol") return solRayMarkup();
    return "";
  }
  var SCANLINE_FLAIRS = /* @__PURE__ */ new Set(["neon", "matrix", "sonar", "glitch"]);
  function flairOverlayInner(raw) {
    return SCANLINE_FLAIRS.has(flairName(raw)) ? `<span class="flairScan" aria-hidden="true"></span>` : "";
  }
  var STAR_TINTS = ["#ffffff", "#ffffff", "#cfe6ff", "#a8ccff", "#dbe9ff", "#bcd8ff", "#e9f2ff"];
  function particleField(count, step, jitterY, tints) {
    const out = [];
    let x = 0;
    for (let i = 0; i < count; i++) {
      x += rnd(step * 0.55, step * 1.45);
      out.push(`${Math.round(x)}px ${Math.round(rnd(-jitterY, jitterY))}px ${pick(tints)}`);
    }
    return out.join(", ");
  }
  function lightningStrikeMarkup(w, h2) {
    const width = Math.max(60, Math.round(w));
    const height = Math.max(8, Math.round(h2));
    const jitter = width * 0.055;
    const segs = 3 + (Math.random() * 3 | 0);
    const pts = [];
    let x = width * (0.12 + Math.random() * 0.76);
    for (let i = 0; i <= segs; i++) {
      const y = height / segs * i;
      pts.push(`${x.toFixed(1)},${y.toFixed(1)}`);
      x = Math.max(2, Math.min(width - 2, x + (Math.random() * 2 - 1) * jitter));
    }
    const main = pts.join(" ");
    let fork = "";
    if (Math.random() < 0.55 && pts.length > 2) {
      const i = 1 + (Math.random() * (pts.length - 2) | 0);
      const [fx, fy] = pts[i].split(",").map(Number);
      const dir = Math.random() < 0.5 ? -1 : 1;
      const f = [
        `${fx.toFixed(1)},${fy.toFixed(1)}`,
        `${(fx + dir * jitter * 1.6).toFixed(1)},${Math.min(height, fy + height * 0.22).toFixed(1)}`,
        `${(fx + dir * jitter * 2.4).toFixed(1)},${Math.min(height, fy + height * 0.44).toFixed(1)}`
      ].join(" ");
      fork = `<polyline class="boltGlow" points="${f}"/><polyline class="boltCore" points="${f}"/>`;
    }
    return `<span class="strike"><span class="boltFlash"></span><svg class="boltSvg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" aria-hidden="true"><polyline class="boltGlow" points="${main}"/><polyline class="boltCore" points="${main}"/>${fork}</svg></span>`;
  }
  var EMBER_TINTS = ["#ffb057", "#ff7a18", "#ffd08a", "#ff9d3d", "#ffc46b", "#ff6a00"];
  var ASH_TINTS = ["#8a7f77", "#6d635c", "#b9a89a", "#c9762f", "#7d726a", "#ffa14d"];
  function wobble(prefix, amp, lean) {
    const d = Math.random() < 0.5 ? -1 : 1;
    return {
      [`${prefix}1`]: `${(d * amp * 0.4 + lean * 0.3).toFixed(1)}px`,
      [`${prefix}2`]: `${(-d * amp * 0.5 + lean * 0.65).toFixed(1)}px`,
      [`${prefix}3`]: `${(d * amp * 0.35 + lean).toFixed(1)}px`
    };
  }
  var EMBER_MIN = 5;
  var EMBER_MAX = 7;
  function fireEmberMarkup() {
    const count = EMBER_MIN + (Math.random() * (EMBER_MAX - EMBER_MIN + 1) | 0);
    let html = "";
    for (let i = 0; i < count; i++) {
      const short2 = Math.random() < 0.4;
      const size = Math.random() < 0.25 ? 3 : 2;
      const style = [
        `--e-x:${Math.round(rnd(4, 92))}%`,
        `--e-size:${size}px`,
        `--e-tint:${pick(EMBER_TINTS)}`,
        `--e-peak:${rnd(0.62, 1).toFixed(2)}`,
        `--e-lift:${rnd(1.5, 2.6).toFixed(2)}em`,
        `--e-amp:${rnd(3, 11).toFixed(1)}px`,
        // unrelated periods for rise vs sway, each phase-shifted on its own
        `--e-rise:${rnd(2.8, 6.4).toFixed(2)}s`,
        `--e-rise-delay:-${rnd(0, 7).toFixed(2)}s`,
        `--e-sway:${rnd(1.3, 2.9).toFixed(2)}s`,
        `--e-sway-delay:-${rnd(0, 3).toFixed(2)}s`
      ].join(";");
      html += `<span class="ember${short2 ? " emberShort" : ""}" style="${style}"></span>`;
    }
    return html;
  }
  var RAIN_TINTS = ["#cfe4f5", "#9fc0d8", "#eaf4ff", "#b9d3e6", "#8fb0c8", "#dceaf6"];
  var DROP_MIN = 7;
  var DROP_MAX = 10;
  var RAIN_WIND_PX = 7;
  function rainDropMarkup() {
    const count = DROP_MIN + (Math.random() * (DROP_MAX - DROP_MIN + 1) | 0);
    let html = "";
    for (let i = 0; i < count; i++) {
      const drift = RAIN_WIND_PX * rnd(0.85, 1.15);
      const tilt = Math.max(-17, Math.min(17, drift * 1.6));
      const style = [
        `--d-x:${Math.round(rnd(2, 96))}%`,
        `--d-len:${rnd(5, 10).toFixed(1)}px`,
        `--d-tint:${pick(RAIN_TINTS)}`,
        `--d-op:${rnd(0.45, 0.95).toFixed(2)}`,
        `--d-lean:${drift.toFixed(1)}px`,
        `--d-tilt:${tilt.toFixed(1)}deg`,
        `--d-ring:${rnd(7, 13).toFixed(1)}px`,
        // gravity is quick: short periods and high turnover. The random negative
        // delay scatters the spawn moments into a real shower rather than a row.
        `--d-fall:${rnd(0.34, 0.72).toFixed(2)}s`,
        `--d-delay:-${rnd(0, 1.2).toFixed(2)}s`
      ].join(";");
      html += `<span class="drop" style="${style}"></span>`;
    }
    return html;
  }
  var PLASMA_TINTS = ["#a855f7", "#c084fc", "#8b5cf6", "#9333ea", "#b06cf0", "#7e3ff2"];
  var PLASMA_CORES = ["#f3e8ff", "#efe0ff", "#ffffff", "#e9d5ff", "#f7efff"];
  var PUFF_MIN = 4;
  var PUFF_MAX = 6;
  var MOTE_TINTS = ["#e9d5ff", "#c084fc", "#f3e8ff", "#d8b4fe", "#a855f7"];
  var MOTE_MIN = 2;
  var MOTE_MAX = 4;
  function plumeMoteMarkup() {
    const count = MOTE_MIN + (Math.random() * (MOTE_MAX - MOTE_MIN + 1) | 0);
    let html = "";
    for (let i = 0; i < count; i++) {
      const style = [
        // starts beyond where the glow has faded out, ends inside the bright edge
        `--m-from:${Math.round(rnd(62, 108))}%`,
        `--m-to:${Math.round(rnd(4, 20))}%`,
        `--m-y:${Math.round(rnd(12, 88))}%`,
        `--m-rise:${rnd(-7, 7).toFixed(1)}px`,
        `--m-size:${Math.random() < 0.3 ? 2 : 1.4}px`,
        `--m-tint:${pick(MOTE_TINTS)}`,
        `--m-op:${rnd(0.4, 0.85).toFixed(2)}`,
        // slow, and long gaps between: the delay is a big negative so most motes
        // spend most of the cycle already gone
        `--m-dur:${rnd(4.5, 9.5).toFixed(2)}s`,
        `--m-delay:-${rnd(0, 9).toFixed(2)}s`
      ].join(";");
      html += `<span class="mote" style="${style}"></span>`;
    }
    return html;
  }
  function plumePuffMarkup() {
    const count = PUFF_MIN + (Math.random() * (PUFF_MAX - PUFF_MIN + 1) | 0);
    let html = "";
    for (let i = 0; i < count; i++) {
      const size = Math.round(rnd(54, 108));
      const style = [
        `--p-x:${Math.round(rnd(-18, 19))}%`,
        `--p-y:${Math.round(rnd(15, 85))}%`,
        `--p-size:${size}px`,
        `--p-tint:${pick(PLASMA_TINTS)}`,
        `--p-core:${pick(PLASMA_CORES)}`,
        `--p-blur:${Math.round(rnd(10, 22))}px`,
        `--p-op:${rnd(0.28, 0.55).toFixed(2)}`,
        `--p-dx:${rnd(-16, 16).toFixed(1)}px`,
        `--p-dy:${rnd(-9, 9).toFixed(1)}px`,
        `--p-swell:${rnd(1.12, 1.42).toFixed(2)}`,
        `--p-drift-dur:${rnd(7.5, 15).toFixed(2)}s`,
        `--p-drift-delay:-${rnd(0, 14).toFixed(2)}s`,
        `--p-swell-dur:${rnd(4.6, 9.4).toFixed(2)}s`,
        `--p-swell-delay:-${rnd(0, 9).toFixed(2)}s`,
        `--p-breathe-dur:${rnd(5.2, 11).toFixed(2)}s`,
        `--p-breathe-delay:-${rnd(0, 10).toFixed(2)}s`
      ].join(";");
      html += `<span class="puff" style="${style}"></span>`;
    }
    return html + plumeMoteMarkup();
  }
  var MATRIX_GLYPHS = "\uFF71\uFF72\uFF73\uFF74\uFF75\uFF76\uFF77\uFF78\uFF79\uFF7A\uFF7B\uFF7C\uFF7D\uFF7E\uFF7F\uFF80\uFF81\uFF82\uFF83\uFF84\uFF85\uFF86\uFF87\uFF88\uFF89\uFF8A\uFF8B\uFF8C\uFF8D\uFF8E\uFF8F\uFF90\uFF91\uFF92\uFF93\uFF94\uFF95\uFF96\uFF97\uFF98\uFF99\uFF9A\uFF9B\uFF9C\uFF9D0123456789";
  var MATRIX_REEL_LEN = 5;
  var MATRIX_TRAIL_MIN = 2;
  var MATRIX_TRAIL_MAX = 3;
  var MATRIX_COL_MIN = 8;
  var MATRIX_COL_MAX = 11;
  var glyph = () => MATRIX_GLYPHS[Math.random() * MATRIX_GLYPHS.length | 0];
  function matrixReel() {
    let out = "";
    for (let i = 0; i < MATRIX_REEL_LEN; i++) out += `<i>${glyph()}</i>`;
    return `<span class="mtxReel">${out}</span>`;
  }
  function matrixColumnMarkup() {
    const count = MATRIX_COL_MIN + (Math.random() * (MATRIX_COL_MAX - MATRIX_COL_MIN + 1) | 0);
    const step = 100 / count;
    let x = rnd(-step * 0.4, step * 0.4);
    let html = "";
    for (let i = 0; i < count; i++) {
      x += step * rnd(0.62, 1.38);
      const trail = MATRIX_TRAIL_MIN + (Math.random() * (MATRIX_TRAIL_MAX - MATRIX_TRAIL_MIN + 1) | 0);
      let body = "";
      for (let d = trail; d >= 1; d--) {
        body += `<span class="mtxGlyph" style="--m-dim:${(1 / (1 + d * 0.45)).toFixed(2)}">${glyph()}</span>`;
      }
      const style = [
        `--m-x:${Math.max(0, Math.min(97, x)).toFixed(1)}%`,
        `--m-size:${rnd(10, 13).toFixed(1)}px`,
        `--m-op:${rnd(0.8, 1).toFixed(2)}`,
        // Fast, because this is a terminal spitting out lines rather than snow
        // drifting past. A column crosses the row in about a second, and the head
        // churns several times inside that - the churn is what actually reads as
        // a machine printing, so it's the quicker of the two by a wide margin.
        // The two periods stay unrelated, so a column never lands on the same
        // glyph at the same height twice.
        `--m-fall:${rnd(0.55, 1.3).toFixed(3)}s`,
        `--m-delay:-${rnd(0, 2).toFixed(3)}s`,
        // This is a period for the WHOLE strip, so the per-character rate is this
        // over MATRIX_REEL_LEN. Pushed much below about a quarter-second the head
        // stops reading as characters at all and becomes a flickering dot - which
        // is faster but says less. Around 10-20 changes a second it still reads as
        // a machine printing something.
        `--m-reel:${rnd(0.26, 0.5).toFixed(3)}s`,
        `--m-reel-delay:-${rnd(0, 0.5).toFixed(3)}s`
      ].join(";");
      html += `<span class="mtxCol" style="${style}">${body}<span class="mtxHead">${matrixReel()}</span></span>`;
    }
    return html;
  }
  var SONAR_RINGS = 3;
  function sonarPingMarkup() {
    let html = "";
    for (let i = 0; i < SONAR_RINGS; i++) {
      html += `<span class="ping" style="--r-i:${i}" aria-hidden="true"><svg viewBox="0 0 100 100" focusable="false" aria-hidden="true"><circle class="pingHalo" cx="50" cy="50" r="5"></circle><circle class="pingCore" cx="50" cy="50" r="5"></circle></svg></span>`;
    }
    return html;
  }
  var FLY_TINTS = ["#d4ff6a", "#c8ff5a", "#b6f542", "#eaff9c", "#ffe98a", "#ddff7e"];
  var FLY_MIN = 4;
  var FLY_MAX = 6;
  function fireflyMarkup() {
    const count = FLY_MIN + (Math.random() * (FLY_MAX - FLY_MIN + 1) | 0);
    let html = "";
    for (let i = 0; i < count; i++) {
      const drift = rnd(3.6, 7.4);
      const bob = Math.min(4.6, Math.max(1.8, drift * rnd(0.38, 0.66)));
      let glow = Math.min(6.4, Math.max(2.6, drift * rnd(0.45, 0.9)));
      if (Math.abs(glow - bob) < 0.6) glow = bob + 0.9;
      const style = [
        // kept off the very top and bottom of the row, and paired with a shallow bob
        // below. A row can be a single line of about twenty pixels, and an insect
        // that wanders further than that is simply clipped away for half its life -
        // which reads as broken rather than as one leaving the frame.
        `--f-x:${Math.round(rnd(4, 92))}%`,
        `--f-y:${Math.round(rnd(22, 78))}%`,
        // the HALO's size, not the insect's - the bright part is the inner quarter of
        // it (see .fly in the stylesheet). A few are noticeably larger, which reads as
        // depth: the big ones are the near ones.
        `--f-size:${Math.round(rnd(9, 15))}px`,
        `--f-tint:${pick(FLY_TINTS)}`,
        `--f-peak:${rnd(0.72, 1).toFixed(2)}`,
        // wide horizontally, shallow vertically - the row has room in only one of
        // those directions
        `--f-ax:${rnd(9, 26).toFixed(1)}px`,
        `--f-ay:${rnd(2.5, 6).toFixed(1)}px`,
        // the three periods worked out above, each phase-shifted on its own so no two
        // insects are ever at the same point of the same cycle
        `--f-drift:${drift.toFixed(2)}s`,
        `--f-drift-delay:-${rnd(0, 9).toFixed(2)}s`,
        `--f-bob:${bob.toFixed(2)}s`,
        `--f-bob-delay:-${rnd(0, 6).toFixed(2)}s`,
        `--f-glow:${glow.toFixed(2)}s`,
        `--f-glow-delay:-${rnd(0, 6.5).toFixed(2)}s`
      ].join(";");
      html += `<span class="fly" style="${style}"></span>`;
    }
    return html;
  }
  var RAY_MIN = 9;
  var RAY_MAX = 14;
  function solRayMarkup() {
    const count = RAY_MIN + (Math.random() * (RAY_MAX - RAY_MIN + 1) | 0);
    const srcX = rnd(-9, -1).toFixed(1);
    const srcY = Math.round(rnd(44, 56));
    const spread = rnd(54, 78);
    const first = -spread / 2 + rnd(-5, 5);
    const step = spread / Math.max(1, count - 1);
    let html = "";
    for (let i = 0; i < count; i++) {
      const ang = first + step * i + rnd(-step * 0.34, step * 0.34);
      const reach = rnd(5.5, 12);
      const turn = Math.min(19, Math.max(7, reach * rnd(1.2, 1.8)));
      let flare = Math.min(9, Math.max(3.2, reach * rnd(0.45, 0.78)));
      if (Math.abs(flare - reach) < 1.2) flare = reach * 0.55 + 1.3;
      const max = rnd(0.86, 1);
      const min = max * rnd(0.36, 0.68);
      const style = [
        `--r-x:${srcX}%`,
        `--r-y:${srcY}%`,
        `--r-ang:${ang.toFixed(1)}deg`,
        // long enough that the shallow rays cross the row even pulled back to --r-min;
        // the overflow on .flair clips whatever leaves.
        `--r-len:${Math.round(rnd(220, 520))}px`,
        // the wedge's thickness at its OUTER end. It narrows to nothing at the sun, so
        // near the core the fan is a set of fine spikes rather than a solid pool.
        `--r-thick:${Math.round(rnd(7, 24))}px`,
        // tight range: these are all meant to be blinding, and a fan whose members
        // differ much in brightness reads as some rays being closer than others
        `--r-peak:${rnd(0.72, 0.95).toFixed(2)}`,
        `--r-min:${min.toFixed(2)}`,
        `--r-max:${max.toFixed(2)}`,
        // the up-and-down swing about the sun. Bigger than it was when the sun was
        // far away: with the origin on the row's own edge, a few degrees at the root
        // is only a few pixels of travel where the ray crosses the row.
        `--r-swing:${rnd(2.4, 7.5).toFixed(2)}deg`,
        `--r-reach-dur:${reach.toFixed(2)}s`,
        `--r-reach-delay:-${rnd(0, 15).toFixed(2)}s`,
        `--r-turn-dur:${turn.toFixed(2)}s`,
        `--r-turn-delay:-${rnd(0, 21).toFixed(2)}s`,
        `--r-flare-dur:${flare.toFixed(2)}s`,
        `--r-flare-delay:-${rnd(0, 9.5).toFixed(2)}s`
      ].join(";");
      html += `<span class="ray" style="${style}"></span>`;
    }
    return html;
  }
  var BUBBLE_TINTS = ["#5fe0d8", "#7ef0e6", "#a8f7f0", "#4fc8d8", "#6fe8ea", "#c9fdfa"];
  var BUBBLE_MIN = 5;
  var BUBBLE_MAX = 8;
  function bubbleMarkup() {
    const count = BUBBLE_MIN + (Math.random() * (BUBBLE_MAX - BUBBLE_MIN + 1) | 0);
    let html = "";
    for (let i = 0; i < count; i++) {
      const short2 = Math.random() < 0.34;
      const size = Math.round(rnd(4, 10));
      const style = [
        `--b-x:${Math.round(rnd(4, 92))}%`,
        `--b-size:${size}px`,
        `--b-tint:${pick(BUBBLE_TINTS)}`,
        `--b-peak:${rnd(0.55, 0.92).toFixed(2)}`,
        `--b-lift:${rnd(1.6, 2.8).toFixed(2)}em`,
        // double fire's, and the reason the two read as different substances: an
        // ember is pushed by draught, a bubble is pushed by water
        `--b-amp:${rnd(7, 20).toFixed(1)}px`,
        // how much bigger it is at the surface than at the floor. Kept under a
        // quarter: past that it stops looking like pressure and starts looking like
        // the bubble coming towards you
        `--b-grow:${rnd(1.1, 1.26).toFixed(3)}`,
        // slower than an ember's, and the three periods are unrelated so the path
        // never closes and the field never marches in step
        `--b-rise:${rnd(4.2, 9.5).toFixed(2)}s`,
        `--b-rise-delay:-${rnd(0, 9).toFixed(2)}s`,
        `--b-sway:${rnd(2.2, 4.4).toFixed(2)}s`,
        `--b-sway-delay:-${rnd(0, 4).toFixed(2)}s`,
        // tied to the rise rather than drawn on its own: the swell IS the climb, so
        // a bubble that grew on some other clock would be shrinking half way up
        `--b-grow-dur:var(--b-rise)`
      ].join(";");
      html += `<span class="bubble${short2 ? " bubbleShort" : ""}" style="${style}"></span>`;
    }
    return html;
  }
  var CIR_LANE_TOP = 4;
  var CIR_LANE_GAP = 16;
  var CIR_LANE_MIN = 3;
  var CIR_LANE_MAX = 4;
  var CIR_RUN_MIN = 7;
  var CIR_RUN_MAX = 16;
  function cirSeg(x1, y1, x2, y2) {
    const x = Math.min(x1, x2);
    const y = Math.min(y1, y2);
    const w = Math.abs(x2 - x1);
    const h2 = Math.abs(y2 - y1);
    const style = `--c-x:${x.toFixed(2)}%;--c-y:${y.toFixed(1)}px;` + // the trace's own width is 1px on whichever axis is the thin one
    (w > 0 ? `--c-w:${w.toFixed(2)}%;--c-h:1px;` : `--c-w:1px;--c-h:${h2.toFixed(1)}px;`) + // a vertical run has one x, so it lights with the horizontal run that feeds it
    `--t:${(Math.max(x1, x2) / 100).toFixed(3)}`;
    return `<i class="cirSeg" style="${style}"></i>`;
  }
  function cirBranch(x, y) {
    const dir = Math.random() < 0.5 ? -1 : 1;
    const y2 = Math.max(2, y + dir * rnd(9, 20));
    const x2 = Math.min(97, x + rnd(3, 9));
    return cirSeg(x, y, x, y2) + cirSeg(x, y2, x2, y2);
  }
  function circuitBoardMarkup() {
    const lanes = CIR_LANE_MIN + (Math.random() * (CIR_LANE_MAX - CIR_LANE_MIN + 1) | 0);
    let html = "";
    for (let i = 0; i < lanes; i++) {
      let x = 0;
      let y = CIR_LANE_TOP + i * CIR_LANE_GAP + rnd(-2, 2);
      while (x < 97) {
        const run = Math.min(rnd(CIR_RUN_MIN, CIR_RUN_MAX), 98 - x);
        html += cirSeg(x, y, x + run, y);
        x += run;
        if (x >= 97) break;
        if (Math.random() < 0.72) {
          const dir = Math.random() < 0.5 ? -1 : 1;
          const y2 = Math.max(2, y + dir * rnd(4, 11));
          html += cirSeg(x, y, x, y2);
          y = y2;
        }
        if (Math.random() < 0.22) html += cirBranch(x, y);
        if (x > 45 && Math.random() < 0.2) break;
      }
    }
    return html + cirCoinMarkup();
  }
  var CIR_B = {
    left: 31.5,
    // the stem's left edge
    stem: 9.3,
    // ...and its width - measured 9.7% of the disc
    bodyTop: 26.5,
    // the bowls, top and bottom, excluding the ticks
    bodyBot: 73.5,
    mid: 49.6,
    // where the two bowls meet
    top: 19.5,
    // the ticks reach this far past the body, top and bottom
    bot: 80.5,
    upperR: 65,
    // how far each bowl reaches right - the lower one is the wider,
    lowerR: 69.5,
    // which is what stops a B reading as an 8
    wallX: 10,
    // the bowl wall's thickness, right and top/bottom
    wallY: 5.6,
    waist: 5.4,
    // the single bar the two bowls share
    cap: 1.25,
    // how square the bowls' right caps are (1 = a true semicircle)
    serifW: 5,
    // the foot on the spine, top and bottom - see below
    serifH: 5.6,
    tickW: 6,
    tick1: 40.5,
    tick2: 51
  };
  function cirCoinPath() {
    const o = CIR_B;
    const markL = o.left - o.serifW;
    const markR = Math.max(o.upperR, o.lowerR);
    const dx = 50 - (markL + markR) / 2;
    const P = (x, y) => `${(x + dx).toFixed(2)},${y.toFixed(2)}`;
    const rect = (x1, y1, x2, y2) => `M${P(x1, y1)} L${P(x2, y1)} L${P(x2, y2)} L${P(x1, y2)} Z`;
    const bowl = (x0, xr, yTop, yBot) => {
      const rr = (yBot - yTop) / 2;
      const ym = (yTop + yBot) / 2;
      const xa = xr - rr;
      const c = rr * 0.5523 * o.cap;
      return `M${P(x0, yTop)} L${P(xa, yTop)} C${P(xa + c, yTop)} ${P(xr, ym - c)} ${P(xr, ym)} C${P(xr, ym + c)} ${P(xa + c, yBot)} ${P(xa, yBot)} L${P(x0, yBot)} Z`;
    };
    const xs = o.left + o.stem;
    return [
      // the disc - two half arcs, so it needs no near-coincident start and end point
      "M2,50 A48,48 0 1,0 98,50 A48,48 0 1,0 2,50 Z",
      // THE SPINE IS NOT DRAWN, and that is the whole trick. It was, once - a rect
      // from `left` to `xs` - and it OVERLAPPED both bowls, which under evenodd is
      // an even number of subpaths and so filled the spine back in with gold. The B
      // came out with no upright at all, which reads as a 3. The bowls already start
      // at `left`, so the strip between there and the counters IS the spine; drawing
      // it again is what erased it.
      bowl(o.left, o.upperR, o.bodyTop, o.mid),
      // the two bowls...
      bowl(o.left, o.lowerR, o.mid, o.bodyBot),
      bowl(xs, o.upperR - o.wallX, o.bodyTop + o.wallY, o.mid - o.waist / 2),
      // ...and their
      bowl(xs, o.lowerR - o.wallX, o.mid + o.waist / 2, o.bodyBot - o.wallY),
      // counters
      // Serifs: a foot off the spine at each end. The bitcoin mark carries them and
      // they do more work than their size suggests - a bare spine ends flush with
      // the bowls and reads as a bar the bowls happen to sit on, where a footed one
      // reads as a letter. They sit entirely LEFT of the bowls, so unlike the spine
      // they overlap nothing and knock out cleanly.
      rect(o.left - o.serifW, o.bodyTop, o.left, o.bodyTop + o.serifH),
      rect(o.left - o.serifW, o.bodyBot - o.serifH, o.left, o.bodyBot),
      // the two strokes through top and bottom - what makes a B a bitcoin B
      rect(o.tick1, o.top, o.tick1 + o.tickW, o.bodyTop),
      rect(o.tick2, o.top, o.tick2 + o.tickW, o.bodyTop),
      rect(o.tick1, o.bodyBot, o.tick1 + o.tickW, o.bot),
      rect(o.tick2, o.bodyBot, o.tick2 + o.tickW, o.bot)
    ].join(" ");
  }
  function cirCoinMarkup() {
    return `<span class="cirCoinWrap" style="--t:1.02" aria-hidden="true"><svg class="cirCoin" viewBox="0 0 100 100"><path fill-rule="evenodd" d="${cirCoinPath()}"/></svg></span>`;
  }
  function flairVars(raw) {
    const n = flairName(raw);
    if (n === "glitch") {
      return {
        "--gl-wash-dur": `${rnd(5.5, 10).toFixed(2)}s`,
        "--gl-wash-delay": `-${rnd(0, 9).toFixed(2)}s`,
        "--gl-wash-peak": rnd(0.55, 0.9).toFixed(2),
        // long, and mostly spent off the row: a tracking bar that crossed
        // continuously would be a scanner, and this is a fault in the hold
        "--gl-track-dur": `${rnd(7, 15).toFixed(2)}s`,
        "--gl-track-delay": `-${rnd(0, 14).toFixed(2)}s`,
        "--gl-text-dur": `${rnd(6, 11).toFixed(2)}s`,
        "--gl-text-delay": `-${rnd(0, 9).toFixed(2)}s`
      };
    }
    if (n === "bitcoin") {
      return {
        "--cir-text-dur": `${rnd(7, 12).toFixed(2)}s`,
        "--cir-text-delay": `-${rnd(0, 9).toFixed(2)}s`
      };
    }
    if (n === "fire") {
      const lean = rnd(-6, 9);
      return {
        "--fire-glow-dur": `${rnd(2.6, 5.2).toFixed(2)}s`,
        "--fire-glow-delay": `-${rnd(0, 5).toFixed(2)}s`,
        "--fire-glow-peak": rnd(0.82, 1).toFixed(2),
        "--fire-glow-low": rnd(0.34, 0.55).toFixed(2),
        // the bright embers are individual spans (see fireEmberMarkup); this field
        // is only the dim ash haze behind them, where uniform timing doesn't read
        // - it's slow, faint, and snuffs out partway up (see flairAshRise).
        "--ash-field": particleField(5, 68, 5, ASH_TINTS),
        "--ash-left": `${Math.round(rnd(8, 40))}px`,
        "--ash-dur": `${rnd(4.2, 7.5).toFixed(2)}s`,
        "--ash-delay": `-${rnd(0, 7).toFixed(2)}s`,
        ...wobble("--ash-x", rnd(6, 13), lean),
        "--fire-text-dur": `${rnd(3.4, 6.2).toFixed(2)}s`,
        "--fire-text-delay": `-${rnd(0, 5).toFixed(2)}s`
      };
    }
    if (n === "lightning") {
      return {
        "--lit-haze-dur": `${rnd(4.5, 9).toFixed(2)}s`,
        "--lit-haze-delay": `-${rnd(0, 6).toFixed(2)}s`,
        "--lit-flash-dur": `${rnd(6.5, 14).toFixed(2)}s`,
        "--lit-flash-delay": `-${rnd(0, 12).toFixed(2)}s`,
        "--lit-flash-peak": rnd(0.18, 0.42).toFixed(2),
        // the faint sheet-lightning glow
        "--lit-flash-x": `${Math.round(rnd(12, 88))}%`,
        // where the glow is centred
        "--lit-text-dur": `${rnd(5.5, 9.5).toFixed(2)}s`,
        // the &g wildcard's flicker
        "--lit-text-delay": `-${rnd(0, 8).toFixed(2)}s`
      };
    }
    if (n === "rain") {
      return {
        "--rain-haze-dur": `${rnd(5, 9.5).toFixed(2)}s`,
        "--rain-haze-delay": `-${rnd(0, 8).toFixed(2)}s`,
        "--rain-haze-peak": rnd(0.55, 0.9).toFixed(2),
        "--rain-text-dur": `${rnd(2.4, 4.6).toFixed(2)}s`,
        "--rain-text-delay": `-${rnd(0, 4).toFixed(2)}s`
      };
    }
    if (n === "plume") {
      return {
        "--plume-wash-dur": `${rnd(6.5, 12).toFixed(2)}s`,
        "--plume-wash-delay": `-${rnd(0, 11).toFixed(2)}s`,
        "--plume-wash-peak": rnd(0.5, 0.8).toFixed(2),
        "--plume-lamp-x": `${Math.round(rnd(4, 22))}%`,
        "--plume-lamp-dur": `${rnd(9, 17).toFixed(2)}s`,
        "--plume-lamp-delay": `-${rnd(0, 16).toFixed(2)}s`,
        // how dim and how bright THIS line's plume burns between. A wide, per-line
        // swing is most of what stops a screenful of them pulsing as one organism.
        "--plume-lamp-low": rnd(0.32, 0.5).toFixed(2),
        "--plume-lamp-peak": rnd(0.74, 0.98).toFixed(2),
        // and how far it reaches, on its own period - so length and brightness are
        // never in step, which is what keeps it from looking like a single throb.
        // `far` is the once-a-cycle long throw (see flairPlumeReach): several
        // times the resting length, enough to run most of the way across a line.
        // The period is long so it stays an event rather than a rhythm.
        "--plume-reach-min": rnd(0.6, 0.82).toFixed(2),
        "--plume-reach-max": rnd(1.02, 1.24).toFixed(2),
        "--plume-reach-far": rnd(1.9, 3.3).toFixed(2),
        "--plume-reach-dur": `${rnd(16, 30).toFixed(2)}s`,
        "--plume-reach-delay": `-${rnd(0, 30).toFixed(2)}s`,
        "--plume-text-dur": `${rnd(4.5, 8.5).toFixed(2)}s`,
        "--plume-text-delay": `-${rnd(0, 8).toFixed(2)}s`
      };
    }
    if (n === "neon") {
      const pink = Math.random() < 0.62;
      const onTop = Math.random() < 0.5;
      return {
        "--neon-lit": pink ? "#ff2d95" : "#22e6ff",
        "--neon-halo": pink ? "#ff5cb0" : "#7ceeff",
        // how hard this tube burns. Hue alone was not enough per-line variety to
        // read: two neon rows in a row looked like one sign printed twice, where
        // two fire rows never do. Bloom carries it - it changes how much of the
        // row the tube lights. (The bend does NOT vary: the corner radius is the
        // one thing here that reads as chrome rather than as glass, and a big or
        // wandering one turns the row straight back into a button.)
        "--neon-bloom": `${rnd(6, 11).toFixed(1)}px`,
        // the hum: fast, shallow, and on its own period per line so no two tubes
        // buzz together. Anything slower than about a second stops reading as
        // electrical and starts reading as breathing.
        "--neon-hum-dur": `${rnd(0.62, 1.35).toFixed(2)}s`,
        "--neon-hum-delay": `-${rnd(0, 1.2).toFixed(2)}s`,
        // the dead-tube stutter. Long period, because it has to stay an EVENT: a
        // tube that gutters every few seconds is a strobe, and the whole point is
        // that you catch it out of the corner of your eye.
        "--neon-dead-dur": `${rnd(11, 23).toFixed(2)}s`,
        "--neon-dead-delay": `-${rnd(0, 22).toFixed(2)}s`,
        // offset so the patch straddles whichever rail fails, biased inward - it
        // has further to reach across the row than off it (see .neonDead)
        "--neon-dead-top": onTop ? "-9px" : "auto",
        "--neon-dead-bottom": onTop ? "auto" : "-9px",
        "--neon-dead-x": `${Math.round(rnd(8, 62))}%`,
        "--neon-dead-w": `${Math.round(rnd(14, 34))}%`,
        "--neon-text-dur": `${rnd(4, 7).toFixed(2)}s`,
        "--neon-text-delay": `-${rnd(0, 6).toFixed(2)}s`
      };
    }
    if (n === "matrix") {
      return {
        "--mtx-wash-dur": `${rnd(4.5, 9).toFixed(2)}s`,
        "--mtx-wash-delay": `-${rnd(0, 8).toFixed(2)}s`,
        "--mtx-wash-peak": rnd(0.5, 0.85).toFixed(2),
        "--mtx-text-dur": `${rnd(3.5, 6.5).toFixed(2)}s`,
        "--mtx-text-delay": `-${rnd(0, 6).toFixed(2)}s`
      };
    }
    if (n === "sonar") {
      return {
        // biased to the left half: a ping needs somewhere to run, and the row runs
        // rightward. An emitter out at 90% spends its whole life against the edge.
        "--son-x": `${Math.round(rnd(8, 66))}%`,
        // kept near the middle so both arcs of a clipped ring are on screen. Off at
        // the top or bottom edge you only ever see half a wavefront, which reads as a
        // curve sliding by rather than as something expanding.
        "--son-y": `${Math.round(rnd(34, 66))}%`,
        // how far this node's ping carries before it dies. Varies per line, so some
        // rows reach most of the way across and others barely leave the origin.
        "--son-reach": `${Math.round(rnd(120, 215))}px`,
        // The whole cycle, silence included - so this is the interval between one
        // burst and the next, not the time a ring spends travelling (which is the
        // expansion window in the keyframes, a little under half of this).
        //
        // Slow, and deliberately much slower than it first was. At three or four
        // seconds a row pinged about as often as a cursor blinks and the effect read
        // as a busy indicator; at ten it reads as something sweeping open water and
        // waiting to hear back. The wide spread matters as much as the number: rows
        // on very different cycles drift in and out of step forever, so a screenful
        // never settles into one beat.
        "--son-ping": `${rnd(8.5, 12).toFixed(2)}s`,
        // how far apart the rings of a burst leave, as a fraction of the cycle. Small
        // on purpose: this is one pulse seen as three wavefronts, not three pulses.
        "--son-gap": rnd(0.075, 0.105).toFixed(3),
        // the row's own phase, so every line sits somewhere different in the cycle.
        // Drawn across the full cycle, or rows would cluster into the part of it the
        // range happened to cover.
        "--son-phase": `-${rnd(0, 12).toFixed(2)}s`,
        "--son-lit": rnd(0.7, 1).toFixed(2),
        "--son-wash-dur": `${rnd(5, 9.5).toFixed(2)}s`,
        "--son-wash-delay": `-${rnd(0, 9).toFixed(2)}s`,
        "--son-wash-peak": rnd(0.55, 0.9).toFixed(2),
        // slow: this is a sweep, and the stylesheet's gradient puts two of them in a
        // cycle, so anything quick turns a scope into a strobe.
        "--son-text-dur": `${rnd(7, 11.5).toFixed(2)}s`,
        "--son-text-delay": `-${rnd(0, 11).toFixed(2)}s`
      };
    }
    if (n === "fireflies") {
      return {
        "--fly-wash-dur": `${rnd(6, 12).toFixed(2)}s`,
        "--fly-wash-delay": `-${rnd(0, 11).toFixed(2)}s`,
        "--fly-wash-peak": rnd(0.55, 0.9).toFixed(2),
        "--fly-text-dur": `${rnd(6, 10).toFixed(2)}s`,
        "--fly-text-delay": `-${rnd(0, 9).toFixed(2)}s`
      };
    }
    if (n === "bubbles") {
      const drift = rnd(-5, 7);
      return {
        "--bub-wash-dur": `${rnd(7, 14).toFixed(2)}s`,
        "--bub-wash-delay": `-${rnd(0, 13).toFixed(2)}s`,
        "--bub-wash-peak": rnd(0.5, 0.82).toFixed(2),
        // the fizz is a cloned field rather than individual nodes, and that is the
        // right call for exactly the reason it is wrong for the bubbles: these are
        // specks a pixel across, far too small for anyone to catch that they share a
        // cadence, and one composited layer is the whole cost of them
        "--fizz-field": particleField(6, 58, 4, BUBBLE_TINTS),
        "--fizz-left": `${Math.round(rnd(6, 44))}px`,
        "--fizz-dur": `${rnd(3.4, 6.2).toFixed(2)}s`,
        "--fizz-delay": `-${rnd(0, 6).toFixed(2)}s`,
        ...wobble("--fizz-x", rnd(5, 12), drift),
        "--bub-text-dur": `${rnd(6, 11).toFixed(2)}s`,
        "--bub-text-delay": `-${rnd(0, 10).toFixed(2)}s`
      };
    }
    if (n === "aurora") {
      return {
        // The sky is one box-shadow field; the curtains are separate gel sheets.
        "--aur-stars": particleField(20, 58, 26, STAR_TINTS),
        "--aur-curtain-dur": `${rnd(12, 24).toFixed(2)}s`,
        "--aur-curtain-delay": `-${rnd(0, 22).toFixed(2)}s`,
        "--aur-sway-dur": `${rnd(9, 17).toFixed(2)}s`,
        "--aur-sway-delay": `-${rnd(0, 16).toFixed(2)}s`,
        "--aur-glow-dur": `${rnd(8, 16).toFixed(2)}s`,
        "--aur-glow-delay": `-${rnd(0, 14).toFixed(2)}s`,
        "--aur-star-dur": `${rnd(4, 8).toFixed(2)}s`,
        "--aur-star-delay": `-${rnd(0, 7).toFixed(2)}s`,
        "--aur-text-dur": `${rnd(8, 15).toFixed(2)}s`,
        "--aur-text-delay": `-${rnd(0, 13).toFixed(2)}s`
      };
    }
    if (n === "sol") {
      return {
        "--sol-glare": rnd(0.85, 1).toFixed(2),
        // the glare bloom at the edge pulsing, and the corona under it breathing slower
        // still - two periods on the same source, so the light never sits perfectly still
        "--sol-shim-dur": `${rnd(4.5, 9.5).toFixed(2)}s`,
        "--sol-shim-delay": `-${rnd(0, 9).toFixed(2)}s`,
        "--sol-glow-dur": `${rnd(11, 21).toFixed(2)}s`,
        "--sol-glow-delay": `-${rnd(0, 19).toFixed(2)}s`,
        "--sol-text-dur": `${rnd(8, 14).toFixed(2)}s`,
        "--sol-text-delay": `-${rnd(0, 12).toFixed(2)}s`
      };
    }
    if (n !== "stars") return {};
    return {
      // two independent fields: a denser one up top, a sparser one lower down
      "--star-a-field": particleField(28, 52, 11, STAR_TINTS),
      "--star-b-field": particleField(20, 68, 12, STAR_TINTS),
      "--star-a-left": `${Math.round(rnd(4, 28))}px`,
      "--star-a-top": `${Math.round(rnd(16, 40))}%`,
      "--star-b-left": `${Math.round(rnd(12, 46))}px`,
      "--star-b-top": `${Math.round(rnd(54, 80))}%`,
      // where each field re-appears after twinkling out (the keyframes move it
      // while it's invisible, so stars come back somewhere new)
      "--star-a-dx": `${Math.round(rnd(-16, 20))}px`,
      "--star-a-dy": `${Math.round(rnd(-7, 7))}px`,
      "--star-b-dx": `${Math.round(rnd(-20, 16))}px`,
      "--star-b-dy": `${Math.round(rnd(-7, 7))}px`,
      // periods differ per line AND per field, so nothing beats in unison; the
      // negative delay starts each one mid-cycle so lines never march together.
      "--star-a-dur": `${rnd(2.2, 4.8).toFixed(2)}s`,
      "--star-b-dur": `${rnd(2.8, 5.6).toFixed(2)}s`,
      "--star-a-delay": `-${rnd(0, 5).toFixed(2)}s`,
      "--star-b-delay": `-${rnd(0, 5).toFixed(2)}s`,
      // the repeating background field fills any row height, including image
      // messages; the offsets keep two rows from tiling in lockstep
      "--star-bg-x": `${Math.round(rnd(0, 160))}px`,
      "--star-bg-y": `${Math.round(rnd(0, 120))}px`
    };
  }

  // src/lib/emojis.js
  var EMOJI_GROUPS = [
    { id: "smileys", label: "Smileys", icon: "\u{1F600}", emojis: ["\u{1F600}", "\u{1F603}", "\u{1F604}", "\u{1F601}", "\u{1F606}", "\u{1F605}", "\u{1F923}", "\u{1F602}", "\u{1F642}", "\u{1F643}", "\u{1FAE0}", "\u{1F609}", "\u{1F60A}", "\u{1F607}", "\u{1F970}", "\u{1F60D}", "\u{1F929}", "\u{1F618}", "\u{1F617}", "\u263A\uFE0F", "\u263A", "\u{1F61A}", "\u{1F619}", "\u{1F972}", "\u{1F60B}", "\u{1F61B}", "\u{1F61C}", "\u{1F92A}", "\u{1F61D}", "\u{1F911}", "\u{1F917}", "\u{1F92D}", "\u{1FAE2}", "\u{1FAE3}", "\u{1F92B}", "\u{1F914}", "\u{1FAE1}", "\u{1F910}", "\u{1F928}", "\u{1F610}", "\u{1F611}", "\u{1F636}", "\u{1FAE5}", "\u{1F636}\u200D\u{1F32B}\uFE0F", "\u{1F636}\u200D\u{1F32B}", "\u{1F60F}", "\u{1F612}", "\u{1F644}", "\u{1F62C}", "\u{1F62E}\u200D\u{1F4A8}", "\u{1F925}", "\u{1FAE8}", "\u{1F642}\u200D\u2194\uFE0F", "\u{1F642}\u200D\u2194", "\u{1F642}\u200D\u2195\uFE0F", "\u{1F642}\u200D\u2195", "\u{1F60C}", "\u{1F614}", "\u{1F62A}", "\u{1F924}", "\u{1F634}", "\u{1FAE9}", "\u{1F637}", "\u{1F912}", "\u{1F915}", "\u{1F922}", "\u{1F92E}", "\u{1F927}", "\u{1F975}", "\u{1F976}", "\u{1F974}", "\u{1F635}", "\u{1F635}\u200D\u{1F4AB}", "\u{1F92F}", "\u{1F920}", "\u{1F973}", "\u{1F978}", "\u{1F60E}", "\u{1F913}", "\u{1F9D0}", "\u{1F615}", "\u{1FAE4}", "\u{1F61F}", "\u{1F641}", "\u2639\uFE0F", "\u2639", "\u{1F62E}", "\u{1F62F}", "\u{1F632}", "\u{1F633}", "\u{1F97A}", "\u{1F979}", "\u{1F626}", "\u{1F627}", "\u{1F628}", "\u{1F630}", "\u{1F625}", "\u{1F622}", "\u{1F62D}", "\u{1F631}", "\u{1F616}", "\u{1F623}", "\u{1F61E}", "\u{1F613}", "\u{1F629}", "\u{1F62B}", "\u{1F971}", "\u{1F624}", "\u{1F621}", "\u{1F620}", "\u{1F92C}", "\u{1F608}", "\u{1F47F}", "\u{1F480}", "\u2620\uFE0F", "\u2620", "\u{1F4A9}", "\u{1F921}", "\u{1F479}", "\u{1F47A}", "\u{1F47B}", "\u{1F47D}", "\u{1F47E}", "\u{1F916}", "\u{1F63A}", "\u{1F638}", "\u{1F639}", "\u{1F63B}", "\u{1F63C}", "\u{1F63D}", "\u{1F640}", "\u{1F63F}", "\u{1F63E}", "\u{1F648}", "\u{1F649}", "\u{1F64A}", "\u{1F48C}", "\u{1F498}", "\u{1F49D}", "\u{1F496}", "\u{1F497}", "\u{1F493}", "\u{1F49E}", "\u{1F495}", "\u{1F49F}", "\u2763\uFE0F", "\u2763", "\u{1F494}", "\u2764\uFE0F\u200D\u{1F525}", "\u2764\u200D\u{1F525}", "\u2764\uFE0F\u200D\u{1FA79}", "\u2764\u200D\u{1FA79}", "\u2764\uFE0F", "\u2764", "\u{1FA77}", "\u{1F9E1}", "\u{1F49B}", "\u{1F49A}", "\u{1F499}", "\u{1FA75}", "\u{1F49C}", "\u{1F90E}", "\u{1F5A4}", "\u{1FA76}", "\u{1F90D}", "\u{1F48B}", "\u{1F4AF}", "\u{1F4A2}", "\u{1F4A5}", "\u{1F4AB}", "\u{1F4A6}", "\u{1F4A8}", "\u{1F573}\uFE0F", "\u{1F573}", "\u{1F4AC}", "\u{1F441}\uFE0F\u200D\u{1F5E8}\uFE0F", "\u{1F441}\u200D\u{1F5E8}\uFE0F", "\u{1F441}\uFE0F\u200D\u{1F5E8}", "\u{1F441}\u200D\u{1F5E8}", "\u{1F5E8}\uFE0F", "\u{1F5E8}", "\u{1F5EF}\uFE0F", "\u{1F5EF}", "\u{1F4AD}", "\u{1F4A4}"] },
    { id: "people", label: "People", icon: "\u{1F44B}", emojis: ["\u{1F44B}", "\u{1F91A}", "\u{1F590}\uFE0F", "\u{1F590}", "\u270B", "\u{1F596}", "\u{1FAF1}", "\u{1FAF2}", "\u{1FAF3}", "\u{1FAF4}", "\u{1FAF7}", "\u{1FAF8}", "\u{1F44C}", "\u{1F90C}", "\u{1F90F}", "\u270C\uFE0F", "\u270C", "\u{1F91E}", "\u{1FAF0}", "\u{1F91F}", "\u{1F918}", "\u{1F919}", "\u{1F448}", "\u{1F449}", "\u{1F446}", "\u{1F595}", "\u{1F447}", "\u261D\uFE0F", "\u261D", "\u{1FAF5}", "\u{1F44D}", "\u{1F44E}", "\u270A", "\u{1F44A}", "\u{1F91B}", "\u{1F91C}", "\u{1F44F}", "\u{1F64C}", "\u{1FAF6}", "\u{1F450}", "\u{1F932}", "\u{1F91D}", "\u{1F64F}", "\u270D\uFE0F", "\u270D", "\u{1F485}", "\u{1F933}", "\u{1F4AA}", "\u{1F9BE}", "\u{1F9BF}", "\u{1F9B5}", "\u{1F9B6}", "\u{1F442}", "\u{1F9BB}", "\u{1F443}", "\u{1F9E0}", "\u{1FAC0}", "\u{1FAC1}", "\u{1F9B7}", "\u{1F9B4}", "\u{1F440}", "\u{1F441}\uFE0F", "\u{1F441}", "\u{1F445}", "\u{1F444}", "\u{1FAE6}", "\u{1F476}", "\u{1F9D2}", "\u{1F466}", "\u{1F467}", "\u{1F9D1}", "\u{1F471}", "\u{1F468}", "\u{1F9D4}", "\u{1F9D4}\u200D\u2642\uFE0F", "\u{1F9D4}\u200D\u2642", "\u{1F9D4}\u200D\u2640\uFE0F", "\u{1F9D4}\u200D\u2640", "\u{1F468}\u200D\u{1F9B0}", "\u{1F468}\u200D\u{1F9B1}", "\u{1F468}\u200D\u{1F9B3}", "\u{1F468}\u200D\u{1F9B2}", "\u{1F469}", "\u{1F469}\u200D\u{1F9B0}", "\u{1F9D1}\u200D\u{1F9B0}", "\u{1F469}\u200D\u{1F9B1}", "\u{1F9D1}\u200D\u{1F9B1}", "\u{1F469}\u200D\u{1F9B3}", "\u{1F9D1}\u200D\u{1F9B3}", "\u{1F469}\u200D\u{1F9B2}", "\u{1F9D1}\u200D\u{1F9B2}", "\u{1F471}\u200D\u2640\uFE0F", "\u{1F471}\u200D\u2640", "\u{1F471}\u200D\u2642\uFE0F", "\u{1F471}\u200D\u2642", "\u{1F9D3}", "\u{1F474}", "\u{1F475}", "\u{1F64D}", "\u{1F64D}\u200D\u2642\uFE0F", "\u{1F64D}\u200D\u2642", "\u{1F64D}\u200D\u2640\uFE0F", "\u{1F64D}\u200D\u2640", "\u{1F64E}", "\u{1F64E}\u200D\u2642\uFE0F", "\u{1F64E}\u200D\u2642", "\u{1F64E}\u200D\u2640\uFE0F", "\u{1F64E}\u200D\u2640", "\u{1F645}", "\u{1F645}\u200D\u2642\uFE0F", "\u{1F645}\u200D\u2642", "\u{1F645}\u200D\u2640\uFE0F", "\u{1F645}\u200D\u2640", "\u{1F646}", "\u{1F646}\u200D\u2642\uFE0F", "\u{1F646}\u200D\u2642", "\u{1F646}\u200D\u2640\uFE0F", "\u{1F646}\u200D\u2640", "\u{1F481}", "\u{1F481}\u200D\u2642\uFE0F", "\u{1F481}\u200D\u2642", "\u{1F481}\u200D\u2640\uFE0F", "\u{1F481}\u200D\u2640", "\u{1F64B}", "\u{1F64B}\u200D\u2642\uFE0F", "\u{1F64B}\u200D\u2642", "\u{1F64B}\u200D\u2640\uFE0F", "\u{1F64B}\u200D\u2640", "\u{1F9CF}", "\u{1F9CF}\u200D\u2642\uFE0F", "\u{1F9CF}\u200D\u2642", "\u{1F9CF}\u200D\u2640\uFE0F", "\u{1F9CF}\u200D\u2640", "\u{1F647}", "\u{1F647}\u200D\u2642\uFE0F", "\u{1F647}\u200D\u2642", "\u{1F647}\u200D\u2640\uFE0F", "\u{1F647}\u200D\u2640", "\u{1F926}", "\u{1F926}\u200D\u2642\uFE0F", "\u{1F926}\u200D\u2642", "\u{1F926}\u200D\u2640\uFE0F", "\u{1F926}\u200D\u2640", "\u{1F937}", "\u{1F937}\u200D\u2642\uFE0F", "\u{1F937}\u200D\u2642", "\u{1F937}\u200D\u2640\uFE0F", "\u{1F937}\u200D\u2640", "\u{1F9D1}\u200D\u2695\uFE0F", "\u{1F9D1}\u200D\u2695", "\u{1F468}\u200D\u2695\uFE0F", "\u{1F468}\u200D\u2695", "\u{1F469}\u200D\u2695\uFE0F", "\u{1F469}\u200D\u2695", "\u{1F9D1}\u200D\u{1F393}", "\u{1F468}\u200D\u{1F393}", "\u{1F469}\u200D\u{1F393}", "\u{1F9D1}\u200D\u{1F3EB}", "\u{1F468}\u200D\u{1F3EB}", "\u{1F469}\u200D\u{1F3EB}", "\u{1F9D1}\u200D\u2696\uFE0F", "\u{1F9D1}\u200D\u2696", "\u{1F468}\u200D\u2696\uFE0F", "\u{1F468}\u200D\u2696", "\u{1F469}\u200D\u2696\uFE0F", "\u{1F469}\u200D\u2696", "\u{1F9D1}\u200D\u{1F33E}", "\u{1F468}\u200D\u{1F33E}", "\u{1F469}\u200D\u{1F33E}", "\u{1F9D1}\u200D\u{1F373}", "\u{1F468}\u200D\u{1F373}", "\u{1F469}\u200D\u{1F373}", "\u{1F9D1}\u200D\u{1F527}", "\u{1F468}\u200D\u{1F527}", "\u{1F469}\u200D\u{1F527}", "\u{1F9D1}\u200D\u{1F3ED}", "\u{1F468}\u200D\u{1F3ED}", "\u{1F469}\u200D\u{1F3ED}", "\u{1F9D1}\u200D\u{1F4BC}", "\u{1F468}\u200D\u{1F4BC}", "\u{1F469}\u200D\u{1F4BC}", "\u{1F9D1}\u200D\u{1F52C}", "\u{1F468}\u200D\u{1F52C}", "\u{1F469}\u200D\u{1F52C}", "\u{1F9D1}\u200D\u{1F4BB}", "\u{1F468}\u200D\u{1F4BB}", "\u{1F469}\u200D\u{1F4BB}", "\u{1F9D1}\u200D\u{1F3A4}", "\u{1F468}\u200D\u{1F3A4}", "\u{1F469}\u200D\u{1F3A4}", "\u{1F9D1}\u200D\u{1F3A8}", "\u{1F468}\u200D\u{1F3A8}", "\u{1F469}\u200D\u{1F3A8}", "\u{1F9D1}\u200D\u2708\uFE0F", "\u{1F9D1}\u200D\u2708", "\u{1F468}\u200D\u2708\uFE0F", "\u{1F468}\u200D\u2708", "\u{1F469}\u200D\u2708\uFE0F", "\u{1F469}\u200D\u2708", "\u{1F9D1}\u200D\u{1F680}", "\u{1F468}\u200D\u{1F680}", "\u{1F469}\u200D\u{1F680}", "\u{1F9D1}\u200D\u{1F692}", "\u{1F468}\u200D\u{1F692}", "\u{1F469}\u200D\u{1F692}", "\u{1F46E}", "\u{1F46E}\u200D\u2642\uFE0F", "\u{1F46E}\u200D\u2642", "\u{1F46E}\u200D\u2640\uFE0F", "\u{1F46E}\u200D\u2640", "\u{1F575}\uFE0F", "\u{1F575}", "\u{1F575}\uFE0F\u200D\u2642\uFE0F", "\u{1F575}\u200D\u2642\uFE0F", "\u{1F575}\uFE0F\u200D\u2642", "\u{1F575}\u200D\u2642", "\u{1F575}\uFE0F\u200D\u2640\uFE0F", "\u{1F575}\u200D\u2640\uFE0F", "\u{1F575}\uFE0F\u200D\u2640", "\u{1F575}\u200D\u2640", "\u{1F482}", "\u{1F482}\u200D\u2642\uFE0F", "\u{1F482}\u200D\u2642", "\u{1F482}\u200D\u2640\uFE0F", "\u{1F482}\u200D\u2640", "\u{1F977}", "\u{1F477}", "\u{1F477}\u200D\u2642\uFE0F", "\u{1F477}\u200D\u2642", "\u{1F477}\u200D\u2640\uFE0F", "\u{1F477}\u200D\u2640", "\u{1FAC5}", "\u{1F934}", "\u{1F478}", "\u{1F473}", "\u{1F473}\u200D\u2642\uFE0F", "\u{1F473}\u200D\u2642", "\u{1F473}\u200D\u2640\uFE0F", "\u{1F473}\u200D\u2640", "\u{1F472}", "\u{1F9D5}", "\u{1F935}", "\u{1F935}\u200D\u2642\uFE0F", "\u{1F935}\u200D\u2642", "\u{1F935}\u200D\u2640\uFE0F", "\u{1F935}\u200D\u2640", "\u{1F470}", "\u{1F470}\u200D\u2642\uFE0F", "\u{1F470}\u200D\u2642", "\u{1F470}\u200D\u2640\uFE0F", "\u{1F470}\u200D\u2640", "\u{1F930}", "\u{1FAC3}", "\u{1FAC4}", "\u{1F931}", "\u{1F469}\u200D\u{1F37C}", "\u{1F468}\u200D\u{1F37C}", "\u{1F9D1}\u200D\u{1F37C}", "\u{1F47C}", "\u{1F385}", "\u{1F936}", "\u{1F9D1}\u200D\u{1F384}", "\u{1F9B8}", "\u{1F9B8}\u200D\u2642\uFE0F", "\u{1F9B8}\u200D\u2642", "\u{1F9B8}\u200D\u2640\uFE0F", "\u{1F9B8}\u200D\u2640", "\u{1F9B9}", "\u{1F9B9}\u200D\u2642\uFE0F", "\u{1F9B9}\u200D\u2642", "\u{1F9B9}\u200D\u2640\uFE0F", "\u{1F9B9}\u200D\u2640", "\u{1F9D9}", "\u{1F9D9}\u200D\u2642\uFE0F", "\u{1F9D9}\u200D\u2642", "\u{1F9D9}\u200D\u2640\uFE0F", "\u{1F9D9}\u200D\u2640", "\u{1F9DA}", "\u{1F9DA}\u200D\u2642\uFE0F", "\u{1F9DA}\u200D\u2642", "\u{1F9DA}\u200D\u2640\uFE0F", "\u{1F9DA}\u200D\u2640", "\u{1F9DB}", "\u{1F9DB}\u200D\u2642\uFE0F", "\u{1F9DB}\u200D\u2642", "\u{1F9DB}\u200D\u2640\uFE0F", "\u{1F9DB}\u200D\u2640", "\u{1F9DC}", "\u{1F9DC}\u200D\u2642\uFE0F", "\u{1F9DC}\u200D\u2642", "\u{1F9DC}\u200D\u2640\uFE0F", "\u{1F9DC}\u200D\u2640", "\u{1F9DD}", "\u{1F9DD}\u200D\u2642\uFE0F", "\u{1F9DD}\u200D\u2642", "\u{1F9DD}\u200D\u2640\uFE0F", "\u{1F9DD}\u200D\u2640", "\u{1F9DE}", "\u{1F9DE}\u200D\u2642\uFE0F", "\u{1F9DE}\u200D\u2642", "\u{1F9DE}\u200D\u2640\uFE0F", "\u{1F9DE}\u200D\u2640", "\u{1F9DF}", "\u{1F9DF}\u200D\u2642\uFE0F", "\u{1F9DF}\u200D\u2642", "\u{1F9DF}\u200D\u2640\uFE0F", "\u{1F9DF}\u200D\u2640", "\u{1F9CC}", "\u{1F486}", "\u{1F486}\u200D\u2642\uFE0F", "\u{1F486}\u200D\u2642", "\u{1F486}\u200D\u2640\uFE0F", "\u{1F486}\u200D\u2640", "\u{1F487}", "\u{1F487}\u200D\u2642\uFE0F", "\u{1F487}\u200D\u2642", "\u{1F487}\u200D\u2640\uFE0F", "\u{1F487}\u200D\u2640", "\u{1F6B6}", "\u{1F6B6}\u200D\u2642\uFE0F", "\u{1F6B6}\u200D\u2642", "\u{1F6B6}\u200D\u2640\uFE0F", "\u{1F6B6}\u200D\u2640", "\u{1F6B6}\u200D\u27A1\uFE0F", "\u{1F6B6}\u200D\u27A1", "\u{1F6B6}\u200D\u2640\uFE0F\u200D\u27A1\uFE0F", "\u{1F6B6}\u200D\u2640\u200D\u27A1\uFE0F", "\u{1F6B6}\u200D\u2640\uFE0F\u200D\u27A1", "\u{1F6B6}\u200D\u2640\u200D\u27A1", "\u{1F6B6}\u200D\u2642\uFE0F\u200D\u27A1\uFE0F", "\u{1F6B6}\u200D\u2642\u200D\u27A1\uFE0F", "\u{1F6B6}\u200D\u2642\uFE0F\u200D\u27A1", "\u{1F6B6}\u200D\u2642\u200D\u27A1", "\u{1F9CD}", "\u{1F9CD}\u200D\u2642\uFE0F", "\u{1F9CD}\u200D\u2642", "\u{1F9CD}\u200D\u2640\uFE0F", "\u{1F9CD}\u200D\u2640", "\u{1F9CE}", "\u{1F9CE}\u200D\u2642\uFE0F", "\u{1F9CE}\u200D\u2642", "\u{1F9CE}\u200D\u2640\uFE0F", "\u{1F9CE}\u200D\u2640", "\u{1F9CE}\u200D\u27A1\uFE0F", "\u{1F9CE}\u200D\u27A1", "\u{1F9CE}\u200D\u2640\uFE0F\u200D\u27A1\uFE0F", "\u{1F9CE}\u200D\u2640\u200D\u27A1\uFE0F", "\u{1F9CE}\u200D\u2640\uFE0F\u200D\u27A1", "\u{1F9CE}\u200D\u2640\u200D\u27A1", "\u{1F9CE}\u200D\u2642\uFE0F\u200D\u27A1\uFE0F", "\u{1F9CE}\u200D\u2642\u200D\u27A1\uFE0F", "\u{1F9CE}\u200D\u2642\uFE0F\u200D\u27A1", "\u{1F9CE}\u200D\u2642\u200D\u27A1", "\u{1F9D1}\u200D\u{1F9AF}", "\u{1F9D1}\u200D\u{1F9AF}\u200D\u27A1\uFE0F", "\u{1F9D1}\u200D\u{1F9AF}\u200D\u27A1", "\u{1F468}\u200D\u{1F9AF}", "\u{1F468}\u200D\u{1F9AF}\u200D\u27A1\uFE0F", "\u{1F468}\u200D\u{1F9AF}\u200D\u27A1", "\u{1F469}\u200D\u{1F9AF}", "\u{1F469}\u200D\u{1F9AF}\u200D\u27A1\uFE0F", "\u{1F469}\u200D\u{1F9AF}\u200D\u27A1", "\u{1F9D1}\u200D\u{1F9BC}", "\u{1F9D1}\u200D\u{1F9BC}\u200D\u27A1\uFE0F", "\u{1F9D1}\u200D\u{1F9BC}\u200D\u27A1", "\u{1F468}\u200D\u{1F9BC}", "\u{1F468}\u200D\u{1F9BC}\u200D\u27A1\uFE0F", "\u{1F468}\u200D\u{1F9BC}\u200D\u27A1", "\u{1F469}\u200D\u{1F9BC}", "\u{1F469}\u200D\u{1F9BC}\u200D\u27A1\uFE0F", "\u{1F469}\u200D\u{1F9BC}\u200D\u27A1", "\u{1F9D1}\u200D\u{1F9BD}", "\u{1F9D1}\u200D\u{1F9BD}\u200D\u27A1\uFE0F", "\u{1F9D1}\u200D\u{1F9BD}\u200D\u27A1", "\u{1F468}\u200D\u{1F9BD}", "\u{1F468}\u200D\u{1F9BD}\u200D\u27A1\uFE0F", "\u{1F468}\u200D\u{1F9BD}\u200D\u27A1", "\u{1F469}\u200D\u{1F9BD}", "\u{1F469}\u200D\u{1F9BD}\u200D\u27A1\uFE0F", "\u{1F469}\u200D\u{1F9BD}\u200D\u27A1", "\u{1F3C3}", "\u{1F3C3}\u200D\u2642\uFE0F", "\u{1F3C3}\u200D\u2642", "\u{1F3C3}\u200D\u2640\uFE0F", "\u{1F3C3}\u200D\u2640", "\u{1F3C3}\u200D\u27A1\uFE0F", "\u{1F3C3}\u200D\u27A1", "\u{1F3C3}\u200D\u2640\uFE0F\u200D\u27A1\uFE0F", "\u{1F3C3}\u200D\u2640\u200D\u27A1\uFE0F", "\u{1F3C3}\u200D\u2640\uFE0F\u200D\u27A1", "\u{1F3C3}\u200D\u2640\u200D\u27A1", "\u{1F3C3}\u200D\u2642\uFE0F\u200D\u27A1\uFE0F", "\u{1F3C3}\u200D\u2642\u200D\u27A1\uFE0F", "\u{1F3C3}\u200D\u2642\uFE0F\u200D\u27A1", "\u{1F3C3}\u200D\u2642\u200D\u27A1", "\u{1F483}", "\u{1F57A}", "\u{1F574}\uFE0F", "\u{1F574}", "\u{1F46F}", "\u{1F46F}\u200D\u2642\uFE0F", "\u{1F46F}\u200D\u2642", "\u{1F46F}\u200D\u2640\uFE0F", "\u{1F46F}\u200D\u2640", "\u{1F9D6}", "\u{1F9D6}\u200D\u2642\uFE0F", "\u{1F9D6}\u200D\u2642", "\u{1F9D6}\u200D\u2640\uFE0F", "\u{1F9D6}\u200D\u2640", "\u{1F9D7}", "\u{1F9D7}\u200D\u2642\uFE0F", "\u{1F9D7}\u200D\u2642", "\u{1F9D7}\u200D\u2640\uFE0F", "\u{1F9D7}\u200D\u2640", "\u{1F93A}", "\u{1F3C7}", "\u26F7\uFE0F", "\u26F7", "\u{1F3C2}", "\u{1F3CC}\uFE0F", "\u{1F3CC}", "\u{1F3CC}\uFE0F\u200D\u2642\uFE0F", "\u{1F3CC}\u200D\u2642\uFE0F", "\u{1F3CC}\uFE0F\u200D\u2642", "\u{1F3CC}\u200D\u2642", "\u{1F3CC}\uFE0F\u200D\u2640\uFE0F", "\u{1F3CC}\u200D\u2640\uFE0F", "\u{1F3CC}\uFE0F\u200D\u2640", "\u{1F3CC}\u200D\u2640", "\u{1F3C4}", "\u{1F3C4}\u200D\u2642\uFE0F", "\u{1F3C4}\u200D\u2642", "\u{1F3C4}\u200D\u2640\uFE0F", "\u{1F3C4}\u200D\u2640", "\u{1F6A3}", "\u{1F6A3}\u200D\u2642\uFE0F", "\u{1F6A3}\u200D\u2642", "\u{1F6A3}\u200D\u2640\uFE0F", "\u{1F6A3}\u200D\u2640", "\u{1F3CA}", "\u{1F3CA}\u200D\u2642\uFE0F", "\u{1F3CA}\u200D\u2642", "\u{1F3CA}\u200D\u2640\uFE0F", "\u{1F3CA}\u200D\u2640", "\u26F9\uFE0F", "\u26F9", "\u26F9\uFE0F\u200D\u2642\uFE0F", "\u26F9\u200D\u2642\uFE0F", "\u26F9\uFE0F\u200D\u2642", "\u26F9\u200D\u2642", "\u26F9\uFE0F\u200D\u2640\uFE0F", "\u26F9\u200D\u2640\uFE0F", "\u26F9\uFE0F\u200D\u2640", "\u26F9\u200D\u2640", "\u{1F3CB}\uFE0F", "\u{1F3CB}", "\u{1F3CB}\uFE0F\u200D\u2642\uFE0F", "\u{1F3CB}\u200D\u2642\uFE0F", "\u{1F3CB}\uFE0F\u200D\u2642", "\u{1F3CB}\u200D\u2642", "\u{1F3CB}\uFE0F\u200D\u2640\uFE0F", "\u{1F3CB}\u200D\u2640\uFE0F", "\u{1F3CB}\uFE0F\u200D\u2640", "\u{1F3CB}\u200D\u2640", "\u{1F6B4}", "\u{1F6B4}\u200D\u2642\uFE0F", "\u{1F6B4}\u200D\u2642", "\u{1F6B4}\u200D\u2640\uFE0F", "\u{1F6B4}\u200D\u2640", "\u{1F6B5}", "\u{1F6B5}\u200D\u2642\uFE0F", "\u{1F6B5}\u200D\u2642", "\u{1F6B5}\u200D\u2640\uFE0F", "\u{1F6B5}\u200D\u2640", "\u{1F938}", "\u{1F938}\u200D\u2642\uFE0F", "\u{1F938}\u200D\u2642", "\u{1F938}\u200D\u2640\uFE0F", "\u{1F938}\u200D\u2640", "\u{1F93C}", "\u{1F93C}\u200D\u2642\uFE0F", "\u{1F93C}\u200D\u2642", "\u{1F93C}\u200D\u2640\uFE0F", "\u{1F93C}\u200D\u2640", "\u{1F93D}", "\u{1F93D}\u200D\u2642\uFE0F", "\u{1F93D}\u200D\u2642", "\u{1F93D}\u200D\u2640\uFE0F", "\u{1F93D}\u200D\u2640", "\u{1F93E}", "\u{1F93E}\u200D\u2642\uFE0F", "\u{1F93E}\u200D\u2642", "\u{1F93E}\u200D\u2640\uFE0F", "\u{1F93E}\u200D\u2640", "\u{1F939}", "\u{1F939}\u200D\u2642\uFE0F", "\u{1F939}\u200D\u2642", "\u{1F939}\u200D\u2640\uFE0F", "\u{1F939}\u200D\u2640", "\u{1F9D8}", "\u{1F9D8}\u200D\u2642\uFE0F", "\u{1F9D8}\u200D\u2642", "\u{1F9D8}\u200D\u2640\uFE0F", "\u{1F9D8}\u200D\u2640", "\u{1F6C0}", "\u{1F6CC}", "\u{1F9D1}\u200D\u{1F91D}\u200D\u{1F9D1}", "\u{1F46D}", "\u{1F46B}", "\u{1F46C}", "\u{1F48F}", "\u{1F469}\u200D\u2764\uFE0F\u200D\u{1F48B}\u200D\u{1F468}", "\u{1F469}\u200D\u2764\u200D\u{1F48B}\u200D\u{1F468}", "\u{1F468}\u200D\u2764\uFE0F\u200D\u{1F48B}\u200D\u{1F468}", "\u{1F468}\u200D\u2764\u200D\u{1F48B}\u200D\u{1F468}", "\u{1F469}\u200D\u2764\uFE0F\u200D\u{1F48B}\u200D\u{1F469}", "\u{1F469}\u200D\u2764\u200D\u{1F48B}\u200D\u{1F469}", "\u{1F491}", "\u{1F469}\u200D\u2764\uFE0F\u200D\u{1F468}", "\u{1F469}\u200D\u2764\u200D\u{1F468}", "\u{1F468}\u200D\u2764\uFE0F\u200D\u{1F468}", "\u{1F468}\u200D\u2764\u200D\u{1F468}", "\u{1F469}\u200D\u2764\uFE0F\u200D\u{1F469}", "\u{1F469}\u200D\u2764\u200D\u{1F469}", "\u{1F468}\u200D\u{1F469}\u200D\u{1F466}", "\u{1F468}\u200D\u{1F469}\u200D\u{1F467}", "\u{1F468}\u200D\u{1F469}\u200D\u{1F467}\u200D\u{1F466}", "\u{1F468}\u200D\u{1F469}\u200D\u{1F466}\u200D\u{1F466}", "\u{1F468}\u200D\u{1F469}\u200D\u{1F467}\u200D\u{1F467}", "\u{1F468}\u200D\u{1F468}\u200D\u{1F466}", "\u{1F468}\u200D\u{1F468}\u200D\u{1F467}", "\u{1F468}\u200D\u{1F468}\u200D\u{1F467}\u200D\u{1F466}", "\u{1F468}\u200D\u{1F468}\u200D\u{1F466}\u200D\u{1F466}", "\u{1F468}\u200D\u{1F468}\u200D\u{1F467}\u200D\u{1F467}", "\u{1F469}\u200D\u{1F469}\u200D\u{1F466}", "\u{1F469}\u200D\u{1F469}\u200D\u{1F467}", "\u{1F469}\u200D\u{1F469}\u200D\u{1F467}\u200D\u{1F466}", "\u{1F469}\u200D\u{1F469}\u200D\u{1F466}\u200D\u{1F466}", "\u{1F469}\u200D\u{1F469}\u200D\u{1F467}\u200D\u{1F467}", "\u{1F468}\u200D\u{1F466}", "\u{1F468}\u200D\u{1F466}\u200D\u{1F466}", "\u{1F468}\u200D\u{1F467}", "\u{1F468}\u200D\u{1F467}\u200D\u{1F466}", "\u{1F468}\u200D\u{1F467}\u200D\u{1F467}", "\u{1F469}\u200D\u{1F466}", "\u{1F469}\u200D\u{1F466}\u200D\u{1F466}", "\u{1F469}\u200D\u{1F467}", "\u{1F469}\u200D\u{1F467}\u200D\u{1F466}", "\u{1F469}\u200D\u{1F467}\u200D\u{1F467}", "\u{1F5E3}\uFE0F", "\u{1F5E3}", "\u{1F464}", "\u{1F465}", "\u{1FAC2}", "\u{1F46A}", "\u{1F9D1}\u200D\u{1F9D1}\u200D\u{1F9D2}", "\u{1F9D1}\u200D\u{1F9D1}\u200D\u{1F9D2}\u200D\u{1F9D2}", "\u{1F9D1}\u200D\u{1F9D2}", "\u{1F9D1}\u200D\u{1F9D2}\u200D\u{1F9D2}", "\u{1F463}", "\u{1FAC6}"] },
    { id: "nature", label: "Nature", icon: "\u{1F43B}", emojis: ["\u{1F435}", "\u{1F412}", "\u{1F98D}", "\u{1F9A7}", "\u{1F436}", "\u{1F415}", "\u{1F9AE}", "\u{1F415}\u200D\u{1F9BA}", "\u{1F429}", "\u{1F43A}", "\u{1F98A}", "\u{1F99D}", "\u{1F431}", "\u{1F408}", "\u{1F408}\u200D\u2B1B", "\u{1F981}", "\u{1F42F}", "\u{1F405}", "\u{1F406}", "\u{1F434}", "\u{1FACE}", "\u{1FACF}", "\u{1F40E}", "\u{1F984}", "\u{1F993}", "\u{1F98C}", "\u{1F9AC}", "\u{1F42E}", "\u{1F402}", "\u{1F403}", "\u{1F404}", "\u{1F437}", "\u{1F416}", "\u{1F417}", "\u{1F43D}", "\u{1F40F}", "\u{1F411}", "\u{1F410}", "\u{1F42A}", "\u{1F42B}", "\u{1F999}", "\u{1F992}", "\u{1F418}", "\u{1F9A3}", "\u{1F98F}", "\u{1F99B}", "\u{1F42D}", "\u{1F401}", "\u{1F400}", "\u{1F439}", "\u{1F430}", "\u{1F407}", "\u{1F43F}\uFE0F", "\u{1F43F}", "\u{1F9AB}", "\u{1F994}", "\u{1F987}", "\u{1F43B}", "\u{1F43B}\u200D\u2744\uFE0F", "\u{1F43B}\u200D\u2744", "\u{1F428}", "\u{1F43C}", "\u{1F9A5}", "\u{1F9A6}", "\u{1F9A8}", "\u{1F998}", "\u{1F9A1}", "\u{1F43E}", "\u{1F983}", "\u{1F414}", "\u{1F413}", "\u{1F423}", "\u{1F424}", "\u{1F425}", "\u{1F426}", "\u{1F427}", "\u{1F54A}\uFE0F", "\u{1F54A}", "\u{1F985}", "\u{1F986}", "\u{1F9A2}", "\u{1F989}", "\u{1F9A4}", "\u{1FAB6}", "\u{1F9A9}", "\u{1F99A}", "\u{1F99C}", "\u{1FABD}", "\u{1F426}\u200D\u2B1B", "\u{1FABF}", "\u{1F426}\u200D\u{1F525}", "\u{1F438}", "\u{1F40A}", "\u{1F422}", "\u{1F98E}", "\u{1F40D}", "\u{1F432}", "\u{1F409}", "\u{1F995}", "\u{1F996}", "\u{1F433}", "\u{1F40B}", "\u{1F42C}", "\u{1F9AD}", "\u{1F41F}", "\u{1F420}", "\u{1F421}", "\u{1F988}", "\u{1F419}", "\u{1F41A}", "\u{1FAB8}", "\u{1FABC}", "\u{1F980}", "\u{1F99E}", "\u{1F990}", "\u{1F991}", "\u{1F9AA}", "\u{1F40C}", "\u{1F98B}", "\u{1F41B}", "\u{1F41C}", "\u{1F41D}", "\u{1FAB2}", "\u{1F41E}", "\u{1F997}", "\u{1FAB3}", "\u{1F577}\uFE0F", "\u{1F577}", "\u{1F578}\uFE0F", "\u{1F578}", "\u{1F982}", "\u{1F99F}", "\u{1FAB0}", "\u{1FAB1}", "\u{1F9A0}", "\u{1F490}", "\u{1F338}", "\u{1F4AE}", "\u{1FAB7}", "\u{1F3F5}\uFE0F", "\u{1F3F5}", "\u{1F339}", "\u{1F940}", "\u{1F33A}", "\u{1F33B}", "\u{1F33C}", "\u{1F337}", "\u{1FABB}", "\u{1F331}", "\u{1FAB4}", "\u{1F332}", "\u{1F333}", "\u{1F334}", "\u{1F335}", "\u{1F33E}", "\u{1F33F}", "\u2618\uFE0F", "\u2618", "\u{1F340}", "\u{1F341}", "\u{1F342}", "\u{1F343}", "\u{1FAB9}", "\u{1FABA}", "\u{1F344}", "\u{1FABE}"] },
    { id: "food", label: "Food", icon: "\u{1F354}", emojis: ["\u{1F347}", "\u{1F348}", "\u{1F349}", "\u{1F34A}", "\u{1F34B}", "\u{1F34B}\u200D\u{1F7E9}", "\u{1F34C}", "\u{1F34D}", "\u{1F96D}", "\u{1F34E}", "\u{1F34F}", "\u{1F350}", "\u{1F351}", "\u{1F352}", "\u{1F353}", "\u{1FAD0}", "\u{1F95D}", "\u{1F345}", "\u{1FAD2}", "\u{1F965}", "\u{1F951}", "\u{1F346}", "\u{1F954}", "\u{1F955}", "\u{1F33D}", "\u{1F336}\uFE0F", "\u{1F336}", "\u{1FAD1}", "\u{1F952}", "\u{1F96C}", "\u{1F966}", "\u{1F9C4}", "\u{1F9C5}", "\u{1F95C}", "\u{1FAD8}", "\u{1F330}", "\u{1FADA}", "\u{1FADB}", "\u{1F344}\u200D\u{1F7EB}", "\u{1FADC}", "\u{1F35E}", "\u{1F950}", "\u{1F956}", "\u{1FAD3}", "\u{1F968}", "\u{1F96F}", "\u{1F95E}", "\u{1F9C7}", "\u{1F9C0}", "\u{1F356}", "\u{1F357}", "\u{1F969}", "\u{1F953}", "\u{1F354}", "\u{1F35F}", "\u{1F355}", "\u{1F32D}", "\u{1F96A}", "\u{1F32E}", "\u{1F32F}", "\u{1FAD4}", "\u{1F959}", "\u{1F9C6}", "\u{1F95A}", "\u{1F373}", "\u{1F958}", "\u{1F372}", "\u{1FAD5}", "\u{1F963}", "\u{1F957}", "\u{1F37F}", "\u{1F9C8}", "\u{1F9C2}", "\u{1F96B}", "\u{1F371}", "\u{1F358}", "\u{1F359}", "\u{1F35A}", "\u{1F35B}", "\u{1F35C}", "\u{1F35D}", "\u{1F360}", "\u{1F362}", "\u{1F363}", "\u{1F364}", "\u{1F365}", "\u{1F96E}", "\u{1F361}", "\u{1F95F}", "\u{1F960}", "\u{1F961}", "\u{1F366}", "\u{1F367}", "\u{1F368}", "\u{1F369}", "\u{1F36A}", "\u{1F382}", "\u{1F370}", "\u{1F9C1}", "\u{1F967}", "\u{1F36B}", "\u{1F36C}", "\u{1F36D}", "\u{1F36E}", "\u{1F36F}", "\u{1F37C}", "\u{1F95B}", "\u2615", "\u{1FAD6}", "\u{1F375}", "\u{1F376}", "\u{1F37E}", "\u{1F377}", "\u{1F378}", "\u{1F379}", "\u{1F37A}", "\u{1F37B}", "\u{1F942}", "\u{1F943}", "\u{1FAD7}", "\u{1F964}", "\u{1F9CB}", "\u{1F9C3}", "\u{1F9C9}", "\u{1F9CA}", "\u{1F962}", "\u{1F37D}\uFE0F", "\u{1F37D}", "\u{1F374}", "\u{1F944}", "\u{1F52A}", "\u{1FAD9}", "\u{1F3FA}"] },
    { id: "activities", label: "Activities", icon: "\u26BD", emojis: ["\u{1F383}", "\u{1F384}", "\u{1F386}", "\u{1F387}", "\u{1F9E8}", "\u2728", "\u{1F388}", "\u{1F389}", "\u{1F38A}", "\u{1F38B}", "\u{1F38D}", "\u{1F38E}", "\u{1F38F}", "\u{1F390}", "\u{1F391}", "\u{1F9E7}", "\u{1F380}", "\u{1F381}", "\u{1F397}\uFE0F", "\u{1F397}", "\u{1F39F}\uFE0F", "\u{1F39F}", "\u{1F3AB}", "\u{1F396}\uFE0F", "\u{1F396}", "\u{1F3C6}", "\u{1F3C5}", "\u{1F947}", "\u{1F948}", "\u{1F949}", "\u26BD", "\u26BE", "\u{1F94E}", "\u{1F3C0}", "\u{1F3D0}", "\u{1F3C8}", "\u{1F3C9}", "\u{1F3BE}", "\u{1F94F}", "\u{1F3B3}", "\u{1F3CF}", "\u{1F3D1}", "\u{1F3D2}", "\u{1F94D}", "\u{1F3D3}", "\u{1F3F8}", "\u{1F94A}", "\u{1F94B}", "\u{1F945}", "\u26F3", "\u26F8\uFE0F", "\u26F8", "\u{1F3A3}", "\u{1F93F}", "\u{1F3BD}", "\u{1F3BF}", "\u{1F6F7}", "\u{1F94C}", "\u{1F3AF}", "\u{1FA80}", "\u{1FA81}", "\u{1F52B}", "\u{1F3B1}", "\u{1F52E}", "\u{1FA84}", "\u{1F3AE}", "\u{1F579}\uFE0F", "\u{1F579}", "\u{1F3B0}", "\u{1F3B2}", "\u{1F9E9}", "\u{1F9F8}", "\u{1FA85}", "\u{1FAA9}", "\u{1FA86}", "\u2660\uFE0F", "\u2660", "\u2665\uFE0F", "\u2665", "\u2666\uFE0F", "\u2666", "\u2663\uFE0F", "\u2663", "\u265F\uFE0F", "\u265F", "\u{1F0CF}", "\u{1F004}", "\u{1F3B4}", "\u{1F3AD}", "\u{1F5BC}\uFE0F", "\u{1F5BC}", "\u{1F3A8}", "\u{1F9F5}", "\u{1FAA1}", "\u{1F9F6}", "\u{1FAA2}"] },
    { id: "travel", label: "Travel", icon: "\u{1F697}", emojis: ["\u{1F30D}", "\u{1F30E}", "\u{1F30F}", "\u{1F310}", "\u{1F5FA}\uFE0F", "\u{1F5FA}", "\u{1F5FE}", "\u{1F9ED}", "\u{1F3D4}\uFE0F", "\u{1F3D4}", "\u26F0\uFE0F", "\u26F0", "\u{1F30B}", "\u{1F5FB}", "\u{1F3D5}\uFE0F", "\u{1F3D5}", "\u{1F3D6}\uFE0F", "\u{1F3D6}", "\u{1F3DC}\uFE0F", "\u{1F3DC}", "\u{1F3DD}\uFE0F", "\u{1F3DD}", "\u{1F3DE}\uFE0F", "\u{1F3DE}", "\u{1F3DF}\uFE0F", "\u{1F3DF}", "\u{1F3DB}\uFE0F", "\u{1F3DB}", "\u{1F3D7}\uFE0F", "\u{1F3D7}", "\u{1F9F1}", "\u{1FAA8}", "\u{1FAB5}", "\u{1F6D6}", "\u{1F3D8}\uFE0F", "\u{1F3D8}", "\u{1F3DA}\uFE0F", "\u{1F3DA}", "\u{1F3E0}", "\u{1F3E1}", "\u{1F3E2}", "\u{1F3E3}", "\u{1F3E4}", "\u{1F3E5}", "\u{1F3E6}", "\u{1F3E8}", "\u{1F3E9}", "\u{1F3EA}", "\u{1F3EB}", "\u{1F3EC}", "\u{1F3ED}", "\u{1F3EF}", "\u{1F3F0}", "\u{1F492}", "\u{1F5FC}", "\u{1F5FD}", "\u26EA", "\u{1F54C}", "\u{1F6D5}", "\u{1F54D}", "\u26E9\uFE0F", "\u26E9", "\u{1F54B}", "\u26F2", "\u26FA", "\u{1F301}", "\u{1F303}", "\u{1F3D9}\uFE0F", "\u{1F3D9}", "\u{1F304}", "\u{1F305}", "\u{1F306}", "\u{1F307}", "\u{1F309}", "\u2668\uFE0F", "\u2668", "\u{1F3A0}", "\u{1F6DD}", "\u{1F3A1}", "\u{1F3A2}", "\u{1F488}", "\u{1F3AA}", "\u{1F682}", "\u{1F683}", "\u{1F684}", "\u{1F685}", "\u{1F686}", "\u{1F687}", "\u{1F688}", "\u{1F689}", "\u{1F68A}", "\u{1F69D}", "\u{1F69E}", "\u{1F68B}", "\u{1F68C}", "\u{1F68D}", "\u{1F68E}", "\u{1F690}", "\u{1F691}", "\u{1F692}", "\u{1F693}", "\u{1F694}", "\u{1F695}", "\u{1F696}", "\u{1F697}", "\u{1F698}", "\u{1F699}", "\u{1F6FB}", "\u{1F69A}", "\u{1F69B}", "\u{1F69C}", "\u{1F3CE}\uFE0F", "\u{1F3CE}", "\u{1F3CD}\uFE0F", "\u{1F3CD}", "\u{1F6F5}", "\u{1F9BD}", "\u{1F9BC}", "\u{1F6FA}", "\u{1F6B2}", "\u{1F6F4}", "\u{1F6F9}", "\u{1F6FC}", "\u{1F68F}", "\u{1F6E3}\uFE0F", "\u{1F6E3}", "\u{1F6E4}\uFE0F", "\u{1F6E4}", "\u{1F6E2}\uFE0F", "\u{1F6E2}", "\u26FD", "\u{1F6DE}", "\u{1F6A8}", "\u{1F6A5}", "\u{1F6A6}", "\u{1F6D1}", "\u{1F6A7}", "\u2693", "\u{1F6DF}", "\u26F5", "\u{1F6F6}", "\u{1F6A4}", "\u{1F6F3}\uFE0F", "\u{1F6F3}", "\u26F4\uFE0F", "\u26F4", "\u{1F6E5}\uFE0F", "\u{1F6E5}", "\u{1F6A2}", "\u2708\uFE0F", "\u2708", "\u{1F6E9}\uFE0F", "\u{1F6E9}", "\u{1F6EB}", "\u{1F6EC}", "\u{1FA82}", "\u{1F4BA}", "\u{1F681}", "\u{1F69F}", "\u{1F6A0}", "\u{1F6A1}", "\u{1F6F0}\uFE0F", "\u{1F6F0}", "\u{1F680}", "\u{1F6F8}", "\u{1F6CE}\uFE0F", "\u{1F6CE}", "\u{1F9F3}", "\u231B", "\u23F3", "\u231A", "\u23F0", "\u23F1\uFE0F", "\u23F1", "\u23F2\uFE0F", "\u23F2", "\u{1F570}\uFE0F", "\u{1F570}", "\u{1F55B}", "\u{1F567}", "\u{1F550}", "\u{1F55C}", "\u{1F551}", "\u{1F55D}", "\u{1F552}", "\u{1F55E}", "\u{1F553}", "\u{1F55F}", "\u{1F554}", "\u{1F560}", "\u{1F555}", "\u{1F561}", "\u{1F556}", "\u{1F562}", "\u{1F557}", "\u{1F563}", "\u{1F558}", "\u{1F564}", "\u{1F559}", "\u{1F565}", "\u{1F55A}", "\u{1F566}", "\u{1F311}", "\u{1F312}", "\u{1F313}", "\u{1F314}", "\u{1F315}", "\u{1F316}", "\u{1F317}", "\u{1F318}", "\u{1F319}", "\u{1F31A}", "\u{1F31B}", "\u{1F31C}", "\u{1F321}\uFE0F", "\u{1F321}", "\u2600\uFE0F", "\u2600", "\u{1F31D}", "\u{1F31E}", "\u{1FA90}", "\u2B50", "\u{1F31F}", "\u{1F320}", "\u{1F30C}", "\u2601\uFE0F", "\u2601", "\u26C5", "\u26C8\uFE0F", "\u26C8", "\u{1F324}\uFE0F", "\u{1F324}", "\u{1F325}\uFE0F", "\u{1F325}", "\u{1F326}\uFE0F", "\u{1F326}", "\u{1F327}\uFE0F", "\u{1F327}", "\u{1F328}\uFE0F", "\u{1F328}", "\u{1F329}\uFE0F", "\u{1F329}", "\u{1F32A}\uFE0F", "\u{1F32A}", "\u{1F32B}\uFE0F", "\u{1F32B}", "\u{1F32C}\uFE0F", "\u{1F32C}", "\u{1F300}", "\u{1F308}", "\u{1F302}", "\u2602\uFE0F", "\u2602", "\u2614", "\u26F1\uFE0F", "\u26F1", "\u26A1", "\u2744\uFE0F", "\u2744", "\u2603\uFE0F", "\u2603", "\u26C4", "\u2604\uFE0F", "\u2604", "\u{1F525}", "\u{1F4A7}", "\u{1F30A}"] },
    { id: "objects", label: "Objects", icon: "\u{1F4A1}", emojis: ["\u{1F453}", "\u{1F576}\uFE0F", "\u{1F576}", "\u{1F97D}", "\u{1F97C}", "\u{1F9BA}", "\u{1F454}", "\u{1F455}", "\u{1F456}", "\u{1F9E3}", "\u{1F9E4}", "\u{1F9E5}", "\u{1F9E6}", "\u{1F457}", "\u{1F458}", "\u{1F97B}", "\u{1FA71}", "\u{1FA72}", "\u{1FA73}", "\u{1F459}", "\u{1F45A}", "\u{1FAAD}", "\u{1F45B}", "\u{1F45C}", "\u{1F45D}", "\u{1F6CD}\uFE0F", "\u{1F6CD}", "\u{1F392}", "\u{1FA74}", "\u{1F45E}", "\u{1F45F}", "\u{1F97E}", "\u{1F97F}", "\u{1F460}", "\u{1F461}", "\u{1FA70}", "\u{1F462}", "\u{1FAAE}", "\u{1F451}", "\u{1F452}", "\u{1F3A9}", "\u{1F393}", "\u{1F9E2}", "\u{1FA96}", "\u26D1\uFE0F", "\u26D1", "\u{1F4FF}", "\u{1F484}", "\u{1F48D}", "\u{1F48E}", "\u{1F507}", "\u{1F508}", "\u{1F509}", "\u{1F50A}", "\u{1F4E2}", "\u{1F4E3}", "\u{1F4EF}", "\u{1F514}", "\u{1F515}", "\u{1F3BC}", "\u{1F3B5}", "\u{1F3B6}", "\u{1F399}\uFE0F", "\u{1F399}", "\u{1F39A}\uFE0F", "\u{1F39A}", "\u{1F39B}\uFE0F", "\u{1F39B}", "\u{1F3A4}", "\u{1F3A7}", "\u{1F4FB}", "\u{1F3B7}", "\u{1FA97}", "\u{1F3B8}", "\u{1F3B9}", "\u{1F3BA}", "\u{1F3BB}", "\u{1FA95}", "\u{1F941}", "\u{1FA98}", "\u{1FA87}", "\u{1FA88}", "\u{1FA89}", "\u{1F4F1}", "\u{1F4F2}", "\u260E\uFE0F", "\u260E", "\u{1F4DE}", "\u{1F4DF}", "\u{1F4E0}", "\u{1F50B}", "\u{1FAAB}", "\u{1F50C}", "\u{1F4BB}", "\u{1F5A5}\uFE0F", "\u{1F5A5}", "\u{1F5A8}\uFE0F", "\u{1F5A8}", "\u2328\uFE0F", "\u2328", "\u{1F5B1}\uFE0F", "\u{1F5B1}", "\u{1F5B2}\uFE0F", "\u{1F5B2}", "\u{1F4BD}", "\u{1F4BE}", "\u{1F4BF}", "\u{1F4C0}", "\u{1F9EE}", "\u{1F3A5}", "\u{1F39E}\uFE0F", "\u{1F39E}", "\u{1F4FD}\uFE0F", "\u{1F4FD}", "\u{1F3AC}", "\u{1F4FA}", "\u{1F4F7}", "\u{1F4F8}", "\u{1F4F9}", "\u{1F4FC}", "\u{1F50D}", "\u{1F50E}", "\u{1F56F}\uFE0F", "\u{1F56F}", "\u{1F4A1}", "\u{1F526}", "\u{1F3EE}", "\u{1FA94}", "\u{1F4D4}", "\u{1F4D5}", "\u{1F4D6}", "\u{1F4D7}", "\u{1F4D8}", "\u{1F4D9}", "\u{1F4DA}", "\u{1F4D3}", "\u{1F4D2}", "\u{1F4C3}", "\u{1F4DC}", "\u{1F4C4}", "\u{1F4F0}", "\u{1F5DE}\uFE0F", "\u{1F5DE}", "\u{1F4D1}", "\u{1F516}", "\u{1F3F7}\uFE0F", "\u{1F3F7}", "\u{1F4B0}", "\u{1FA99}", "\u{1F4B4}", "\u{1F4B5}", "\u{1F4B6}", "\u{1F4B7}", "\u{1F4B8}", "\u{1F4B3}", "\u{1F9FE}", "\u{1F4B9}", "\u2709\uFE0F", "\u2709", "\u{1F4E7}", "\u{1F4E8}", "\u{1F4E9}", "\u{1F4E4}", "\u{1F4E5}", "\u{1F4E6}", "\u{1F4EB}", "\u{1F4EA}", "\u{1F4EC}", "\u{1F4ED}", "\u{1F4EE}", "\u{1F5F3}\uFE0F", "\u{1F5F3}", "\u270F\uFE0F", "\u270F", "\u2712\uFE0F", "\u2712", "\u{1F58B}\uFE0F", "\u{1F58B}", "\u{1F58A}\uFE0F", "\u{1F58A}", "\u{1F58C}\uFE0F", "\u{1F58C}", "\u{1F58D}\uFE0F", "\u{1F58D}", "\u{1F4DD}", "\u{1F4BC}", "\u{1F4C1}", "\u{1F4C2}", "\u{1F5C2}\uFE0F", "\u{1F5C2}", "\u{1F4C5}", "\u{1F4C6}", "\u{1F5D2}\uFE0F", "\u{1F5D2}", "\u{1F5D3}\uFE0F", "\u{1F5D3}", "\u{1F4C7}", "\u{1F4C8}", "\u{1F4C9}", "\u{1F4CA}", "\u{1F4CB}", "\u{1F4CC}", "\u{1F4CD}", "\u{1F4CE}", "\u{1F587}\uFE0F", "\u{1F587}", "\u{1F4CF}", "\u{1F4D0}", "\u2702\uFE0F", "\u2702", "\u{1F5C3}\uFE0F", "\u{1F5C3}", "\u{1F5C4}\uFE0F", "\u{1F5C4}", "\u{1F5D1}\uFE0F", "\u{1F5D1}", "\u{1F512}", "\u{1F513}", "\u{1F50F}", "\u{1F510}", "\u{1F511}", "\u{1F5DD}\uFE0F", "\u{1F5DD}", "\u{1F528}", "\u{1FA93}", "\u26CF\uFE0F", "\u26CF", "\u2692\uFE0F", "\u2692", "\u{1F6E0}\uFE0F", "\u{1F6E0}", "\u{1F5E1}\uFE0F", "\u{1F5E1}", "\u2694\uFE0F", "\u2694", "\u{1F4A3}", "\u{1FA83}", "\u{1F3F9}", "\u{1F6E1}\uFE0F", "\u{1F6E1}", "\u{1FA9A}", "\u{1F527}", "\u{1FA9B}", "\u{1F529}", "\u2699\uFE0F", "\u2699", "\u{1F5DC}\uFE0F", "\u{1F5DC}", "\u2696\uFE0F", "\u2696", "\u{1F9AF}", "\u{1F517}", "\u26D3\uFE0F\u200D\u{1F4A5}", "\u26D3\u200D\u{1F4A5}", "\u26D3\uFE0F", "\u26D3", "\u{1FA9D}", "\u{1F9F0}", "\u{1F9F2}", "\u{1FA9C}", "\u{1FA8F}", "\u2697\uFE0F", "\u2697", "\u{1F9EA}", "\u{1F9EB}", "\u{1F9EC}", "\u{1F52C}", "\u{1F52D}", "\u{1F4E1}", "\u{1F489}", "\u{1FA78}", "\u{1F48A}", "\u{1FA79}", "\u{1FA7C}", "\u{1FA7A}", "\u{1FA7B}", "\u{1F6AA}", "\u{1F6D7}", "\u{1FA9E}", "\u{1FA9F}", "\u{1F6CF}\uFE0F", "\u{1F6CF}", "\u{1F6CB}\uFE0F", "\u{1F6CB}", "\u{1FA91}", "\u{1F6BD}", "\u{1FAA0}", "\u{1F6BF}", "\u{1F6C1}", "\u{1FAA4}", "\u{1FA92}", "\u{1F9F4}", "\u{1F9F7}", "\u{1F9F9}", "\u{1F9FA}", "\u{1F9FB}", "\u{1FAA3}", "\u{1F9FC}", "\u{1FAE7}", "\u{1FAA5}", "\u{1F9FD}", "\u{1F9EF}", "\u{1F6D2}", "\u{1F6AC}", "\u26B0\uFE0F", "\u26B0", "\u{1FAA6}", "\u26B1\uFE0F", "\u26B1", "\u{1F9FF}", "\u{1FAAC}", "\u{1F5FF}", "\u{1FAA7}", "\u{1FAAA}"] },
    { id: "symbols", label: "Symbols", icon: "\u2764\uFE0F", emojis: ["\u{1F3E7}", "\u{1F6AE}", "\u{1F6B0}", "\u267F", "\u{1F6B9}", "\u{1F6BA}", "\u{1F6BB}", "\u{1F6BC}", "\u{1F6BE}", "\u{1F6C2}", "\u{1F6C3}", "\u{1F6C4}", "\u{1F6C5}", "\u26A0\uFE0F", "\u26A0", "\u{1F6B8}", "\u26D4", "\u{1F6AB}", "\u{1F6B3}", "\u{1F6AD}", "\u{1F6AF}", "\u{1F6B1}", "\u{1F6B7}", "\u{1F4F5}", "\u{1F51E}", "\u2622\uFE0F", "\u2622", "\u2623\uFE0F", "\u2623", "\u2B06\uFE0F", "\u2B06", "\u2197\uFE0F", "\u2197", "\u27A1\uFE0F", "\u27A1", "\u2198\uFE0F", "\u2198", "\u2B07\uFE0F", "\u2B07", "\u2199\uFE0F", "\u2199", "\u2B05\uFE0F", "\u2B05", "\u2196\uFE0F", "\u2196", "\u2195\uFE0F", "\u2195", "\u2194\uFE0F", "\u2194", "\u21A9\uFE0F", "\u21A9", "\u21AA\uFE0F", "\u21AA", "\u2934\uFE0F", "\u2934", "\u2935\uFE0F", "\u2935", "\u{1F503}", "\u{1F504}", "\u{1F519}", "\u{1F51A}", "\u{1F51B}", "\u{1F51C}", "\u{1F51D}", "\u{1F6D0}", "\u269B\uFE0F", "\u269B", "\u{1F549}\uFE0F", "\u{1F549}", "\u2721\uFE0F", "\u2721", "\u2638\uFE0F", "\u2638", "\u262F\uFE0F", "\u262F", "\u271D\uFE0F", "\u271D", "\u2626\uFE0F", "\u2626", "\u262A\uFE0F", "\u262A", "\u262E\uFE0F", "\u262E", "\u{1F54E}", "\u{1F52F}", "\u{1FAAF}", "\u2648", "\u2649", "\u264A", "\u264B", "\u264C", "\u264D", "\u264E", "\u264F", "\u2650", "\u2651", "\u2652", "\u2653", "\u26CE", "\u{1F500}", "\u{1F501}", "\u{1F502}", "\u25B6\uFE0F", "\u25B6", "\u23E9", "\u23ED\uFE0F", "\u23ED", "\u23EF\uFE0F", "\u23EF", "\u25C0\uFE0F", "\u25C0", "\u23EA", "\u23EE\uFE0F", "\u23EE", "\u{1F53C}", "\u23EB", "\u{1F53D}", "\u23EC", "\u23F8\uFE0F", "\u23F8", "\u23F9\uFE0F", "\u23F9", "\u23FA\uFE0F", "\u23FA", "\u23CF\uFE0F", "\u23CF", "\u{1F3A6}", "\u{1F505}", "\u{1F506}", "\u{1F4F6}", "\u{1F6DC}", "\u{1F4F3}", "\u{1F4F4}", "\u2640\uFE0F", "\u2640", "\u2642\uFE0F", "\u2642", "\u26A7\uFE0F", "\u26A7", "\u2716\uFE0F", "\u2716", "\u2795", "\u2796", "\u2797", "\u{1F7F0}", "\u267E\uFE0F", "\u267E", "\u203C\uFE0F", "\u203C", "\u2049\uFE0F", "\u2049", "\u2753", "\u2754", "\u2755", "\u2757", "\u3030\uFE0F", "\u3030", "\u{1F4B1}", "\u{1F4B2}", "\u2695\uFE0F", "\u2695", "\u267B\uFE0F", "\u267B", "\u269C\uFE0F", "\u269C", "\u{1F531}", "\u{1F4DB}", "\u{1F530}", "\u2B55", "\u2705", "\u2611\uFE0F", "\u2611", "\u2714\uFE0F", "\u2714", "\u274C", "\u274E", "\u27B0", "\u27BF", "\u303D\uFE0F", "\u303D", "\u2733\uFE0F", "\u2733", "\u2734\uFE0F", "\u2734", "\u2747\uFE0F", "\u2747", "\xA9\uFE0F", "\xA9", "\xAE\uFE0F", "\xAE", "\u2122\uFE0F", "\u2122", "\u{1FADF}", "#\uFE0F\u20E3", "#\u20E3", "*\uFE0F\u20E3", "*\u20E3", "0\uFE0F\u20E3", "0\u20E3", "1\uFE0F\u20E3", "1\u20E3", "2\uFE0F\u20E3", "2\u20E3", "3\uFE0F\u20E3", "3\u20E3", "4\uFE0F\u20E3", "4\u20E3", "5\uFE0F\u20E3", "5\u20E3", "6\uFE0F\u20E3", "6\u20E3", "7\uFE0F\u20E3", "7\u20E3", "8\uFE0F\u20E3", "8\u20E3", "9\uFE0F\u20E3", "9\u20E3", "\u{1F51F}", "\u{1F520}", "\u{1F521}", "\u{1F522}", "\u{1F523}", "\u{1F524}", "\u{1F170}\uFE0F", "\u{1F170}", "\u{1F18E}", "\u{1F171}\uFE0F", "\u{1F171}", "\u{1F191}", "\u{1F192}", "\u{1F193}", "\u2139\uFE0F", "\u2139", "\u{1F194}", "\u24C2\uFE0F", "\u24C2", "\u{1F195}", "\u{1F196}", "\u{1F17E}\uFE0F", "\u{1F17E}", "\u{1F197}", "\u{1F17F}\uFE0F", "\u{1F17F}", "\u{1F198}", "\u{1F199}", "\u{1F19A}", "\u{1F201}", "\u{1F202}\uFE0F", "\u{1F202}", "\u{1F237}\uFE0F", "\u{1F237}", "\u{1F236}", "\u{1F22F}", "\u{1F250}", "\u{1F239}", "\u{1F21A}", "\u{1F232}", "\u{1F251}", "\u{1F238}", "\u{1F234}", "\u{1F233}", "\u3297\uFE0F", "\u3297", "\u3299\uFE0F", "\u3299", "\u{1F23A}", "\u{1F235}", "\u{1F534}", "\u{1F7E0}", "\u{1F7E1}", "\u{1F7E2}", "\u{1F535}", "\u{1F7E3}", "\u{1F7E4}", "\u26AB", "\u26AA", "\u{1F7E5}", "\u{1F7E7}", "\u{1F7E8}", "\u{1F7E9}", "\u{1F7E6}", "\u{1F7EA}", "\u{1F7EB}", "\u2B1B", "\u2B1C", "\u25FC\uFE0F", "\u25FC", "\u25FB\uFE0F", "\u25FB", "\u25FE", "\u25FD", "\u25AA\uFE0F", "\u25AA", "\u25AB\uFE0F", "\u25AB", "\u{1F536}", "\u{1F537}", "\u{1F538}", "\u{1F539}", "\u{1F53A}", "\u{1F53B}", "\u{1F4A0}", "\u{1F518}", "\u{1F533}", "\u{1F532}"] },
    { id: "flags", label: "Flags", icon: "\u{1F3F3}\uFE0F", emojis: ["\u{1F3C1}", "\u{1F6A9}", "\u{1F38C}", "\u{1F3F4}", "\u{1F3F3}\uFE0F", "\u{1F3F3}", "\u{1F3F3}\uFE0F\u200D\u{1F308}", "\u{1F3F3}\u200D\u{1F308}", "\u{1F3F3}\uFE0F\u200D\u26A7\uFE0F", "\u{1F3F3}\u200D\u26A7\uFE0F", "\u{1F3F3}\uFE0F\u200D\u26A7", "\u{1F3F3}\u200D\u26A7", "\u{1F3F4}\u200D\u2620\uFE0F", "\u{1F3F4}\u200D\u2620", "\u{1F1E6}\u{1F1E8}", "\u{1F1E6}\u{1F1E9}", "\u{1F1E6}\u{1F1EA}", "\u{1F1E6}\u{1F1EB}", "\u{1F1E6}\u{1F1EC}", "\u{1F1E6}\u{1F1EE}", "\u{1F1E6}\u{1F1F1}", "\u{1F1E6}\u{1F1F2}", "\u{1F1E6}\u{1F1F4}", "\u{1F1E6}\u{1F1F6}", "\u{1F1E6}\u{1F1F7}", "\u{1F1E6}\u{1F1F8}", "\u{1F1E6}\u{1F1F9}", "\u{1F1E6}\u{1F1FA}", "\u{1F1E6}\u{1F1FC}", "\u{1F1E6}\u{1F1FD}", "\u{1F1E6}\u{1F1FF}", "\u{1F1E7}\u{1F1E6}", "\u{1F1E7}\u{1F1E7}", "\u{1F1E7}\u{1F1E9}", "\u{1F1E7}\u{1F1EA}", "\u{1F1E7}\u{1F1EB}", "\u{1F1E7}\u{1F1EC}", "\u{1F1E7}\u{1F1ED}", "\u{1F1E7}\u{1F1EE}", "\u{1F1E7}\u{1F1EF}", "\u{1F1E7}\u{1F1F1}", "\u{1F1E7}\u{1F1F2}", "\u{1F1E7}\u{1F1F3}", "\u{1F1E7}\u{1F1F4}", "\u{1F1E7}\u{1F1F6}", "\u{1F1E7}\u{1F1F7}", "\u{1F1E7}\u{1F1F8}", "\u{1F1E7}\u{1F1F9}", "\u{1F1E7}\u{1F1FB}", "\u{1F1E7}\u{1F1FC}", "\u{1F1E7}\u{1F1FE}", "\u{1F1E7}\u{1F1FF}", "\u{1F1E8}\u{1F1E6}", "\u{1F1E8}\u{1F1E8}", "\u{1F1E8}\u{1F1E9}", "\u{1F1E8}\u{1F1EB}", "\u{1F1E8}\u{1F1EC}", "\u{1F1E8}\u{1F1ED}", "\u{1F1E8}\u{1F1EE}", "\u{1F1E8}\u{1F1F0}", "\u{1F1E8}\u{1F1F1}", "\u{1F1E8}\u{1F1F2}", "\u{1F1E8}\u{1F1F3}", "\u{1F1E8}\u{1F1F4}", "\u{1F1E8}\u{1F1F5}", "\u{1F1E8}\u{1F1F6}", "\u{1F1E8}\u{1F1F7}", "\u{1F1E8}\u{1F1FA}", "\u{1F1E8}\u{1F1FB}", "\u{1F1E8}\u{1F1FC}", "\u{1F1E8}\u{1F1FD}", "\u{1F1E8}\u{1F1FE}", "\u{1F1E8}\u{1F1FF}", "\u{1F1E9}\u{1F1EA}", "\u{1F1E9}\u{1F1EC}", "\u{1F1E9}\u{1F1EF}", "\u{1F1E9}\u{1F1F0}", "\u{1F1E9}\u{1F1F2}", "\u{1F1E9}\u{1F1F4}", "\u{1F1E9}\u{1F1FF}", "\u{1F1EA}\u{1F1E6}", "\u{1F1EA}\u{1F1E8}", "\u{1F1EA}\u{1F1EA}", "\u{1F1EA}\u{1F1EC}", "\u{1F1EA}\u{1F1ED}", "\u{1F1EA}\u{1F1F7}", "\u{1F1EA}\u{1F1F8}", "\u{1F1EA}\u{1F1F9}", "\u{1F1EA}\u{1F1FA}", "\u{1F1EB}\u{1F1EE}", "\u{1F1EB}\u{1F1EF}", "\u{1F1EB}\u{1F1F0}", "\u{1F1EB}\u{1F1F2}", "\u{1F1EB}\u{1F1F4}", "\u{1F1EB}\u{1F1F7}", "\u{1F1EC}\u{1F1E6}", "\u{1F1EC}\u{1F1E7}", "\u{1F1EC}\u{1F1E9}", "\u{1F1EC}\u{1F1EA}", "\u{1F1EC}\u{1F1EB}", "\u{1F1EC}\u{1F1EC}", "\u{1F1EC}\u{1F1ED}", "\u{1F1EC}\u{1F1EE}", "\u{1F1EC}\u{1F1F1}", "\u{1F1EC}\u{1F1F2}", "\u{1F1EC}\u{1F1F3}", "\u{1F1EC}\u{1F1F5}", "\u{1F1EC}\u{1F1F6}", "\u{1F1EC}\u{1F1F7}", "\u{1F1EC}\u{1F1F8}", "\u{1F1EC}\u{1F1F9}", "\u{1F1EC}\u{1F1FA}", "\u{1F1EC}\u{1F1FC}", "\u{1F1EC}\u{1F1FE}", "\u{1F1ED}\u{1F1F0}", "\u{1F1ED}\u{1F1F2}", "\u{1F1ED}\u{1F1F3}", "\u{1F1ED}\u{1F1F7}", "\u{1F1ED}\u{1F1F9}", "\u{1F1ED}\u{1F1FA}", "\u{1F1EE}\u{1F1E8}", "\u{1F1EE}\u{1F1E9}", "\u{1F1EE}\u{1F1EA}", "\u{1F1EE}\u{1F1F1}", "\u{1F1EE}\u{1F1F2}", "\u{1F1EE}\u{1F1F3}", "\u{1F1EE}\u{1F1F4}", "\u{1F1EE}\u{1F1F6}", "\u{1F1EE}\u{1F1F7}", "\u{1F1EE}\u{1F1F8}", "\u{1F1EE}\u{1F1F9}", "\u{1F1EF}\u{1F1EA}", "\u{1F1EF}\u{1F1F2}", "\u{1F1EF}\u{1F1F4}", "\u{1F1EF}\u{1F1F5}", "\u{1F1F0}\u{1F1EA}", "\u{1F1F0}\u{1F1EC}", "\u{1F1F0}\u{1F1ED}", "\u{1F1F0}\u{1F1EE}", "\u{1F1F0}\u{1F1F2}", "\u{1F1F0}\u{1F1F3}", "\u{1F1F0}\u{1F1F5}", "\u{1F1F0}\u{1F1F7}", "\u{1F1F0}\u{1F1FC}", "\u{1F1F0}\u{1F1FE}", "\u{1F1F0}\u{1F1FF}", "\u{1F1F1}\u{1F1E6}", "\u{1F1F1}\u{1F1E7}", "\u{1F1F1}\u{1F1E8}", "\u{1F1F1}\u{1F1EE}", "\u{1F1F1}\u{1F1F0}", "\u{1F1F1}\u{1F1F7}", "\u{1F1F1}\u{1F1F8}", "\u{1F1F1}\u{1F1F9}", "\u{1F1F1}\u{1F1FA}", "\u{1F1F1}\u{1F1FB}", "\u{1F1F1}\u{1F1FE}", "\u{1F1F2}\u{1F1E6}", "\u{1F1F2}\u{1F1E8}", "\u{1F1F2}\u{1F1E9}", "\u{1F1F2}\u{1F1EA}", "\u{1F1F2}\u{1F1EB}", "\u{1F1F2}\u{1F1EC}", "\u{1F1F2}\u{1F1ED}", "\u{1F1F2}\u{1F1F0}", "\u{1F1F2}\u{1F1F1}", "\u{1F1F2}\u{1F1F2}", "\u{1F1F2}\u{1F1F3}", "\u{1F1F2}\u{1F1F4}", "\u{1F1F2}\u{1F1F5}", "\u{1F1F2}\u{1F1F6}", "\u{1F1F2}\u{1F1F7}", "\u{1F1F2}\u{1F1F8}", "\u{1F1F2}\u{1F1F9}", "\u{1F1F2}\u{1F1FA}", "\u{1F1F2}\u{1F1FB}", "\u{1F1F2}\u{1F1FC}", "\u{1F1F2}\u{1F1FD}", "\u{1F1F2}\u{1F1FE}", "\u{1F1F2}\u{1F1FF}", "\u{1F1F3}\u{1F1E6}", "\u{1F1F3}\u{1F1E8}", "\u{1F1F3}\u{1F1EA}", "\u{1F1F3}\u{1F1EB}", "\u{1F1F3}\u{1F1EC}", "\u{1F1F3}\u{1F1EE}", "\u{1F1F3}\u{1F1F1}", "\u{1F1F3}\u{1F1F4}", "\u{1F1F3}\u{1F1F5}", "\u{1F1F3}\u{1F1F7}", "\u{1F1F3}\u{1F1FA}", "\u{1F1F3}\u{1F1FF}", "\u{1F1F4}\u{1F1F2}", "\u{1F1F5}\u{1F1E6}", "\u{1F1F5}\u{1F1EA}", "\u{1F1F5}\u{1F1EB}", "\u{1F1F5}\u{1F1EC}", "\u{1F1F5}\u{1F1ED}", "\u{1F1F5}\u{1F1F0}", "\u{1F1F5}\u{1F1F1}", "\u{1F1F5}\u{1F1F2}", "\u{1F1F5}\u{1F1F3}", "\u{1F1F5}\u{1F1F7}", "\u{1F1F5}\u{1F1F8}", "\u{1F1F5}\u{1F1F9}", "\u{1F1F5}\u{1F1FC}", "\u{1F1F5}\u{1F1FE}", "\u{1F1F6}\u{1F1E6}", "\u{1F1F7}\u{1F1EA}", "\u{1F1F7}\u{1F1F4}", "\u{1F1F7}\u{1F1F8}", "\u{1F1F7}\u{1F1FA}", "\u{1F1F7}\u{1F1FC}", "\u{1F1F8}\u{1F1E6}", "\u{1F1F8}\u{1F1E7}", "\u{1F1F8}\u{1F1E8}", "\u{1F1F8}\u{1F1E9}", "\u{1F1F8}\u{1F1EA}", "\u{1F1F8}\u{1F1EC}", "\u{1F1F8}\u{1F1ED}", "\u{1F1F8}\u{1F1EE}", "\u{1F1F8}\u{1F1EF}", "\u{1F1F8}\u{1F1F0}", "\u{1F1F8}\u{1F1F1}", "\u{1F1F8}\u{1F1F2}", "\u{1F1F8}\u{1F1F3}", "\u{1F1F8}\u{1F1F4}", "\u{1F1F8}\u{1F1F7}", "\u{1F1F8}\u{1F1F8}", "\u{1F1F8}\u{1F1F9}", "\u{1F1F8}\u{1F1FB}", "\u{1F1F8}\u{1F1FD}", "\u{1F1F8}\u{1F1FE}", "\u{1F1F8}\u{1F1FF}", "\u{1F1F9}\u{1F1E6}", "\u{1F1F9}\u{1F1E8}", "\u{1F1F9}\u{1F1E9}", "\u{1F1F9}\u{1F1EB}", "\u{1F1F9}\u{1F1EC}", "\u{1F1F9}\u{1F1ED}", "\u{1F1F9}\u{1F1EF}", "\u{1F1F9}\u{1F1F0}", "\u{1F1F9}\u{1F1F1}", "\u{1F1F9}\u{1F1F2}", "\u{1F1F9}\u{1F1F3}", "\u{1F1F9}\u{1F1F4}", "\u{1F1F9}\u{1F1F7}", "\u{1F1F9}\u{1F1F9}", "\u{1F1F9}\u{1F1FB}", "\u{1F1F9}\u{1F1FC}", "\u{1F1F9}\u{1F1FF}", "\u{1F1FA}\u{1F1E6}", "\u{1F1FA}\u{1F1EC}", "\u{1F1FA}\u{1F1F2}", "\u{1F1FA}\u{1F1F3}", "\u{1F1FA}\u{1F1F8}", "\u{1F1FA}\u{1F1FE}", "\u{1F1FA}\u{1F1FF}", "\u{1F1FB}\u{1F1E6}", "\u{1F1FB}\u{1F1E8}", "\u{1F1FB}\u{1F1EA}", "\u{1F1FB}\u{1F1EC}", "\u{1F1FB}\u{1F1EE}", "\u{1F1FB}\u{1F1F3}", "\u{1F1FB}\u{1F1FA}", "\u{1F1FC}\u{1F1EB}", "\u{1F1FC}\u{1F1F8}", "\u{1F1FD}\u{1F1F0}", "\u{1F1FE}\u{1F1EA}", "\u{1F1FE}\u{1F1F9}", "\u{1F1FF}\u{1F1E6}", "\u{1F1FF}\u{1F1F2}", "\u{1F1FF}\u{1F1FC}", "\u{1F3F4}\u{E0067}\u{E0062}\u{E0065}\u{E006E}\u{E0067}\u{E007F}", "\u{1F3F4}\u{E0067}\u{E0062}\u{E0073}\u{E0063}\u{E0074}\u{E007F}", "\u{1F3F4}\u{E0067}\u{E0062}\u{E0077}\u{E006C}\u{E0073}\u{E007F}"] }
  ];

  // src/lib/glub.js
  var GLUB_TAG = "glub";
  var COLORS = {
    "0": "#48484f",
    "1": "#4a5bd6",
    "2": "#3fb950",
    "3": "#2dd4bf",
    "4": "#e5484d",
    "5": "#c74ddb",
    "6": "#f0a020",
    "7": "#a0a0a8",
    "8": "#6e6e78",
    "9": "#5b8dff",
    a: "#55ff77",
    b: "#55ffff",
    c: "#ff6a6a",
    d: "#ff77ff",
    e: "#ffe45e",
    f: "#ffffff"
  };
  var COLOR_NAMES = {
    "0": "black",
    "1": "dark blue",
    "2": "dark green",
    "3": "dark aqua",
    "4": "dark red",
    "5": "dark purple",
    "6": "gold",
    "7": "gray",
    "8": "dark gray",
    "9": "blue",
    a: "green",
    b: "aqua",
    c: "red",
    d: "light purple",
    e: "yellow",
    f: "white"
  };
  var FORMATS = /* @__PURE__ */ new Set(["l", "m", "n", "o"]);
  var OBFUSCATE = "k";
  var RAINBOW = "g";
  var RESET = "r";
  var FMT_MAX = 200;
  var RICH_MAX = 8e3;
  var FLAIRS2 = [
    { name: "fire", label: "fire", description: "rising embers and a warm glow" },
    { name: "lightning", label: "lightning", description: "electric arcs across the line" },
    { name: "stars", label: "stars", description: "a slow twinkling starfield" },
    { name: "rain", label: "rain", description: "falling drops and a cool wash" },
    { name: "plume", label: "plume", description: "soft smoke plumes drifting upward" },
    { name: "neon", label: "neon", description: "a pulsing neon frame" },
    { name: "matrix", label: "matrix", description: "falling green glyph columns" },
    { name: "sonar", label: "sonar", description: "expanding radar rings" },
    { name: "fireflies", label: "fireflies", description: "drifting glowing motes" },
    { name: "bubbles", label: "bubbles", description: "bright bubbles floating up" },
    { name: "aurora", label: "aurora", description: "flowing polar light" },
    { name: "bitcoin", label: "bitcoin", description: "orange coins and sparks" },
    { name: "glitch", label: "glitch", description: "RGB tears and screen noise" },
    { name: "sol", label: "sol", description: "golden solar rays (glub.chat NIP-05 only)", gated: true }
  ];
  var FLAIR_NAMES = new Set(FLAIRS2.map((f) => f.name));
  var TEMPLATE_PRESETS = [
    { label: "Classic", value: "&l{name}&7{tag}&f: {msg}" },
    { label: "Brackets", value: "&b[cool]&f<{name}&7{tag}&f> &b\xBB &g{msg}" },
    { label: "Bold name", value: "&b&l<{name}> &r{msg}" },
    { label: "Neon", value: "&d\u25B8 &f{name}&8{tag} &d:: &f{msg}" },
    { label: "Rainbow", value: "&g{name}&f{tag} &7\xBB &f{msg}" },
    { label: "Terminal", value: "&a{name}&8@&a{tag}&7 > &f{msg}" },
    { label: "Minimal", value: "&7{name}&8{tag} &f{msg}" }
  ];
  function isCodeChar(ch) {
    return Object.prototype.hasOwnProperty.call(COLORS, ch) || FORMATS.has(ch) || ch === OBFUSCATE || ch === RAINBOW || ch === RESET;
  }
  function tokenize(raw) {
    const s = String(raw || "");
    const tokens = [];
    let text = "";
    const flush = () => {
      if (text) {
        tokens.push({ t: "text", v: text });
        text = "";
      }
    };
    let i = 0;
    while (i < s.length) {
      const ch = s[i];
      if ((ch === "h" || ch === "H") && /^https?:\/\//i.test(s.slice(i))) {
        const url = s.slice(i).match(/^https?:\/\/[^\s<>]+/i);
        if (url) {
          text += url[0];
          i += url[0].length;
          continue;
        }
      }
      if (ch === "&" && i + 1 < s.length) {
        const next = s[i + 1];
        if (next === "&") {
          text += "&";
          i += 2;
          continue;
        }
        if (isCodeChar(next)) {
          flush();
          tokens.push({ t: "code", c: next });
          i += 2;
          continue;
        }
      }
      text += ch;
      i++;
    }
    flush();
    return tokens;
  }
  function stripFormat(raw) {
    let out = "";
    for (const tok of tokenize(raw)) if (tok.t === "text") out += tok.v;
    return out;
  }
  function hasFormat(raw) {
    return stripFormat(raw) !== String(raw || "");
  }
  var BLANK = {
    color: null,
    bold: false,
    italic: false,
    underline: false,
    strike: false,
    obf: false,
    rainbow: false
  };
  function applyCode(state2, c) {
    if (c === RESET) return { ...BLANK };
    if (Object.prototype.hasOwnProperty.call(COLORS, c)) {
      return { ...BLANK, color: COLORS[c] };
    }
    const next = { ...state2 };
    if (c === "l") next.bold = true;
    else if (c === "o") next.italic = true;
    else if (c === "n") next.underline = true;
    else if (c === "m") next.strike = true;
    else if (c === OBFUSCATE) next.obf = true;
    else if (c === RAINBOW) {
      next.rainbow = true;
      next.color = null;
    }
    return next;
  }
  function stateStyle(state2) {
    let style = "";
    if (!state2.rainbow && state2.color) style += `color:${state2.color};-webkit-text-fill-color:${state2.color};`;
    if (state2.bold) style += "font-weight:700;";
    if (state2.italic) style += "font-style:italic;";
    const deco = [];
    if (state2.underline) deco.push("underline");
    if (state2.strike) deco.push("line-through");
    if (deco.length) style += `text-decoration:${deco.join(" ")};`;
    return style;
  }
  function stateClass(state2) {
    const cls = [];
    if (state2.rainbow) cls.push("fmtRainbow");
    if (state2.obf) cls.push("fmtObf");
    return cls.join(" ");
  }
  function escapeHtml(s) {
    return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }
  var EMOJI_RE = new RegExp("(?:[\\u{1F1E6}-\\u{1F1FF}]{2}|[#*0-9]\\uFE0F?\\u20E3|\\p{Extended_Pictographic}(?:\\uFE0F|\\u20E3|[\\u{1F3FB}-\\u{1F3FF}])?(?:\\u200D\\p{Extended_Pictographic}(?:\\uFE0F|[\\u{1F3FB}-\\u{1F3FF}])?)*)", "gu");
  function emojiHtml(text) {
    const source = String(text ?? "");
    let html = "";
    let last = 0;
    EMOJI_RE.lastIndex = 0;
    for (const match of source.matchAll(EMOJI_RE)) {
      const index = match.index ?? 0;
      if (index > last) html += escapeHtml(source.slice(last, index));
      html += `<span class="fmtEmoji">${escapeHtml(match[0])}</span>`;
      last = index + match[0].length;
    }
    if (last < source.length) html += escapeHtml(source.slice(last));
    return html || escapeHtml(source);
  }
  function richText(raw) {
    const source = String(raw ?? "");
    let html = "";
    let last = 0;
    EMOJI_RE.lastIndex = 0;
    for (const match of source.matchAll(EMOJI_RE)) {
      const index = match.index ?? 0;
      if (index > last) html += linkify(escapeHtml(source.slice(last, index)));
      html += `<span class="fmtEmoji">${escapeHtml(match[0])}</span>`;
      last = index + match[0].length;
    }
    if (last < source.length) html += linkify(escapeHtml(source.slice(last)));
    return html;
  }
  function linkify(text) {
    return text.replace(/(https?:\/\/[^\s<]+)/g, (url) => {
      const clean = url.replace(/[.,!?;:]+$/, "");
      const tail = url.slice(clean.length);
      return `<a href="${clean}" target="_blank" rel="noopener noreferrer">${clean}</a>${tail}`;
    });
  }
  function renderFormatHtml(raw, { bodyFn = richText } = {}) {
    let state2 = { ...BLANK };
    let html = "";
    for (const tok of tokenize(raw)) {
      if (tok.t === "code") {
        state2 = applyCode(state2, tok.c);
        continue;
      }
      const inner = bodyFn(tok.v);
      const style = stateStyle(state2);
      const cls = stateClass(state2);
      if (!style && !cls) {
        html += inner;
        continue;
      }
      const attrs = `${cls ? ` class="${cls}"` : ""}${style ? ` style="${style}"` : ""}${state2.obf ? ` data-obf-text="${escapeHtml(tok.v)}"` : ""}`;
      html += `<span${attrs}>${inner}</span>`;
    }
    return html;
  }
  function sanitizeTemplate(raw) {
    const s = String(raw || "").replace(/[\r\n\t]+/g, " ").trim();
    return s && s.length <= FMT_MAX ? s : "";
  }
  function normalizeTemplate(raw) {
    const tpl = sanitizeTemplate(raw);
    if (!tpl) return "";
    if (tpl.includes("{msg}")) return tpl;
    const room = Math.max(0, FMT_MAX - 6);
    return `${tpl.slice(0, room).trimEnd()} {msg}`;
  }
  function renderLineHtml(template, { name = "you", tag = "#a1b2", msgHtml = "hello", msgText = "" } = {}) {
    const tpl = normalizeTemplate(template);
    if (!tpl) return msgHtml;
    const cleanTag = `#${String(tag).replace(/^#/, "")}`;
    const safeParts = {
      "{name}": emojiHtml(name),
      "{tag}": `<span class="ba-line-tag">${emojiHtml(cleanTag)}</span>`,
      "{msg}": msgHtml
    };
    const plainParts = { "{name}": name, "{tag}": cleanTag, "{msg}": msgText || "hello" };
    let state2 = { ...BLANK };
    let html = "";
    for (const tok of tokenize(tpl)) {
      if (tok.t === "code") {
        state2 = applyCode(state2, tok.c);
        continue;
      }
      let inner = escapeHtml(tok.v).replace(/\{(name|tag|msg)\}/g, (m) => safeParts[m] ?? m);
      const style = stateStyle(state2);
      const cls = stateClass(state2);
      if (style || cls) {
        const obfText = tok.v.replace(/\{(name|tag|msg)\}/g, (m) => plainParts[m] ?? m);
        inner = `<span${cls ? ` class="${cls}"` : ""}${style ? ` style="${style}"` : ""}${state2.obf ? ` data-obf-text="${escapeHtml(obfText)}"` : ""}>${inner}</span>`;
      }
      html += inner;
    }
    return html;
  }
  function parseGlubMeta(eventOrTags) {
    const tags = Array.isArray(eventOrTags) ? eventOrTags : eventOrTags?.tags || [];
    const out = {};
    for (const tag of tags) {
      if (!Array.isArray(tag) || tag[0] !== GLUB_TAG) continue;
      for (let i = 1; i + 1 < tag.length; i += 2) {
        const k = tag[i];
        const v = tag[i + 1];
        if (typeof k === "string" && typeof v === "string" && !(k in out)) out[k] = v;
      }
    }
    return out;
  }
  function getTag(tags, name) {
    if (!Array.isArray(tags)) return void 0;
    for (const t of tags) {
      if (Array.isArray(t) && t[0] === name) return t;
    }
    return void 0;
  }
  function getTagValue(tags, name) {
    return getTag(tags, name)?.[1];
  }
  function isValidFlair(name) {
    return !!flairName(name);
  }
  function kindGroup(kind) {
    if (kind === 2e4 || kind === 20001 || kind === 23333) return "chat";
    if (kind === 1) return "note";
    if (kind === 5 || kind === 7) return "reaction";
    if (kind === 4 || kind === 13 || kind === 14 || kind === 1059) return "dm";
    if (kind === 0 || kind === 3) return "profile";
    return "other";
  }
  var KIND_GROUPS = [
    { id: "chat", label: "Chat messages", detail: "kinds 20000, 20001, 23333" },
    { id: "note", label: "Notes & replies", detail: "kind 1" },
    { id: "reaction", label: "Reactions & deletions", detail: "kinds 5, 7" },
    { id: "dm", label: "Direct messages", detail: "kinds 4, 13, 14, 1059" },
    { id: "profile", label: "Profiles & contacts", detail: "kinds 0, 3" },
    { id: "other", label: "Everything else", detail: "all remaining kinds" }
  ];
  var CLIENT_PRESETS = [
    "BetterAgnostr",
    "glub.chat",
    "Agnostr",
    "Damus",
    "Amethyst",
    "Primal",
    "Coracle",
    "Snort",
    "0xChat",
    "Nostrudel"
  ];

  // src/lib/themes.js
  var GLUB_THEMES = [
    {
      id: "bitchat",
      label: "Chat",
      description: "black phosphor green, blue channels",
      bg: "#000000",
      fg: "#8fe89c",
      muted: "#7a828c",
      geo: "#5cb3ff",
      accent: "#30d158",
      danger: "#ff7b72"
    },
    {
      id: "cyberpunk-2077",
      label: "Cyberpunk 2077",
      description: "cyan readouts & hot-pink chrome",
      bg: "#000000",
      fg: "#d7d7dc",
      muted: "#7e7e88",
      geo: "#2de2e6",
      accent: "#ff2a6d",
      danger: "#ff5a5a"
    },
    {
      id: "blade-runner-blossom",
      label: "Blade Runner",
      description: "blossom pink on violet haze",
      bg: "#0a0712",
      fg: "#e4d9f2",
      muted: "#857a9e",
      geo: "#b48cff",
      accent: "#ff6ac2",
      danger: "#ff7b72"
    },
    {
      id: "ex-machina",
      label: "Ex Machina",
      description: "emergency red & amber alarm",
      bg: "#0b0507",
      fg: "#f2d9d9",
      muted: "#93706e",
      geo: "#ff8a5c",
      accent: "#ff3b30",
      danger: "#ffd60a"
    },
    {
      id: "giedi-prime",
      label: "Giedi Prime",
      description: "infrared monochrome",
      bg: "#050505",
      fg: "#ededed",
      muted: "#878787",
      geo: "#bdbdbd",
      accent: "#e6e6e6",
      danger: "#ff7b72"
    },
    {
      id: "matrix-neo",
      label: "Matrix Neo",
      description: "code-rain green on true black",
      bg: "#000000",
      fg: "#a8ffdf",
      muted: "#567b70",
      geo: "#80fffb",
      accent: "#00ffa1",
      danger: "#ff7b72"
    },
    {
      id: "star-lord",
      label: "Star-Lord",
      description: "amber-gold & engine cyan",
      bg: "#0c0806",
      fg: "#f2ddb8",
      muted: "#8e7d67",
      geo: "#ff8c42",
      accent: "#3fd8ff",
      danger: "#ff7b72"
    },
    {
      id: "time-variance-amber",
      label: "Time Variance",
      description: "mid-century CRT amber",
      bg: "#0b0906",
      fg: "#ffd98c",
      muted: "#97845f",
      geo: "#ffc861",
      accent: "#ff9e1f",
      danger: "#ff6b5e"
    },
    {
      id: "tron-legacy",
      label: "Tron Legacy",
      description: "grid ice blue & disc cyan",
      bg: "#04070c",
      fg: "#cdeeff",
      muted: "#5f7f8e",
      geo: "#5ce1ff",
      accent: "#00b8ff",
      danger: "#ff7b72"
    },
    {
      id: "lumon-light",
      label: "Lumon Light",
      description: "milky office light & teal",
      bg: "#eef0ea",
      fg: "#24424a",
      muted: "#6c8189",
      geo: "#2f7d97",
      accent: "#106a74",
      danger: "#b3362b",
      light: true
    },
    {
      id: "her-light",
      label: "Her Light",
      description: "coral & cream",
      bg: "#f7efe6",
      fg: "#6b4a3f",
      muted: "#a2867a",
      geo: "#b04a36",
      accent: "#e0654f",
      danger: "#a63324",
      light: true
    },
    {
      id: "iced-matcha-latte",
      label: "Iced Matcha Latte",
      description: "oat cream, iced matcha, cold green lift",
      bg: "#f1f0e7",
      fg: "#29382f",
      muted: "#778578",
      geo: "#5b8b6e",
      accent: "#4c8a5f",
      danger: "#b04a3c",
      light: true
    }
  ];
  var THEME_BY_ID = new Map(GLUB_THEMES.map((t) => [t.id, t]));
  var AGNOSTR_THEME = {
    id: "agnostr",
    label: "Agnostr",
    description: "use Agnostr's own theme setting",
    css: ""
  };
  var ALL_THEMES = [AGNOSTR_THEME, ...GLUB_THEMES];
  function themeById(id) {
    return THEME_BY_ID.get(id) || null;
  }
  function parseHex(hex) {
    const s = String(hex || "").replace("#", "");
    if (!/^[0-9a-f]{6}$/i.test(s)) return [0, 0, 0];
    return [parseInt(s.slice(0, 2), 16), parseInt(s.slice(2, 4), 16), parseInt(s.slice(4, 6), 16)];
  }
  function toHex([r, g, b2]) {
    const c = (n) => Math.max(0, Math.min(255, Math.round(n))).toString(16).padStart(2, "0");
    return `#${c(r)}${c(g)}${c(b2)}`;
  }
  function mix(a, b2, amount) {
    const A = parseHex(a);
    const B = parseHex(b2);
    const t = Math.max(0, Math.min(1, amount));
    return toHex([A[0] + (B[0] - A[0]) * t, A[1] + (B[1] - A[1]) * t, A[2] + (B[2] - A[2]) * t]);
  }
  function alpha(hex, a) {
    const [r, g, b2] = parseHex(hex);
    return `rgba(${r}, ${g}, ${b2}, ${a})`;
  }
  function shade(hex, amount) {
    return amount < 0 ? mix(hex, "#000000", -amount) : mix(hex, "#ffffff", amount);
  }
  function buildThemeCss(theme) {
    if (!theme || theme.id === "agnostr") return "";
    const light = !!theme.light;
    const bg = theme.bg;
    const fg = theme.fg;
    const muted = theme.muted;
    const geo = theme.geo;
    const accent = theme.accent;
    const danger = theme.danger || (light ? "#b91c1c" : "#ef4444");
    const surface = light ? mix(bg, "#ffffff", 0.38) : mix(bg, fg, 0.045);
    const elevated = light ? mix(bg, "#ffffff", 0.68) : mix(bg, fg, 0.085);
    const subtle = light ? mix(bg, "#000000", 0.08) : mix(bg, fg, 0.13);
    const active = light ? mix(bg, "#000000", 0.13) : mix(bg, fg, 0.17);
    const input = light ? mix(bg, "#ffffff", 0.52) : mix(bg, "#000000", 0.22);
    const text2 = mix(fg, muted, 0.48);
    const accentHover = light ? shade(accent, -0.12) : shade(accent, 0.22);
    const ok = light ? "#15803d" : "#22c55e";
    const warn = light ? "#b45309" : "#f59e0b";
    const vars = {
      "--theme-meta-color": bg,
      "--bg-canvas": bg,
      "--bg-surface": surface,
      "--bg-elevated": elevated,
      "--bg-subtle": subtle,
      "--bg-hover": alpha(fg, light ? 0.06 : 0.055),
      "--bg-active": active,
      "--bg-glass": alpha(bg, 0.9),
      "--bg-overlay": light ? "rgba(20, 16, 12, .34)" : alpha(bg, 0.7),
      "--bg-input": input,
      "--border-subtle": alpha(fg, light ? 0.11 : 0.08),
      "--border-default": alpha(fg, light ? 0.2 : 0.15),
      "--border-strong": alpha(fg, light ? 0.34 : 0.28),
      "--border-accent": alpha(accent, 0.5),
      "--text-primary": fg,
      "--text-secondary": text2,
      "--text-muted": muted,
      "--text-inverse": light ? "#ffffff" : bg,
      "--accent": accent,
      "--accent-hover": accentHover,
      "--accent-soft": alpha(accent, light ? 0.11 : 0.14),
      "--accent-glow": `0 0 0 3px ${alpha(accent, 0.2)}`,
      "--accent-secondary": geo,
      "--accent-secondary-soft": alpha(geo, 0.14),
      "--status-ok": ok,
      "--status-ok-soft": alpha(ok, 0.14),
      "--status-warn": warn,
      "--status-warn-soft": alpha(warn, 0.15),
      "--status-danger": danger,
      "--status-danger-soft": alpha(danger, 0.15),
      "--dm-accent": geo,
      "--dm-soft": alpha(geo, 0.15),
      "--mesh-accent": geo,
      "--mesh-soft": alpha(geo, 0.14),
      "--handle-s": light ? "72%" : "68%",
      "--handle-l": light ? "36%" : "72%",
      "--identicon-bg-l": light ? "88%" : "16%",
      "--shadow-sm": light ? "0 1px 2px rgba(20,16,12,.08)" : "0 1px 2px rgba(0,0,0,.3)",
      "--shadow-md": light ? "0 6px 20px rgba(20,16,12,.12)" : "0 6px 20px rgba(0,0,0,.42)",
      "--shadow-lg": light ? "0 18px 48px rgba(20,16,12,.18)" : "0 18px 48px rgba(0,0,0,.6)",
      "--ambient-glow": light ? "none" : `0 0 80px ${alpha(accent, 0.08)}`
    };
    const body = Object.entries(vars).map(([k, v]) => `${k}: ${v} !important;`).join("\n  ");
    return `html:root {
  color-scheme: ${light ? "light" : "dark"} !important;
  ${body}
}`;
  }
  function themeSwatch(theme) {
    if (!theme || theme.id === "agnostr") return ["#0b0c0f", "#171a21", "#3b82f6", "#f1f3f7"];
    return [theme.bg, theme.light ? mix(theme.bg, "#ffffff", 0.35) : mix(theme.bg, theme.fg, 0.08), theme.accent, theme.fg];
  }

  // src/lib/sounds.js
  var MESSAGE_SOUNDS = [
    { id: "off", label: "off" },
    { id: "macintosh", label: "Macintosh" },
    { id: "sun", label: "Sun Sparc" },
    { id: "sgi", label: "SGI IRIX" },
    { id: "msn", label: "MSN Messenger" },
    { id: "aol", label: "AOL Mail" },
    { id: "icq", label: "ICQ" },
    { id: "palm", label: "Palm PDA" },
    { id: "blackberry", label: "BlackBerry" },
    { id: "blade-runner", label: "Blade Runner" },
    { id: "tron", label: "Tron" },
    { id: "c64", label: "Commodore 64" },
    { id: "amiga", label: "Amiga" }
  ];
  var CLICK_SOUNDS = [
    { id: "off", label: "off" },
    { id: "model-m", label: "Model M" },
    { id: "mac-click", label: "Mac mouse" },
    { id: "sun-type", label: "Sun keyboard" },
    { id: "sgi-beep", label: "SGI blip" },
    { id: "msn-nudge", label: "MSN nudge" },
    { id: "aol-ok", label: "AOL chime" },
    { id: "palm-tap", label: "Palm tap" },
    { id: "blackberry-key", label: "BlackBerry key" },
    { id: "blade-runner-ui", label: "Blade Runner UI" },
    { id: "tron-disc", label: "Tron disc" },
    { id: "c64-key", label: "C64 key" },
    { id: "amiga-click", label: "Amiga click" }
  ];
  var ctx = null;
  var lastClickAt = 0;
  function audio() {
    if (typeof AudioContext === "undefined" && !globalThis.webkitAudioContext) return null;
    if (!ctx) {
      const Ctor = typeof AudioContext !== "undefined" ? AudioContext : globalThis.webkitAudioContext;
      try {
        ctx = new Ctor();
      } catch {
        return null;
      }
    }
    if (ctx.state === "suspended") {
      try {
        ctx.resume().catch(() => {
        });
      } catch {
      }
    }
    return ctx;
  }
  function unlockAudio() {
    audio();
  }
  function envGain(ac, start, duration, peak, master) {
    const g = ac.createGain();
    const t = ac.currentTime + start;
    const level = Math.max(1e-4, peak * master);
    g.gain.setValueAtTime(1e-4, t);
    g.gain.exponentialRampToValueAtTime(level, t + 8e-3);
    g.gain.exponentialRampToValueAtTime(1e-4, t + Math.max(0.02, duration));
    return g;
  }
  function tone(ac, { freq, start = 0, duration = 0.12, peak = 0.08, master = 0.6, type = "sine", slideTo = null, filter = null }) {
    const osc = ac.createOscillator();
    const gain = envGain(ac, start, duration, peak, master);
    osc.type = type;
    const t = ac.currentTime + start;
    osc.frequency.setValueAtTime(freq, t);
    if (slideTo) osc.frequency.exponentialRampToValueAtTime(Math.max(20, slideTo), t + duration);
    let tail = osc;
    if (filter) {
      const f = ac.createBiquadFilter();
      f.type = filter.type || "bandpass";
      f.frequency.setValueAtTime(filter.freq || 1200, t);
      f.Q.setValueAtTime(filter.q ?? 2, t);
      tail.connect(f);
      tail = f;
    }
    tail.connect(gain);
    gain.connect(ac.destination);
    osc.start(t);
    osc.stop(t + duration + 0.03);
  }
  var noiseBuffers = /* @__PURE__ */ new WeakMap();
  function noise(ac, { start = 0, duration = 0.035, peak = 0.04, master = 0.6, freq = 1800, q = 1.2 }) {
    const length = Math.max(1, Math.floor(ac.sampleRate * duration));
    let cache = noiseBuffers.get(ac);
    if (!cache) {
      cache = /* @__PURE__ */ new Map();
      noiseBuffers.set(ac, cache);
    }
    let buffer = cache.get(length);
    if (!buffer) {
      buffer = ac.createBuffer(1, length, ac.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < length; i++) data[i] = Math.random() * 2 - 1;
      cache.set(length, buffer);
    }
    const source = ac.createBufferSource();
    source.buffer = buffer;
    const filter = ac.createBiquadFilter();
    filter.type = "bandpass";
    filter.frequency.value = freq;
    filter.Q.value = q;
    const gain = envGain(ac, start, duration, peak, master);
    source.connect(filter);
    filter.connect(gain);
    gain.connect(ac.destination);
    source.start(ac.currentTime + start);
    source.stop(ac.currentTime + start + duration + 0.02);
  }
  function playMessage(id, volume) {
    if (!id || id === "off") return false;
    const ac = audio();
    if (!ac) return false;
    const vol = Number(volume);
    const master = Number.isFinite(vol) ? Math.max(0, Math.min(1, vol)) : 0.6;
    try {
      switch (id) {
        case "macintosh":
          [261.63, 329.63, 392, 523.25].forEach(
            (f, i) => tone(ac, { freq: f, start: i * 0.045, duration: 1.15, peak: 0.032, master, type: "sine", filter: { type: "lowpass", freq: 1800, q: 0.6 } })
          );
          tone(ac, { freq: 1046.5, start: 0.18, duration: 0.7, peak: 0.012, master, type: "triangle" });
          break;
        case "sun":
          [784, 1046.5, 1318.5, 1568].forEach(
            (f, i) => tone(ac, { freq: f, start: i * 0.065, duration: 0.28, peak: 0.04, master, type: "triangle" })
          );
          break;
        case "sgi":
          tone(ac, { freq: 880, start: 0, duration: 0.9, peak: 0.055, master, type: "sine" });
          tone(ac, { freq: 1320, start: 0.01, duration: 0.7, peak: 0.022, master, type: "sine" });
          tone(ac, { freq: 440, start: 0.03, duration: 0.8, peak: 0.018, master, type: "triangle" });
          break;
        case "msn":
          tone(ac, { freq: 1318.5, start: 0, duration: 0.09, peak: 0.055, master, type: "square" });
          tone(ac, { freq: 1046.5, start: 0.14, duration: 0.2, peak: 0.045, master, type: "square" });
          break;
        case "aol":
          [1046.5, 1318.5, 1568].forEach(
            (f, i) => tone(ac, { freq: f, start: i * 0.11, duration: 0.32, peak: 0.04, master, type: "triangle" })
          );
          break;
        case "icq":
          tone(ac, { freq: 1350, start: 0, duration: 0.11, peak: 0.05, master, type: "square" });
          tone(ac, { freq: 900, start: 0.13, duration: 0.18, peak: 0.04, master, type: "square" });
          break;
        case "palm":
          tone(ac, { freq: 1760, start: 0, duration: 0.06, peak: 0.04, master, type: "sine" });
          tone(ac, { freq: 1760, start: 0.1, duration: 0.06, peak: 0.04, master, type: "sine" });
          break;
        case "blackberry":
          tone(ac, { freq: 1480, start: 0, duration: 0.08, peak: 0.045, master, type: "square" });
          tone(ac, { freq: 1850, start: 0.11, duration: 0.1, peak: 0.04, master, type: "square" });
          break;
        case "blade-runner":
          tone(ac, { freq: 110, start: 0, duration: 1.8, peak: 0.045, master, type: "sawtooth", filter: { type: "lowpass", freq: 700, q: 1.5 } });
          tone(ac, { freq: 164.81, start: 0.05, duration: 1.7, peak: 0.033, master, type: "sawtooth", filter: { type: "lowpass", freq: 900, q: 1.2 } });
          tone(ac, { freq: 220, start: 0.1, duration: 1.5, peak: 0.02, master, type: "triangle" });
          break;
        case "tron":
          [330, 440, 660, 880, 1320].forEach(
            (f, i) => tone(ac, { freq: f, start: i * 0.055, duration: 0.14, peak: 0.035, master, type: "square" })
          );
          break;
        case "c64":
          [523, 659, 784, 1047, 784, 659].forEach(
            (f, i) => tone(ac, { freq: f, start: i * 0.04, duration: 0.075, peak: 0.035, master, type: "square" })
          );
          break;
        case "amiga":
          [392, 523, 659, 784, 1047, 784].forEach(
            (f, i) => tone(ac, { freq: f, start: i * 0.05, duration: 0.18, peak: 0.03, master, type: "triangle" })
          );
          break;
        default:
          return false;
      }
      return true;
    } catch {
      return false;
    }
  }
  function playClick(id, volume) {
    if (!id || id === "off") return false;
    const ac = audio();
    if (!ac) return false;
    const now = performance.now();
    if (now - lastClickAt < 45) return false;
    lastClickAt = now;
    const vol = Number(volume);
    const master = Number.isFinite(vol) ? Math.max(0, Math.min(1, vol)) : 0.55;
    try {
      switch (id) {
        case "model-m":
          noise(ac, { duration: 0.03, peak: 0.045, master, freq: 900, q: 0.7 });
          tone(ac, { freq: 180, start: 0, duration: 0.045, peak: 0.045, master, type: "sine" });
          break;
        case "mac-click":
          noise(ac, { duration: 0.018, peak: 0.03, master, freq: 2400, q: 1.1 });
          tone(ac, { freq: 820, start: 0, duration: 0.018, peak: 0.018, master, type: "triangle" });
          break;
        case "sun-type":
          tone(ac, { freq: 1900, start: 0, duration: 0.012, peak: 0.025, master, type: "square" });
          noise(ac, { duration: 0.015, peak: 0.018, master, freq: 3e3, q: 1.5 });
          break;
        case "sgi-beep":
          tone(ac, { freq: 990, start: 0, duration: 0.045, peak: 0.035, master, type: "sine" });
          break;
        case "msn-nudge":
          tone(ac, { freq: 1200, start: 0, duration: 0.018, peak: 0.028, master, type: "square" });
          tone(ac, { freq: 1500, start: 0.035, duration: 0.018, peak: 0.025, master, type: "square" });
          break;
        case "aol-ok":
          tone(ac, { freq: 880, start: 0, duration: 0.06, peak: 0.03, master, type: "triangle" });
          tone(ac, { freq: 1320, start: 0.05, duration: 0.08, peak: 0.022, master, type: "triangle" });
          break;
        case "palm-tap":
          tone(ac, { freq: 1600, start: 0, duration: 0.012, peak: 0.022, master, type: "sine" });
          break;
        case "blackberry-key":
          noise(ac, { duration: 0.018, peak: 0.03, master, freq: 1400, q: 0.8 });
          tone(ac, { freq: 320, start: 0.01, duration: 0.035, peak: 0.025, master, type: "sine" });
          break;
        case "blade-runner-ui":
          tone(ac, { freq: 220, start: 0, duration: 0.12, peak: 0.035, master, type: "sawtooth", filter: { type: "lowpass", freq: 800, q: 2 } });
          tone(ac, { freq: 330, start: 0.02, duration: 0.09, peak: 0.018, master, type: "triangle" });
          break;
        case "tron-disc":
          noise(ac, { duration: 0.07, peak: 0.028, master, freq: 2600, q: 2.4 });
          tone(ac, { freq: 740, start: 0, duration: 0.07, peak: 0.022, master, type: "sine", slideTo: 980 });
          break;
        case "c64-key":
          tone(ac, { freq: 1046, start: 0, duration: 0.02, peak: 0.03, master, type: "square" });
          noise(ac, { duration: 0.012, peak: 0.016, master, freq: 2200, q: 1.2 });
          break;
        case "amiga-click":
          tone(ac, { freq: 620, start: 0, duration: 0.03, peak: 0.028, master, type: "triangle" });
          break;
        default:
          return false;
      }
      return true;
    } catch {
      return false;
    }
  }
  function playMessageSound(id, volume = 0.6) {
    return playMessage(id, volume);
  }
  function playClickSound(id, volume = 0.5) {
    return playClick(id, volume);
  }
  function previewSound(kind, id, volume = 0.6) {
    return kind === "message" ? playMessage(id, volume) : playClick(id, volume);
  }

  // src/lib/settings.js
  var STORAGE_KEY = "betterAgnostr.settings.v1";
  var KIND_POLICIES = ["leave", "spoof", "strip"];
  var DEFAULT_SETTINGS = {
    schema: 4,
    enabled: true,
    studio: {
      enabled: true,
      template: "&b&l<{name}> &r{msg}",
      flair: "aurora",
      applyRich: true,
      showComposerToolbar: false,
      renderInAgnostr: true,
      renderRichInAgnostr: true,
      reduceMotion: false,
      rainbowStyle: "glub"
    },
    client: {
      name: "BetterAgnostr",
      policies: {
        chat: "spoof",
        note: "leave",
        reaction: "leave",
        dm: "leave",
        profile: "leave",
        other: "leave"
      }
    },
    privacy: {
      stripTags: [],
      stripTracking: true,
      hideLocate: true,
      hideTimestamps: false,
      omitTeleport: true,
      removeVoiceMemo: true,
      reviewEnabled: false,
      reviewGroups: ["chat"],
      calls: {
        disable: true,
        hideUi: true,
        blockSignals: true,
        blockOutgoing: true
      }
    },
    theme: {
      preset: "agnostr",
      customCss: ""
    },
    appearance: {
      hideNotificationButton: false
    },
    sounds: {
      message: "macintosh",
      click: "model-m",
      volume: 0.55,
      messageEnabled: true,
      clickEnabled: true,
      events: {
        chat: true,
        mentionOnly: false,
        dm: true,
        calls: true
      }
    },
    font: {
      family: "default",
      customFamily: "",
      customUrl: ""
    },
    actions: {
      custom: "boops"
    },
    glub: {
      build: "",
      buildFetchedAt: 0,
      manualBuild: "",
      autoSync: true
    },
    inspector: {
      paused: false,
      maxEvents: 1500
    },
    ui: {
      activeTab: "studio",
      betterTab: "line",
      firstRun: true,
      panelOpen: false
    }
  };
  var STRIPPABLE_TAGS = [
    { name: "client", label: "client", detail: "which app sent the event" },
    { name: "n", label: "n (nickname)", detail: "the display name attached to chat messages" },
    { name: "lud16", label: "lud16", detail: "your lightning address" },
    { name: "t", label: "t (topic)", detail: "teleport and other topic markers" },
    { name: "expiration", label: "expiration", detail: "the event's self-delete time" },
    { name: "nonce", label: "nonce", detail: "proof-of-work nonce and target" },
    { name: "emoji", label: "emoji", detail: "custom emoji declarations" },
    { name: "r", label: "r (reference)", detail: "external URL references" }
  ];
  var PRESET_IDS = /* @__PURE__ */ new Set(["agnostr", ...GLUB_THEMES.map((t) => t.id)]);
  var MESSAGE_IDS = new Set(MESSAGE_SOUNDS.map((s) => s.id));
  var CLICK_IDS = new Set(CLICK_SOUNDS.map((s) => s.id));
  function clone(value) {
    return JSON.parse(JSON.stringify(value));
  }
  function isObject(v) {
    return v && typeof v === "object" && !Array.isArray(v);
  }
  function section(value, fallback) {
    return isObject(value) ? value : clone(fallback);
  }
  function mergeSettings(base, patch) {
    if (!isObject(base)) return clone(patch);
    const out = clone(base);
    if (!isObject(patch)) return out;
    for (const [key, value] of Object.entries(patch)) {
      if (isObject(value) && isObject(out[key])) out[key] = mergeSettings(out[key], value);
      else out[key] = value;
    }
    return out;
  }
  function normalizeSettings(raw) {
    const source = isObject(raw) ? raw : {};
    const legacyClient = typeof source.schema !== "number" || source.schema < 2;
    const legacyToolbar = typeof source.schema !== "number" || source.schema < 3;
    const legacyPrivacy = typeof source.schema !== "number" || source.schema < 4;
    const s = mergeSettings(DEFAULT_SETTINGS, source);
    for (const key of ["studio", "client", "privacy", "theme", "appearance", "sounds", "font", "actions", "glub", "inspector", "ui"]) {
      s[key] = section(s[key], DEFAULT_SETTINGS[key]);
    }
    s.client.policies = section(s.client.policies, DEFAULT_SETTINGS.client.policies);
    s.privacy.calls = section(s.privacy.calls, DEFAULT_SETTINGS.privacy.calls);
    s.sounds.events = section(s.sounds.events, DEFAULT_SETTINGS.sounds.events);
    if (legacyClient && s.client.name === "glub.chat") s.client.name = "BetterAgnostr";
    if (legacyToolbar) s.studio.showComposerToolbar = false;
    if (legacyPrivacy) s.privacy.omitTeleport = true;
    s.schema = 4;
    s.enabled = s.enabled !== false;
    s.studio.enabled = s.studio.enabled !== false;
    s.studio.applyRich = s.studio.applyRich !== false;
    s.studio.showComposerToolbar = s.studio.showComposerToolbar !== false;
    s.studio.renderInAgnostr = s.studio.renderInAgnostr !== false;
    s.studio.renderRichInAgnostr = s.studio.renderRichInAgnostr !== false;
    s.studio.reduceMotion = s.studio.reduceMotion === true;
    s.studio.rainbowStyle = s.studio.rainbowStyle === "bright" ? "bright" : "glub";
    s.studio.template = String(s.studio.template || "").replace(/[\r\n\t]+/g, " ").slice(0, FMT_MAX);
    s.studio.flair = flairName(s.studio.flair);
    s.client.name = String(s.client.name || "").trim().slice(0, 64);
    if (!s.client.policies || typeof s.client.policies !== "object") s.client.policies = {};
    for (const group of ["chat", "note", "reaction", "dm", "profile", "other"]) {
      if (!KIND_POLICIES.includes(s.client.policies[group])) s.client.policies[group] = "leave";
    }
    if (!Array.isArray(s.privacy.stripTags)) s.privacy.stripTags = [];
    s.privacy.stripTags = [...new Set(s.privacy.stripTags.filter((t) => typeof t === "string" && /^[a-zA-Z0-9_-]+$/.test(t)))];
    s.privacy.stripTracking = s.privacy.stripTracking !== false;
    s.privacy.hideLocate = s.privacy.hideLocate !== false;
    s.privacy.hideTimestamps = s.privacy.hideTimestamps === true;
    s.privacy.omitTeleport = s.privacy.omitTeleport === true;
    s.privacy.removeVoiceMemo = s.privacy.removeVoiceMemo !== false;
    s.privacy.reviewEnabled = s.privacy.reviewEnabled === true;
    if (!Array.isArray(s.privacy.reviewGroups)) s.privacy.reviewGroups = [];
    s.privacy.reviewGroups = [...new Set(s.privacy.reviewGroups.filter((g) => ["chat", "note", "reaction", "dm", "profile", "other"].includes(g)))];
    const calls = s.privacy.calls || {};
    s.privacy.calls = {
      disable: calls.disable !== false,
      hideUi: calls.hideUi !== false,
      blockSignals: calls.blockSignals !== false,
      blockOutgoing: calls.blockOutgoing !== false
    };
    s.glub.build = String(s.glub.build || "").trim().slice(0, 64);
    s.glub.manualBuild = String(s.glub.manualBuild || "").trim().slice(0, 64);
    if (s.glub.manualBuild && !/^[a-zA-Z0-9._-]{3,64}$/.test(s.glub.manualBuild)) s.glub.manualBuild = "";
    s.glub.buildFetchedAt = Number.isFinite(s.glub.buildFetchedAt) ? s.glub.buildFetchedAt : 0;
    s.glub.autoSync = s.glub.autoSync !== false;
    if (!PRESET_IDS.has(s.theme.preset)) s.theme.preset = "agnostr";
    s.theme.customCss = String(s.theme.customCss || "").slice(0, 4e4);
    if (!s.appearance || typeof s.appearance !== "object") s.appearance = {};
    s.appearance.hideNotificationButton = s.appearance.hideNotificationButton === true;
    s.sounds.message = MESSAGE_IDS.has(s.sounds.message) ? s.sounds.message : "macintosh";
    s.sounds.click = CLICK_IDS.has(s.sounds.click) ? s.sounds.click : "model-m";
    {
      const volume = Number(s.sounds.volume);
      s.sounds.volume = Number.isFinite(volume) ? Math.max(0, Math.min(1, volume)) : 0.55;
    }
    s.sounds.messageEnabled = s.sounds.messageEnabled !== false;
    s.sounds.clickEnabled = s.sounds.clickEnabled !== false;
    if (!s.sounds.events || typeof s.sounds.events !== "object") s.sounds.events = {};
    s.sounds.events.chat = s.sounds.events.chat !== false;
    s.sounds.events.mentionOnly = s.sounds.events.mentionOnly === true;
    s.sounds.events.dm = s.sounds.events.dm !== false;
    s.sounds.events.calls = s.sounds.events.calls === true;
    const fontIds = /* @__PURE__ */ new Set([
      "default",
      "inter",
      "jetbrains",
      "plex",
      "atkinson",
      "lexend",
      "source-serif",
      "plex-serif",
      "merriweather",
      "crimson",
      "spectral",
      "noto-serif",
      "baskerville",
      "noto",
      "source",
      "fira",
      "ubuntu",
      "custom"
    ]);
    s.font.family = fontIds.has(s.font.family) ? s.font.family : "default";
    s.font.customFamily = String(s.font.customFamily || "").trim().slice(0, 80);
    s.font.customUrl = String(s.font.customUrl || "").trim().slice(0, 500);
    s.actions.custom = String(s.actions.custom || "boops").trim().slice(0, 60) || "boops";
    s.inspector.maxEvents = Math.max(100, Math.min(5e3, Number(s.inspector.maxEvents) || 1500));
    s.inspector.paused = s.inspector.paused === true;
    s.ui.firstRun = s.ui.firstRun === true;
    s.ui.panelOpen = s.ui.panelOpen === true;
    delete s.ui.showVoiceMemo;
    if (!["studio", "relay", "help"].includes(s.ui.activeTab)) s.ui.activeTab = "studio";
    if (!["line", "client"].includes(s.ui.betterTab)) s.ui.betterTab = "line";
    return s;
  }
  function effectiveBuild(settings) {
    return settings?.glub?.manualBuild || settings?.glub?.build || "";
  }

  // src/lib/version.js
  var VERSION = "1.3.3";

  // src/content.js
  var api = globalThis.browser ?? globalThis.chrome;
  var NATIVE_NOTIFICATIONS_KEY = "agnostr:v2:notifications";
  var NATIVE_NOTIFICATIONS_BACKUP = "betterAgnostr.nativeNotifications.v1";
  var NATIVE_SETTINGS_KEY = "agnostr:v2:settings";
  var NATIVE_SETTINGS_BACKUP = "betterAgnostr.nativeSettings.v1";
  var SETTINGS_BACKUP_KEY = "betterAgnostr.settings.backup.v1";
  var CHIME_LOCK_KEY = "betterAgnostr.lastChime.v1";
  var toastCooldowns = /* @__PURE__ */ new Map();
  var NATIVE_SOUND_OWNERS_KEY = "betterAgnostr.nativeSoundOwners.v1";
  var NATIVE_SOUND_OWNER_TTL = 12 * 60 * 60 * 1e3;
  var TAB_ID = (() => {
    try {
      const key = "betterAgnostr.tabId.v1";
      const existing = globalThis.sessionStorage.getItem(key);
      if (existing) return existing;
      const next = `tab-${crypto.randomUUID?.() || Math.random().toString(36).slice(2)}-${Date.now()}`;
      globalThis.sessionStorage.setItem(key, next);
      return next;
    } catch {
      return `tab-${crypto.randomUUID?.() || Math.random().toString(36).slice(2)}-${Date.now()}`;
    }
  })();
  function readSettingsBackup() {
    try {
      const raw = localStorage.getItem(SETTINGS_BACKUP_KEY);
      if (!raw) return null;
      const saved = JSON.parse(raw);
      return saved?.settings && typeof saved.settings === "object" ? saved.settings : null;
    } catch {
      return null;
    }
  }
  function writeSettingsBackup(settings) {
    try {
      localStorage.setItem(
        SETTINGS_BACKUP_KEY,
        JSON.stringify({ version: 1, savedAt: Date.now(), settings })
      );
    } catch {
    }
  }
  function nativeSoundOwners() {
    try {
      const raw = JSON.parse(localStorage.getItem(NATIVE_SOUND_OWNERS_KEY) || "[]");
      if (!Array.isArray(raw)) return [];
      const cutoff = Date.now() - NATIVE_SOUND_OWNER_TTL;
      return raw.filter((owner) => owner && typeof owner.id === "string" && Number(owner.at) >= cutoff);
    } catch {
      return [];
    }
  }
  function writeNativeSoundOwners(owners) {
    try {
      if (!owners.length) localStorage.removeItem(NATIVE_SOUND_OWNERS_KEY);
      else localStorage.setItem(NATIVE_SOUND_OWNERS_KEY, JSON.stringify(owners));
    } catch {
    }
  }
  function setNativeSoundFlag(key, backupKey, enabled) {
    try {
      const raw = localStorage.getItem(key);
      let current = {};
      try {
        current = raw ? JSON.parse(raw) : {};
      } catch {
        current = {};
      }
      if (!current || typeof current !== "object") current = {};
      if (enabled === null) delete current.soundEnabled;
      else current.soundEnabled = enabled;
      if (enabled === null && !Object.keys(current).length) localStorage.removeItem(key);
      else localStorage.setItem(key, JSON.stringify(current));
      if (enabled === null) localStorage.removeItem(backupKey);
    } catch {
    }
  }
  function captureNativeSound(key, backupKey) {
    try {
      if (localStorage.getItem(backupKey) !== null) return;
      const raw = localStorage.getItem(key);
      let present = false;
      let value = true;
      try {
        const parsed = raw ? JSON.parse(raw) : {};
        if (parsed && typeof parsed === "object" && Object.prototype.hasOwnProperty.call(parsed, "soundEnabled")) {
          present = true;
          value = parsed.soundEnabled !== false;
        }
      } catch {
      }
      localStorage.setItem(backupKey, JSON.stringify({ present, value: value === true }));
    } catch {
    }
  }
  function restoreNativeSound(key, backupKey) {
    try {
      const backup = localStorage.getItem(backupKey);
      if (backup === null) return;
      const saved = JSON.parse(backup);
      setNativeSoundFlag(key, backupKey, saved?.present ? saved.value !== false : null);
    } catch {
      try {
        localStorage.removeItem(backupKey);
      } catch {
      }
    }
  }
  function claimNativeSounds() {
    const owners = nativeSoundOwners();
    const ours = owners.some((owner) => owner.id === TAB_ID);
    captureNativeSound(NATIVE_NOTIFICATIONS_KEY, NATIVE_NOTIFICATIONS_BACKUP);
    captureNativeSound(NATIVE_SETTINGS_KEY, NATIVE_SETTINGS_BACKUP);
    setNativeSoundFlag(NATIVE_NOTIFICATIONS_KEY, NATIVE_NOTIFICATIONS_BACKUP, false);
    setNativeSoundFlag(NATIVE_SETTINGS_KEY, NATIVE_SETTINGS_BACKUP, false);
    if (!ours) owners.push({ id: TAB_ID, at: Date.now() });
    writeNativeSoundOwners(owners);
  }
  function releaseNativeSounds() {
    const owners = nativeSoundOwners().filter((owner) => owner.id !== TAB_ID);
    writeNativeSoundOwners(owners);
    if (owners.length) return;
    restoreNativeSound(NATIVE_NOTIFICATIONS_KEY, NATIVE_NOTIFICATIONS_BACKUP);
    restoreNativeSound(NATIVE_SETTINGS_KEY, NATIVE_SETTINGS_BACKUP);
  }
  function overrideNativeSounds() {
    claimNativeSounds();
  }
  function restoreNativeSounds() {
    releaseNativeSounds();
  }
  var FONT_PRESETS = [
    { id: "default", label: "Agnostr default" },
    { id: "inter", label: "Inter", stack: "Inter, system-ui, sans-serif" },
    { id: "jetbrains", label: "JetBrains Mono", stack: "'JetBrains Mono', ui-monospace, monospace", mono: true },
    { id: "plex", label: "IBM Plex Sans", stack: "'BA IBM Plex Sans', 'IBM Plex Sans', sans-serif" },
    { id: "atkinson", label: "Atkinson Hyperlegible", stack: "'BA Atkinson', 'Atkinson Hyperlegible', sans-serif" },
    { id: "lexend", label: "Lexend", stack: "'BA Lexend', Lexend, sans-serif" },
    { id: "source-serif", label: "Source Serif 4", stack: "'BA Source Serif', 'Source Serif 4', Georgia, serif" },
    { id: "plex-serif", label: "IBM Plex Serif", stack: "'BA Plex Serif', 'IBM Plex Serif', Georgia, serif" },
    { id: "merriweather", label: "Merriweather", stack: "'BA Merriweather', Merriweather, Georgia, serif" },
    { id: "crimson", label: "Crimson Pro", stack: "'BA Crimson', 'Crimson Pro', Georgia, serif" },
    { id: "spectral", label: "Spectral", stack: "'BA Spectral', Spectral, Georgia, serif" },
    { id: "noto-serif", label: "Noto Serif", stack: "'BA Noto Serif', 'Noto Serif', Georgia, serif" },
    { id: "baskerville", label: "Libre Baskerville", stack: "'BA Baskerville', 'Libre Baskerville', Georgia, serif" },
    { id: "noto", label: "Noto Sans", stack: "'Noto Sans', system-ui, sans-serif" },
    { id: "source", label: "Source Sans 3", stack: "'Source Sans 3', 'Source Sans Pro', sans-serif" },
    { id: "fira", label: "Fira Sans", stack: "'Fira Sans', system-ui, sans-serif" },
    { id: "ubuntu", label: "Ubuntu", stack: "Ubuntu, system-ui, sans-serif" },
    { id: "custom", label: "Custom font" }
  ];
  var state = {
    settings: normalizeSettings({}),
    pageToken: `ba-${crypto.randomUUID?.() || Math.random().toString(36).slice(2)}-${Date.now()}`,
    pageReady: false,
    helloAttempts: 0,
    enabledReady: false,
    status: null,
    events: /* @__PURE__ */ new Map(),
    aliases: /* @__PURE__ */ new Map(),
    logs: [],
    pending: /* @__PURE__ */ new Map(),
    host: null,
    shadow: null,
    ui: {},
    activeTab: "studio",
    viewer: null,
    viewerRequestSeq: 0,
    review: null,
    reviewQueue: [],
    modalOpen: null,
    modalReturnFocus: null,
    logFilter: "",
    buildError: "",
    buildStale: false,
    buildFetching: false,
    lastOutgoingId: null,
    decoratedRows: /* @__PURE__ */ new Set(),
    richApplied: /* @__PURE__ */ new WeakMap(),
    betterPeers: /* @__PURE__ */ new Map(),
    peerClients: /* @__PURE__ */ new Map(),
    emojiCategory: "smileys",
    lastBetterClients: 0,
    betterClientsTimer: null,
    lastBitchatReplace: 0,
    bitchatTimer: null,
    lastCallMaintenance: 0,
    callMaintenanceTimer: null,
    settingsEpoch: 0,
    fontCssSignature: "",
    enhancePending: false,
    obfCache: [],
    obfNextScan: 0,
    pageObserver: null,
    pageObserverStart: null,
    pendingLookups: /* @__PURE__ */ new Set(),
    enhanceTimer: null,
    saveTimer: null,
    toasts: /* @__PURE__ */ new Set(),
    verified: /* @__PURE__ */ new Map(),
    entities: /* @__PURE__ */ new Map(),
    restoreMap: /* @__PURE__ */ new WeakMap(),
    richObservers: /* @__PURE__ */ new WeakMap(),
    richRoots: /* @__PURE__ */ new Set(),
    richRepairing: /* @__PURE__ */ new WeakSet(),
    repairingRows: /* @__PURE__ */ new WeakSet(),
    logRenderTimer: null,
    themeStyle: null,
    pageStyle: null,
    callObserver: null,
    sendSeq: 0,
    pageSeen: /* @__PURE__ */ new Set(),
    settingsBetterActive: false,
    aboutActive: false,
    settingsModalOpen: false,
    betterTab: "line",
    betterPreviewSig: "",
    settingsTimer: null,
    contextTarget: null,
    customAction: null,
    seenChimeIds: /* @__PURE__ */ new Set(),
    ownEventIds: /* @__PURE__ */ new Set(),
    agnostrActiveThemeCard: null,
    lastChimeAt: 0,
    lastUiSoundAt: 0,
    soundUnlocked: false,
    themeCssSignature: ""
  };
  function h(value) {
    return escapeHtml(String(value ?? ""));
  }
  var EMOJI_DOM_RE = new RegExp("(?:[\\u{1F1E6}-\\u{1F1FF}]{2}|[#*0-9]\\uFE0F?\\u20E3|\\p{Extended_Pictographic}(?:\\uFE0F|\\u20E3|[\\u{1F3FB}-\\u{1F3FF}])?(?:\\u200D\\p{Extended_Pictographic}(?:\\uFE0F|[\\u{1F3FB}-\\u{1F3FF}])?)*)", "gu");
  var OBF_BUCKETS = [
    "0123456789",
    "abcdefghijklmnopqrstuvwxyz",
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
    ".,;:!?'\"`",
    "@#$%^&*()_+-=[]{}<>/\\|~"
  ];
  function obfGlyph(ch) {
    for (const bucket of OBF_BUCKETS) if (bucket.includes(ch)) return bucket[Math.floor(Math.random() * bucket.length)];
    return ch;
  }
  var obfBursts = /* @__PURE__ */ new WeakMap();
  function startObfBurst(real, now) {
    const candidates = [];
    const chars = [...real];
    for (let i = 0; i < chars.length; i++) {
      if (OBF_BUCKETS.some((bucket) => bucket.includes(chars[i]))) candidates.push(i);
    }
    if (!candidates.length) return null;
    for (let i = candidates.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [candidates[i], candidates[j]] = [candidates[j], candidates[i]];
    }
    const count = Math.min(2, 1 + (Math.random() < 0.3 ? 1 : 0), candidates.length);
    return { indices: candidates.slice(0, count), until: now + 280 + Math.random() * 200 };
  }
  function tickObfuscation() {
    if (document.hidden) return;
    const now = performance.now();
    if (now >= state.obfNextScan) {
      state.obfCache = [...document.querySelectorAll(".fmtObf")];
      if (state.shadow) state.obfCache.push(...state.shadow.querySelectorAll(".fmtObf"));
      state.obfNextScan = now + 1200;
    }
    const els = state.obfCache.filter((el) => el.isConnected);
    state.obfCache = els;
    if (!els.length) return;
    const still = window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches;
    for (const el of els) {
      if (el.dataset.obfText == null) el.dataset.obfText = el.textContent || "";
      const real = el.dataset.obfText;
      if (!real) continue;
      if (still) {
        if (el.textContent !== real) el.textContent = real;
        el.dataset.obfStatic = "1";
        continue;
      }
      let burst = obfBursts.get(el);
      if (!burst) {
        if (Math.random() >= 0.01) {
          if (el.textContent !== real) el.textContent = real;
          continue;
        }
        burst = startObfBurst(real, now);
        if (!burst) continue;
        obfBursts.set(el, burst);
      }
      if (now >= burst.until) {
        obfBursts.delete(el);
        if (el.textContent !== real) el.textContent = real;
        continue;
      }
      const chars = [...real];
      for (const index of burst.indices) chars[index] = obfGlyph(chars[index]);
      const next = chars.join("");
      if (el.textContent !== next) el.textContent = next;
    }
  }
  function handleGlobalClickSound(event) {
    if (!state.settings.sounds.clickEnabled || state.settings.sounds.click === "off") return;
    const path = event.composedPath?.() || [];
    const isPreview = path.some(
      (el) => el instanceof Element && (el.matches('[data-action^="preview-"]') || el.matches('[data-ba-settings-action^="preview-"]'))
    );
    if (isPreview) return;
    const interactive = path.some(
      (el) => el instanceof Element && el.matches('button, a[href], [role="button"], input[type="checkbox"], input[type="radio"], select, .ag-set-nav-item, .ag-ctx-item, .ag-rail-tile, .ag-msg-act-btn')
    );
    if (!interactive) return;
    if (Date.now() - state.lastUiSoundAt < 45) return;
    state.lastUiSoundAt = Date.now();
    playClickSound(state.settings.sounds.click, state.settings.sounds.volume);
  }
  function getPath(obj, path) {
    return path.split(".").reduce((acc, key) => acc == null ? void 0 : acc[key], obj);
  }
  function setPath(obj, path, value) {
    const parts = path.split(".");
    let cur = obj;
    for (let i = 0; i < parts.length - 1; i++) {
      if (!cur[parts[i]] || typeof cur[parts[i]] !== "object") cur[parts[i]] = {};
      cur = cur[parts[i]];
    }
    cur[parts[parts.length - 1]] = value;
    return obj;
  }
  function short(value, len = 10) {
    const s = String(value || "");
    return s.length > len ? `${s.slice(0, len)}\u2026` : s;
  }
  function kindLabel(kind) {
    if (kind === 2e4) return "chat";
    if (kind === 20001) return "presence";
    if (kind === 23333) return "named chat";
    if (kind === 1) return "note";
    if (kind === 0) return "profile";
    if (kind === 3) return "contacts";
    if (kind === 7) return "reaction";
    if (kind === 5) return "deletion";
    if (kind === 4) return "dm";
    if (kind === 13) return "seal";
    if (kind === 14) return "dm";
    if (kind === 1059) return "gift wrap";
    if (kind === 25050) return "call signal";
    return `kind ${kind}`;
  }
  function timeLabel(ts) {
    try {
      return new Date(ts < 1e12 ? ts * 1e3 : ts).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
    } catch {
      return "";
    }
  }
  function dateLabel(ts) {
    try {
      return new Date(ts < 1e12 ? ts * 1e3 : ts).toLocaleString();
    } catch {
      return "";
    }
  }
  function hostOf(url) {
    try {
      return new URL(url).host.replace(/^www\./, "");
    } catch {
      return String(url || "");
    }
  }
  function debounceSave() {
    window.clearTimeout(state.saveTimer);
    state.saveTimer = window.setTimeout(persistSettings, 180);
  }
  async function persistSettings() {
    try {
      await api.storage.local.set({ [STORAGE_KEY]: state.settings });
      writeSettingsBackup(state.settings);
    } catch (err) {
      console.warn("[Better Agnostr] could not save settings", err);
    }
  }
  function broadcastConfig() {
    sendPage("config", { settings: JSON.stringify(state.settings) });
  }
  function updateSettings(mutator, { broadcast = true, sync = true } = {}) {
    const next = clone(state.settings);
    mutator(next);
    state.settings = normalizeSettings(next);
    state.settingsEpoch += 1;
    state.lastBetterClients = 0;
    state.lastCallMaintenance = 0;
    debounceSave();
    if (broadcast) broadcastConfig();
    if (sync) {
      syncInputs();
      syncDynamic();
      applyTheme();
      applyCallCss();
      ensureToolbars();
      applyShortcutVisibility();
      scheduleEnhance();
      scheduleSettingsSync();
    }
  }
  function markSettingsDirty() {
    debounceSave();
    broadcastConfig();
  }
  function sendPage(type, payload = {}, id) {
    state.sendSeq += 1;
    const envelope = { __ba: true, dir: "ui", token: state.pageToken, seq: state.sendSeq, type, payload, id };
    try {
      window.postMessage(envelope, location.origin);
    } catch {
    }
  }
  function askPage(type, payload = {}, timeoutMs = 8e3) {
    return new Promise((resolve) => {
      const id = `ba-req-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
      const timer = window.setTimeout(() => {
        state.pending.delete(id);
        resolve(null);
      }, timeoutMs);
      state.pending.set(id, (value) => {
        window.clearTimeout(timer);
        resolve(value);
      });
      sendPage(type, payload, id);
    });
  }
  function hello() {
    if (state.pageReady) return;
    state.helloAttempts += 1;
    sendPage("hello", { settings: JSON.stringify(state.settings) });
    if (state.helloAttempts < 120) window.setTimeout(hello, 250);
  }
  async function refreshBuild(force = false) {
    if (state.buildFetching) return;
    state.buildFetching = true;
    try {
      const res = await api.runtime.sendMessage({ type: "getGlubBuild", force });
      if (res?.build) {
        state.buildStale = !!res.stale;
        state.buildError = res.stale && res.error ? `Using cached build: ${res.error}` : "";
        const nextBuild = String(res.build);
        const changed = state.settings.glub.build !== nextBuild;
        state.settings.glub.build = nextBuild;
        state.settings.glub.buildFetchedAt = Number(res.fetchedAt) || Date.now();
        if (changed) markSettingsDirty();
        syncDynamic();
      } else if (res?.error) {
        state.buildStale = false;
        state.buildError = String(res.error);
        syncDynamic();
      }
    } catch (err) {
      state.buildError = err instanceof Error ? err.message : String(err);
      syncDynamic();
    } finally {
      state.buildFetching = false;
    }
  }
  function handlePageMessage(event) {
    if (event.source && event.source !== window && event.source !== window.wrappedJSObject) return;
    if (event.origin && event.origin !== location.origin) return;
    const data = event?.data;
    if (!data || data.__ba !== true || data.dir !== "page") return;
    if (!data.token || data.token !== state.pageToken) return;
    if (data.seq != null) {
      const key = `${data.token || ""}:seq:${data.seq}`;
      if (state.pageSeen.has(key)) return;
      state.pageSeen.add(key);
      if (state.pageSeen.size > 300) {
        const first = state.pageSeen.values().next().value;
        if (first) state.pageSeen.delete(first);
      }
    }
    handlePageData(data);
  }
  function handlePageData(data) {
    if (!data.token || data.token !== state.pageToken) return;
    if (!state.enabledReady || state.settings.enabled === false) return;
    if (data.id && state.pending.has(data.id)) {
      const fn = state.pending.get(data.id);
      state.pending.delete(data.id);
      fn(data.payload);
      return;
    }
    switch (data.type) {
      case "ready":
        state.pageReady = true;
        sendPage("config", { settings: state.settings });
        askPage("getRecent", { limit: 300 }).then((res) => {
          if (res?.events) {
            for (const ev of res.events) rememberEvent(ev);
            scheduleEnhance();
            renderRelaySoon();
          }
        });
        refreshBuild(false);
        break;
      case "status": {
        const previous = state.status || {};
        state.status = data.payload || {};
        if (previous.pubkey !== state.status.pubkey || previous.signerHooked !== state.status.signerHooked || previous.signMode !== state.status.signMode || previous.nip07Patched !== state.status.nip07Patched || previous.eventCount !== state.status.eventCount) {
          scheduleEnhance();
        }
        if (state.status.build) {
          if (!state.settings.glub.build) {
            state.settings.glub.build = state.status.build;
            state.settings.glub.buildFetchedAt = state.status.buildFetchedAt || Date.now();
            void persistSettings();
          }
        }
        syncFooter();
        syncBuildBadges();
        scheduleSettingsSync();
        if (state.activeTab === "relay") renderRelay();
        break;
      }
      case "logs": {
        const logs = data.payload?.logs || [];
        appendLogs(logs);
        break;
      }
      case "recent": {
        const events = data.payload?.events || [];
        for (const ev of events) rememberEvent(ev);
        scheduleEnhance();
        renderRelaySoon();
        break;
      }
      case "event": {
        const ev = data.payload?.event;
        if (ev) rememberEvent(ev);
        break;
      }
      case "alias": {
        if (data.payload?.from && data.payload?.to) {
          state.aliases.set(data.payload.from, data.payload.to);
          if (state.aliases.size > 1e3) {
            const first = state.aliases.keys().next().value;
            if (first) state.aliases.delete(first);
          }
          scheduleEnhance();
        }
        break;
      }
      case "notice":
        toast(data.payload?.level || "info", data.payload?.title || "Better Agnostr", data.payload?.detail || "");
        break;
      case "build": {
        const reqId = data.id;
        refreshBuild(!!data.payload?.force).then(() => {
          const build = effectiveBuild(state.settings);
          sendPage(
            "response",
            { build, fetchedAt: state.settings.glub.buildFetchedAt, error: state.buildError, stale: state.buildStale },
            reqId
          );
        }).catch((err) => {
          sendPage("response", { build: effectiveBuild(state.settings), fetchedAt: state.settings.glub.buildFetchedAt, error: String(err), stale: state.buildStale }, reqId);
        });
        break;
      }
      case "review": {
        const proposed = data.payload?.proposed;
        if (!proposed || typeof proposed !== "object" || !Array.isArray(proposed.tags)) {
          if (data.id) sendPage("response", { action: "cancel" }, data.id);
          break;
        }
        queueReview(data.payload || {}, data.id);
        break;
      }
      case "verified": {
        if (state.viewer?.event?.id) {
          state.verified.set(state.viewer.event.id, data.payload);
          if (state.verified.size > 500) {
            const first = state.verified.keys().next().value;
            if (first) state.verified.delete(first);
          }
          if (state.viewer.tab === "verify") renderViewer();
        }
        break;
      }
      case "entities": {
        if (state.viewer?.event?.id) {
          state.entities.set(state.viewer.event.id, data.payload || {});
          if (state.entities.size > 500) {
            const first = state.entities.keys().next().value;
            if (first) state.entities.delete(first);
          }
          renderViewer();
        }
        break;
      }
      default:
        break;
    }
  }
  function isValidEventShape(ev) {
    return ev && typeof ev === "object" && typeof ev.id === "string" && /^[0-9a-f]{64}$/i.test(ev.id) && typeof ev.pubkey === "string" && (ev._reconstructed ? true : /^[0-9a-f]{64}$/i.test(ev.pubkey)) && Number.isFinite(ev.kind) && Number.isFinite(ev.created_at) && typeof ev.content === "string" && Array.isArray(ev.tags);
  }
  function rememberEvent(ev) {
    if (!isValidEventShape(ev)) return false;
    const existing = state.events.get(ev.id);
    let changed = false;
    if (!existing) {
      state.events.set(ev.id, ev);
      changed = true;
    } else if (existing._reconstructed && !ev._reconstructed) {
      state.events.set(ev.id, ev);
      changed = true;
    }
    if (ev.pubkey && Array.isArray(ev.tags)) {
      const pubkey = String(ev.pubkey).toLowerCase();
      if (isBetterClient(ev)) {
        state.betterPeers.set(pubkey, eventHandle(ev));
        if (state.betterPeers.size > 2e3) {
          const first = state.betterPeers.keys().next().value;
          if (first) state.betterPeers.delete(first);
        }
      }
      const client = String(getTagValue(ev.tags, "client") || "").trim();
      if (client) {
        const at = Number(ev.created_at) || 0;
        const previous = state.peerClients.get(pubkey);
        if (!previous || at >= previous.at) state.peerClients.set(pubkey, { name: client, at });
        if (state.peerClients.size > 2e3) {
          const first = state.peerClients.keys().next().value;
          if (first) state.peerClients.delete(first);
        }
      }
    }
    const cap = Math.max(100, Math.min(5e3, Number(state.settings.inspector?.maxEvents) || 1500));
    if (state.events.size > cap) {
      const first = state.events.keys().next().value;
      if (first) state.events.delete(first);
    }
    return changed;
  }
  function eventById(id) {
    if (!id) return null;
    if (state.events.has(id)) return state.events.get(id);
    const alias = state.aliases.get(id);
    if (alias && state.events.has(alias)) return state.events.get(alias);
    return null;
  }
  function appendLogs(logs) {
    if (!Array.isArray(logs) || !logs.length) return;
    const internalKinds = /* @__PURE__ */ new Set([25050, 25051, 25052, 25053, 25054, 25055, 25058, 25059, 30078]);
    let changed = false;
    for (const log of logs) {
      if (!log || typeof log !== "object") continue;
      if (log.event && rememberEvent(log.event)) changed = true;
      if (log.dir === "out" && log.eventId) {
        state.ownEventIds.add(log.eventId);
        if (!internalKinds.has(log.kind)) state.lastOutgoingId = log.eventId;
      }
      if (log.dir === "in" && log.event && isValidEventShape(log.event)) handleIncomingAlert(log.event);
    }
    state.logs.push(...logs);
    if (state.logs.length > 300) state.logs.splice(0, state.logs.length - 300);
    if (state.ownEventIds.size > 2e3) {
      const first = state.ownEventIds.values().next().value;
      if (first) state.ownEventIds.delete(first);
    }
    if (changed) scheduleEnhance();
    renderRelaySoon();
    syncLastOutgoing();
  }
  function isMentionEvent(event) {
    if (!event) return false;
    const own = String(state.status?.pubkey || "").toLowerCase();
    if (own) {
      for (const tag2 of event.tags || []) {
        if (Array.isArray(tag2) && tag2[0] === "p" && String(tag2[1] || "").toLowerCase() === own) return true;
      }
    }
    const name = String(state.status?.nickname || "").toLowerCase();
    if (!name) return false;
    const tag = own ? own.slice(-4) : "";
    const content = String(event.content || "").toLowerCase();
    const needles = [`@${name}`, ...tag ? [`@${name}#${tag}`] : []];
    for (const needle of needles) {
      let start = content.indexOf(needle);
      while (start !== -1) {
        const before = start === 0 ? "" : content[start - 1];
        const end = start + needle.length;
        const after = content[end] || "";
        if (!/[a-z0-9_]/i.test(before) && !/[a-z0-9_]/i.test(after)) return true;
        start = content.indexOf(needle, start + 1);
      }
    }
    return false;
  }
  function alertKind(event) {
    const kind = Number(event?.kind);
    if (kind === 2e4 || kind === 23333) return isMentionEvent(event) ? "mention" : "chat";
    if (kind === 4 || kind === 14 || kind === 1059) return "dm";
    if (kind >= 25050 && kind <= 25059) return "call";
    return "";
  }
  function alertAllowed(kind, events) {
    if (kind === "dm") return events.dm !== false;
    if (kind === "call") return events.calls === true && !state.settings.privacy.calls.disable;
    if (kind === "chat" || kind === "mention") {
      if (events.chat === false) return false;
      if (events.mentionOnly && kind !== "mention") return false;
      return true;
    }
    return false;
  }
  function handleIncomingAlert(event) {
    if (!event) return;
    const kind = alertKind(event);
    if (!kind) return;
    const events = state.settings.sounds.events || {};
    if (!alertAllowed(kind, events)) return;
    if (state.seenChimeIds.has(event.id) || state.ownEventIds.has(event.id)) return;
    const age = Math.floor(Date.now() / 1e3) - Number(event.created_at || 0);
    if (!Number.isFinite(age) || age < -10 || age > 15) return;
    const own = state.status?.pubkey?.toLowerCase();
    if (own && String(event.pubkey || "").toLowerCase() === own) return;
    state.seenChimeIds.add(event.id);
    const now = Date.now();
    if (now - state.lastChimeAt < 350) return;
    try {
      const shared = Number(localStorage.getItem(CHIME_LOCK_KEY) || 0);
      if (now - shared < 350) return;
      localStorage.setItem(CHIME_LOCK_KEY, String(now));
    } catch {
    }
    state.lastChimeAt = now;
    if (state.seenChimeIds.size > 1e3) {
      const first = state.seenChimeIds.values().next().value;
      if (first) state.seenChimeIds.delete(first);
    }
    const sounds = state.settings.sounds;
    if (sounds.messageEnabled && sounds.message !== "off") {
      playMessageSound(sounds.message, sounds.volume);
    }
  }
  function renderRelaySoon() {
    if (state.activeTab !== "relay") return;
    window.clearTimeout(state.logRenderTimer);
    state.logRenderTimer = window.setTimeout(renderRelay, 120);
  }
  function ensureHost() {
    if (state.host) return;
    if (!document.body) {
      document.addEventListener("DOMContentLoaded", ensureHost, { once: true });
      return;
    }
    const host = document.createElement("div");
    host.id = "better-agnostr-host";
    host.setAttribute("data-better-agnostr", "1");
    document.documentElement.appendChild(host);
    const shadow = host.attachShadow({ mode: "open" });
    state.host = host;
    state.shadow = shadow;
    const style = document.createElement("style");
    style.textContent = panel_default;
    shadow.appendChild(style);
    const flairStyle = document.createElement("style");
    flairStyle.textContent = glub_flair_default;
    shadow.appendChild(flairStyle);
    const shell = document.createElement("div");
    shell.innerHTML = shellHtml();
    shadow.appendChild(shell);
    state.ui = { shell };
    injectPageStyles();
    wireShell();
    buildDynamicParts();
    syncInputs();
    syncDynamic();
    applyTheme();
    applyCallCss();
    updatePanelVisibility();
  }
  function modalWrap(which) {
    return state.shadow?.querySelector(`[data-modal='${which}']`) || null;
  }
  function modalFocusable(wrap) {
    if (!wrap) return [];
    return [...wrap.querySelectorAll(
      'button:not([disabled]), a[href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
    )].filter((el) => el instanceof HTMLElement && !el.hidden && el.getAttribute("aria-hidden") !== "true");
  }
  function setModalOpen(which, open) {
    const wrap = modalWrap(which);
    if (!wrap) return;
    if (open && state.modalOpen && state.modalOpen !== which) setModalOpen(state.modalOpen, false);
    wrap.hidden = !open;
    wrap.classList.toggle("is-open", open);
    wrap.setAttribute("aria-hidden", open ? "false" : "true");
    if ("inert" in wrap) wrap.inert = !open;
    if (open) {
      wrap.removeAttribute("inert");
      state.modalOpen = which;
      state.modalReturnFocus = document.activeElement;
      window.requestAnimationFrame(() => {
        if (state.modalOpen !== which) return;
        const dialog = wrap.querySelector("[role='dialog']");
        const first = modalFocusable(wrap)[0];
        if (first instanceof HTMLElement) first.focus();
        else if (dialog instanceof HTMLElement) {
          dialog.setAttribute("tabindex", "-1");
          dialog.focus();
        }
      });
    } else {
      wrap.setAttribute("inert", "");
      if (state.modalOpen === which) state.modalOpen = null;
      const target = state.modalReturnFocus;
      state.modalReturnFocus = null;
      if (target instanceof HTMLElement && target.isConnected) {
        try {
          target.focus({ preventScroll: true });
        } catch {
        }
      }
    }
  }
  function trapModalKey(event) {
    if (!state.modalOpen) return false;
    if (event.key === "Escape") {
      event.preventDefault();
      event.stopPropagation();
      if (state.modalOpen === "review") finishReview("cancel");
      else if (state.modalOpen === "action") closeActionModal();
      else if (state.modalOpen === "viewer") closeViewer();
      return true;
    }
    if (event.key !== "Tab") return false;
    const wrap = modalWrap(state.modalOpen);
    const items = modalFocusable(wrap);
    if (!items.length) {
      event.preventDefault();
      return true;
    }
    const active = state.shadow?.activeElement || document.activeElement;
    const first = items[0];
    const last = items[items.length - 1];
    if (event.shiftKey && (active === first || !items.includes(active))) {
      event.preventDefault();
      last.focus();
      return true;
    }
    if (!event.shiftKey && (active === last || !items.includes(active))) {
      event.preventDefault();
      first.focus();
      return true;
    }
    return false;
  }
  function shellHtml() {
    return `
  <div class="ba-modal-wrap" data-modal="viewer" aria-hidden="true" hidden>
    <div class="ba-modal-backdrop" data-close-modal="viewer"></div>
    <div class="ba-modal" role="dialog" aria-modal="true" aria-label="Event details">
      <div data-role="viewer-content"></div>
    </div>
  </div>
  <div class="ba-modal-wrap" data-modal="review" aria-hidden="true" hidden>
    <div class="ba-modal-backdrop" data-close-modal="review"></div>
    <div class="ba-modal small" role="dialog" aria-modal="true" aria-label="Review outgoing event">
      <div data-role="review-content"></div>
    </div>
  </div>
  <div class="ba-modal-wrap" data-modal="action" aria-hidden="true" hidden>
    <div class="ba-modal-backdrop" data-close-modal="action"></div>
    <div class="ba-modal small" role="dialog" aria-modal="true" aria-label="Custom action">
      <div data-role="action-content"></div>
    </div>
  </div>
  <div class="ba-toasts" data-role="toasts" role="status" aria-live="polite" aria-atomic="false"></div>
`;
  }
  function injectPageStyles() {
    const head = document.head || document.documentElement;
    if (!document.getElementById("ba-glub-flair-css")) {
      const flairStyle = document.createElement("style");
      flairStyle.id = "ba-glub-flair-css";
      flairStyle.textContent = glub_flair_default;
      head.appendChild(flairStyle);
    }
    if (!state.pageStyle || !state.pageStyle.isConnected) {
      const existing = document.getElementById("ba-page-css");
      if (existing) state.pageStyle = existing;
      else {
        const style = document.createElement("style");
        style.id = "ba-page-css";
        style.textContent = page_default;
        head.appendChild(style);
        state.pageStyle = style;
      }
    }
    applyTheme();
  }
  function applyRainbowStyle() {
    const mode = state.settings.studio.rainbowStyle === "bright" ? "bright" : "glub";
    document.documentElement.dataset.baRainbow = mode;
    if (state.host) state.host.dataset.baRainbow = mode;
  }
  function applyUiPreferences() {
    document.documentElement.classList.toggle(
      "ba-hide-notification-button",
      state.settings.appearance?.hideNotificationButton === true
    );
  }
  function applyTheme() {
    const head = document.head || document.documentElement;
    if (!head) return;
    if (!state.themeStyle || !state.themeStyle.isConnected) {
      state.themeCssSignature = "";
      state.themeStyle = document.getElementById("ba-theme-css");
      if (!state.themeStyle) {
        state.themeStyle = document.createElement("style");
        state.themeStyle.id = "ba-theme-css";
        head.appendChild(state.themeStyle);
      }
    }
    applyRainbowStyle();
    applyUiPreferences();
    if (state.themeStyle.parentNode === head && head.lastElementChild !== state.themeStyle) {
      head.appendChild(state.themeStyle);
    }
    const theme = themeById(state.settings.theme.preset);
    const themeCss = theme ? buildThemeCss(theme) : "";
    if (theme) document.documentElement.dataset.baTheme = theme.id;
    else delete document.documentElement.dataset.baTheme;
    const next = `${themeCss}
${state.settings.theme.customCss || ""}`;
    if (next !== state.themeCssSignature) {
      state.themeStyle.textContent = next;
      state.themeCssSignature = next;
    }
    applyFont();
  }
  function safeFontUrl(url) {
    const value = String(url || "").trim();
    if (!value) return "";
    if (!/^(https:|moz-extension:|chrome-extension:|data:font)/i.test(value)) return "";
    return value;
  }
  function applyFont() {
    const head = document.head || document.documentElement;
    if (!head) return;
    let style = document.getElementById("ba-font-css");
    if (!style || !style.isConnected) {
      state.fontCssSignature = "";
      style = document.createElement("style");
      style.id = "ba-font-css";
      head.appendChild(style);
    }
    const f = state.settings.font;
    const family = FONT_PRESETS.find((p) => p.id === f.family) || FONT_PRESETS[0];
    const bundled = `
@font-face{font-family:"BA IBM Plex Sans";src:url("${api.runtime.getURL("fonts/plex-400.woff2")}") format("woff2");font-weight:400;font-style:normal;font-display:swap}
@font-face{font-family:"BA IBM Plex Sans";src:url("${api.runtime.getURL("fonts/plex-600.woff2")}") format("woff2");font-weight:600;font-style:normal;font-display:swap}
@font-face{font-family:"BA Atkinson";src:url("${api.runtime.getURL("fonts/atkinson-400.woff2")}") format("woff2");font-weight:400;font-style:normal;font-display:swap}
@font-face{font-family:"BA Atkinson";src:url("${api.runtime.getURL("fonts/atkinson-700.woff2")}") format("woff2");font-weight:700;font-style:normal;font-display:swap}
@font-face{font-family:"BA Lexend";src:url("${api.runtime.getURL("fonts/lexend-400.woff2")}") format("woff2");font-weight:400;font-style:normal;font-display:swap}
@font-face{font-family:"BA Lexend";src:url("${api.runtime.getURL("fonts/lexend-600.woff2")}") format("woff2");font-weight:600;font-style:normal;font-display:swap}
@font-face{font-family:"BA Source Serif";src:url("${api.runtime.getURL("fonts/source-serif-400.woff2")}") format("woff2");font-weight:400;font-style:normal;font-display:swap}
@font-face{font-family:"BA Source Serif";src:url("${api.runtime.getURL("fonts/source-serif-600.woff2")}") format("woff2");font-weight:600;font-style:normal;font-display:swap}
@font-face{font-family:"BA Plex Serif";src:url("${api.runtime.getURL("fonts/plex-serif-400.woff2")}") format("woff2");font-weight:400;font-style:normal;font-display:swap}
@font-face{font-family:"BA Plex Serif";src:url("${api.runtime.getURL("fonts/plex-serif-600.woff2")}") format("woff2");font-weight:600;font-style:normal;font-display:swap}
@font-face{font-family:"BA Merriweather";src:url("${api.runtime.getURL("fonts/merriweather-400.woff2")}") format("woff2");font-weight:400;font-style:normal;font-display:swap}
@font-face{font-family:"BA Merriweather";src:url("${api.runtime.getURL("fonts/merriweather-600.woff2")}") format("woff2");font-weight:600;font-style:normal;font-display:swap}
@font-face{font-family:"BA Crimson";src:url("${api.runtime.getURL("fonts/crimson-400.woff2")}") format("woff2");font-weight:400;font-style:normal;font-display:swap}
@font-face{font-family:"BA Crimson";src:url("${api.runtime.getURL("fonts/crimson-600.woff2")}") format("woff2");font-weight:600;font-style:normal;font-display:swap}
@font-face{font-family:"BA Spectral";src:url("${api.runtime.getURL("fonts/spectral-400.woff2")}") format("woff2");font-weight:400;font-style:normal;font-display:swap}
@font-face{font-family:"BA Spectral";src:url("${api.runtime.getURL("fonts/spectral-600.woff2")}") format("woff2");font-weight:600;font-style:normal;font-display:swap}
@font-face{font-family:"BA Noto Serif";src:url("${api.runtime.getURL("fonts/noto-serif-400.woff2")}") format("woff2");font-weight:400;font-style:normal;font-display:swap}
@font-face{font-family:"BA Noto Serif";src:url("${api.runtime.getURL("fonts/noto-serif-600.woff2")}") format("woff2");font-weight:600;font-style:normal;font-display:swap}
@font-face{font-family:"BA Baskerville";src:url("${api.runtime.getURL("fonts/baskerville-400.woff2")}") format("woff2");font-weight:400;font-style:normal;font-display:swap}
@font-face{font-family:"BA Baskerville";src:url("${api.runtime.getURL("fonts/baskerville-700.woff2")}") format("woff2");font-weight:700;font-style:normal;font-display:swap}
`;
    let extra = "";
    let stack = family.stack || "";
    if (f.family === "custom") {
      const customFamily = String(f.customFamily || "").replace(/[\\"'{};\r\n]/g, "").trim();
      const url = safeFontUrl(f.customUrl);
      if (url) {
        extra = `@font-face{font-family:"BA Custom";src:url(${JSON.stringify(url)});font-style:normal;font-display:swap}`;
        stack = `"BA Custom"${customFamily ? `, "${customFamily}"` : ""}, sans-serif`;
      } else if (customFamily) {
        stack = `"${customFamily}", sans-serif`;
      }
    }
    const css = !stack ? bundled : `${bundled}
${extra}
html:root{${family.mono ? `--font-sans: ${stack} !important; --font-mono: ${stack} !important;` : `--font-sans: ${stack} !important;`}}`;
    if (css === state.fontCssSignature) return;
    state.fontCssSignature = css;
    style.textContent = css;
  }
  function applyCallCss() {
    const calls = state.settings.privacy.calls;
    document.documentElement.classList.toggle("ba-calls-hidden", !!(calls.disable && calls.hideUi));
    document.documentElement.classList.toggle("ba-hide-locate", state.settings.privacy.hideLocate !== false);
    document.documentElement.classList.toggle("ba-hide-timestamps", state.settings.privacy.hideTimestamps === true);
    removeCallMenuItems();
    applyCallButtons();
    hideCallUi();
    markLocateButtons();
  }
  function markLocateButtons() {
    const hide = state.settings.privacy.hideLocate !== false;
    for (const btn of document.querySelectorAll("button")) {
      if (!(btn instanceof HTMLElement)) continue;
      const label = `${btn.textContent || ""} ${btn.getAttribute("aria-label") || ""} ${btn.title || ""}`;
      if (/locate me|locate my area/i.test(label)) {
        btn.classList.toggle("ba-locate-hidden", hide);
      }
    }
  }
  function isCallControlText(text) {
    const value = String(text || "").replace(/\s+/g, " ").trim();
    return /(?:^|\b)(?:(?:start|join|answer|leave|end)\s+(?:(?:voice|video)\s+)?call|(?:voice|video)\s+call)\b|voice lounge|chat group call/i.test(value);
  }
  function removeCallMenuItems() {
    const calls = state.settings.privacy.calls;
    if (!calls.disable) {
      for (const item of document.querySelectorAll("[data-ba-call-disabled]")) {
        if (!(item instanceof HTMLElement)) continue;
        item.disabled = false;
        item.style.display = item.dataset.baCallDisplay || "";
        delete item.dataset.baCallDisplay;
        delete item.dataset.baCallDisabled;
      }
      return;
    }
    for (const label of document.querySelectorAll(".ag-ctx-item-label")) {
      if (!isCallControlText(label.textContent)) continue;
      const item = label.closest(".ag-ctx-item");
      if (!item) continue;
      item.disabled = true;
      item.dataset.baCallDisabled = "1";
      if (calls.hideUi) {
        if (item.dataset.baCallDisplay === void 0) item.dataset.baCallDisplay = item.style.display;
        item.style.display = "none";
      }
    }
  }
  function hideCallUi() {
    const calls = state.settings.privacy.calls;
    if (!calls.disable || !calls.hideUi) {
      for (const el of document.querySelectorAll("[data-ba-call-ui-hidden]")) {
        el.style.display = el.dataset.baCallDisplay || "";
        delete el.dataset.baCallDisplay;
        delete el.dataset.baCallUiHidden;
      }
      return;
    }
    for (const el of document.querySelectorAll(
      '[class*="ag-call-"], [class*="ag-geo-call-"], [class*="ag-srv-voice-"], [class*="ag-srv-discord-voice-"]'
    )) {
      if (!(el instanceof HTMLElement)) continue;
      if (el.closest(".ag-settings-modal, .ba-better-overlay, .ba-about-overlay")) continue;
      if (el.dataset.baCallDisplay === void 0) el.dataset.baCallDisplay = el.style.display;
      el.style.display = "none";
      el.dataset.baCallUiHidden = "1";
    }
    for (const section2 of document.querySelectorAll(".ag-sheet-section")) {
      const title = section2.querySelector(".ag-sheet-section-title")?.textContent || "";
      if (!section2.querySelector(".ag-sheet-call-card") && !/group call|voice call|video call/i.test(title)) continue;
      if (section2.dataset.baCallDisplay === void 0) section2.dataset.baCallDisplay = section2.style.display;
      section2.style.display = "none";
      section2.dataset.baCallUiHidden = "1";
    }
  }
  function applyCallButtons() {
    const calls = state.settings.privacy.calls;
    const blocked = !!calls.disable;
    for (const btn of document.querySelectorAll("button")) {
      if (btn.closest(".ag-settings-modal")) continue;
      const text = `${btn.textContent || ""} ${btn.getAttribute("aria-label") || ""} ${btn.title || ""}`.replace(/\s+/g, " ").trim();
      if (!isCallControlText(text)) continue;
      if (blocked) {
        btn.disabled = true;
        btn.dataset.baCallDisabled = "1";
        btn.classList.add("ba-call-disabled");
      } else if (btn.dataset.baCallDisabled === "1") {
        btn.disabled = false;
        delete btn.dataset.baCallDisabled;
        btn.classList.remove("ba-call-disabled");
      }
      if (blocked) {
        if (calls.hideUi) {
          if (btn.dataset.baCallDisplay === void 0) btn.dataset.baCallDisplay = btn.style.display;
          btn.style.display = "none";
          btn.dataset.baCallHidden = "1";
        }
      } else if (btn.dataset.baCallHidden === "1") {
        btn.style.display = btn.dataset.baCallDisplay || "";
        delete btn.dataset.baCallDisplay;
        delete btn.dataset.baCallHidden;
      }
    }
  }
  function blockCallControlClick(event) {
    if (!state.enabledReady || state.settings.enabled === false) return;
    if (!state.settings.privacy.calls.disable) return;
    const target = event.target;
    if (!(target instanceof Element)) return;
    const control = target.closest("button, a, [role='button'], .ag-ctx-item, .ag-sheet-action-btn");
    if (!control) return;
    const text = `${control.textContent || ""} ${control.getAttribute("aria-label") || ""} ${control.title || ""}`;
    if (!isCallControlText(text)) return;
    event.preventDefault();
    event.stopImmediatePropagation();
  }
  document.addEventListener("click", blockCallControlClick, true);
  document.addEventListener("pointerdown", blockCallControlClick, true);
  var CHECK_ICON = '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg>';
  var PREVIEW_MESSAGE = "The sky above the port was the color of television, tuned to a dead channel.";
  function themeCardHtml(theme) {
    const [bg, surface, accent] = themeSwatch(theme);
    const active = state.settings.theme.preset === theme.id;
    return `<button type="button" class="ag-set-theme-card${active ? " active" : ""}" data-ba-glub-theme="${theme.id}" aria-pressed="${active ? "true" : "false"}">
    <div class="ag-set-theme-swatch" style="background-color:${bg};">
      <span class="ag-set-swatch-rail" style="background-color:${surface};">
        <span class="ag-set-swatch-pill" style="background-color:${accent};"></span>
        <span class="ag-set-swatch-line" style="background-color:${surface};"></span>
      </span>
      <span class="ag-set-swatch-stream">
        <span class="ag-set-swatch-row" style="background-color:${surface};"></span>
        <span class="ag-set-swatch-row short" style="background-color:${surface};"></span>
      </span>
    </div>
    <div class="ag-set-theme-info">
      <span class="ag-set-theme-name">${h(theme.label)}</span>
      <span class="ag-set-theme-tag">${h(theme.description)}</span>
    </div>
    ${active ? `<span class="ag-set-theme-check" aria-hidden="true">${CHECK_ICON}</span>` : ""}
  </button>`;
  }
  function glubThemeGroupHtml() {
    return `<div class="ag-set-group ba-glub-theme-group" data-ba-settings-group="themes">
    <span class="ag-set-label">Glub.chat themes</span>
    <div class="ag-set-theme-grid ba-glub-theme-grid" role="group" aria-label="Choose a Glub.chat theme">
      ${GLUB_THEMES.map(themeCardHtml).join("")}
    </div>
  </div>`;
  }
  function customCssGroupHtml() {
    return `<div class="ag-set-group ba-glub-css-group" data-ba-settings-group="css">
    <div class="ba-set-label-row"><span class="ag-set-label">Better Agnostr custom CSS</span><button type="button" class="ba-set-link" data-ba-settings-action="reset-css">clear</button></div>
    <textarea class="ag-input ba-set-css" data-ba-setting="theme.customCss" aria-label="Better Agnostr custom CSS" spellcheck="false" rows="4" placeholder="html:root { --accent: #ff4ecd; }">${h(state.settings.theme.customCss)}</textarea>
    <div class="ba-set-note">Injected after the selected theme. Use html:root for variable overrides.</div>
  </div>`;
  }
  function rainbowStyleGroupHtml() {
    const glub = state.settings.studio.rainbowStyle !== "bright";
    return `<div class="ag-set-group" data-ba-settings-group="rainbow">
    <label class="ag-set-toggle-card ba-set-toggle">
      <div class="ag-set-toggle-copy">
        <span class="ag-set-toggle-title">Glub rainbow</span>
        <span class="ag-set-toggle-desc">Use glub.chat's rainbow palette and motion; off switches to the bright rainbow</span>
      </div>
      <input class="ag-switch" type="checkbox" data-ba-rainbow-toggle${glub ? " checked" : ""}>
    </label>
  </div>`;
  }
  function baToggle(path, title, desc = "") {
    const checked = !!getPath(state.settings, path);
    return `<label class="ag-set-toggle-card ba-set-toggle">
    <div class="ag-set-toggle-copy">
      <span class="ag-set-toggle-title">${h(title)}</span>
      ${desc ? `<span class="ag-set-toggle-desc">${h(desc)}</span>` : ""}
    </div>
    <input class="ag-switch" type="checkbox" data-ba-setting="${path}"${checked ? " checked" : ""}>
  </label>`;
  }
  function interfaceGroupHtml() {
    return `<div class="ag-set-group" data-ba-settings-group="interface">
    ${baToggle("appearance.hideNotificationButton", "Hide notification button", "Remove the Alerts button from the rail and mobile tab bar")}
  </div>`;
  }
  function betterSettingsPaneHtml() {
    const tabs = [
      ["line", "Line"],
      ["client", "Client"]
    ];
    return `<div class="ba-settings-shell" data-ba-better-pane="1">
    <div class="ba-set-tabs" role="tablist" aria-label="Better Agnostr sections">
      ${tabs.map(([id, label]) => `<button type="button" class="ba-set-tab${state.betterTab === id ? " is-active" : ""}" data-ba-better-tab="${id}" id="ba-tab-${id}" role="tab" aria-selected="${state.betterTab === id ? "true" : "false"}" aria-controls="ba-tabpanel-${id}" tabindex="${state.betterTab === id ? "0" : "-1"}">${label}</button>`).join("")}
    </div>
    <div class="ba-set-content" data-ba-better-content role="tabpanel" id="ba-tabpanel-${state.betterTab}" aria-labelledby="ba-tab-${state.betterTab}"></div>
  </div>`;
  }
  function betterLineHtml() {
    const template = state.settings.studio.template;
    return `
    <div class="ba-set-preview" data-ba-settings-preview></div>

    <div class="ag-set-group">
      ${baToggle("studio.enabled", "Apply line & flair", "Outgoing chat messages")}
      ${baToggle("studio.applyRich", "Convert & codes", "Keep plaintext in content")}
    </div>

    <div class="ag-set-group">
      <div class="ba-set-label-row">
        <span class="ag-set-label">Line format</span>
        <span class="ba-set-count" data-ba-template-count></span>
      </div>
      <input class="ag-input ba-set-template" data-ba-setting="studio.template" aria-label="Line format template" maxlength="200" spellcheck="false" autocomplete="off" value="${h(template)}" placeholder="&l{name}&7{tag}&f: {msg}">
      <div class="ba-set-chips">
        <button type="button" class="ba-set-chip" data-ba-template-placeholder="{name}">{name}</button>
        <button type="button" class="ba-set-chip" data-ba-template-placeholder="{tag}">{tag}</button>
        <button type="button" class="ba-set-chip" data-ba-template-placeholder="{msg}">{msg}</button>
      </div>
      <div class="ba-set-colors">
        ${Object.entries(COLORS).map(([code, color]) => `<button type="button" class="ba-set-swatch" data-ba-template-code="&${code}" title="&amp;${code}" style="background:${color}">${code}</button>`).join("")}
      </div>
      <div class="ba-set-tools">
        ${[["&l", "B", "bold"], ["&o", "I", "italic"], ["&n", "U", "underline"], ["&m", "S", "strike"], ["&k", "K", "obfuscate"], ["&g", "G", "rainbow"], ["&r", "R", "reset"]].map(([code, label, title]) => `<button type="button" class="ba-set-tool" data-ba-template-code="${code}" title="${title}">${label}</button>`).join("")}
      </div>
      <div class="ba-set-chips">
        ${TEMPLATE_PRESETS.map((p) => `<button type="button" class="ba-set-chip" data-ba-template-preset="${h(p.value)}">${h(p.label)}</button>`).join("")}
      </div>
    </div>

    <div class="ag-set-group">
      <span class="ag-set-label">Flair</span>
      <div class="ba-set-flairs">
        <button type="button" class="ba-set-flair${!state.settings.studio.flair ? " active" : ""}" data-ba-flair-choice="" aria-pressed="${!state.settings.studio.flair ? "true" : "false"}">none</button>
        ${FLAIRS2.map((f) => `<button type="button" class="ba-set-flair${state.settings.studio.flair === f.name ? " active" : ""}${f.gated ? " gated" : ""}" data-ba-flair-choice="${f.name}" aria-pressed="${state.settings.studio.flair === f.name ? "true" : "false"}" title="${h(f.description)}">${h(f.label)}</button>`).join("")}
      </div>
    </div>

    <div class="ag-set-group">
      ${baToggle("studio.showComposerToolbar", "Composer formatting bar")}
      ${baToggle("studio.renderInAgnostr", "Render flair in Agnostr")}
      ${baToggle("studio.renderRichInAgnostr", "Render rich text in Agnostr")}
      ${baToggle("studio.reduceMotion", "Reduce motion")}
    </div>`;
  }
  function betterClientHtml() {
    const policies = state.settings.client.policies;
    return `
    <div class="ag-set-group">
      <span class="ag-set-label">Client tag</span>
      <input class="ag-input" data-ba-setting="client.name" aria-label="Client tag" maxlength="64" spellcheck="false" autocomplete="off" value="${h(state.settings.client.name)}">
      <div class="ba-set-chips">
        ${CLIENT_PRESETS.map((name) => `<button type="button" class="ba-set-chip" data-ba-client-preset="${h(name)}">${h(name)}</button>`).join("")}
      </div>
    </div>
    <div class="ag-set-group">
      <span class="ag-set-label">Per event type</span>
      <div class="ba-set-policies">
        ${KIND_GROUPS.map((g) => `<div class="ba-set-policy">
          <span>${h(g.label)}</span>
          <select class="ag-input ba-set-select" data-ba-client-policy="${g.id}" aria-label="${h(g.label)} client policy">
            ${KIND_POLICIES.map((p) => `<option value="${p}"${policies[g.id] === p ? " selected" : ""}>${p}</option>`).join("")}
          </select>
        </div>`).join("")}
      </div>
      <div class="ba-set-note">Applied when an event is signed.</div>
    </div>`;
  }
  function renderBetterTabContent(modal) {
    const content = modal.querySelector("[data-ba-better-content]");
    if (!content) return;
    if (state.betterTab === "client") content.innerHTML = betterClientHtml();
    else content.innerHTML = betterLineHtml();
    content.id = `ba-tabpanel-${state.betterTab}`;
    content.setAttribute("aria-labelledby", `ba-tab-${state.betterTab}`);
    for (const tab of modal.querySelectorAll("[data-ba-better-tab]")) {
      const active = tab.getAttribute("data-ba-better-tab") === state.betterTab;
      tab.classList.toggle("is-active", active);
      tab.setAttribute("aria-selected", active ? "true" : "false");
      tab.tabIndex = active ? 0 : -1;
    }
    state.betterPreviewSig = "";
    if (state.betterTab === "line") renderBetterPreview(modal);
  }
  function previewAvatarSrc() {
    const img = document.querySelector(".ag-conv-footer .ag-profile-avatar, .ag-profile-avatar");
    if (img && img.tagName === "IMG" && img.getAttribute("src")) return img.getAttribute("src");
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40"><rect width="40" height="40" rx="10" fill="hsl(258,30%,14%)"/><rect x=".75" y=".75" width="38.5" height="38.5" rx="9.25" fill="none" stroke="hsla(300,75%,60%,.32)"/><rect x="8" y="8" width="6" height="6" rx="1.5" fill="hsl(258,82%,60%)"/><rect x="17" y="8" width="6" height="6" rx="1.5" fill="hsl(300,82%,66%)"/><rect x="26" y="8" width="6" height="6" rx="1.5" fill="hsl(258,82%,60%)"/><rect x="8" y="17" width="6" height="6" rx="1.5" fill="hsl(300,82%,66%)"/><rect x="17" y="17" width="6" height="6" rx="1.5" fill="hsl(258,82%,60%)"/><rect x="26" y="17" width="6" height="6" rx="1.5" fill="hsl(300,82%,66%)"/><rect x="8" y="26" width="6" height="6" rx="1.5" fill="hsl(258,82%,60%)"/><rect x="17" y="26" width="6" height="6" rx="1.5" fill="hsl(300,82%,66%)"/><rect x="26" y="26" width="6" height="6" rx="1.5" fill="hsl(258,82%,60%)"/></svg>`;
    return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
  }
  function previewRowHtml({ name, tag, avatar, line, flair, reduceMotion = false }) {
    const flairClasses = flair ? flairClass(flair) : "";
    const flairStyle = flair ? flairStyleVars(flairVars(flair)) : "";
    const fx = flair && flairHasFx(flair) ? `<span class="flairFx" aria-hidden="true">${flairFxInner(flair)}</span>` : "";
    const overlay = flair ? flairOverlayInner(flair) : "";
    return `<div class="ba-set-preview-row ${flairClasses}${reduceMotion ? " flairQuiet" : ""}" style="${flairStyle}">
      <img class="ba-set-preview-avatar" src="${h(avatar)}" alt="">
      <span class="ba-set-preview-main">
        <span class="ba-set-preview-meta"><span class="ba-set-preview-name">${h(name)}</span><span class="ba-set-preview-tag">#${h(tag)}</span></span>
        <span class="ba-set-preview-line">${line}</span>
      </span>
      ${fx}${overlay}
    </div>`;
  }
  function previewBlockHtml(options) {
    return `<div class="ba-set-preview">${previewRowHtml(options)}</div>`;
  }
  function renderBetterPreview(modal) {
    const el = modal.querySelector("[data-ba-settings-preview]");
    if (!el) return;
    const s = state.settings;
    const template = s.studio.enabled ? s.studio.template : "";
    const flair = s.studio.enabled ? s.studio.flair : "";
    const name = state.status?.nickname || "you";
    const tag = (state.status?.pubkey || "a1b2c3d4").slice(-4);
    const msg = PREVIEW_MESSAGE;
    const avatar = previewAvatarSrc();
    const sig = JSON.stringify([template, flair, msg, name, tag, avatar, s.studio.enabled, s.studio.reduceMotion, s.studio.rainbowStyle]);
    if (sig === state.betterPreviewSig) return;
    state.betterPreviewSig = sig;
    const msgHtml = renderFormatHtml(msg);
    let line;
    try {
      line = renderLineHtml(template, { name, tag, msgHtml, msgText: msg });
    } catch {
      line = h(msg);
    }
    el.innerHTML = previewBlockHtml({
      name,
      tag,
      avatar,
      line: line || h(msg),
      flair,
      reduceMotion: s.studio.reduceMotion
    });
    const count = modal.querySelector("[data-ba-template-count]");
    if (count) count.textContent = `${template.length}/200${template.includes("{msg}") ? "" : " \xB7 {msg} appended"}`;
  }
  function syncBetterSettings(modal) {
    for (const el of modal.querySelectorAll("[data-ba-setting]")) {
      const path = el.getAttribute("data-ba-setting");
      const value = getPath(state.settings, path);
      if (el === document.activeElement) continue;
      if (el.type === "checkbox") el.checked = !!value;
      else el.value = value ?? "";
    }
    for (const el of modal.querySelectorAll("[data-ba-client-policy]")) {
      const group = el.getAttribute("data-ba-client-policy");
      el.value = state.settings.client.policies[group] || "leave";
    }
    for (const el of modal.querySelectorAll("[data-ba-strip-tag]")) {
      el.checked = state.settings.privacy.stripTags.includes(el.getAttribute("data-ba-strip-tag"));
    }
    for (const el of modal.querySelectorAll("[data-ba-review-group]")) {
      el.checked = state.settings.privacy.reviewGroups.includes(el.getAttribute("data-ba-review-group"));
    }
    for (const el of modal.querySelectorAll("[data-ba-flair-choice]")) {
      const active = (el.getAttribute("data-ba-flair-choice") || "") === (state.settings.studio.flair || "");
      el.classList.toggle("active", active);
      el.setAttribute("aria-pressed", active ? "true" : "false");
    }
    const count = modal.querySelector("[data-ba-template-count]");
    if (count) {
      const template = state.settings.studio.template;
      count.textContent = `${template.length}/200${template.includes("{msg}") ? "" : " \xB7 {msg} appended"}`;
    }
    if (state.betterTab === "line") renderBetterPreview(modal);
  }
  function scheduleSettingsSync() {
    if (state.settingsTimer !== null) return;
    state.settingsTimer = window.setTimeout(() => {
      state.settingsTimer = null;
      syncSettingsIntegration();
    }, 70);
  }
  function ensureBetterNav(modal) {
    const navList = modal.querySelector(".ag-set-nav-list");
    if (!navList) return null;
    let nav = navList.querySelector("[data-ba-settings-nav]");
    if (nav) return nav;
    const appearance = [...navList.querySelectorAll(".ag-set-nav-item")].find((b2) => b2.textContent.includes("Appearance"));
    const source = appearance || navList.querySelector(".ag-set-nav-item");
    if (!source) return null;
    nav = source.cloneNode(true);
    nav.classList.remove("active");
    nav.removeAttribute("aria-current");
    nav.removeAttribute("id");
    nav.removeAttribute("aria-controls");
    nav.removeAttribute("aria-describedby");
    nav.setAttribute("data-ba-settings-nav", "1");
    const icon = nav.querySelector(".ag-set-nav-icon");
    if (icon) {
      icon.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3Z"/><path d="M19 17l.8 2.2L22 20l-2.2.8L19 23l-.8-2.2L16 20l2.2-.8L19 17Z"/></svg>';
    }
    const label = nav.querySelector(".ag-set-nav-label");
    if (label) label.textContent = "Better Agnostr";
    const sub = nav.querySelector(".ag-set-nav-sub");
    if (sub) sub.textContent = "Line, flair & client";
    nav.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      state.settingsBetterActive = true;
      state.aboutActive = false;
      syncSettingsIntegration();
    });
    source.after(nav);
    return nav;
  }
  function nativeSettingsNav(modal) {
    const items = [
      ...modal.querySelectorAll(
        ".ag-set-nav-list .ag-set-nav-item:not([data-ba-settings-nav]):not([data-ba-about-nav])"
      )
    ];
    return items.find((item) => !item.classList.contains("active")) || items[0] || null;
  }
  function enterSettingsMobileDetail(modal) {
    if (!window.matchMedia?.("(max-width: 867px)")?.matches) return false;
    if (!modal.classList.contains("mobile-menu")) return false;
    if (modal.dataset.baMobileEntering === "1") return true;
    const native = nativeSettingsNav(modal);
    if (!native) return false;
    const better = state.settingsBetterActive;
    const about = state.aboutActive;
    modal.dataset.baMobileEntering = "1";
    native.click();
    let tries = 0;
    const fail = () => {
      state.settingsBetterActive = false;
      state.aboutActive = false;
      delete modal.dataset.baMobileEntering;
      modal.classList.remove("ba-better-active", "ba-about-active");
      scheduleSettingsSync();
    };
    const check = () => {
      if (!modal.isConnected) {
        fail();
        return;
      }
      if (!modal.classList.contains("mobile-menu")) {
        delete modal.dataset.baMobileEntering;
        state.settingsBetterActive = better;
        state.aboutActive = about;
        syncSettingsIntegration();
        return;
      }
      tries += 1;
      if (tries < 30) window.setTimeout(check, 30);
      else fail();
    };
    window.setTimeout(check, 20);
    return true;
  }
  function ensureAboutNav(modal) {
    const navList = modal.querySelector(".ag-set-nav-list");
    if (!navList) return null;
    let nav = navList.querySelector("[data-ba-about-nav]");
    if (nav) {
      if (nav.nextElementSibling) navList.appendChild(nav);
      return nav;
    }
    const better = navList.querySelector("[data-ba-settings-nav]");
    const source = better || navList.querySelector(".ag-set-nav-item");
    if (!source) return null;
    nav = source.cloneNode(true);
    nav.classList.remove("active");
    nav.removeAttribute("aria-current");
    nav.removeAttribute("id");
    nav.removeAttribute("aria-controls");
    nav.removeAttribute("aria-describedby");
    nav.removeAttribute("data-ba-settings-nav");
    nav.setAttribute("data-ba-about-nav", "1");
    const icon = nav.querySelector(".ag-set-nav-icon");
    if (icon) {
      icon.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><path d="M12 16v-4"></path><path d="M12 8h.01"></path></svg>';
    }
    const label = nav.querySelector(".ag-set-nav-label");
    if (label) label.textContent = "About";
    const sub = nav.querySelector(".ag-set-nav-sub");
    if (sub) sub.textContent = "Version & credits";
    nav.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      state.aboutActive = true;
      state.settingsBetterActive = false;
      syncSettingsIntegration();
    });
    navList.appendChild(nav);
    return nav;
  }
  function agnostrBuildId() {
    const script = [...document.querySelectorAll("script[src]")].find((s) => /\/assets\/index-[^/]+\.js/.test(s.getAttribute("src") || ""));
    const src = script?.getAttribute("src") || "";
    const match = src.match(/index-([A-Za-z0-9_-]+)\.js/);
    return match ? match[1] : "";
  }
  function openProfileByNpub(npub) {
    const value = String(npub || "").trim();
    if (!value) return;
    const modal = document.querySelector(".ag-settings-modal");
    modal?.querySelector(".ag-sheet-close-btn")?.click();
    window.setTimeout(() => {
      try {
        location.hash = `dm=${value}`;
      } catch {
      }
      let tries = 0;
      const open = () => {
        const header = document.querySelector(".ag-header");
        const identity = document.querySelector(".ag-header-identity");
        const text = header?.innerText || "";
        if (identity && /encrypted dm|direct message|dm/i.test(text)) {
          identity.click();
          return;
        }
        tries += 1;
        if (tries < 40) window.setTimeout(open, 120);
        else toast("warning", "Profile unavailable", "Could not open the profile for that key.");
      };
      window.setTimeout(open, 450);
    }, 120);
  }
  function aboutPaneHtml() {
    const manifest = api.runtime.getManifest?.() || {};
    const version = manifest.version || VERSION;
    const build = agnostrBuildId();
    const appVersion = build ? `web build ${build}` : "web";
    return `<div class="ba-about-pane">
    <img class="ba-about-logo" src="https://agnostr.com/icon.svg" alt="Agnostr">
    <div class="ba-about-name">Agnostr</div>
    <div class="ba-about-version">${h(appVersion)}</div>
    <div class="ba-about-with">with Better Agnostr version ${h(version)}</div>
    <div class="ba-about-credits">
      <div class="ba-about-credit">
        <span class="ba-about-credit-name">Agnostr</span>
        <span class="ba-about-credit-line">by hinsley</span>
        <a href="https://github.com/hinsley/Agnostr" target="_blank" rel="noopener noreferrer">github.com/hinsley/Agnostr</a>
      </div>
      <div class="ba-about-credit">
        <span class="ba-about-credit-name">Better Agnostr</span>
        <span class="ba-about-credit-line">by <a class="ba-about-angel" href="#dm=npub1t9kl0mq3f8pesupc9nqndpq389af4czsk7nnpvr5g6kg9hyenxvssjs0yk" data-ba-angel-link data-npub="npub1t9kl0mq3f8pesupc9nqndpq389af4czsk7nnpvr5g6kg9hyenxvssjs0yk">Angel</a></span>
        <a href="https://github.com/angeltrue/BetterAgnostr" target="_blank" rel="noopener noreferrer">github.com/angeltrue/BetterAgnostr</a>
      </div>
    </div>
  </div>`;
  }
  function openExternalLink(href) {
    const link = document.createElement("a");
    link.href = href;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    link.style.display = "none";
    document.body.appendChild(link);
    link.click();
    link.remove();
  }
  function bindAboutLinks(overlay) {
    if (overlay.dataset.baLinksBound === "1") return;
    overlay.dataset.baLinksBound = "1";
    overlay.addEventListener("click", (event) => {
      const target = event.target;
      if (!(target instanceof Element)) return;
      const link = target.closest("a[href]");
      if (!link || !overlay.contains(link)) return;
      const npub = link.getAttribute("data-npub");
      if (npub) {
        event.preventDefault();
        event.stopPropagation();
        openProfileByNpub(npub);
        return;
      }
      let url;
      try {
        url = new URL(link.getAttribute("href"), location.href);
      } catch {
        return;
      }
      if (url.protocol !== "http:" && url.protocol !== "https:") return;
      event.preventDefault();
      event.stopPropagation();
      openExternalLink(url.href);
    }, true);
  }
  function renderAboutPane(modal) {
    const body = modal.querySelector(".ag-set-detail-body");
    if (!body) return;
    let overlay = body.querySelector("[data-ba-about-overlay]");
    if (!overlay) {
      overlay = document.createElement("div");
      overlay.className = "ba-about-overlay";
      overlay.setAttribute("data-ba-about-overlay", "1");
      body.appendChild(overlay);
    }
    bindAboutLinks(overlay);
    const manifest = api.runtime.getManifest?.() || {};
    const signature = `${manifest.version || ""}|${agnostrBuildId()}`;
    if (overlay.dataset.baAboutSignature !== signature || !overlay.querySelector(".ba-about-pane")) {
      overlay.innerHTML = aboutPaneHtml();
      overlay.dataset.baAboutSignature = signature;
    }
    overlay.hidden = false;
    modal.classList.add("ba-about-active");
    modal.classList.remove("ba-better-active");
    const better = modal.querySelector("[data-ba-better-overlay]");
    if (better) better.hidden = true;
  }
  function hideAboutPane(modal) {
    modal.classList.remove("ba-about-active");
    const overlay = modal.querySelector("[data-ba-about-overlay]");
    if (overlay) overlay.hidden = true;
  }
  function ensureThemeCheck(card, active) {
    if (!card.hasAttribute("data-ba-glub-theme")) return;
    let check = card.querySelector(".ag-set-theme-check");
    if (active && !check) {
      check = document.createElement("span");
      check.className = "ag-set-theme-check";
      check.setAttribute("aria-hidden", "true");
      check.innerHTML = CHECK_ICON;
      card.appendChild(check);
    } else if (!active && check) {
      check.remove();
    }
  }
  function syncThemeCards(modal) {
    const preset = state.settings.theme.preset;
    for (const card of modal.querySelectorAll(".ag-set-theme-card")) {
      const id = card.getAttribute("data-ba-glub-theme");
      if (id) {
        const active = preset === id;
        card.classList.toggle("active", active);
        card.setAttribute("aria-pressed", active ? "true" : "false");
        ensureThemeCheck(card, active);
      } else if (preset !== "agnostr") {
        if (card.classList.contains("active")) state.agnostrActiveThemeCard = card;
        card.classList.remove("active");
        card.setAttribute("aria-pressed", "false");
        ensureThemeCheck(card, false);
      }
    }
    if (preset === "agnostr" && state.agnostrActiveThemeCard?.isConnected) {
      const card = state.agnostrActiveThemeCard;
      card.classList.add("active");
      card.setAttribute("aria-pressed", "true");
      ensureThemeCheck(card, true);
    }
  }
  function syncSettingsFields(modal) {
    for (const el of modal.querySelectorAll("[data-ba-setting]")) {
      const path = el.getAttribute("data-ba-setting");
      const value = getPath(state.settings, path);
      if (el === document.activeElement) continue;
      if (el.type === "checkbox") el.checked = !!value;
      else el.value = value ?? "";
    }
    for (const el of modal.querySelectorAll("[data-ba-setting-toggle]")) {
      const value = !!getPath(state.settings, el.getAttribute("data-ba-setting-toggle"));
      el.classList.toggle("is-on", value);
    }
    for (const el of modal.querySelectorAll("[data-ba-rainbow-toggle]")) {
      el.checked = state.settings.studio.rainbowStyle !== "bright";
    }
    syncThemeCards(modal);
    const status = modal.querySelector("[data-ba-status]");
    if (status) {
      const st = state.status || {};
      const signer = st.signerHooked ? `signer: ${st.signMode || "attached"}` : st.nip07Patched ? "rewriter: NIP-07" : "signer: waiting";
      status.textContent = `${signer} \xB7 ${state.events.size} events captured \xB7 glub ${effectiveBuild(state.settings) || "build missing"}`;
    }
    const build = modal.querySelector("[data-ba-build-status]");
    if (build) {
      const b2 = effectiveBuild(state.settings);
      build.textContent = b2 ? `Build: ${b2}${state.settings.glub.manualBuild ? " (manual)" : " (auto)"}` : "Build: not synced";
    }
  }
  function optionsHtml(list, selected) {
    return list.map((item) => `<option value="${h(item.id)}"${item.id === selected ? " selected" : ""}>${h(item.label)}</option>`).join("");
  }
  function nativePrivacyHtml() {
    const strip = new Set(state.settings.privacy.stripTags);
    const review = new Set(state.settings.privacy.reviewGroups);
    return `<div class="ag-set-group ba-native-group" data-ba-native="privacy">
    <span class="ag-set-label">Better Agnostr</span>
    ${baToggle("privacy.hideLocate", "Hide Locate Me")}
    ${baToggle("privacy.hideTimestamps", "Hide timestamps", "Hide per-message clock times in chat")}
    ${baToggle("privacy.omitTeleport", "Omit teleport tag")}
    ${baToggle("privacy.removeVoiceMemo", "Remove voice memo")}
    ${baToggle("privacy.stripTracking", "Strip tracking parameters")}
    ${baToggle("privacy.reviewEnabled", "Review before signing")}
    ${baToggle("privacy.calls.disable", "Block calls")}
    ${baToggle("privacy.calls.hideUi", "Hide call buttons")}
    ${baToggle("privacy.calls.blockSignals", "Block call signals")}
    ${baToggle("privacy.calls.blockOutgoing", "Block outgoing calls")}
    <details class="ba-native-details">
      <summary>Tags to remove</summary>
      <div class="ba-native-checks">${STRIPPABLE_TAGS.map((t) => `<label class="ba-native-check"><input type="checkbox" data-ba-strip-tag="${h(t.name)}"${strip.has(t.name) ? " checked" : ""}><span>${h(t.label)}</span></label>`).join("")}</div>
    </details>
    <details class="ba-native-details">
      <summary>Review types</summary>
      <div class="ba-native-checks">${KIND_GROUPS.map((g) => `<label class="ba-native-check"><input type="checkbox" data-ba-review-group="${h(g.id)}"${review.has(g.id) ? " checked" : ""}><span>${h(g.label)}</span></label>`).join("")}</div>
    </details>
  </div>`;
  }
  function injectNativePrivacy(modal) {
    const stack = modal.querySelector(".ag-set-pane-stack") || modal.querySelector(".ag-set-detail-body");
    if (!stack || stack.querySelector("[data-ba-native='privacy']")) return;
    const holder = document.createElement("div");
    holder.innerHTML = nativePrivacyHtml();
    const group = holder.firstElementChild;
    const broadcast = [...stack.querySelectorAll(".ag-set-toggle-card, .ag-set-notif-row")].find(
      (el) => /broadcast agnostr client|share agnostr client tag/i.test(el.textContent || "")
    );
    if (broadcast) {
      broadcast.style.display = "none";
      broadcast.setAttribute("data-ba-hidden-native-broadcast", "1");
      broadcast.after(group);
    } else {
      stack.prepend(group);
    }
  }
  function clearNativePrivacy(modal) {
    for (const el of modal.querySelectorAll("[data-ba-native='privacy']")) el.remove();
  }
  function soundsSectionHtml() {
    const sounds = state.settings.sounds;
    const events = sounds.events || {};
    const toggleRow = (title, desc, path, checked) => `
    <label class="ag-set-notif-row">
      <div class="ag-set-notif-row-copy">
        <span class="ag-set-notif-row-title">${h(title)}</span>
        <span class="ag-set-notif-row-desc">${h(desc)}</span>
      </div>
      <input class="ag-switch" type="checkbox" data-ba-setting="${h(path)}"${checked ? " checked" : ""}>
    </label>`;
    const selectRow = (title, desc, path, list, value) => `
    <div class="ag-set-notif-row">
      <div class="ag-set-notif-row-copy">
        <span class="ag-set-notif-row-title">${h(title)}</span>
        <span class="ag-set-notif-row-desc">${h(desc)}</span>
      </div>
      <select class="ag-input ba-set-select ba-notif-select" data-ba-setting="${h(path)}" aria-label="${h(title)}">${optionsHtml(list, value)}</select>
    </div>`;
    const rangeRow = (title, desc, path, value) => `
    <div class="ag-set-notif-row">
      <div class="ag-set-notif-row-copy">
        <span class="ag-set-notif-row-title">${h(title)}</span>
        <span class="ag-set-notif-row-desc">${h(desc)}</span>
      </div>
      <input class="ba-set-range ba-notif-range" type="range" min="0" max="1" step="0.05" data-ba-setting="${h(path)}" aria-label="${h(title)}" value="${h(String(value))}">
    </div>`;
    return `<section class="ag-set-section" data-ba-native="sounds">
      <div class="ag-set-section-head">
        <div class="ag-set-section-copy">
          <div class="ag-set-section-title-row"><h3 class="ag-set-section-title">Better Agnostr sounds</h3></div>
          <p class="ag-set-section-desc">These chimes and UI clicks replace Agnostr's native message chime and sound effects. Agnostr notifications, ringtone, vibration, and lock-screen previews above remain in control.</p>
        </div>
      </div>
      <div class="ag-set-card-list">
        ${toggleRow("Message chimes", "Play the selected chime for new alerts", "sounds.messageEnabled", sounds.messageEnabled !== false)}
        ${selectRow("Message chime", "Sound for new messages", "sounds.message", MESSAGE_SOUNDS, sounds.message)}
        ${rangeRow("Volume", "Chime and interface-click volume", "sounds.volume", sounds.volume)}
        ${toggleRow("UI clicks", "Play a sound for buttons and controls", "sounds.clickEnabled", sounds.clickEnabled !== false)}
        ${selectRow("UI click", "Sound for interface clicks", "sounds.click", CLICK_SOUNDS, sounds.click)}
      </div>
      <div class="ba-native-actions">
        <button type="button" class="ag-btn ag-btn-secondary ag-btn-sm" data-ba-settings-action="preview-message-sound">Test chime</button>
        <button type="button" class="ag-btn ag-btn-secondary ag-btn-sm" data-ba-settings-action="preview-click-sound">Test click</button>
      </div>
    </section>
    <section class="ag-set-section" data-ba-native="chime-triggers">
      <div class="ag-set-section-head">
        <div class="ag-set-section-copy">
          <div class="ag-set-section-title-row"><h3 class="ag-set-section-title">Chime triggers</h3></div>
          <p class="ag-set-section-desc">Choose which incoming activity plays a Better Agnostr sound.</p>
        </div>
      </div>
      <div class="ag-set-card-list">
        ${toggleRow("Direct messages", "Encrypted one-to-one chats", "sounds.events.dm", events.dm !== false)}
        ${toggleRow("Chat & rooms", "Chat and group channel messages", "sounds.events.chat", events.chat !== false)}
        ${toggleRow("Mentions only", "Limit chat sounds to @mentions and direct replies", "sounds.events.mentionOnly", events.mentionOnly === true)}
        ${toggleRow("Call invites", "Incoming call signals", "sounds.events.calls", events.calls === true)}
      </div>
    </section>`;
  }
  function injectNativeSounds(modal) {
    const stack = modal.querySelector(".ag-set-pane-stack") || modal.querySelector(".ag-set-detail-body");
    if (!stack) return;
    const nativeChime = [...modal.querySelectorAll(".ag-set-notif-row")].find((el) => {
      if (el.closest("[data-ba-native]")) return false;
      const text = `${el.querySelector(".ag-set-notif-row-title")?.textContent || ""} ${el.textContent || ""}`;
      return /message\s+chimes?|message\s+sounds?/i.test(text);
    });
    if (nativeChime) {
      if (nativeChime.dataset.baChimeDisplay === void 0) nativeChime.dataset.baChimeDisplay = nativeChime.style.display;
      nativeChime.style.display = "none";
      nativeChime.setAttribute("data-ba-hidden-native-chime", "1");
    }
    if (stack.querySelector("[data-ba-native='sounds']")) return;
    const anchor = [...stack.querySelectorAll("section.ag-set-section")].find(
      (el) => /sounds?\s*(?:&|and)?\s*lock\s*screen|sound\s+effects/i.test(
        el.querySelector(".ag-set-section-title")?.textContent || ""
      )
    );
    const holder = document.createElement("div");
    holder.innerHTML = soundsSectionHtml();
    const nodes = [...holder.children];
    if (anchor) anchor.after(...nodes);
    else stack.append(...nodes);
  }
  function clearNativeSoundsOverride(modal) {
    const stack = modal.querySelector(".ag-set-pane-stack") || modal.querySelector(".ag-set-detail-body");
    if (!stack) return;
    for (const el of stack.querySelectorAll("[data-ba-native='sounds'], [data-ba-native='chime-triggers']")) el.remove();
    for (const el of stack.querySelectorAll("[data-ba-hidden-native-chime]")) {
      if (!(el instanceof HTMLElement)) continue;
      el.style.display = el.dataset.baChimeDisplay || "";
      delete el.dataset.baChimeDisplay;
      el.removeAttribute("data-ba-hidden-native-chime");
    }
  }
  function clearAppearanceExtras(modal) {
    for (const el of modal.querySelectorAll("[data-ba-hidden-native-audio]")) {
      if (!(el instanceof HTMLElement)) continue;
      el.style.display = el.dataset.baAudioDisplay || "";
      delete el.dataset.baAudioDisplay;
      el.removeAttribute("data-ba-hidden-native-audio");
    }
    for (const group of modal.querySelectorAll("[data-ba-settings-group]")) group.remove();
  }
  function injectAppearanceExtras(modal) {
    const stack = modal.querySelector(".ag-set-pane-stack") || modal.querySelector(".ag-set-detail-body");
    if (!stack) return;
    const audioSection = [...stack.querySelectorAll("section.ag-set-section")].find(
      (el) => el.querySelector(".ag-set-section-title")?.textContent?.trim() === "Audio"
    );
    if (audioSection) {
      if (audioSection.dataset.baAudioDisplay === void 0) audioSection.dataset.baAudioDisplay = audioSection.style.display;
      audioSection.style.display = "none";
      audioSection.setAttribute("data-ba-hidden-native-audio", "1");
    }
    const agnThemeGrid = [...modal.querySelectorAll(".ag-set-theme-grid")].find((g) => !g.classList.contains("ba-glub-theme-grid"));
    const anchor = agnThemeGrid?.closest("section.ag-set-section, .ag-set-group") || null;
    const holder = document.createElement("div");
    const ensureGroup = (id, html) => {
      let group = stack.querySelector(`[data-ba-settings-group='${id}']`);
      if (!group) {
        holder.innerHTML = html;
        group = holder.firstElementChild;
      }
      return group;
    };
    const themeGroup = ensureGroup("themes", glubThemeGroupHtml());
    const rainbowGroup = ensureGroup("rainbow", rainbowStyleGroupHtml());
    const interfaceGroup = ensureGroup("interface", interfaceGroupHtml());
    const cssGroup = ensureGroup("css", customCssGroupHtml());
    const fontGroup = ensureGroup("font", `<div class="ag-set-group" data-ba-settings-group="font">
        <span class="ag-set-label">Font</span>
        <div class="ba-set-field"><span>Family</span><select class="ag-input ba-set-select" data-ba-setting="font.family" aria-label="Font family">
          ${FONT_PRESETS.map((f) => `<option value="${f.id}"${state.settings.font.family === f.id ? " selected" : ""}>${h(f.label)}</option>`).join("")}
        </select></div>
        <div class="ba-set-field"><span>Custom family</span><input class="ag-input" data-ba-setting="font.customFamily" aria-label="Custom font family" maxlength="80" value="${h(state.settings.font.customFamily)}" placeholder="installed family name"></div>
        <div class="ba-set-field"><span>Custom URL</span><input class="ag-input" data-ba-setting="font.customUrl" aria-label="Custom font URL" maxlength="500" value="${h(state.settings.font.customUrl)}" placeholder="https://\u2026/font.woff2"></div>
        <div class="ba-set-note">IBM Plex, Atkinson Hyperlegible, Lexend, and readable serif families are bundled.</div>
      </div>`);
    const groups = [themeGroup, rainbowGroup, interfaceGroup, cssGroup, fontGroup];
    let previous = anchor;
    for (const group of groups) {
      if (!group) continue;
      if (previous) previous.after(group);
      else stack.append(group);
      previous = group;
    }
    syncSettingsFields(modal);
  }
  function shootStar(el, delay = 0) {
    if (typeof el.animate !== "function") return;
    const layer = el.parentElement;
    const row = layer?.closest(".ag-msg-row") || layer;
    if (!layer || !row) return;
    const line = row.querySelector(".ag-msg-rich") || row.querySelector(".ag-msg-content") || row;
    const layerRect = layer.getBoundingClientRect();
    const lineRect = line.getBoundingClientRect();
    const offsetX = Math.max(0, lineRect.left - layerRect.left);
    const offsetY = Math.max(0, lineRect.top - layerRect.top);
    const w = Math.max(60, layerRect.width - offsetX - 4);
    const h2 = Math.max(12, lineRect.height);
    const star = document.createElement("span");
    star.className = "ba-shooting-star";
    star.setAttribute("aria-hidden", "true");
    star.style.width = `${(28 + Math.random() * 46).toFixed(1)}px`;
    layer.appendChild(star);
    const startX = offsetX + 4 + Math.random() * Math.max(1, w * 0.86);
    const startY = offsetY + 3 + Math.random() * Math.max(1, h2 - 6);
    const travel = Math.max(50, Math.min(w - (startX - offsetX) - 8, 70 + Math.random() * 300));
    const angle = 5 + Math.random() * 14;
    const endX = startX + travel;
    const endY = Math.min(offsetY + h2 - 2, startY + travel * Math.tan(angle * Math.PI / 180) * 0.34);
    const rotation = `rotate(${angle.toFixed(1)}deg)`;
    const anim = star.animate(
      [
        { transform: `translate3d(${startX.toFixed(1)}px, ${startY.toFixed(1)}px, 0) ${rotation}`, opacity: 0 },
        { opacity: 0.98, offset: 0.16 },
        { opacity: 0.9, offset: 0.7 },
        { transform: `translate3d(${endX.toFixed(1)}px, ${endY.toFixed(1)}px, 0) ${rotation}`, opacity: 0 }
      ],
      {
        duration: 400 + Math.random() * 480,
        delay,
        easing: "cubic-bezier(.2,.65,.3,1)",
        fill: "both"
      }
    );
    anim.onfinish = () => star.remove();
    anim.oncancel = () => star.remove();
  }
  function visibleFxTargets(selector) {
    const out = [];
    for (const el of document.querySelectorAll(selector)) {
      const row = el.parentElement;
      if (!row || row.classList.contains("flairQuiet")) continue;
      const rect = row.getBoundingClientRect();
      if (rect.width <= 0 || rect.height <= 0) continue;
      if (rect.bottom < 0 || rect.top > window.innerHeight) continue;
      out.push(el);
    }
    return out;
  }
  function rollFxTargets(selector, chance, run, maxPerTick) {
    const targets = visibleFxTargets(selector);
    if (!targets.length) return;
    const start = Math.random() * targets.length | 0;
    let fired = 0;
    for (let i = 0; i < targets.length && fired < maxPerTick; i++) {
      if (Math.random() >= chance) continue;
      run(targets[(start + i) % targets.length]);
      fired += 1;
    }
  }
  function circuitSurge(el) {
    if (typeof el.animate !== "function") return;
    if (el.dataset.surging === "1") return;
    const bits = el.querySelectorAll(".cirSeg, .cirCoinWrap");
    if (!bits.length) return;
    el.dataset.surging = "1";
    const travel = 620 + Math.random() * 560;
    const p = 1.45 + Math.random() * 0.95;
    const lit = 165 + Math.random() * 120;
    const peak = 0.5 + Math.random() * 0.42;
    let last = null;
    let lastEnd = -1;
    for (const bit of bits) {
      const t = Math.max(0, Math.min(1.05, parseFloat(bit.style.getPropertyValue("--t")) || 0));
      const delay = Math.max(0, travel * Math.pow(t, p) + (Math.random() * 46 - 23));
      const coin = bit.classList.contains("cirCoinWrap");
      const dur = coin ? lit * 3.8 : lit;
      const top = coin ? Math.min(0.68, peak * 1.5) : peak;
      const anim = bit.animate(
        coin ? [{ opacity: 0 }, { opacity: top, offset: 0.12 }, { opacity: top * 0.72, offset: 0.4 }, { opacity: top * 0.3, offset: 0.72 }, { opacity: 0 }] : [{ opacity: 0 }, { opacity: top, offset: 0.22 }, { opacity: top * 0.45, offset: 0.5 }, { opacity: 0 }],
        { duration: dur, delay, easing: "linear" }
      );
      if (delay + dur > lastEnd) {
        lastEnd = delay + dur;
        last = anim;
      }
    }
    const done = () => {
      el.dataset.surging = "";
    };
    if (last) {
      last.onfinish = done;
      last.oncancel = done;
    } else done();
  }
  function flairStrike(el) {
    if (typeof el.animate !== "function") return;
    const row = el.parentElement;
    if (!row) return;
    el.insertAdjacentHTML("beforeend", lightningStrikeMarkup(row.clientWidth, row.clientHeight));
    const strike = el.lastElementChild;
    const anim = strike.animate(
      [
        { opacity: 0 },
        { opacity: 1, offset: 0.12 },
        { opacity: 0.25, offset: 0.3 },
        { opacity: 0.9, offset: 0.46 },
        { opacity: 0.15, offset: 0.66 },
        { opacity: 0 }
      ],
      { duration: 260 + Math.random() * 170, easing: "linear" }
    );
    anim.onfinish = () => strike.remove();
    anim.oncancel = () => strike.remove();
  }
  function flairTickerTick() {
    if (document.hidden || state.settings.studio.reduceMotion || state.settings.studio.renderInAgnostr === false) return;
    if (window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches) return;
    const stars = visibleFxTargets(".flair-stars > .flairFx");
    if (stars.length && Math.random() < 0.34) {
      const count = Math.min(stars.length, 1 + Math.floor(Math.random() * 3));
      const used = /* @__PURE__ */ new Set();
      for (let i = 0; i < count; i++) {
        let index = Math.floor(Math.random() * stars.length);
        let guard = 0;
        while (used.has(index) && guard < stars.length) {
          index = (index + 1) % stars.length;
          guard += 1;
        }
        used.add(index);
        shootStar(stars[index], Math.random() * 1600);
      }
    }
    rollFxTargets(".flair-lightning > .flairFx", 0.13, flairStrike, 3);
    rollFxTargets(".flair-bitcoin > .flairFx", 0.3, circuitSurge, 4);
  }
  function renderBetterSettingsPane(modal) {
    const body = modal.querySelector(".ag-set-detail-body");
    if (!body) return;
    let overlay = body.querySelector("[data-ba-better-overlay]");
    if (!overlay) {
      overlay = document.createElement("div");
      overlay.className = "ba-better-overlay";
      overlay.setAttribute("data-ba-better-overlay", "1");
      overlay.innerHTML = betterSettingsPaneHtml();
      body.appendChild(overlay);
    }
    overlay.hidden = false;
    modal.classList.remove("ba-about-active");
    modal.classList.add("ba-better-active");
    hideAboutPane(modal);
    for (const tab of modal.querySelectorAll("[data-ba-better-tab]")) {
      tab.classList.toggle("is-active", tab.getAttribute("data-ba-better-tab") === state.betterTab);
    }
    if (!overlay.querySelector("[data-ba-better-content]")?.firstElementChild) renderBetterTabContent(modal);
    syncBetterSettings(modal);
  }
  function hideBetterSettingsPane(modal) {
    modal.classList.remove("ba-better-active");
    const overlay = modal.querySelector("[data-ba-better-overlay]");
    if (overlay) overlay.hidden = true;
  }
  function hideNativeBroadcastClient(modal) {
    for (const card of modal.querySelectorAll(".ag-set-toggle-card, .ag-set-notif-row")) {
      if (!/broadcast agnostr client|share agnostr client tag/i.test(card.textContent || "")) continue;
      card.style.display = "none";
      card.setAttribute("data-ba-hidden-native-broadcast", "1");
      const input = card.querySelector('input[type="checkbox"]');
      if (input instanceof HTMLInputElement && input.checked) {
        if (card.dataset.baBroadcastToggle !== "1") {
          card.dataset.baBroadcastToggle = "1";
          input.click();
        }
      }
    }
  }
  function syncSettingsMobileTitle(modal, title) {
    const section2 = modal.querySelector(".ag-set-mobile-section");
    if (!section2 || !title) return;
    const label = section2.querySelector(".ag-set-mobile-title");
    if (label) {
      if (label.textContent !== title) label.textContent = title;
    } else {
      const textNode = [...section2.childNodes].find(
        (node) => node.nodeType === Node.TEXT_NODE && (node.nodeValue || "").trim()
      );
      if (textNode) textNode.nodeValue = title;
      else if (!section2.children.length) section2.textContent = title;
      else section2.setAttribute("aria-label", title);
    }
    const back = modal.querySelector(".ag-set-mobile-back, .ag-sheet-back-btn, [data-close-modal]");
    back?.setAttribute("aria-label", `Back from ${title}`);
  }
  function settingsModalTitle(modal) {
    return modal.querySelector(".ag-set-detail-title")?.textContent?.trim() || modal.querySelector(".ag-set-mobile-title")?.textContent?.trim() || modal.getAttribute("aria-label")?.trim() || "";
  }
  function syncSettingsIntegration() {
    if (state.settings.enabled === false) return;
    const modal = document.querySelector(".ag-settings-modal");
    if (!modal) {
      state.settingsModalOpen = false;
      state.settingsBetterActive = false;
      state.aboutActive = false;
      return;
    }
    hideNativeBroadcastClient(modal);
    if (!state.settingsModalOpen) {
      state.settingsModalOpen = true;
      state.settingsBetterActive = false;
      state.aboutActive = false;
    }
    const nav = ensureBetterNav(modal);
    const aboutNav = ensureAboutNav(modal);
    if (!nav || !aboutNav) {
      state.settingsBetterActive = false;
      state.aboutActive = false;
      modal.classList.remove("ba-better-active", "ba-about-active");
      hideBetterSettingsPane(modal);
      hideAboutPane(modal);
      const title2 = settingsModalTitle(modal);
      if (/appearance/i.test(title2)) injectAppearanceExtras(modal);
      else clearAppearanceExtras(modal);
      if (/privacy|trust/i.test(title2)) injectNativePrivacy(modal);
      else clearNativePrivacy(modal);
      if (/notif|alert/i.test(title2)) injectNativeSounds(modal);
      else clearNativeSoundsOverride(modal);
      syncThemeCards(modal);
      return;
    }
    if (state.settingsBetterActive || state.aboutActive) {
      if (enterSettingsMobileDetail(modal)) return;
    }
    if (state.aboutActive) {
      for (const item of modal.querySelectorAll(".ag-set-nav-item")) item.classList.toggle("active", item === aboutNav);
      state.settingsBetterActive = false;
      syncSettingsMobileTitle(modal, "About");
      hideBetterSettingsPane(modal);
      renderAboutPane(modal);
      return;
    }
    if (state.settingsBetterActive) {
      for (const item of modal.querySelectorAll(".ag-set-nav-item")) item.classList.toggle("active", item === nav);
      syncSettingsMobileTitle(modal, "Better Agnostr");
      hideAboutPane(modal);
      renderBetterSettingsPane(modal);
      return;
    }
    nav.classList.remove("active");
    aboutNav.classList.remove("active");
    hideBetterSettingsPane(modal);
    hideAboutPane(modal);
    const title = settingsModalTitle(modal);
    syncSettingsMobileTitle(modal, title);
    if (/appearance/i.test(title)) injectAppearanceExtras(modal);
    else clearAppearanceExtras(modal);
    if (/privacy|trust/i.test(title)) injectNativePrivacy(modal);
    else clearNativePrivacy(modal);
    if (/notif|alert/i.test(title)) injectNativeSounds(modal);
    else clearNativeSoundsOverride(modal);
    syncThemeCards(modal);
  }
  function openAgnostrSettings(navLabel = "Appearance") {
    closePanel();
    const settingsBtn = findNativeSettingsButton();
    if (!settingsBtn) {
      toast("warning", "Settings not found", "Open Agnostr settings from the suite menu.");
      return;
    }
    settingsBtn.click();
    window.setTimeout(() => {
      const items = [...document.querySelectorAll(".ag-settings-modal .ag-set-nav-item")];
      const item = items.find((b2) => b2.textContent.includes(navLabel));
      if (item) {
        state.settingsBetterActive = false;
        item.click();
      }
      scheduleSettingsSync();
    }, 120);
  }
  function handleSettingsAction(action) {
    switch (action) {
      case "open-panel":
      case "open-studio":
        openBetterSettings("line");
        break;
      case "open-client":
        openBetterSettings("client");
        break;
      case "open-appearance":
        state.settingsBetterActive = false;
        {
          const items = [...document.querySelectorAll(".ag-settings-modal .ag-set-nav-item")];
          const item = items.find((b2) => !b2.hasAttribute("data-ba-settings-nav") && b2.textContent.includes("Appearance"));
          item?.click();
        }
        scheduleSettingsSync();
        break;
      case "open-settings-page":
        openAgnostrSettings("Appearance");
        break;
      case "sync-build":
        refreshBuild(true);
        break;
      case "reset-css":
        updateSettings((s) => {
          s.theme.customCss = "";
        });
        applyTheme();
        scheduleSettingsSync();
        break;
      case "preview-message-sound":
        previewSound("message", state.settings.sounds.message, state.settings.sounds.volume);
        break;
      case "preview-click-sound":
        previewSound("click", state.settings.sounds.click, state.settings.sounds.volume);
        break;
      case "copy-diagnostics":
        copyDiagnostics();
        break;
      default:
        break;
    }
  }
  document.addEventListener(
    "click",
    (event) => {
      if (!state.enabledReady || state.settings.enabled === false) return;
      const target = event.target;
      if (!(target instanceof Element)) return;
      const suiteBetter = target.closest("[data-ba-suite-better]");
      if (suiteBetter) {
        event.preventDefault();
        event.stopPropagation();
        openBetterSettings(state.betterTab || "line");
        window.setTimeout(() => {
          document.querySelector(".ag-suite-backdrop .ag-suite-close")?.click();
        }, 0);
        return;
      }
      const emojiTab = target.closest("[data-ba-emoji-tab]");
      if (emojiTab) {
        event.preventDefault();
        event.stopPropagation();
        state.emojiCategory = emojiTab.getAttribute("data-ba-emoji-tab") || "smileys";
        const pop = emojiPicker();
        pop.innerHTML = emojiPickerBodyHtml();
        pop.hidden = false;
        if (state.emojiAnchor) positionEmojiPicker(state.emojiAnchor);
        return;
      }
      const emojiItem = target.closest("[data-ba-emoji]");
      if (emojiItem) {
        event.preventDefault();
        event.stopPropagation();
        insertEmoji(emojiItem.getAttribute("data-ba-emoji") || "");
        return;
      }
      const emojiTrigger = target.closest("[data-ba-emoji-trigger]");
      if (emojiTrigger) {
        event.preventDefault();
        event.stopPropagation();
        openEmojiPicker(emojiTrigger);
        return;
      }
      if (!target.closest(".ba-emoji-popover") && !target.closest("[data-ba-emoji-trigger]")) {
        hideEmojiPicker();
      }
      const formatToggle = target.closest("[data-ba-format-toggle]");
      if (formatToggle) {
        event.preventDefault();
        event.stopPropagation();
        updateSettings((s) => {
          s.studio.showComposerToolbar = s.studio.showComposerToolbar === false;
        });
        return;
      }
      const betterTab = target.closest("[data-ba-better-tab]");
      if (betterTab) {
        event.preventDefault();
        state.betterTab = betterTab.getAttribute("data-ba-better-tab");
        state.settings.ui.betterTab = state.betterTab;
        debounceSave();
        const modal = document.querySelector(".ag-settings-modal");
        if (modal) {
          for (const t of modal.querySelectorAll("[data-ba-better-tab]")) t.classList.toggle("is-active", t === betterTab);
          renderBetterTabContent(modal);
          syncBetterSettings(modal);
        }
        return;
      }
      const flairChoice = target.closest("[data-ba-flair-choice]");
      if (flairChoice) {
        event.preventDefault();
        const flair = flairChoice.getAttribute("data-ba-flair-choice") || "";
        updateSettings((s) => {
          s.studio.flair = flair;
        });
        const modal = document.querySelector(".ag-settings-modal");
        if (modal) {
          state.betterPreviewSig = "";
          syncBetterSettings(modal);
        }
        return;
      }
      const templatePreset = target.closest("[data-ba-template-preset]");
      if (templatePreset) {
        event.preventDefault();
        const input = document.querySelector('.ag-settings-modal [data-ba-setting="studio.template"]');
        if (input instanceof HTMLInputElement) {
          const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
          setter?.call(input, templatePreset.getAttribute("data-ba-template-preset") || "");
          input.dispatchEvent(new Event("input", { bubbles: true }));
          input.focus();
        }
        return;
      }
      const templateCode = target.closest("[data-ba-template-code]");
      if (templateCode) {
        event.preventDefault();
        const input = document.querySelector('.ag-settings-modal [data-ba-setting="studio.template"]');
        insertInto(input, templateCode.getAttribute("data-ba-template-code") || "");
        return;
      }
      const templatePlaceholder = target.closest("[data-ba-template-placeholder]");
      if (templatePlaceholder) {
        event.preventDefault();
        const input = document.querySelector('.ag-settings-modal [data-ba-setting="studio.template"]');
        insertInto(input, templatePlaceholder.getAttribute("data-ba-template-placeholder") || "");
        return;
      }
      const clientPreset = target.closest("[data-ba-client-preset]");
      if (clientPreset) {
        event.preventDefault();
        updateSettings((s) => {
          s.client.name = clientPreset.getAttribute("data-ba-client-preset") || "";
        });
        const modal = document.querySelector(".ag-settings-modal");
        if (modal) syncBetterSettings(modal);
        return;
      }
      const logRow = target.closest("[data-ba-log-index]");
      if (logRow) {
        event.preventDefault();
        const log = state.logs[Number(logRow.getAttribute("data-ba-log-index"))];
        if (log?.eventId) openViewer(log.eventId, log.event ? "json" : "relay");
        return;
      }
      const themeCard = target.closest("[data-ba-glub-theme]");
      if (themeCard) {
        event.preventDefault();
        event.stopPropagation();
        const id = themeCard.getAttribute("data-ba-glub-theme");
        updateSettings((s) => {
          s.theme.preset = id;
        });
        applyTheme();
        syncSettingsIntegration();
        return;
      }
      const agnTheme = target.closest(".ag-set-theme-card");
      if (agnTheme && !agnTheme.hasAttribute("data-ba-glub-theme")) {
        state.agnostrActiveThemeCard = agnTheme;
        if (state.settings.theme.preset !== "agnostr") {
          updateSettings((s) => {
            s.theme.preset = "agnostr";
          });
          applyTheme();
        }
        return;
      }
      const angel = target.closest("[data-ba-angel-link]");
      if (angel) {
        event.preventDefault();
        event.stopPropagation();
        openProfileByNpub(angel.getAttribute("data-npub"));
        return;
      }
      const action = target.closest("[data-ba-settings-action]")?.getAttribute("data-ba-settings-action");
      if (action) {
        event.preventDefault();
        event.stopPropagation();
        handleSettingsAction(action);
        return;
      }
      const settingsBack = target.closest(".ag-settings-modal .ag-sheet-back-btn");
      if (settingsBack) {
        state.settingsBetterActive = false;
        state.aboutActive = false;
        scheduleSettingsSync();
      }
      const nav = target.closest(".ag-set-nav-item");
      if (nav && !nav.hasAttribute("data-ba-settings-nav") && !nav.hasAttribute("data-ba-about-nav")) {
        const modal = nav.closest(".ag-settings-modal");
        if (modal?.dataset.baMobileEntering === "1") return;
        state.settingsBetterActive = false;
        state.aboutActive = false;
        scheduleSettingsSync();
      }
    },
    true
  );
  document.addEventListener(
    "input",
    (event) => {
      if (!state.enabledReady || state.settings.enabled === false) return;
      const target = event.target;
      if (!(target instanceof HTMLElement)) return;
      const path = target.getAttribute("data-ba-setting");
      if (!path) return;
      if (target.type === "checkbox") return;
      updateSettings((s) => setPath(s, path, target.value), { sync: false });
      if (path === "theme.customCss") {
        applyTheme();
        scheduleSettingsSync();
      }
      if (path === "font.customFamily" || path === "font.customUrl") {
        state.settings.font.family = "custom";
        debounceSave();
        broadcastConfig();
        const fontSelect = document.querySelector('.ag-settings-modal [data-ba-setting="font.family"]');
        if (fontSelect) fontSelect.value = "custom";
      }
      if (path.startsWith("font.")) applyFont();
      if (path.startsWith("studio.") || path.startsWith("sounds.") || path.startsWith("client.") || path.startsWith("font.") || path === "glub.manualBuild") {
        scheduleSettingsSync();
      }
    },
    true
  );
  document.addEventListener(
    "change",
    (event) => {
      if (!state.enabledReady || state.settings.enabled === false) return;
      const target = event.target;
      if (!(target instanceof HTMLElement)) return;
      if (target.matches("[data-ba-strip-tag]")) {
        const name = target.getAttribute("data-ba-strip-tag");
        updateSettings((s) => {
          const set = new Set(s.privacy.stripTags);
          if (target.checked) set.add(name);
          else set.delete(name);
          s.privacy.stripTags = [...set];
        });
        return;
      }
      if (target.matches("[data-ba-rainbow-toggle]")) {
        updateSettings((s) => {
          s.studio.rainbowStyle = target.checked ? "glub" : "bright";
        });
        return;
      }
      if (target.matches("[data-ba-review-group]")) {
        const name = target.getAttribute("data-ba-review-group");
        updateSettings((s) => {
          const set = new Set(s.privacy.reviewGroups);
          if (target.checked) set.add(name);
          else set.delete(name);
          s.privacy.reviewGroups = [...set];
        });
        return;
      }
      if (target.matches("[data-ba-client-policy]")) {
        const group = target.getAttribute("data-ba-client-policy");
        updateSettings((s) => {
          s.client.policies[group] = target.value;
        });
        return;
      }
      const path = target.getAttribute("data-ba-setting");
      if (!path) return;
      const value = target.type === "checkbox" ? target.checked : target.value;
      updateSettings((s) => setPath(s, path, value), { sync: true });
      if (path === "theme.customCss") applyTheme();
      if (path.startsWith("sounds.") || path === "glub.manualBuild") scheduleSettingsSync();
    },
    true
  );
  function wireShell() {
    const root = state.shadow;
    root.addEventListener("click", (event) => {
      const target = event.target;
      if (!(target instanceof Element)) return;
      const backdrop = target.closest("[data-role='backdrop']");
      if (backdrop) {
        closePanel();
        return;
      }
      const tab = target.closest("[data-tab]");
      if (tab) {
        switchTab(tab.dataset.tab);
        return;
      }
      const closeModal = target.closest("[data-close-modal]");
      if (closeModal) {
        const which = closeModal.getAttribute("data-close-modal");
        if (which === "viewer") closeViewer();
        if (which === "review") finishReview("cancel");
        if (which === "action") closeActionModal();
        return;
      }
      const toggle = target.closest("[data-toggle]");
      if (toggle) {
        const path = toggle.dataset.toggle;
        const current = !!getPath(state.settings, path);
        updateSettings((s) => setPath(s, path, !current));
        return;
      }
      const action = target.closest("[data-action]")?.getAttribute("data-action");
      if (action) {
        handleAction(action);
        return;
      }
      const flair = target.closest("[data-flair-choice]");
      if (flair) {
        const name = flair.getAttribute("data-flair-choice");
        updateSettings((s) => {
          s.studio.flair = name;
        });
        return;
      }
      const preset = target.closest("[data-template-preset]");
      if (preset) {
        const value = preset.getAttribute("data-template-preset") || "";
        updateSettings((s) => {
          s.studio.template = value;
        });
        return;
      }
      const placeholder = target.closest("[data-placeholder]");
      if (placeholder) {
        insertInto(templateInput(), placeholder.getAttribute("data-placeholder") || "");
        return;
      }
      const fmt = target.closest("[data-code]");
      if (fmt) {
        insertInto(templateInput(), fmt.getAttribute("data-code") || "");
        return;
      }
      const color = target.closest("[data-color]");
      if (color) {
        const code = color.getAttribute("data-color") || "";
        if (target.closest("[data-role='colors']")) insertInto(templateInput(), `&${code}`);
        else insertInto(composerTextarea(), `&${code}`);
        return;
      }
      const clientPreset = target.closest("[data-client-preset]");
      if (clientPreset) {
        const value = clientPreset.getAttribute("data-client-preset") || "";
        updateSettings((s) => {
          s.client.name = value;
        });
        return;
      }
      const theme = target.closest("[data-theme-preset]");
      if (theme) {
        const value = theme.getAttribute("data-theme-preset") || "agnostr";
        updateSettings((s) => {
          s.theme.preset = value;
        });
        return;
      }
      const viewerTab = target.closest("[data-viewer-tab]");
      if (viewerTab) {
        if (state.viewer) {
          const tab2 = viewerTab.getAttribute("data-viewer-tab");
          state.viewer.tab = tab2;
          renderViewer();
          window.requestAnimationFrame(() => {
            const next = state.shadow?.querySelector(`[data-viewer-tab='${tab2}']`);
            if (next instanceof HTMLElement) next.focus({ preventScroll: true });
          });
        }
        return;
      }
      const logRow = target.closest("[data-log-index]");
      if (logRow) {
        const index = Number(logRow.getAttribute("data-log-index"));
        const log = state.logs[index];
        if (log?.eventId) openViewer(log.eventId, log.event ? "json" : "relay");
        return;
      }
    });
    root.addEventListener("input", (event) => {
      const target = event.target;
      if (!(target instanceof HTMLElement)) return;
      if (target.matches("[data-setting]")) {
        const path = target.getAttribute("data-setting");
        let value = target.value;
        if (target.type === "checkbox") value = target.checked;
        updateSettings((s) => setPath(s, path, value), { sync: false });
        if (path === "studio.template") {
          syncStudioMeta();
          renderPreview();
          renderClientPreview();
        }
        if (path === "client.name") renderClientPreview();
        if (path === "theme.customCss") applyTheme();
        if (path === "glub.manualBuild") {
          syncBuildBadges();
          renderPreview();
          renderClientPreview();
        }
        return;
      }
      if (target.matches("[data-role='log-filter']")) {
        state.logFilter = target.value;
        renderRelay();
        return;
      }
      if (target.matches("[data-policy-group]")) {
        const group = target.getAttribute("data-policy-group");
        const value = target.value;
        updateSettings((s) => {
          s.client.policies[group] = value;
        });
        renderClientPreview();
        return;
      }
    });
    root.addEventListener("change", (event) => {
      const target = event.target;
      if (!(target instanceof HTMLElement)) return;
      if (target.matches("[data-setting]")) {
        const path = target.getAttribute("data-setting");
        const value = target.type === "checkbox" ? target.checked : target.value;
        updateSettings((s) => setPath(s, path, value), { sync: false });
        if (path === "theme.customCss") {
          applyTheme();
          scheduleSettingsSync();
        }
        if (path.startsWith("sounds.")) scheduleSettingsSync();
        return;
      }
      if (target.matches("[data-review-tag]")) {
        if (!state.review) return;
        const index = Number(target.getAttribute("data-review-tag"));
        if (!Number.isInteger(index)) return;
        if (target.checked) state.review.selected.add(index);
        else state.review.selected.delete(index);
        return;
      }
      if (target.matches("[data-strip-tag]")) {
        const name = target.getAttribute("data-strip-tag");
        updateSettings((s) => {
          const set = new Set(s.privacy.stripTags);
          if (target.checked) set.add(name);
          else set.delete(name);
          s.privacy.stripTags = [...set];
        });
      }
      if (target.matches("[data-review-group]")) {
        const name = target.getAttribute("data-review-group");
        updateSettings((s) => {
          const set = new Set(s.privacy.reviewGroups);
          if (target.checked) set.add(name);
          else set.delete(name);
          s.privacy.reviewGroups = [...set];
        });
      }
    });
  }
  document.addEventListener(
    "keydown",
    (event) => {
      if (trapModalKey(event)) return;
      if (event.key === "Escape" && !state.modalOpen && state.settings.ui.panelOpen) {
        closePanel();
      }
    },
    true
  );
  function handleAction(action) {
    switch (action) {
      case "open-panel":
        openPanel(state.settings.ui.activeTab || "studio");
        break;
      case "close-panel":
        closePanel();
        break;
      case "clear-flair":
        updateSettings((s) => {
          s.studio.flair = "";
        });
        break;
      case "refresh-build":
        refreshBuild(true);
        break;
      case "inspect-last":
        if (state.lastOutgoingId) openViewer(state.lastOutgoingId);
        else toast("info", "No outgoing event yet", "Send a chat message and try again.");
        break;
      case "toggle-pause":
        updateSettings((s) => {
          s.inspector.paused = !s.inspector.paused;
        });
        if (!state.settings.inspector.paused) {
          askPage("getLogs", { limit: 500 }).then((res) => {
            if (res?.logs) appendLogs(res.logs);
          });
        }
        renderRelay();
        break;
      case "clear-logs":
        state.logs = [];
        renderRelay();
        break;
      case "reset-css":
        updateSettings((s) => {
          s.theme.customCss = "";
        });
        applyTheme();
        break;
      case "copy-diagnostics":
        copyDiagnostics();
        break;
      case "verify-event":
        if (state.viewer?.event) {
          const target = state.viewer.event;
          askPage("verify", { event: target }).then((res) => {
            if (res && state.viewer?.event?.id === target.id) {
              state.verified.set(target.id, res);
              renderViewer();
            }
          });
        }
        break;
      case "copy-json":
        if (state.viewer?.event) copyText(JSON.stringify(state.viewer.event, null, 2), "Event JSON copied");
        break;
      case "download-json":
        if (state.viewer?.event) downloadJson(state.viewer.event);
        break;
      case "copy-id":
        if (state.viewer?.event) copyText(state.viewer.event.id, "Event id copied");
        break;
      case "copy-pubkey":
        if (state.viewer?.event) copyText(state.viewer.event.pubkey, "Pubkey copied");
        break;
      case "copy-npub": {
        const entities = state.viewer?.event ? state.entities.get(state.viewer.event.id) : null;
        if (entities?.npub) copyText(entities.npub, "npub copied");
        break;
      }
      case "open-njump": {
        if (!state.viewer?.event) break;
        const entities = state.entities.get(state.viewer.event.id);
        const id = state.viewer.event.id;
        const url = entities?.nevent ? `https://njump.me/${entities.nevent}` : `https://njump.me/${id}`;
        window.open(url, "_blank", "noopener,noreferrer");
        break;
      }
      case "review-send":
        finishReview("send", false);
        break;
      case "review-scrub":
        finishReview("send", true);
        break;
      case "review-cancel":
        finishReview("cancel");
        break;
      case "action-send":
        sendCustomAction();
        break;
      case "action-insert-user":
        insertCustomActionToken("{user}");
        break;
      case "action-insert-sender":
        insertCustomActionToken("{sender}");
        break;
      case "action-cancel":
        closeActionModal();
        break;
      case "open-studio":
        openPanel("studio");
        break;
      case "open-last":
        if (state.lastOutgoingId) openViewer(state.lastOutgoingId);
        break;
      case "preview-message-sound":
        previewSound("message", state.settings.sounds.message, state.settings.sounds.volume);
        break;
      case "preview-click-sound":
        previewSound("click", state.settings.sounds.click, state.settings.sounds.volume);
        break;
      case "open-agnostr-settings":
        openAgnostrSettings("Appearance");
        break;
      default:
        break;
    }
  }
  function buildDynamicParts() {
    const root = state.shadow;
    if (!root) return;
    const q = (sel) => root.querySelector(sel);
    const colors = q("[data-role='colors']");
    if (colors) {
      colors.innerHTML = Object.entries(COLORS).map(
        ([code, value]) => `<button type="button" class="ba-swatch" data-color="${code}" title="&amp;${code} \xB7 ${COLOR_NAMES[code]}" style="background:${value};${["f", "e", "b", "a"].includes(code) ? "color:rgba(0,0,0,.65)" : "color:rgba(255,255,255,.38)"}">${code}</button>`
      ).join("");
    }
    const actions = q("[data-role='format-actions']");
    if (actions) {
      const items = [
        ["&l", "B", "Bold"],
        ["&o", "I", "Italic"],
        ["&n", "U", "Underline"],
        ["&m", "S", "Strikethrough"],
        ["&k", "K", "Obfuscate"],
        ["&g", "G", "Rainbow gradient"],
        ["&r", "R", "Reset"]
      ];
      actions.innerHTML = items.map(([code, label, title]) => `<button type="button" class="ba-btn small" data-code="${code}" title="${title}">${label}</button>`).join("");
    }
    const placeholders = q("[data-role='placeholders']");
    if (placeholders) {
      placeholders.innerHTML = [
        ["{name}", "{name}"],
        ["{tag}", "{tag}"],
        ["{msg}", "{msg}"]
      ].map(([value, label]) => `<button type="button" class="ba-chip" data-placeholder="${value}">${label}</button>`).join("");
    }
    const presets = q("[data-role='presets']");
    if (presets) {
      presets.innerHTML = TEMPLATE_PRESETS.map(
        (p) => `<button type="button" class="ba-chip" data-template-preset="${h(p.value)}">${h(p.label)}</button>`
      ).join("");
    }
    const flairs = q("[data-role='flairs']");
    if (flairs) {
      flairs.innerHTML = FLAIRS2.map(
        (f) => `<button type="button" class="ba-flair-option${f.gated ? " is-gated" : ""}" data-flair-choice="${f.name}" data-preview-flair="${f.name}" title="${h(f.description)}"><span class="ba-flair-name">${h(f.label)}</span><span class="ba-flair-desc">${h(f.description)}</span></button>`
      ).join("");
    }
    const clientPresets = q("[data-role='client-presets']");
    if (clientPresets) {
      clientPresets.innerHTML = CLIENT_PRESETS.map(
        (name) => `<button type="button" class="ba-chip" data-client-preset="${h(name)}">${h(name)}</button>`
      ).join("");
    }
    const policies = q("[data-role='policies']");
    if (policies) {
      policies.innerHTML = KIND_GROUPS.map(
        (g) => `
      <div class="ba-policy-row">
        <div class="ba-policy-label">${h(g.label)}<small>${h(g.detail)}</small></div>
        <select class="ba-select" data-policy-group="${g.id}">
          ${KIND_POLICIES.map((p) => `<option value="${p}">${p}</option>`).join("")}
        </select>
      </div>`
      ).join("");
    }
    const stripTags = q("[data-role='strip-tags']");
    if (stripTags) {
      stripTags.innerHTML = STRIPPABLE_TAGS.map(
        (t) => `<label class="ba-check" title="${h(t.detail)}"><input type="checkbox" data-strip-tag="${t.name}"> <span>${h(t.label)}</span></label>`
      ).join("");
    }
    const reviewGroups = q("[data-role='review-groups']");
    if (reviewGroups) {
      reviewGroups.innerHTML = KIND_GROUPS.map(
        (g) => `<label class="ba-check"><input type="checkbox" data-review-group="${g.id}"> <span>${h(g.label)}</span></label>`
      ).join("");
    }
    const themes = q("[data-role='themes']");
    if (themes) {
      themes.innerHTML = ALL_THEMES.map((t) => {
        const colors2 = themeSwatch(t);
        return `<button type="button" class="ba-theme-btn" data-theme-preset="${t.id}" title="${h(t.description)}"><span class="ba-theme-swatch">${colors2.map((c) => `<span style="background:${c}"></span>`).join("")}</span><span class="ba-theme-name">${h(t.label)}</span></button>`;
      }).join("");
    }
    for (const select of root.querySelectorAll("[data-sound-kind]")) {
      const list = select.getAttribute("data-sound-kind") === "click" ? CLICK_SOUNDS : MESSAGE_SOUNDS;
      select.innerHTML = list.map((s) => `<option value="${s.id}">${h(s.label)}</option>`).join("");
    }
    const logFilter = q("[data-role='log-filter']");
    if (logFilter) logFilter.value = state.logFilter;
  }
  function syncInputs() {
    const root = state.shadow;
    if (!root) return;
    for (const el of root.querySelectorAll("[data-setting]")) {
      const path = el.getAttribute("data-setting");
      const value = getPath(state.settings, path);
      if (el === root.activeElement) continue;
      if (el.type === "checkbox") el.checked = !!value;
      else el.value = value ?? "";
    }
    for (const el of root.querySelectorAll("[data-toggle]")) {
      const value = !!getPath(state.settings, el.getAttribute("data-toggle"));
      el.classList.toggle("is-on", value);
      el.setAttribute("aria-pressed", value ? "true" : "false");
    }
    for (const el of root.querySelectorAll("[data-policy-group]")) {
      const group = el.getAttribute("data-policy-group");
      el.value = state.settings.client.policies[group] || "leave";
    }
    for (const el of root.querySelectorAll("[data-strip-tag]")) {
      el.checked = state.settings.privacy.stripTags.includes(el.getAttribute("data-strip-tag"));
    }
    for (const el of root.querySelectorAll("[data-review-group]")) {
      el.checked = state.settings.privacy.reviewGroups.includes(el.getAttribute("data-review-group"));
    }
  }
  function syncDynamic() {
    const root = state.shadow;
    if (!root) return;
    for (const el of root.querySelectorAll("[data-policy-group]")) {
      el.disabled = false;
    }
    for (const el of root.querySelectorAll("[data-flair-choice]")) {
      const name = el.getAttribute("data-flair-choice");
      el.classList.toggle("is-active", state.settings.studio.flair === name);
      el.style.setProperty("--ba-flair-tint", flairTint(name));
    }
    for (const el of root.querySelectorAll("[data-theme-preset]")) {
      el.classList.toggle("is-active", state.settings.theme.preset === el.getAttribute("data-theme-preset"));
    }
    for (const el of root.querySelectorAll("[data-client-preset]")) {
      el.classList.toggle("is-active", state.settings.client.name === el.getAttribute("data-client-preset"));
    }
    for (const el of root.querySelectorAll("[data-template-preset]")) {
      el.classList.toggle("is-active", state.settings.studio.template === el.getAttribute("data-template-preset"));
    }
    syncStudioMeta();
    renderPreview();
    renderClientPreview();
    syncFooter();
    syncBuildBadges();
    syncLastOutgoing();
    const pauseBtn = root.querySelector("[data-action='toggle-pause']");
    if (pauseBtn) pauseBtn.textContent = state.settings.inspector.paused ? "resume" : "pause";
    if (state.activeTab === "relay") renderRelay();
    if (state.activeTab === "help") renderDiagnostics();
  }
  function syncStudioMeta() {
    const root = state.shadow;
    if (!root) return;
    const count = root.querySelector("[data-role='fmt-count']");
    if (count) {
      const tpl = state.settings.studio.template || "";
      count.textContent = `${tpl.length}/${FMT_MAX}${tpl.includes("{msg}") ? "" : " \xB7 {msg} appended"}`;
      count.classList.toggle("warn", tpl.length > FMT_MAX * 0.9);
    }
  }
  function templateInput() {
    return state.shadow?.querySelector("[data-setting='studio.template']") || null;
  }
  function composerTextarea(scope = null) {
    const root = scope?.closest?.(".ag-composer-dock") || scope?.closest?.(".ag-composer") || document;
    let list = [...root.querySelectorAll(".ag-composer-input")];
    if (!list.length && root !== document) list = [...document.querySelectorAll(".ag-composer-input")];
    const active = document.activeElement;
    return list.find((el) => el === active) || list.find((el) => el instanceof HTMLTextAreaElement && !el.disabled && !el.readOnly && el.offsetParent !== null) || list[0] || null;
  }
  function insertInto(input, text) {
    if (!input) {
      toast("warning", "No target field", "Open a chat composer or the line-format field first.");
      return;
    }
    if ((input instanceof HTMLTextAreaElement || input instanceof HTMLInputElement) && (input.disabled || input.readOnly)) {
      toast("warning", "Field is read-only", "This field cannot be edited right now.");
      return;
    }
    if (input instanceof HTMLTextAreaElement || input instanceof HTMLInputElement) {
      const start = input.selectionStart ?? input.value.length;
      const end = input.selectionEnd ?? input.value.length;
      const next = input.value.slice(0, start) + text + input.value.slice(end);
      const proto = input instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
      if (setter) setter.call(input, next);
      else input.value = next;
      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.focus();
      try {
        input.setSelectionRange(start + text.length, start + text.length);
      } catch {
      }
      return;
    }
    input.focus();
    document.execCommand?.("insertText", false, text);
  }
  function flairTint(name) {
    switch (name) {
      case "fire":
        return "radial-gradient(ellipse at 50% 120%, rgba(255,94,25,.48) 0%, rgba(255,94,25,.06) 55%, transparent 75%)";
      case "lightning":
        return "linear-gradient(110deg, rgba(88,160,255,.42), rgba(160,120,255,.16) 55%, transparent)";
      case "stars":
        return "radial-gradient(ellipse at 50% 20%, rgba(129,140,248,.4), rgba(129,140,248,.05) 65%, transparent)";
      case "rain":
        return "linear-gradient(180deg, rgba(56,189,248,.12), rgba(37,99,235,.38))";
      case "plume":
        return "linear-gradient(100deg, rgba(167,139,250,.4), rgba(148,163,184,.15) 60%, transparent)";
      case "neon":
        return "linear-gradient(90deg, rgba(236,72,153,.38), rgba(34,211,238,.32))";
      case "matrix":
        return "linear-gradient(180deg, rgba(34,197,94,.35), rgba(34,197,94,.04))";
      case "sonar":
        return "radial-gradient(circle at 20% 50%, rgba(45,212,191,.42), transparent 58%)";
      case "fireflies":
        return "radial-gradient(ellipse at 40% 60%, rgba(250,204,21,.34), transparent 68%)";
      case "bubbles":
        return "linear-gradient(0deg, rgba(34,211,238,.38), transparent 66%)";
      case "aurora":
        return "linear-gradient(110deg, rgba(34,197,94,.4), rgba(56,189,248,.26), rgba(168,85,247,.4))";
      case "bitcoin":
        return "linear-gradient(90deg, rgba(247,147,26,.4), transparent 65%)";
      case "glitch":
        return "linear-gradient(90deg, rgba(239,68,68,.34), rgba(34,211,238,.26))";
      case "sol":
        return "radial-gradient(circle at 50% 50%, rgba(250,204,21,.5), rgba(250,204,21,.06) 60%, transparent 75%)";
      default:
        return "linear-gradient(135deg, transparent, rgba(255,255,255,.04))";
    }
  }
  function renderPreview() {
    const root = state.shadow;
    if (!root) return;
    const container = root.querySelector("[data-role='preview']");
    if (!container) return;
    const build = effectiveBuild(state.settings);
    const template = state.settings.studio.template;
    const flair = state.settings.studio.flair;
    const name = state.status?.nickname || "you";
    const tag = (state.status?.pubkey || "a1b2c3d4").slice(-4);
    const msg = PREVIEW_MESSAGE;
    const avatar = previewAvatarSrc();
    const msgHtml = renderFormatHtml(msg);
    let line;
    try {
      line = renderLineHtml(template, { name, tag, msgHtml, msgText: msg });
    } catch {
      line = h(msg);
    }
    const plain = stripFormat(msg);
    const flairClasses = flair ? flairClass(flair) : "";
    const flairStyle = flair ? flairStyleVars(flairVars(flair)) : "";
    const fx = flair && flairHasFx(flair) ? `<span class="flairFx" aria-hidden="true">${flairFxInner(flair)}</span>` : "";
    const overlay = flair ? flairOverlayInner(flair) : "";
    container.innerHTML = `
    <div class="ba-preview-wrap">
      <div class="ba-preview-head">
        <span>glub.chat view</span>
        <span class="ba-preview-build ${build ? "ok" : "warn"}">${build ? `build ${h(build.slice(0, 7))}` : "build missing \xB7 glub metadata skipped"}</span>
      </div>
      <div class="ba-preview-row ${flairClasses}" style="${flairStyle}">
        <img class="ba-preview-avatar" src="${h(avatar)}" alt="">
        <span class="ba-preview-main">
          <span class="ba-preview-meta">${h(name)}#${h(tag)} \xB7 just now \xB7 ${h(flair || "no flair")}</span>
          <span class="ba-preview-line">${line || h(msg)}</span>
        </span>
        ${fx}${overlay}
      </div>
      <div class="ba-preview-native"><span class="ba-preview-native-label">native</span><span>${h(plain)}</span></div>
      <div class="ba-preview-template"><span>template</span><code>${h(template || "(none)")}</code></div>
    </div>`;
  }
  function renderClientPreview() {
    const root = state.shadow;
    if (!root) return;
    const pre = root.querySelector("[data-role='client-preview']");
    if (!pre) return;
    const build = effectiveBuild(state.settings);
    const policies = state.settings.client.policies;
    const meta = {
      rich: "",
      fmt: state.settings.studio.enabled ? normalizeTemplate(state.settings.studio.template) : "",
      flair: state.settings.studio.enabled ? state.settings.studio.flair : ""
    };
    const sample = {
      kind: 2e4,
      tags: [["g", "dr5r"], ["n", state.status?.nickname || "you"]],
      content: "hello"
    };
    if (policies.chat === "spoof" && state.settings.client.name) {
      sample.tags.push(["client", state.settings.client.name]);
    } else if (policies.chat === "strip") {
      sample.tags = sample.tags.filter((t) => t[0] !== "client");
    }
    if (meta.fmt || meta.flair) {
      const tag = ["glub"];
      if (meta.rich) tag.push("rich", meta.rich);
      if (meta.fmt) tag.push("fmt", meta.fmt);
      if (meta.flair) tag.push("flair", meta.flair);
      if (build) tag.push("v", build);
      if (tag.length > 1) sample.tags.push(tag);
    } else if (policies.chat === "spoof" && state.settings.client.name.toLowerCase() === "glub.chat" && build) {
      sample.tags.push(["glub", "v", build]);
    }
    const lines = sample.tags.map((t) => `["${t[0]}", ${t.slice(1).map((x) => JSON.stringify(x)).join(", ")}]`).join(",\n  ");
    pre.textContent = `{
  "kind": 20000,
  "tags": [
  ${lines}
  ],
  "content": "hello"
}`;
    const clientBuild = root.querySelector("[data-role='client-build']");
    if (clientBuild) {
      clientBuild.textContent = build ? `build ${build.slice(0, 8)} \xB7 live` : "build missing";
      clientBuild.className = `ba-hint ${build ? "ok" : "warn"}`;
    }
    if (clientBuild) clientBuild.classList.add("ba-hint");
  }
  function syncFooter() {
    const root = state.shadow;
    if (!root) return;
    const status = state.status || {};
    const signer = root.querySelector("[data-role='foot-signer']");
    if (signer) {
      if (status.signerHooked) signer.textContent = `signer: ${status.signMode || "attached"}`;
      else if (status.nip07Patched) signer.textContent = "rewriter: nip-07";
      else signer.textContent = "signer: waiting";
    }
    const build = root.querySelector("[data-role='foot-build']");
    if (build) {
      const b2 = effectiveBuild(state.settings);
      build.textContent = b2 ? `build: ${b2.slice(0, 8)}` : "build: \u2014";
    }
    const events = root.querySelector("[data-role='foot-events']");
    if (events) events.textContent = `${state.events.size} events`;
    const sub = root.querySelector("[data-role='header-sub']");
    if (sub) {
      const parts = [];
      parts.push(
        status.signerHooked ? `signer ${status.signMode || "attached"}` : status.nip07Patched ? "NIP-07 rewriter" : "signer waiting"
      );
      if (b()) parts.push(`glub ${b().slice(0, 7)}`);
      sub.textContent = parts.join(" \xB7 ");
    }
    const dot = root.querySelector("[data-role='header-dot']");
    if (dot) {
      dot.className = "ba-status-dot";
      if ((status.signerHooked || status.nip07Patched) && b()) dot.classList.add("ok");
      else if (status.signerHooked || status.nip07Patched || b()) dot.classList.add("warn");
      else dot.classList.add("err");
    }
  }
  function b() {
    return effectiveBuild(state.settings);
  }
  function syncBuildBadges() {
    const root = state.shadow;
    if (!root) return;
    const build = effectiveBuild(state.settings);
    const badge = root.querySelector("[data-role='build-badge']");
    if (badge) {
      if (build) {
        badge.textContent = `glub build ${build.slice(0, 8)}`;
        badge.className = "ba-hint ok";
      } else {
        badge.textContent = state.buildError ? "build sync failed" : "syncing build\u2026";
        badge.className = `ba-hint ${state.buildError ? "err" : "warn"}`;
      }
    }
    const clientBuild = root.querySelector("[data-role='client-build']");
    if (clientBuild) {
      clientBuild.textContent = build ? `build ${build.slice(0, 8)} \xB7 live` : "build missing";
      clientBuild.className = `ba-hint ${build ? "ok" : "warn"}`;
    }
    const footBuild = root.querySelector("[data-role='foot-build']");
    if (footBuild) footBuild.textContent = build ? `build: ${build.slice(0, 8)}` : "build: \u2014";
    const cardStatus = root.querySelector("[data-role='build-card-status']");
    if (cardStatus) {
      if (state.settings.glub.manualBuild) {
        cardStatus.textContent = `Manual override active: ${state.settings.glub.manualBuild}`;
        cardStatus.className = "ba-hint warn";
      } else if (build) {
        cardStatus.textContent = `Auto-synced build ${build}. Messages are stamped with this value.`;
        cardStatus.className = "ba-hint ok";
      } else {
        cardStatus.textContent = state.buildError || "No build stamp yet; glub metadata will be skipped.";
        cardStatus.className = `ba-hint ${state.buildError ? "err" : "warn"}`;
      }
    }
    syncFooter();
  }
  function syncLastOutgoing() {
    const root = state.shadow;
    if (!root) return;
    const pre = root.querySelector("[data-role='last-outgoing']");
    if (!pre) return;
    const ev = state.lastOutgoingId ? eventById(state.lastOutgoingId) : null;
    if (!ev) {
      pre.textContent = "No outgoing event captured yet.";
      return;
    }
    pre.textContent = JSON.stringify(ev, null, 2);
  }
  function mapBetterTab(tab) {
    const map = { studio: "line", line: "line", client: "client", general: "line", theme: "line" };
    return map[tab] || "line";
  }
  function findNativeSettingsButton() {
    const roots = [
      ...document.querySelectorAll(".ag-app-rail, .ag-suite-popover, .ag-suite-footer, .ag-header, header")
    ];
    const scoped = roots.length ? roots.flatMap((root) => [...root.querySelectorAll("button")]) : [...document.querySelectorAll("button")];
    const candidates = [...new Set(scoped)].filter(
      (b2) => !b2.closest(".ba-composer-bar") && !b2.hasAttribute("data-ba-suite-better") && /settings/i.test(`${b2.getAttribute("aria-label") || ""} ${b2.title || ""} ${b2.textContent || ""}`)
    );
    const visible = candidates.find((b2) => b2.offsetParent !== null);
    if (visible) return visible;
    const hiddenNative = document.querySelector("[data-ba-hidden-native-settings]");
    if (hiddenNative) return hiddenNative;
    return candidates[0] || null;
  }
  function openBetterSettings(tab = "line") {
    state.betterTab = mapBetterTab(tab);
    state.settings.ui.betterTab = state.betterTab;
    debounceSave();
    state.settingsBetterActive = true;
    state.aboutActive = false;
    const modal = document.querySelector(".ag-settings-modal");
    if (modal) {
      syncSettingsIntegration();
      return;
    }
    const btn = findNativeSettingsButton();
    if (!btn) {
      toast("warning", "Settings unavailable", "Open Agnostr settings from the suite menu.");
      return;
    }
    btn.click();
    let attempts = 0;
    const finishOpen = () => {
      const m = document.querySelector(".ag-settings-modal");
      if (!m) {
        attempts += 1;
        if (attempts < 24) window.setTimeout(finishOpen, 80);
        return;
      }
      state.settingsModalOpen = true;
      state.settingsBetterActive = true;
      state.aboutActive = false;
      syncSettingsIntegration();
      ensureBetterNav(m);
      renderBetterSettingsPane(m);
    };
    window.setTimeout(finishOpen, 80);
    const age = Date.now() - Number(state.settings.glub.buildFetchedAt || 0);
    if (!state.settings.glub.build || age > 2 * 60 * 1e3) refreshBuild(false);
    askPage("getRecent", { limit: 300 }).then((res) => {
      if (res?.events) {
        for (const ev of res.events) rememberEvent(ev);
        scheduleEnhance();
        scheduleSettingsSync();
      }
    });
  }
  function openPanel(tab) {
    openBetterSettings(tab);
  }
  function closePanel() {
  }
  function updatePanelVisibility() {
  }
  function switchTab() {
  }
  function renderRelay() {
    const root = state.shadow;
    if (!root) return;
    const statusEl = root.querySelector("[data-role='relay-status']");
    const list = root.querySelector("[data-role='relay-list']");
    const info = root.querySelector("[data-role='session-info']");
    const status = state.status || {};
    if (statusEl) {
      const relays = status.relays || [];
      statusEl.innerHTML = relays.length > 0 ? relays.slice(0, 16).map(
        (r) => `<span class="ba-relay-pill ${r.status === "open" ? "ok" : r.status === "error" || r.status === "closed" ? "err" : ""}" title="${h(r.error || "")}">${h(hostOf(r.url))} \xB7 ${h(r.status)}</span>`
      ).join("") : `<span class="ba-relay-pill">no sockets observed yet</span>`;
    }
    if (info) {
      const signer = status.signerHooked ? status.signMode || "attached" : status.nip07Patched ? "nip-07" : "waiting";
      info.innerHTML = `
      <div class="ba-kv"><span>signer</span><span>${h(signer)}</span></div>
      <div class="ba-kv"><span>pubkey</span><span>${h(short(status.pubkey || "", 18))}</span></div>
      <div class="ba-kv"><span>sockets</span><span>${h(String(status.socketCount || 0))}</span></div>
      <div class="ba-kv"><span>events captured</span><span>${h(String(state.events.size))}</span></div>
      <div class="ba-kv"><span>frames logged</span><span>${h(String(state.logs.length))}</span></div>
      <div class="ba-kv"><span>blocked call signals</span><span>${h(String(status.callDrops || 0))}</span></div>`;
    }
    if (!list) return;
    const filter = state.logFilter.trim().toLowerCase();
    const filtered = [];
    for (let i = state.logs.length - 1; i >= 0 && filtered.length < 180; i--) {
      const log = state.logs[i];
      const hay = `${log.type} ${log.relay} ${log.kind ?? ""} ${log.eventId ?? ""} ${log.summary ?? ""}`.toLowerCase();
      if (filter && !hay.includes(filter)) continue;
      filtered.push([i, log]);
    }
    if (!filtered.length) {
      list.innerHTML = `<div class="ba-empty">${state.logs.length ? "No frames match the filter." : "Relay traffic will appear here as the page connects."}</div>`;
      return;
    }
    list.innerHTML = filtered.map(([index, log]) => {
      const dir = log.dir === "out" ? "out" : log.dir === "sys" ? "sys" : log.type?.startsWith("BLOCKED") ? "blocked" : "in";
      const arrow = dir === "out" ? "\u2192" : dir === "sys" ? "\u2022" : dir === "blocked" ? "\xD7" : "\u2190";
      return `<button type="button" class="ba-log" data-log-index="${index}" title="${h(log.summary || "")}">
        <span class="ba-log-dir ${dir}">${arrow}</span>
        <span class="ba-log-time">${h(timeLabel(log.ts))}</span>
        <span class="ba-log-summary">${h(log.summary || log.type || "")}</span>
        <span class="ba-log-type">${h(short(hostOf(log.relay), 14))}</span>
      </button>`;
    }).join("");
  }
  function scheduleEnhance(force = false) {
    if (!state.enabledReady || state.settings.enabled === false) return;
    if (!force && document.hidden) {
      state.enhancePending = true;
      return;
    }
    if (state.enhanceTimer !== null) return;
    state.enhanceTimer = window.setTimeout(() => {
      state.enhanceTimer = null;
      enhanceAll();
    }, 120);
  }
  var CHAT_LABEL_RE = /\bBitchat\b/gi;
  var CHAT_LABEL_BLOCKED = [
    ".ag-msg-rich",
    ".ag-msg-content",
    ".ag-chat-row-preview",
    ".ag-msg-preview",
    ".ag-conv-preview",
    ".ag-composer",
    ".ag-msg-author",
    ".ag-users-name",
    ".ag-peer-modal-name",
    ".ag-qp-display-name",
    "textarea",
    "input",
    "select",
    "option",
    "pre",
    "code",
    "script",
    "style",
    "[contenteditable='true']"
  ].join(", ");
  function chatLabel(value) {
    return String(value || "").replace(CHAT_LABEL_RE, "Chat");
  }
  function removeTransientNativeToasts() {
    for (const toast2 of document.querySelectorAll(".ag-toast")) {
      const title = toast2.querySelector(".ag-toast-title")?.textContent || "";
      const detail = toast2.querySelector(".ag-toast-detail")?.textContent || "";
      const callsBlocked = !!state.settings.privacy.calls.disable;
      if (/running\s+locally\s+via\s+(?:wasm|webgpu)/i.test(detail) || /image\s+safety\s+classifier.*ready/i.test(title) || /\bwasm\b.*\bloaded\b|\bloaded\b.*\bwasm\b/i.test(`${title} ${detail}`) || callsBlocked && /call\s+(?:blocked|signaling failed|failed)|unable to join .*call/i.test(`${title} ${detail}`)) {
        toast2.remove();
      }
    }
  }
  function replaceBitchatText() {
    if (!state.enabledReady || state.settings.enabled === false || !document.body) return;
    const now = performance.now();
    if (now - state.lastBitchatReplace < 350) {
      if (state.bitchatTimer === null) {
        state.bitchatTimer = window.setTimeout(() => {
          state.bitchatTimer = null;
          replaceBitchatText();
        }, 350 - (now - state.lastBitchatReplace));
      }
      return;
    }
    state.lastBitchatReplace = now;
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        if (!CHAT_LABEL_RE.test(node.nodeValue || "")) {
          CHAT_LABEL_RE.lastIndex = 0;
          return NodeFilter.FILTER_REJECT;
        }
        CHAT_LABEL_RE.lastIndex = 0;
        const parent = node.parentElement;
        if (!parent || parent.closest(CHAT_LABEL_BLOCKED)) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    for (const node of nodes) node.nodeValue = chatLabel(node.nodeValue || "");
    for (const el of document.querySelectorAll("[aria-label], [title], [placeholder], [alt]")) {
      if (!(el instanceof HTMLElement) || el.closest(CHAT_LABEL_BLOCKED)) continue;
      for (const attr of ["aria-label", "title", "placeholder", "alt"]) {
        const value = el.getAttribute(attr);
        if (value && CHAT_LABEL_RE.test(value)) {
          CHAT_LABEL_RE.lastIndex = 0;
          el.setAttribute(attr, chatLabel(value));
        }
        CHAT_LABEL_RE.lastIndex = 0;
      }
    }
    if (/\bbitchat\b/i.test(document.title)) {
      document.title = document.title.replace(CHAT_LABEL_RE, "Chat");
      CHAT_LABEL_RE.lastIndex = 0;
    }
  }
  function scheduleBitchatReplace(delay = 80) {
    if (state.bitchatTimer !== null) return;
    state.bitchatTimer = window.setTimeout(() => {
      state.bitchatTimer = null;
      replaceBitchatText();
    }, delay);
  }
  function observeChatLabels() {
    if (typeof MutationObserver !== "function" || !document.body) return;
    const observer = new MutationObserver((records) => {
      for (const record of records) {
        if (record.type === "characterData") {
          if (CHAT_LABEL_RE.test(record.target.nodeValue || "")) {
            CHAT_LABEL_RE.lastIndex = 0;
            scheduleBitchatReplace();
            return;
          }
          CHAT_LABEL_RE.lastIndex = 0;
          continue;
        }
        if (record.type === "attributes") {
          const el = record.target;
          if (!(el instanceof Element)) continue;
          const value = el.getAttribute(record.attributeName || "");
          if (value && CHAT_LABEL_RE.test(value)) {
            CHAT_LABEL_RE.lastIndex = 0;
            scheduleBitchatReplace();
            return;
          }
          CHAT_LABEL_RE.lastIndex = 0;
          continue;
        }
        for (const node of record.addedNodes) {
          if (!(node instanceof Element)) continue;
          if (CHAT_LABEL_RE.test(node.textContent || "") || CHAT_LABEL_RE.test(node.getAttribute("aria-label") || "") || CHAT_LABEL_RE.test(node.getAttribute("title") || "")) {
            CHAT_LABEL_RE.lastIndex = 0;
            scheduleBitchatReplace();
            return;
          }
          CHAT_LABEL_RE.lastIndex = 0;
        }
      }
    });
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true,
      attributes: true,
      attributeFilter: ["aria-label", "title", "placeholder", "alt"]
    });
  }
  function maintainCallControls() {
    if (!state.enabledReady || state.settings.enabled === false) return;
    const now = Date.now();
    const elapsed = now - (state.lastCallMaintenance || 0);
    if (elapsed < 2e3) {
      if (state.callMaintenanceTimer === null) {
        state.callMaintenanceTimer = window.setTimeout(() => {
          state.callMaintenanceTimer = null;
          maintainCallControls();
        }, 2e3 - elapsed + 20);
      }
      return;
    }
    state.lastCallMaintenance = now;
    applyCallButtons();
    hideCallUi();
    markLocateButtons();
  }
  function enhanceAll() {
    if (!state.enabledReady || state.settings.enabled === false) return;
    if (!document.body) return;
    if (document.hidden) {
      state.enhancePending = true;
      return;
    }
    const observer = state.pageObserver;
    observer?.disconnect();
    try {
      if (document.querySelector(".ag-ctx-menu")) {
        enhanceContextMenu();
        return;
      }
      removeCallMenuItems();
      maintainCallControls();
      ensureSuiteButton();
      ensureToolbars();
      ensureComposerEmoji();
      decorateRows();
      cleanupRichObservers();
      enhanceContextMenu();
      markBetterClients();
      hideSelfTeleportBadges();
      removeTransientNativeToasts();
      scheduleBitchatReplace();
    } finally {
      state.pageObserverStart?.();
    }
  }
  function applyShortcutVisibility() {
    for (const node of document.querySelectorAll("[data-ba-rail], .ba-rail-slot")) node.remove();
    ensureSuiteButton();
  }
  function isGroupChatView() {
    const avatar = document.querySelector(".ag-header .ag-header-avatar.server");
    return avatar instanceof HTMLElement && avatar.getClientRects().length > 0;
  }
  function returnToPublicChat() {
    const railChat = document.querySelector(".ag-rail-bitchat");
    if (railChat instanceof HTMLElement) {
      railChat.click();
      return true;
    }
    const mobile = [...document.querySelectorAll(".ag-mtab-btn, .ag-mobile-tabbar button")].find(
      (el) => /(^|\s)chat(\s|$)/i.test(`${el.textContent || ""} ${el.getAttribute("aria-label") || ""}`) || !!el.querySelector('svg[class*="lucide-waves"]')
    );
    if (mobile instanceof HTMLElement) {
      mobile.click();
      return true;
    }
    const card = [...document.querySelectorAll(".ag-suite-card")].find(
      (el) => /chat/i.test(el.querySelector(".ag-suite-card-name")?.textContent || "")
    );
    if (card instanceof HTMLElement) {
      card.click();
      return true;
    }
    return false;
  }
  function ensureSuiteBetter() {
    const footer = document.querySelector(".ag-suite-footer");
    if (!footer) return;
    let button = footer.querySelector("[data-ba-suite-better]");
    if (!button) {
      button = document.createElement("button");
      button.type = "button";
      button.className = "ag-suite-util-btn ba-suite-better";
      button.setAttribute("data-ba-suite-better", "1");
      button.title = "Better Agnostr settings";
      button.setAttribute("aria-label", "Better Agnostr settings");
      button.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3Z"></path><path d="M19 17l.8 2.2L22 20l-2.2.8L19 23l-.8-2.2L16 20l2.2-.8L19 17Z"></path></svg><span>Better Agnostr</span>';
      footer.append(button);
    }
    footer.classList.add("ba-suite-footer-dynamic");
  }
  function ensureSuiteButton() {
    const footer = document.querySelector(".ag-suite-footer");
    for (const btn of document.querySelectorAll(".ag-suite-util-btn")) {
      if (btn.hasAttribute("data-ba-suite-better")) continue;
      const text = (btn.textContent || "").trim();
      if (/^(radar map|search|better)/i.test(text)) {
        btn.style.display = "none";
        btn.setAttribute("data-ba-suite-util-hidden", "1");
      } else if (/^settings/i.test(text)) {
        btn.style.removeProperty("display");
        btn.removeAttribute("data-ba-suite-util-hidden");
      }
    }
    if (!footer) return;
    footer.style.removeProperty("display");
    ensureSuiteBetter();
    const prev = footer.previousElementSibling;
    if (prev?.classList.contains("ag-suite-divider")) prev.style.removeProperty("display");
  }
  function activeEmojiGroup() {
    return EMOJI_GROUPS.find((group) => group.id === state.emojiCategory) || EMOJI_GROUPS[0];
  }
  function emojiPickerBodyHtml() {
    const active = activeEmojiGroup();
    const tabs = EMOJI_GROUPS.map(
      (group) => `<button type="button" class="ba-emoji-tab${group.id === active.id ? " is-active" : ""}" data-ba-emoji-tab="${group.id}" title="${h(group.label)}" aria-label="${h(group.label)}">${group.icon}</button>`
    ).join("");
    const items = active.emojis.map((emoji) => `<button type="button" class="ba-emoji-item" data-ba-emoji="${emoji}" aria-label="Insert ${emoji}">${emoji}</button>`).join("");
    return `<div class="ba-emoji-tabs">${tabs}</div><div class="ba-emoji-grid">${items}</div>`;
  }
  function emojiPicker() {
    let pop = document.querySelector(".ba-emoji-popover");
    if (!pop) {
      pop = document.createElement("div");
      pop.className = "ba-emoji-popover";
      pop.setAttribute("data-ba-emoji-picker", "1");
      pop.setAttribute("role", "dialog");
      pop.setAttribute("aria-label", "Emoji picker");
      pop.hidden = true;
      document.body.appendChild(pop);
    }
    if (!pop.dataset.ready) {
      pop.innerHTML = emojiPickerBodyHtml();
      pop.dataset.ready = "1";
    }
    return pop;
  }
  function hideEmojiPicker() {
    const pop = document.querySelector(".ba-emoji-popover");
    if (pop) pop.hidden = true;
    if (state.emojiAnchor instanceof HTMLElement) state.emojiAnchor.setAttribute("aria-expanded", "false");
    state.emojiAnchor = null;
  }
  function positionEmojiPicker(anchor) {
    const pop = emojiPicker();
    pop.hidden = false;
    const rect = anchor.getBoundingClientRect();
    const box = pop.getBoundingClientRect();
    const viewport = window.visualViewport;
    const width = viewport?.width || window.innerWidth;
    const height = viewport?.height || window.innerHeight;
    const offsetTop = viewport?.offsetTop || 0;
    const margin = 10;
    let left = Math.min(rect.left, width - box.width - margin);
    left = Math.max(margin, left);
    let top = rect.bottom + 7;
    if (top + box.height > height - margin) top = Math.max(margin + offsetTop, rect.top - box.height - 7);
    pop.style.left = `${Math.round(left)}px`;
    pop.style.top = `${Math.round(top)}px`;
  }
  function openEmojiPicker(anchor) {
    const pop = emojiPicker();
    if (!pop.hidden) {
      const same = state.emojiAnchor === anchor;
      state.emojiAnchor = anchor;
      if (same) {
        hideEmojiPicker();
        return;
      }
    }
    state.emojiAnchor = anchor;
    anchor.setAttribute("aria-expanded", "true");
    positionEmojiPicker(anchor);
    const first = pop.querySelector(".ba-emoji-tab.is-active, .ba-emoji-item");
    if (first instanceof HTMLElement) first.focus({ preventScroll: true });
  }
  function insertEmoji(emoji) {
    insertInto(composerTextarea(), emoji);
    hideEmojiPicker();
  }
  function ensureComposerEmoji() {
    for (const right of document.querySelectorAll(".ag-composer-right")) {
      if (right.querySelector("[data-ba-emoji-trigger='composer']")) continue;
      const button = document.createElement("button");
      button.type = "button";
      button.className = "ag-composer-icon-btn ba-emoji-btn";
      button.setAttribute("data-ba-emoji-trigger", "composer");
      button.setAttribute("aria-label", "Insert emoji");
      button.setAttribute("aria-expanded", "false");
      button.title = "Insert emoji";
      button.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><path d="M8 14s1.5 2 4 2 4-2 4-2"></path><line x1="9" x2="9.01" y1="9" y2="9"></line><line x1="15" x2="15.01" y1="9" y2="9"></line></svg>';
      const voice = right.querySelector('button[aria-label*="voice memo" i], button[title*="voice memo" i]');
      if (voice) voice.before(button);
      else right.prepend(button);
    }
  }
  function applyVoiceMemoVisibility() {
    const remove = state.settings.privacy.removeVoiceMemo !== false;
    for (const btn of document.querySelectorAll(
      '.ag-composer-dock button[aria-label*="voice memo" i], .ag-composer-dock button[title*="voice memo" i]'
    )) {
      if (!(btn instanceof HTMLElement)) continue;
      if (remove) {
        if (btn.dataset.baVoiceHidden !== "1") {
          btn.dataset.baVoiceDisplay = btn.style.display;
          btn.dataset.baVoiceHidden = "1";
        }
        btn.style.display = "none";
      } else if (btn.dataset.baVoiceHidden === "1") {
        btn.style.display = btn.dataset.baVoiceDisplay || "";
        delete btn.dataset.baVoiceHidden;
        delete btn.dataset.baVoiceDisplay;
      }
    }
  }
  function composerToolbarHtml() {
    const colorButtons = Object.entries(COLORS).map(
      ([code, value]) => `<button type="button" data-color="${code}" title="&amp;${code} \xB7 ${COLOR_NAMES[code]}" aria-label="${h(COLOR_NAMES[code])}" style="background:${value}"></button>`
    ).join("");
    return `
    <button type="button" class="ba-composer-toggle" data-ba-format-toggle="1" title="Formatting" aria-label="Toggle formatting bar" aria-expanded="false">Aa</button>
    <div class="ba-composer-bar" role="toolbar" aria-label="Message formatting">
      <button type="button" data-code="&l" title="Bold" aria-label="Bold">B</button>
      <button type="button" data-code="&o" title="Italic" aria-label="Italic" style="font-style:italic">I</button>
      <button type="button" data-code="&n" title="Underline" aria-label="Underline" style="text-decoration:underline">U</button>
      <button type="button" data-code="&m" title="Strikethrough" aria-label="Strikethrough" style="text-decoration:line-through">S</button>
      <button type="button" data-code="&k" title="Obfuscate" aria-label="Obfuscate">K</button>
      <button type="button" data-code="&g" title="Rainbow" aria-label="Rainbow">G</button>
      <button type="button" data-code="&r" title="Reset" aria-label="Reset formatting">R</button>
      <button type="button" class="ba-color-toggle" data-action="toggle-colors" title="Colors" aria-label="Colors" aria-expanded="false"></button>
      <div class="ba-color-popover" hidden>${colorButtons}</div>
    </div>`;
  }
  function ensureToolbars() {
    applyVoiceMemoVisibility();
    for (const dock of document.querySelectorAll(".ag-composer-dock")) {
      for (const old of dock.querySelectorAll(":scope > .ba-composer-bar")) old.remove();
      let head = dock.querySelector(":scope > .ba-composer-head");
      if (!head || !head.querySelector(".ba-composer-bar")) {
        if (!head) {
          head = document.createElement("div");
          head.className = "ba-composer-head";
        }
        head.innerHTML = composerToolbarHtml();
        if (head.dataset.baWired !== "1") {
          head.dataset.baWired = "1";
          head.addEventListener("mousedown", (event) => {
            if (event.target.closest("button")) event.preventDefault();
          });
        }
        if (!head.isConnected) dock.prepend(head);
      }
      const bar = head.querySelector(".ba-composer-bar");
      const hidden = state.settings.studio.showComposerToolbar === false;
      if (bar) bar.hidden = hidden;
      const toggle = head.querySelector("[data-ba-format-toggle]");
      if (toggle) toggle.setAttribute("aria-expanded", hidden ? "false" : "true");
    }
  }
  function rowDecorationIntact(row, ev) {
    if (row.dataset.baFlairSuppressed) {
      const suppressed = row.dataset.baFlairSuppressed;
      const limit = flairLimit(suppressed);
      if (limit > 0 && document.querySelectorAll(`.ag-msg-row.flair-${suppressed}`).length < limit) {
        delete row.dataset.baFlairSuppressed;
        return false;
      }
      return true;
    }
    if (!row.querySelector(".ba-json-btn, .ba-row-json-btn")) return false;
    if (row.dataset.baFlair) {
      if (!row.classList.contains("flair")) return false;
      if (!row.classList.contains(`flair-${row.dataset.baFlair}`)) return false;
      if (!row.querySelector(":scope > .ba-flair-layer")) return false;
      try {
        const expected = JSON.parse(row.dataset.baFlairVars || "{}");
        for (const [key, value] of Object.entries(expected)) {
          if (row.style.getPropertyValue(key) !== String(value)) return false;
        }
      } catch {
        return false;
      }
    }
    const rich = row.querySelector(".ag-msg-rich");
    const author = row.querySelector(".ag-msg-author");
    for (const el of [author, rich]) {
      if (!(el instanceof HTMLElement)) continue;
      if (el.dataset.baLineRainbow === "1" && !el.classList.contains("fmtRainbow")) return false;
      const expected = String(el.dataset.baLineClasses || "").split(" ").filter(Boolean);
      if (expected.some((cls) => !el.classList.contains(cls))) return false;
    }
    const ownPubkey = String(state.status?.pubkey || "").toLowerCase();
    const ownMessage = !!ev.pubkey && String(ev.pubkey).toLowerCase() === ownPubkey;
    const expectedBetter = isBetterClient(ev) || ownMessage && ownBetterClient();
    if (author && expectedBetter && !author.classList.contains("ba-better-name")) return false;
    if (row.dataset.baRichId && (!rich || rich.dataset.baRich !== row.dataset.baRichId)) return false;
    try {
      const expectedVars = JSON.parse(row.dataset.baLineVars || "{}");
      for (const vars of Object.values(expectedVars)) {
        for (const [key, value] of Object.entries(vars || {})) {
          if (row.style.getPropertyValue(key) !== value) return false;
        }
      }
    } catch {
      return false;
    }
    return true;
  }
  function repairRowNow(row) {
    if (!(row instanceof HTMLElement)) return false;
    if (state.repairingRows.has(row)) return true;
    if (!row.dataset.baDecorated && !row.dataset.baFlair && !row.querySelector(".fmtRainbow, [data-ba-line-rainbow]")) return false;
    const id = row.id?.startsWith("msg-") ? row.id.slice(4) : "";
    if (!id) return false;
    const ev = eventById(id);
    if (!ev) return false;
    if (rowDecorationIntact(row, ev)) return true;
    state.repairingRows.add(row);
    try {
      ensureRowButtons(row, id);
      markRowClientLabels(row, ev);
      decorateRow(row, ev);
      const ownPubkey = String(state.status?.pubkey || "").toLowerCase();
      row.dataset.baDecorated = `${id}:${state.settingsEpoch}:${ownPubkey}`;
    } finally {
      window.setTimeout(() => state.repairingRows.delete(row), 0);
    }
    return true;
  }
  function decorateRows() {
    const rows = document.querySelectorAll(".ag-msg-row");
    for (const row of rows) {
      if (!(row instanceof HTMLElement)) continue;
      if (row.classList.contains("is-system")) continue;
      const id = row.id?.startsWith("msg-") ? row.id.slice(4) : "";
      if (!id) continue;
      ensureRowButtons(row, id);
      const ev = eventById(id);
      if (!ev) {
        if (!state.pendingLookups.has(id) && state.pageReady) {
          state.pendingLookups.add(id);
          askPage("getEvent", { id }, 5e3).then((res) => {
            state.pendingLookups.delete(id);
            if (res?.event) {
              rememberEvent(res.event);
              scheduleEnhance();
            }
          });
        }
        continue;
      }
      const ownPubkey = String(state.status?.pubkey || "").toLowerCase();
      const signature = `${id}:${state.settingsEpoch}:${ownPubkey}`;
      if (row.dataset.baDecorated === signature && rowDecorationIntact(row, ev)) continue;
      markRowClientLabels(row, ev);
      decorateRow(row, ev);
      row.dataset.baDecorated = signature;
    }
  }
  function ensureRowButtons(row, id) {
    if (row.querySelector(".ba-json-btn, .ba-row-json-btn")) return;
    const actions = row.querySelector(".ag-msg-actions");
    const button = document.createElement("button");
    button.type = "button";
    button.className = actions ? "ag-msg-act-btn ba-json-btn" : "ba-row-json-btn";
    button.setAttribute("data-ba-json", id);
    button.title = "View event JSON";
    button.setAttribute("aria-label", "View event JSON");
    button.textContent = "{ }";
    button.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      button.blur();
      clearStuckHoverMenus(null);
      openViewer(id, "json");
    });
    if (actions) actions.prepend(button);
    else row.appendChild(button);
  }
  function eventHandle(ev) {
    const name = getTagValue(ev.tags, "n") || `agnon${String(ev.pubkey || "").slice(-4)}`;
    return `@${String(name).toLowerCase()}#${String(ev.pubkey || "").slice(-4).toLowerCase()}`;
  }
  function isBetterClientName(name) {
    return /^(betteragnostr|better-agnostr|better agnostr)$/i.test(String(name || "").trim());
  }
  function isBetterClient(ev) {
    return isBetterClientName(getTagValue(ev.tags, "client"));
  }
  function outgoingToolsReady() {
    const status = state.status;
    if (!status) return true;
    return status.signerHooked === true || status.nip07Patched === true;
  }
  function ownBetterClient() {
    return state.settings.client.name.trim().toLowerCase() === "betteragnostr" && state.settings.client.policies.chat === "spoof" && outgoingToolsReady();
  }
  function setBetterName(el, show) {
    if (el instanceof HTMLElement) el.classList.toggle("ba-better-name", !!show);
  }
  function knownBetterHandle(handle) {
    const value = String(handle || "").trim().toLowerCase();
    if (!value) return false;
    for (const [pubkey, known] of state.betterPeers) {
      if (known.toLowerCase() !== value) continue;
      return isBetterClientName(state.peerClients.get(pubkey)?.name);
    }
    return false;
  }
  function markRowClientLabels(row, ev) {
    if (!(row instanceof HTMLElement) || !ev) return;
    const author = row.querySelector(".ag-msg-author");
    if (!(author instanceof HTMLElement)) return;
    const ownPubkey = String(state.status?.pubkey || "").toLowerCase();
    const ownMessage = !!ev.pubkey && String(ev.pubkey).toLowerCase() === ownPubkey;
    const better = isBetterClient(ev) || ownMessage && ownBetterClient();
    setBetterName(author, better);
    author.classList.remove("ba-better-spoof", "ba-client-name");
    delete author.dataset.baClient;
  }
  function clientPillDisplay(raw) {
    const name = String(raw || "").trim();
    const lower = name.toLowerCase();
    if (!name) return null;
    if (lower === "agnostr") return { text: "Agnostr", cls: "ag-client-pill-agnostr" };
    if (lower === "glub.chat" || lower === "glubchat" || lower.startsWith("glub")) {
      return { text: "Glub.chat", cls: "ag-client-pill-glubchat" };
    }
    if (lower === "nymchat" || lower === "nym" || lower.includes("nymchat")) {
      return { text: "Nymchat", cls: "ag-client-pill-nymchat" };
    }
    if (/^betteragnostr$|^better-agnostr$|^better agnostr$/i.test(name)) {
      return { text: "BetterAgnostr", cls: "ba-client-pill-ba" };
    }
    const safe = name.length > 32 ? `${name.slice(0, 31)}\u2026` : name;
    return { text: safe === lower ? `${safe.charAt(0).toUpperCase()}${safe.slice(1)}` : safe, cls: "ba-client-pill-unknown" };
  }
  function syncPeerClientPill(modal) {
    const pill = modal.querySelector(".ag-peer-client-pill");
    const clientRow = [...modal.querySelectorAll(".ag-key-row")].find(
      (row) => row.querySelector(".ag-key-label")?.textContent?.trim().toUpperCase() === "CLIENT"
    );
    const fallback = !pill ? clientRow?.querySelector(".ag-key-value") : null;
    if (!(pill instanceof HTMLElement) && !(fallback instanceof HTMLElement)) return;
    const hexRow = [...modal.querySelectorAll(".ag-key-row")].find(
      (row) => row.querySelector(".ag-key-label")?.textContent?.trim().toUpperCase() === "HEX PUBKEY"
    );
    const pubkey = String(hexRow?.querySelector(".ag-key-value")?.textContent || "").trim().toLowerCase();
    if (!pubkey) return;
    const ownPubkey = String(state.status?.pubkey || "").toLowerCase();
    let client = state.peerClients.get(pubkey);
    if (!client && pubkey === ownPubkey && outgoingToolsReady() && state.settings.client.policies.chat === "spoof" && state.settings.client.name) {
      client = { name: state.settings.client.name, at: Date.now() };
    }
    if (!client) return;
    const display = clientPillDisplay(client.name);
    if (!display) return;
    const target = pill instanceof HTMLElement ? pill : fallback;
    if (!(target instanceof HTMLElement)) return;
    if (pill instanceof HTMLElement) {
      pill.textContent = display.text;
      pill.title = display.text;
      pill.setAttribute("aria-label", `Client: ${display.text}`);
      for (const cls of [...pill.classList]) {
        if (cls.startsWith("ag-client-pill-") || cls.startsWith("ba-client-pill-")) pill.classList.remove(cls);
      }
      pill.classList.add(display.cls);
      pill.dataset.baClientPill = "1";
    } else if (target.children.length === 0) {
      target.textContent = display.text;
      target.title = display.text;
      target.dataset.baClientPill = "1";
    }
  }
  function markBetterClients() {
    if (!state.enabledReady || state.settings.enabled === false) return;
    const now = Date.now();
    const elapsed = now - (state.lastBetterClients || 0);
    if (elapsed < 500) {
      if (state.betterClientsTimer === null) {
        state.betterClientsTimer = window.setTimeout(() => {
          state.betterClientsTimer = null;
          markBetterClients();
        }, 500 - elapsed + 20);
      }
      return;
    }
    state.lastBetterClients = now;
    const ownPubkey = String(state.status?.pubkey || "").toLowerCase();
    const ownBetter = ownBetterClient();
    for (const row of document.querySelectorAll(".ag-users-row")) {
      const handle = row.querySelector(".ag-users-name")?.textContent?.trim().toLowerCase() || "";
      const own = !!ownPubkey && handle.endsWith(`#${ownPubkey.slice(-4)}`);
      const better = knownBetterHandle(handle) || own && ownBetter;
      const nameEl = row.querySelector(".ag-users-name");
      setBetterName(nameEl, better);
      if (nameEl instanceof HTMLElement) {
        nameEl.classList.remove("ba-better-spoof", "ba-client-name");
        delete nameEl.dataset.baClient;
      }
    }
    for (const pop of document.querySelectorAll(".ag-quick-profile-popover")) {
      setBetterName(pop.querySelector(".ag-qp-display-name"), ownBetter);
    }
    for (const modal of document.querySelectorAll(".ag-peer-modal")) {
      const badges = modal.querySelector(".ag-peer-modal-badges");
      const isSelf = [...badges?.querySelectorAll(".ag-badge") || []].some(
        (badge) => badge.textContent?.trim().toLowerCase() === "you"
      );
      const nameEl = modal.querySelector(".ag-peer-modal-name");
      const label = (nameEl?.textContent || "").replace(/\s+/g, "").toLowerCase();
      const better = isSelf && ownBetter || knownBetterHandle(label);
      setBetterName(nameEl, better);
      if (nameEl instanceof HTMLElement) {
        nameEl.classList.remove("ba-better-spoof", "ba-client-name");
        delete nameEl.dataset.baClient;
      }
      syncPeerClientPill(modal);
    }
    for (const title of document.querySelectorAll(".ag-sheet-hero-title")) {
      const label = (title.textContent || "").replace(/\s+/g, "").toLowerCase();
      const better = knownBetterHandle(label) || !!ownPubkey && label.includes(ownPubkey.slice(-4)) && ownBetter;
      setBetterName(title, better);
    }
  }
  function hideSelfTeleportBadges() {
    for (const modal of document.querySelectorAll(".ag-peer-modal")) {
      const badges = modal.querySelector(".ag-peer-modal-badges");
      if (!badges) continue;
      const isSelf = [...badges.querySelectorAll(".ag-badge")].some(
        (badge) => badge.textContent?.trim().toLowerCase() === "you"
      );
      for (const badge of badges.querySelectorAll(".ag-badge")) {
        if (badge.textContent?.trim().toLowerCase() !== "teleport") continue;
        if (isSelf && state.settings.privacy.omitTeleport) {
          badge.dataset.baTeleportHidden = "1";
          badge.style.display = "none";
        } else if (badge.dataset.baTeleportHidden === "1") {
          badge.style.removeProperty("display");
          delete badge.dataset.baTeleportHidden;
        }
      }
    }
  }
  function clearStuckHoverMenus(hoveredRow = null) {
    if (document.querySelector(".ag-ctx-menu, .ag-rpicker, .ag-emoji-popover")) return;
    for (const row of document.querySelectorAll(".ag-msg-row.actions-open")) {
      if (row !== hoveredRow) row.classList.remove("actions-open");
    }
    for (const actions of document.querySelectorAll(".ag-msg-actions.picker-open")) {
      if (!hoveredRow || !hoveredRow.contains(actions)) actions.classList.remove("picker-open");
    }
    const active = document.activeElement;
    if (active instanceof HTMLElement && active.closest(".ag-msg-actions, .ba-row-json-btn") && (!hoveredRow || !hoveredRow.contains(active))) {
      active.blur();
    }
  }
  function decorateRow(row, ev) {
    const meta = parseGlubMeta(ev.tags);
    const hasGlub = !!(meta.rich || meta.fmt || meta.flair || meta.v) || getTagValue(ev.tags, "client")?.toLowerCase() === "glub.chat";
    const ownPubkey = String(state.status?.pubkey || "").toLowerCase();
    const ownMessage = !!ev.pubkey && String(ev.pubkey).toLowerCase() === ownPubkey;
    const better = isBetterClient(ev) || ownMessage && ownBetterClient();
    if (better && ev.pubkey) state.betterPeers.set(ev.pubkey.toLowerCase(), eventHandle(ev));
    if (hasGlub && state.settings.studio.renderInAgnostr && meta.flair && isValidFlair(meta.flair)) {
      applyFlair(row, ev, meta.flair);
    } else {
      clearFlair(row);
    }
    if (hasGlub && state.settings.studio.renderRichInAgnostr && meta.rich) {
      applyRichText(row, ev, meta);
    } else {
      restoreRich(row);
    }
    applyLineStyles(row, hasGlub ? meta : {});
  }
  function formatStateAt(template, placeholder) {
    const tpl = normalizeTemplate(template || "");
    if (!tpl) return null;
    let st = {
      color: null,
      bold: false,
      italic: false,
      underline: false,
      strike: false,
      obf: false,
      rainbow: false
    };
    for (const tok of tokenize(tpl)) {
      if (tok.t === "code") {
        st = nextFormatState(st, tok.c);
        continue;
      }
      if (tok.v.includes(placeholder)) return st;
    }
    return null;
  }
  function lineVisual(st) {
    if (!st) return null;
    const out = {};
    if (st.color) out.color = st.color;
    if (st.bold) out.bold = true;
    if (st.italic) out.italic = true;
    if (st.underline) out.underline = true;
    if (st.strike) out.strike = true;
    if (st.rainbow) out.rainbow = true;
    if (st.obf) out.obf = true;
    return Object.keys(out).length ? out : null;
  }
  function protectRainbowEmojis(el, enabled) {
    if (!(el instanceof HTMLElement)) return;
    if (!enabled) {
      const protectedSpans = el.querySelectorAll(".fmtEmoji[data-ba-emoji-protect='1']");
      if (!protectedSpans.length) return;
      for (const span of protectedSpans) span.replaceWith(document.createTextNode(span.textContent || ""));
      el.normalize();
      return;
    }
    const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const value = node.nodeValue || "";
        if (!value || node.parentElement?.closest(".fmtEmoji, pre, code, textarea, input, script, style")) return NodeFilter.FILTER_REJECT;
        EMOJI_DOM_RE.lastIndex = 0;
        return EMOJI_DOM_RE.test(value) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
      }
    });
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    for (const node of nodes) {
      const text = node.nodeValue || "";
      const fragment = document.createDocumentFragment();
      let last = 0;
      EMOJI_DOM_RE.lastIndex = 0;
      for (const match of text.matchAll(EMOJI_DOM_RE)) {
        const index = match.index ?? 0;
        if (index > last) fragment.append(text.slice(last, index));
        const span = document.createElement("span");
        span.className = "fmtEmoji";
        span.dataset.baEmojiProtect = "1";
        span.textContent = match[0];
        fragment.append(span);
        last = index + match[0].length;
      }
      if (last < text.length) fragment.append(text.slice(last));
      node.replaceWith(fragment);
    }
  }
  function applyLineClasses(el, prefix, vis, row) {
    if (!el) return;
    protectRainbowEmojis(el, !!vis?.rainbow);
    const classes = [
      `${prefix}`,
      `${prefix}-color`,
      `${prefix}-bold`,
      `${prefix}-italic`,
      `${prefix}-deco`
    ];
    for (const cls of classes) el.classList.toggle(cls, !!vis && (cls === prefix || (cls === `${prefix}-color` ? !!vis.color : cls === `${prefix}-bold` ? !!vis.bold : cls === `${prefix}-italic` ? !!vis.italic : !!(vis.underline || vis.strike))));
    if (vis?.rainbow) {
      el.dataset.baLineRainbow = "1";
      el.classList.add("fmtRainbow");
    } else if (el.dataset.baLineRainbow) {
      el.classList.remove("fmtRainbow");
      delete el.dataset.baLineRainbow;
    }
    if (vis?.obf) {
      if (!el.classList.contains("fmtObf")) {
        el.classList.add("fmtObf");
        delete el.dataset.obfText;
        delete el.dataset.obfStatic;
        obfBursts.delete(el);
      }
    } else if (el.classList.contains("fmtObf")) {
      const real = el.dataset.obfText;
      if (real != null) el.textContent = real;
      el.classList.remove("fmtObf");
      delete el.dataset.obfText;
      delete el.dataset.obfStatic;
      obfBursts.delete(el);
    }
    const activeLineClasses = [];
    for (const cls of classes) {
      if (el.classList.contains(cls)) activeLineClasses.push(cls);
    }
    if (vis?.rainbow) activeLineClasses.push("fmtRainbow");
    if (vis?.obf) activeLineClasses.push("fmtObf");
    if (activeLineClasses.length) el.dataset.baLineClasses = activeLineClasses.join(" ");
    else delete el.dataset.baLineClasses;
    const ns = prefix === "ba-line-name" ? "name" : "msg";
    const vars = {};
    if (vis?.color) {
      row.style.setProperty(`--ba-line-${ns}-color`, vis.color);
      vars[`--ba-line-${ns}-color`] = vis.color;
    } else {
      row.style.removeProperty(`--ba-line-${ns}-color`);
    }
    if (vis?.underline || vis?.strike) {
      const deco = [vis.underline ? "underline" : "", vis.strike ? "line-through" : ""].filter(Boolean).join(" ");
      row.style.setProperty(`--ba-line-${ns}-deco`, deco);
      vars[`--ba-line-${ns}-deco`] = deco;
    } else {
      row.style.removeProperty(`--ba-line-${ns}-deco`);
    }
    try {
      const all = JSON.parse(row.dataset.baLineVars || "{}");
      if (Object.keys(vars).length) all[ns] = vars;
      else delete all[ns];
      if (Object.keys(all).length) row.dataset.baLineVars = JSON.stringify(all);
      else delete row.dataset.baLineVars;
    } catch {
      delete row.dataset.baLineVars;
    }
  }
  function applyLineStyles(row, meta) {
    const enabled = state.settings.studio.renderRichInAgnostr !== false;
    const fmt = enabled ? meta.fmt : "";
    const nameVis = fmt ? lineVisual(formatStateAt(fmt, "{name}")) : null;
    const msgVis = fmt ? lineVisual(formatStateAt(fmt, "{msg}")) : null;
    const author = row.querySelector(".ag-msg-author");
    const root = row.querySelector(".ag-msg-rich");
    applyLineClasses(author, "ba-line-name", nameVis, row);
    applyLineClasses(root, "ba-line-msg", msgVis, row);
  }
  function clearFlair(row) {
    row.classList.remove("flair", "ba-flair", "flairQuiet", "ba-flair-static");
    for (const cls of [...row.classList]) {
      if (cls.startsWith("ba-flair-") || cls.startsWith("flair-")) row.classList.remove(cls);
    }
    row.querySelectorAll(":scope > .ba-flair-layer, :scope > .flairFx, :scope > .flairScan, :scope > .ba-flair-fx").forEach((n) => n.remove());
    row.removeAttribute("data-ba-flair");
    row.removeAttribute("data-flair");
    delete row.dataset.baFlairVars;
  }
  function flairStyleVars(vars) {
    return Object.entries(vars || {}).map(([k, v]) => `${k}:${v}`).join(";");
  }
  function applyFlair(row, ev, flair) {
    flair = flairName(flair);
    if (!flair) {
      clearFlair(row);
      return;
    }
    const classes = flairClass(flair).split(" ").filter(Boolean);
    const limit = flairLimit(flair);
    if (limit > 0 && !row.classList.contains(`flair-${flair}`)) {
      const active = document.querySelectorAll(`.ag-msg-row.flair-${flair}`).length;
      if (active >= limit) {
        clearFlair(row);
        row.dataset.baFlairSuppressed = flair;
        return;
      }
      delete row.dataset.baFlairSuppressed;
    }
    const layer = row.querySelector(":scope > .ba-flair-layer");
    const hasFx = !flairHasFx(flair) || !!layer?.querySelector(":scope > .flairFx");
    const hasScan = !flairOverlayInner(flair) || !!layer?.querySelector(":scope > .flairScan");
    const hasClasses = classes.every((cls) => row.classList.contains(cls));
    const quiet = !!state.settings.studio.reduceMotion;
    let hasVars = false;
    try {
      const saved = JSON.parse(row.dataset.baFlairVars || "{}");
      const entries = Object.entries(saved);
      hasVars = entries.length === 0 ? row.dataset.baFlairVars === "{}" : entries.every(([k, v]) => row.style.getPropertyValue(k) === String(v));
    } catch {
    }
    if (row.dataset.baFlair === flair && hasClasses && layer && hasFx && hasScan && hasVars) {
      row.classList.toggle("flairQuiet", quiet);
      layer.classList.toggle("flairQuiet", quiet);
      return;
    }
    clearFlair(row);
    const vars = flairVars(flair);
    row.dataset.baFlairVars = JSON.stringify(vars);
    for (const cls of classes) row.classList.add(cls);
    row.dataset.baFlair = flair;
    for (const [k, v] of Object.entries(vars)) row.style.setProperty(k, v);
    if (quiet) row.classList.add("flairQuiet");
    const wrap = document.createElement("span");
    wrap.className = "ba-flair-layer";
    wrap.setAttribute("aria-hidden", "true");
    for (const cls of classes) wrap.classList.add(cls);
    if (quiet) wrap.classList.add("flairQuiet");
    if (flairHasFx(flair)) {
      const fx = document.createElement("span");
      fx.className = "flairFx";
      fx.setAttribute("aria-hidden", "true");
      fx.innerHTML = flairFxInner(flair);
      wrap.appendChild(fx);
    }
    const overlay = flairOverlayInner(flair);
    if (overlay) wrap.insertAdjacentHTML("beforeend", overlay);
    row.prepend(wrap);
  }
  function cleanupRichObservers() {
    for (const root of state.richRoots) {
      if (root.isConnected) continue;
      const observer = state.richObservers.get(root);
      observer?.disconnect();
      state.richObservers.delete(root);
      state.richRoots.delete(root);
    }
  }
  function ensureRichObserver(root) {
    if (state.richObservers.has(root) || typeof MutationObserver !== "function") return;
    const observer = new MutationObserver((records) => {
      if (state.richRepairing.has(root)) return;
      const obfuscationOnly = records.length > 0 && records.every((record) => {
        const node = record.target;
        const element = node instanceof Element ? node : node?.parentElement;
        return !!element?.closest?.(".fmtObf");
      });
      if (obfuscationOnly) return;
      const row = root.closest(".ag-msg-row");
      if (!(row instanceof HTMLElement)) return;
      const id = row.id?.startsWith("msg-") ? row.id.slice(4) : "";
      if (!id) return;
      const ev = eventById(id);
      if (!ev) return;
      const meta = parseGlubMeta(ev.tags);
      if (!meta.rich) return;
      state.richRepairing.add(root);
      try {
        applyRichText(row, ev, meta);
      } finally {
        window.setTimeout(() => state.richRepairing.delete(root), 0);
      }
    });
    observer.observe(root, { childList: true, subtree: true, characterData: true });
    state.richObservers.set(root, observer);
    state.richRoots.add(root);
  }
  function applyRichText(row, ev, meta) {
    const root = row.querySelector(".ag-msg-rich");
    if (!root) return;
    const previous = state.richApplied.get(root);
    if (previous && previous.id === ev.id && previous.html === root.innerHTML) return;
    const rich = meta.rich;
    if (!rich || typeof rich !== "string") return;
    if (rich.length > RICH_MAX) return;
    if (stripFormat(rich) !== ev.content) return;
    if (!hasFormat(rich)) return;
    if (!state.restoreMap.has(root)) state.restoreMap.set(root, root.innerHTML);
    const complex = root.querySelector("pre, code, img, audio, video, input, textarea, button, canvas, svg, .ag-codeblock, .ag-voice-player, .ag-img-card");
    const normalizedText = (root.textContent || "").replace(/\s+/g, " ").trim();
    const normalizedContent = String(ev.content || "").replace(/\s+/g, " ").trim();
    if (!complex && normalizedText === normalizedContent) {
      root.innerHTML = renderFormatHtml(rich);
      root.dataset.baRich = ev.id;
      row.dataset.baRichId = ev.id;
      state.richApplied.set(root, { id: ev.id, html: root.innerHTML, content: ev.content });
      ensureRichObserver(root);
      return;
    }
    const nodes = [];
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const parent = node.parentElement;
        if (!parent) return NodeFilter.FILTER_REJECT;
        if (parent.closest("pre, code, textarea, input, script, style")) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    while (walker.nextNode()) nodes.push(walker.currentNode);
    let st = {
      color: null,
      bold: false,
      italic: false,
      underline: false,
      strike: false,
      obf: false,
      rainbow: false
    };
    let changed = false;
    for (const node of nodes) {
      const text = node.nodeValue || "";
      if (!text || !text.includes("&")) continue;
      const tokens = tokenize(text);
      if (!tokens.some((t) => t.t === "code")) continue;
      const frag = document.createDocumentFragment();
      for (const tok of tokens) {
        if (tok.t === "code") {
          st = nextFormatState(st, tok.c);
          continue;
        }
        if (st.color || st.bold || st.italic || st.underline || st.strike || st.obf || st.rainbow) {
          const span = document.createElement("span");
          const style = stateStyle(st);
          if (style) span.style.cssText = style;
          const cls = stateClass(st);
          if (cls) span.className = cls;
          if (st.obf) span.dataset.obfText = tok.v;
          span.textContent = tok.v;
          frag.appendChild(span);
        } else {
          frag.appendChild(document.createTextNode(tok.v));
        }
      }
      node.replaceWith(frag);
      changed = true;
    }
    if (changed) {
      root.dataset.baRich = ev.id;
      row.dataset.baRichId = ev.id;
      state.richApplied.set(root, { id: ev.id, html: root.innerHTML, content: ev.content });
      ensureRichObserver(root);
    }
  }
  function nextFormatState(st, code) {
    const next = { ...st };
    if (code === "r") {
      return { color: null, bold: false, italic: false, underline: false, strike: false, obf: false, rainbow: false };
    }
    if (Object.prototype.hasOwnProperty.call(COLORS, code)) {
      return { color: COLORS[code], bold: false, italic: false, underline: false, strike: false, obf: false, rainbow: false };
    }
    if (code === "l") next.bold = true;
    else if (code === "o") next.italic = true;
    else if (code === "n") next.underline = true;
    else if (code === "m") next.strike = true;
    else if (code === "k") next.obf = true;
    else if (code === "g") {
      next.rainbow = true;
      next.color = null;
    }
    return next;
  }
  function restoreRich(row) {
    const root = row.querySelector(".ag-msg-rich");
    if (!root) return;
    const applied = state.richApplied.get(root);
    state.richApplied.delete(root);
    delete row.dataset.baRichId;
    const observer = state.richObservers.get(root);
    if (observer) {
      observer.disconnect();
      state.richObservers.delete(root);
      state.richRoots.delete(root);
    }
    if (!root.dataset.baRich) return;
    const current = (root.textContent || "").replace(/\s+/g, " ").trim();
    const expected = String(applied?.content || "").replace(/\s+/g, " ").trim();
    if (applied && expected && current !== expected) {
      delete root.dataset.baRich;
      state.restoreMap.delete(root);
      return;
    }
    const original = state.restoreMap.get(root);
    if (original != null) root.innerHTML = original;
    delete root.dataset.baRich;
    state.restoreMap.delete(root);
  }
  async function openViewer(id, tab = "json") {
    if (!id) return;
    const request = ++state.viewerRequestSeq;
    let ev = eventById(id);
    if (!ev && state.pageReady) {
      const res = await askPage("getEvent", { id });
      if (request !== state.viewerRequestSeq) return;
      if (res?.event) {
        ev = res.event;
        rememberEvent(ev);
      }
    }
    if (request !== state.viewerRequestSeq) return;
    if (!ev) {
      toast("warning", "Event not captured", "Open or reload the channel so the extension can observe relay traffic.");
      return;
    }
    state.viewer = { id, event: ev, tab, verified: state.verified.get(ev.id) || null, entities: state.entities.get(ev.id) || null };
    if (!state.entities.has(ev.id)) {
      askPage("entities", { id: ev.id, pubkey: ev.pubkey, kind: ev.kind }).then((res) => {
        if (res && state.viewer?.event?.id === ev.id) {
          state.entities.set(ev.id, res);
          state.viewer.entities = res;
          renderViewer();
        }
      });
    }
    renderViewer();
    setModalOpen("viewer", true);
  }
  function closeViewer() {
    state.viewerRequestSeq += 1;
    setModalOpen("viewer", false);
    state.viewer = null;
    const container = state.shadow?.querySelector("[data-role='viewer-content']");
    if (container) container.innerHTML = "";
    clearStuckHoverMenus(null);
  }
  function renderViewer() {
    if (!state.viewer) return;
    const container = state.shadow?.querySelector("[data-role='viewer-content']");
    if (!container) return;
    const { event, tab } = state.viewer;
    const meta = parseGlubMeta(event.tags);
    const build = effectiveBuild(state.settings);
    const stale = !!(meta.v && build && meta.v !== build);
    const reconstructed = event._reconstructed;
    const verified = state.verified.get(event.id);
    const entities = state.entities.get(event.id) || {};
    const tabs = [
      ["json", "JSON"],
      ["tags", "Tags"],
      ...meta.rich || meta.fmt || meta.flair ? [["glub", "Glub"]] : [],
      ["verify", "Verify"],
      ["relay", "Relay"]
    ];
    const tabButtons = tabs.map(
      ([id, label]) => `<button type="button" class="ba-modal-tab${id === tab ? " is-active" : ""}" data-viewer-tab="${id}" role="tab" aria-selected="${id === tab ? "true" : "false"}">${label}</button>`
    ).join("");
    let body = "";
    if (tab === "json") {
      body = `${reconstructed ? `<div class="ba-warning">This event was reconstructed from Agnostr's local message store; it has no signature.</div>` : ""}
      <pre class="ba-json">${highlightJson(JSON.stringify(event, null, 2))}</pre>`;
    } else if (tab === "tags") {
      const rows = (event.tags || []).map(
        (t, i) => `<tr><td>${i}</td><td>${h(t?.[0] ?? "")}</td><td>${h(t?.[1] ?? "")}</td><td>${h(t?.[2] ?? "")}</td><td>${h(t?.[3] ?? "")}</td></tr>`
      ).join("");
      body = `<table class="ba-tags"><thead><tr><th>#</th><th>Name</th><th>Value</th><th>Relay</th><th>Marker</th></tr></thead><tbody>${rows || `<tr><td colspan="5" class="ba-empty">No tags.</td></tr>`}</tbody></table>`;
    } else if (tab === "glub") {
      body = `${stale ? `<div class="ba-warning">Build mismatch: this event says <code class="ba-code">${h(meta.v)}</code> but glub.chat currently serves <code class="ba-code">${h(build)}</code>. glub will drop it.</div>` : meta.v ? `<div class="ba-warning ok">Build ${h(meta.v)} matches the live glub.chat build.</div>` : ""}
      ${renderLinePreview(event, meta)}`;
    } else if (tab === "verify") {
      body = `
      <div class="ba-meta-grid">
        <div class="ba-meta-cell"><div class="ba-meta-k">status</div><div class="ba-meta-v">${verified ? verified.ok ? "valid signature" : "invalid" : "not checked"}</div></div>
        <div class="ba-meta-cell"><div class="ba-meta-k">event id</div><div class="ba-meta-v">${h(event.id || "")}</div></div>
        <div class="ba-meta-cell"><div class="ba-meta-k">pubkey</div><div class="ba-meta-v">${h(event.pubkey || "")}</div></div>
        <div class="ba-meta-cell"><div class="ba-meta-k">created</div><div class="ba-meta-v">${h(dateLabel(event.created_at))}</div></div>
      </div>
      ${verified ? `<div class="ba-warning ${verified.ok ? "ok" : "err"}">${h(verified.ok ? "Signature and id verify against the event fields." : verified.error || "Verification failed.")}</div>` : `<div class="ba-hint">Click verify signature to check the event with the page's own nostr-tools build.</div>`}
      <button type="button" class="ba-btn" data-action="verify-event">verify signature</button>`;
    } else {
      const eventIds = /* @__PURE__ */ new Set([event.id]);
      const alias = state.aliases.get(event.id);
      if (alias) eventIds.add(alias);
      for (const [from, to] of state.aliases) if (to === event.id) eventIds.add(from);
      const rows = state.logs.filter((log) => eventIds.has(log.eventId)).slice(-30).reverse().map(
        (log) => `<div class="ba-kv"><span>${h(log.dir)} \xB7 ${h(hostOf(log.relay))}</span><span>${h(log.type)} \xB7 ${h(timeLabel(log.ts))}</span></div>`
      ).join("");
      body = rows ? `<div class="ba-scrollbox">${rows}</div>` : `<div class="ba-empty">No relay frames for this event in the current session.</div>`;
    }
    container.innerHTML = `
    <div class="ba-modal-head">
      <div>
        <div class="ba-modal-title">Event</div>
        <div class="ba-modal-sub">${h(kindLabel(event.kind))} \xB7 ${h(short(event.id || "", 20))} \xB7 ${h(dateLabel(event.created_at))}</div>
      </div>
      <div class="ba-modal-space"></div>
      <button type="button" class="ba-icon-btn" data-close-modal="viewer" aria-label="Close">\u2715</button>
    </div>
    <div class="ba-modal-tabs" role="tablist" aria-label="Event details sections">${tabButtons}</div>
    <div class="ba-modal-body">
      <div class="ba-meta-grid">
        <div class="ba-meta-cell"><div class="ba-meta-k">kind</div><div class="ba-meta-v">${h(event.kind)} \xB7 ${h(kindLabel(event.kind))}</div></div>
        <div class="ba-meta-cell"><div class="ba-meta-k">id</div><div class="ba-meta-v">${h(short(event.id || "", 26))}</div></div>
        <div class="ba-meta-cell"><div class="ba-meta-k">pubkey</div><div class="ba-meta-v">${h(short(event.pubkey || "", 26))}</div></div>
        <div class="ba-meta-cell"><div class="ba-meta-k">created</div><div class="ba-meta-v">${h(timeLabel(event.created_at))}</div></div>
        <div class="ba-meta-cell"><div class="ba-meta-k">content</div><div class="ba-meta-v">${h(String(event.content || "").slice(0, 80))}</div></div>
      </div>
      ${body}
    </div>
    <div class="ba-modal-actions">
      <button type="button" class="ba-btn" data-action="copy-json">Copy JSON</button>
      <button type="button" class="ba-btn" data-action="download-json">Download</button>
      <button type="button" class="ba-btn" data-action="copy-id">Copy ID</button>
      <button type="button" class="ba-btn" data-action="copy-pubkey">Copy pubkey</button>
      <button type="button" class="ba-btn" data-action="copy-npub">Copy npub</button>
      <button type="button" class="ba-btn" data-action="open-njump">Open in njump</button>
      <span class="ba-space"></span>
      ${entities.npub ? `<span class="ba-hint">${h(short(entities.npub, 24))}</span>` : ""}
    </div>`;
  }
  function eventAvatarSrc(event) {
    const row = document.getElementById(`msg-${event.id}`);
    const img = row?.querySelector(".ag-msg-avatar-btn img, .ag-stream-avatar, .ag-profile-avatar");
    const src = img?.getAttribute("src");
    if (src) return src;
    return previewAvatarSrc();
  }
  function renderLinePreview(event, meta) {
    const name = getTagValue(event.tags, "n") || `agnon${String(event.pubkey || "").slice(-4)}`;
    const tag = String(event.pubkey || "").slice(-4);
    const rich = meta.rich || "";
    const msgHtml = rich && stripFormat(rich) === event.content ? renderFormatHtml(rich) : h(event.content || "");
    let line;
    try {
      line = meta.fmt ? renderLineHtml(meta.fmt, { name, tag, msgHtml, msgText: event.content || "" }) : msgHtml;
    } catch {
      line = msgHtml;
    }
    const flair = meta.flair && isValidFlair(meta.flair) ? meta.flair : "";
    return previewBlockHtml({
      name,
      tag,
      avatar: eventAvatarSrc(event),
      line,
      flair,
      reduceMotion: state.settings.studio.reduceMotion
    });
  }
  function highlightJson(text) {
    const escaped = String(text).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    const re = /("(?:\\.|[^"\\])*")(\s*:)?|\b(true|false)\b|\b(null)\b|(-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)/g;
    return escaped.replace(re, (match, str, colon, bool, nul, num) => {
      if (str) return `<span class="${colon ? "j-key" : "j-str"}">${str}</span>${colon || ""}`;
      if (bool) return `<span class="j-bool">${bool}</span>`;
      if (nul) return `<span class="j-null">${nul}</span>`;
      if (num) return `<span class="j-num">${num}</span>`;
      return match;
    });
  }
  function queueReview(payload, requestId) {
    if (!state.shadow?.querySelector("[data-role='review-content']")) {
      sendPage("response", { action: "cancel" }, requestId);
      toast("warning", "Review unavailable", "The outgoing event was cancelled because the review UI is not ready.");
      return;
    }
    if (state.reviewQueue.length >= 8) {
      sendPage("response", { action: "cancel" }, requestId);
      toast("warning", "Review queue full", "The outgoing event was cancelled; finish the open reviews and try again.");
      return;
    }
    state.reviewQueue.push({ payload, requestId });
    if (!state.review) openNextReview();
  }
  function reviewCountdown() {
    if (!state.review) return "review expired";
    const seconds = Math.max(0, Math.ceil((state.review.deadline - Date.now()) / 1e3));
    return `${seconds}s left`;
  }
  function openNextReview() {
    const next = state.reviewQueue.shift();
    if (!next) return;
    state.review = { ...next, selected: /* @__PURE__ */ new Set(), timer: null, ticker: null, deadline: Date.now() + 174e3 };
    renderReview();
    setModalOpen("review", true);
    state.review.timer = window.setTimeout(() => finishReview("cancel"), 174e3);
    state.review.ticker = window.setInterval(() => {
      const el = state.shadow?.querySelector("[data-role='review-timer']");
      if (el) el.textContent = reviewCountdown();
    }, 1e3);
  }
  function finishReview(action, scrub = false) {
    if (!state.review) return;
    const review = state.review;
    window.clearTimeout(review.timer);
    if (review.ticker) window.clearInterval(review.ticker);
    const payload = action === "send" ? { action: "send", stripTagIndexes: scrub ? [...review.selected] : [] } : { action: "cancel" };
    sendPage("response", payload, review.requestId);
    state.review = null;
    setModalOpen("review", false);
    const container = state.shadow?.querySelector("[data-role='review-content']");
    if (container) container.innerHTML = "";
    if (state.reviewQueue.length) openNextReview();
  }
  function renderReview() {
    if (!state.review) return;
    const container = state.shadow?.querySelector("[data-role='review-content']");
    if (!container) return;
    const { payload } = state.review;
    const proposed = payload.proposed || {};
    const meta = parseGlubMeta(proposed.tags || []);
    const important = /* @__PURE__ */ new Set(["g", "d", "e", "p", "k", "h", "a", "q"]);
    const tags = (proposed.tags || []).map((tag, index) => {
      const name = tag?.[0] || "";
      const value = tag?.slice(1).join(" ") || "";
      const disabled = important.has(name) || name === "glub";
      return `<label class="ba-review-tag">
      <input type="checkbox" data-review-tag="${index}" ${disabled ? "disabled" : ""}>
      <span class="ba-review-name">${h(name)}</span>
      <span class="ba-review-val">${h(value)}</span>
    </label>`;
    }).join("");
    container.innerHTML = `
    <div class="ba-modal-head">
      <div>
        <div class="ba-modal-title">review outgoing ${h(kindLabel(proposed.kind))}</div>
        <div class="ba-modal-sub">${h(payload.group || kindGroup(proposed.kind))} \xB7 check a tag to remove it before signing \xB7 <span data-role="review-timer">${h(reviewCountdown())}</span></div>
      </div>
      <div class="ba-modal-space"></div>
      <button type="button" class="ba-icon-btn" data-action="review-cancel" aria-label="Cancel">\u2715</button>
    </div>
    <div class="ba-modal-body">
      <div class="ba-warning">This event is paused before signing. Nothing has left your client yet.</div>
      <div class="ba-meta-grid">
        <div class="ba-meta-cell"><div class="ba-meta-k">kind</div><div class="ba-meta-v">${h(proposed.kind)} \xB7 ${h(kindLabel(proposed.kind))}</div></div>
        <div class="ba-meta-cell"><div class="ba-meta-k">content</div><div class="ba-meta-v"><pre class="ba-review-content">${h(String(proposed.content || ""))}</pre></div></div>
        ${String(payload.original?.content || "") !== String(proposed.content || "") ? `<div class="ba-meta-cell"><div class="ba-meta-k">original</div><div class="ba-meta-v"><pre class="ba-review-content">${h(String(payload.original?.content || ""))}</pre></div></div>` : ""}
        <div class="ba-meta-cell"><div class="ba-meta-k">source</div><div class="ba-meta-v">${h(payload.source || "provider")}</div></div>
      </div>
      <div class="ba-card-head" style="margin-top:4px"><span class="ba-card-title">Tags</span><span class="ba-head-space"></span><span class="ba-hint">hover to read</span></div>
      <div class="ba-scrollbox">${tags || `<div class="ba-empty">No tags.</div>`}</div>
      ${meta.rich || meta.fmt || meta.flair ? `<div style="margin-top:10px">${renderLinePreview(proposed, meta)}</div>` : ""}
    </div>
    <div class="ba-modal-actions">
      <button type="button" class="ba-btn primary" data-action="review-send">send as proposed</button>
      <button type="button" class="ba-btn" data-action="review-scrub">send with checked removals</button>
      <span class="ba-space"></span>
      <button type="button" class="ba-btn danger" data-action="review-cancel">cancel</button>
    </div>`;
  }
  document.addEventListener(
    "click",
    (event) => {
      if (!state.enabledReady || state.settings.enabled === false) return;
      const target = event.target;
      if (!(target instanceof Element)) return;
      const bar = target.closest(".ba-composer-bar");
      if (!bar) return;
      const colorToggle = target.closest("[data-action='toggle-colors']");
      if (colorToggle) {
        event.preventDefault();
        event.stopPropagation();
        const pop = bar.querySelector(".ba-color-popover");
        if (pop) {
          pop.hidden = !pop.hidden;
          colorToggle.setAttribute("aria-expanded", pop.hidden ? "false" : "true");
        }
        return;
      }
      const codeBtn = target.closest("[data-code]");
      if (codeBtn) {
        event.preventDefault();
        event.stopPropagation();
        insertInto(composerTextarea(bar), codeBtn.getAttribute("data-code") || "");
        return;
      }
      const color = target.closest("[data-color]");
      if (color) {
        event.preventDefault();
        event.stopPropagation();
        insertInto(composerTextarea(bar), `&${color.getAttribute("data-color")}`);
        return;
      }
      const action = target.closest("[data-action]")?.getAttribute("data-action");
      if (action === "open-studio") {
        event.preventDefault();
        event.stopPropagation();
        openPanel("studio");
      } else if (action === "open-last") {
        event.preventDefault();
        event.stopPropagation();
        handleAction("inspect-last");
      }
    },
    true
  );
  document.addEventListener(
    "pointerdown",
    (event) => {
      if (!state.enabledReady || state.settings.enabled === false) return;
      const target = event.target;
      if (!(target instanceof Element)) return;
      if (target.closest(".ba-composer-bar")) event.preventDefault();
      const bar = target.closest(".ba-composer-bar");
      if (!bar) {
        for (const pop of document.querySelectorAll(".ba-composer-bar .ba-color-popover:not([hidden])")) pop.hidden = true;
      }
    },
    true
  );
  function authorMention(row, event) {
    let text = row?.querySelector(".ag-msg-author")?.textContent?.trim() || "";
    if (/^@[^#\s]+#?[0-9a-f]{0,4}$/i.test(text)) return text.startsWith("@") ? text : `@${text}`;
    const name = getTagValue(event?.tags, "n") || text.replace(/^@/, "").replace(/#[0-9a-f]{4}$/i, "").trim();
    const tag = event?.pubkey ? String(event.pubkey).slice(-4) : "";
    if (name) return `@${name}${tag ? `#${tag}` : ""}`;
    return text || "@friend";
  }
  function captureContextTarget(event) {
    if (!state.enabledReady || state.settings.enabled === false) return;
    const target = event.target;
    if (!(target instanceof Element)) {
      state.contextTarget = null;
      return;
    }
    const row = target.closest(".ag-msg-row");
    if (!(row instanceof HTMLElement) || !row.id?.startsWith("msg-")) {
      state.contextTarget = null;
      return;
    }
    const id = row.id.slice(4);
    const ev = eventById(id);
    state.contextTarget = { id, event: ev, mention: authorMention(row, ev), row };
  }
  function fitContextMenu(menu) {
    if (!(menu instanceof HTMLElement)) return;
    menu.style.overflowY = "auto";
    menu.style.overscrollBehavior = "contain";
    if (!menu.dataset.baWheel) {
      menu.dataset.baWheel = "1";
      menu.addEventListener("wheel", (event) => event.stopPropagation(), { passive: true });
    }
    window.requestAnimationFrame(() => {
      const margin = 12;
      const viewport = window.innerHeight;
      const rect = menu.getBoundingClientRect();
      if (rect.bottom > viewport - margin) {
        const top = Math.max(margin, viewport - margin - rect.height);
        if (top < rect.top) menu.style.top = `${top}px`;
      }
      const next = menu.getBoundingClientRect();
      menu.style.maxHeight = `${Math.max(180, viewport - Math.max(margin, next.top) - margin)}px`;
    });
  }
  function enhanceContextMenu() {
    const menu = document.querySelector(".ag-ctx-menu");
    if (!menu) return;
    if (menu.querySelector("[data-ba-actions]")) {
      fitContextMenu(menu);
      return;
    }
    const target = state.contextTarget;
    if (!target?.mention) return;
    const labels = [...menu.querySelectorAll(".ag-ctx-item-label")].map((el) => (el.textContent || "").trim().toLowerCase());
    const messageMenu = labels.some((label) => /^(reply|copy event id|view profile|block peer|mention\b)/.test(label));
    if (!messageMenu) return;
    const make = (kind, icon, label, title) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "ag-ctx-item";
      btn.setAttribute("data-ba-action", kind);
      btn.setAttribute("role", "menuitem");
      btn.tabIndex = 0;
      btn.title = title || label;
      const iconEl = document.createElement("span");
      iconEl.className = "ag-ctx-item-icon";
      iconEl.textContent = icon;
      const labelEl = document.createElement("span");
      labelEl.className = "ag-ctx-item-label";
      labelEl.textContent = label;
      btn.append(iconEl, labelEl);
      return btn;
    };
    const divider = document.createElement("div");
    divider.className = "ag-ctx-divider";
    divider.setAttribute("data-ba-actions", "1");
    divider.setAttribute("role", "separator");
    const items = [...menu.querySelectorAll(".ag-ctx-item")];
    const last = items[items.length - 1];
    if (last) last.after(divider);
    else menu.append(divider);
    divider.after(
      make("hug", "\u2661", "Hug", `Hug ${target.mention}`),
      make("slap", "\u270B", "Slap", `Slap ${target.mention}`),
      make("custom", "\u2726", "Custom action\u2026", `Send a custom action to ${target.mention}`)
    );
    fitContextMenu(menu);
  }
  function sendComposerText(text) {
    const ta = composerTextarea();
    if (!(ta instanceof HTMLTextAreaElement) || ta.disabled || ta.readOnly) {
      toast("warning", "Composer unavailable", "Open a channel or DM with a working composer first.");
      return false;
    }
    const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value")?.set;
    if (setter) setter.call(ta, text);
    else ta.value = text;
    ta.dispatchEvent(new Event("input", { bubbles: true }));
    ta.focus();
    try {
      ta.setSelectionRange(text.length, text.length);
    } catch {
    }
    const dock = ta.closest(".ag-composer-dock") || document;
    let tries = 0;
    const send = () => {
      const btn = dock.querySelector(".ag-composer-send-btn") || document.querySelector(".ag-composer-send-btn");
      if (btn instanceof HTMLElement && !btn.disabled) {
        btn.click();
        return;
      }
      tries += 1;
      if (tries < 12) {
        window.setTimeout(send, 50);
        return;
      }
      ta.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", bubbles: true, cancelable: true }));
    };
    window.setTimeout(send, 50);
    return true;
  }
  function closeContextMenu() {
    window.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true, cancelable: true }));
  }
  function sendAction(kind) {
    const target = state.contextTarget;
    if (!target?.mention) {
      toast("warning", "No message target", "Right-click a message and choose an action.");
      return;
    }
    let text = "";
    if (kind === "hug") text = `* hugs ${target.mention} *`;
    else if (kind === "slap") text = `* slaps ${target.mention} with a large trout *`;
    else {
      openCustomAction();
      return;
    }
    closeContextMenu();
    clearStuckHoverMenus(null);
    if (sendComposerText(text)) closePanel();
  }
  function selfMention() {
    const name = String(state.status?.nickname || "").trim();
    const pubkey = String(state.status?.pubkey || "").trim();
    const tag = pubkey ? pubkey.slice(-4) : "";
    if (!name && !tag) return "";
    return `@${name || "you"}${tag ? `#${tag}` : ""}`;
  }
  function formatActionText(raw, mention, sender) {
    const cleaned = String(raw || "").replace(/^\*+|\*+$/g, "").trim();
    if (!cleaned) return "";
    const core = cleaned.replace(/\{user\}/g, mention || "").replace(/\{sender\}/g, sender || "");
    return `* ${core} *`;
  }
  function insertCustomActionToken(token) {
    const input = state.shadow?.querySelector("#ba-custom-action-input");
    if (!input) return;
    insertInto(input, token);
  }
  function sendSlashAction(raw) {
    const match = String(raw || "").match(/^\/me\s*([\s\S]*)$/i);
    const text = match?.[1]?.trim() || "";
    if (!text) {
      toast("warning", "Nothing to send", "Write something after /me first.");
      return false;
    }
    const body = formatActionText(text, state.contextTarget?.mention || "", selfMention());
    if (!body) return false;
    return sendComposerText(body);
  }
  function closeActionModal() {
    setModalOpen("action", false);
    state.customAction = null;
    state.contextTarget = null;
    const container = state.shadow?.querySelector("[data-role='action-content']");
    if (container) container.innerHTML = "";
  }
  function renderCustomAction() {
    const container = state.shadow?.querySelector("[data-role='action-content']");
    if (!container || !state.customAction) return;
    const target = state.contextTarget;
    const action = state.customAction.text || state.settings.actions.custom || "boops";
    container.innerHTML = `
    <div class="ba-modal-head">
      <div>
        <div class="ba-modal-title">Custom action</div>
        <div class="ba-modal-sub">${h(target?.mention || "someone")}</div>
      </div>
      <div class="ba-modal-space"></div>
      <button type="button" class="ba-icon-btn" data-action="action-cancel" aria-label="Close">\u2715</button>
    </div>
    <div class="ba-modal-body">
      <label class="ba-label" for="ba-custom-action-input">Action</label>
      <input id="ba-custom-action-input" class="ba-input" maxlength="60" value="${h(action)}" spellcheck="false" autocomplete="off">
      <div class="ba-set-chips" style="margin-top:7px">
        <button type="button" class="ba-set-chip" data-action="action-insert-user" title="Insert the target user">{user}</button>
        <button type="button" class="ba-set-chip" data-action="action-insert-sender" title="Insert your name">{sender}</button>
      </div>
      <div class="ba-hint" style="margin-top:6px">Use <code class="ba-code">{user}</code> for the target and <code class="ba-code">{sender}</code> for your name. Nothing is appended automatically.</div>
      <div class="ba-card" style="margin-top:10px;margin-bottom:0">
        <div class="ba-card-head"><span class="ba-card-title">Preview</span></div>
        <div class="ba-preview-line" data-role="action-preview" style="font-size:13px"></div>
      </div>
    </div>
    <div class="ba-modal-actions">
      <button type="button" class="ba-btn primary" data-action="action-send">Send action</button>
      <span class="ba-space"></span>
      <button type="button" class="ba-btn" data-action="action-cancel">Cancel</button>
    </div>`;
    const input = container.querySelector("#ba-custom-action-input");
    const update = () => {
      const raw = input?.value || "";
      state.customAction.text = raw;
      const mention = target?.mention || "";
      const preview = formatActionText(raw, mention, selfMention());
      const p = container.querySelector("[data-role='action-preview']");
      if (p) p.textContent = preview;
    };
    update();
    input?.addEventListener("input", update);
    input?.focus();
    input?.select();
  }
  function openCustomAction() {
    if (!state.contextTarget?.mention) {
      toast("warning", "No message target", "Right-click a message first.");
      return;
    }
    closeContextMenu();
    clearStuckHoverMenus(null);
    state.customAction = { text: state.settings.actions.custom || "boops" };
    renderCustomAction();
    setModalOpen("action", true);
    window.requestAnimationFrame(() => {
      const input = state.shadow?.querySelector("#ba-custom-action-input");
      if (input instanceof HTMLInputElement) {
        input.focus();
        input.select();
      }
    });
  }
  function sendCustomAction() {
    const target = state.contextTarget;
    if (!target?.mention) {
      closeActionModal();
      return;
    }
    const raw = (state.customAction?.text || state.settings.actions.custom || "boops").trim();
    if (!raw) return;
    updateSettings((s) => {
      s.actions.custom = raw.slice(0, 60);
    });
    const body = formatActionText(raw, target.mention, selfMention());
    if (!body) return;
    closeActionModal();
    clearStuckHoverMenus(null);
    if (sendComposerText(body)) closePanel();
  }
  document.addEventListener(
    "click",
    (event) => {
      if (!state.enabledReady || state.settings.enabled === false) return;
      const target = event.target;
      if (!(target instanceof Element)) return;
      const card = target.closest(".ag-suite-card");
      if (!card) return;
      const name = card.querySelector(".ag-suite-card-name")?.textContent?.trim().toLowerCase();
      if (name !== "chat" || !isGroupChatView()) return;
      window.setTimeout(() => returnToPublicChat(), 0);
    },
    true
  );
  document.addEventListener("contextmenu", captureContextTarget, true);
  document.addEventListener(
    "click",
    (event) => {
      if (!state.enabledReady || state.settings.enabled === false) return;
      const target = event.target;
      if (!(target instanceof Element)) return;
      const btn = target.closest("[data-ba-action]");
      if (!btn) return;
      event.preventDefault();
      event.stopPropagation();
      const kind = btn.getAttribute("data-ba-action");
      if (kind === "custom") openCustomAction();
      else sendAction(kind);
    },
    true
  );
  document.addEventListener(
    "mousedown",
    (event) => {
      if (!state.enabledReady || state.settings.enabled === false) return;
      const target = event.target;
      if (!(target instanceof Element)) return;
      if (target.closest("[data-ba-action]")) {
        event.preventDefault();
        event.stopPropagation();
      }
    },
    true
  );
  function toastIcon(level) {
    if (level === "success") {
      return '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg>';
    }
    if (level === "warning") {
      return '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10.3 3.7 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.7a2 2 0 0 0-3.4 0Z"></path><path d="M12 9v4"></path><path d="M12 17h.01"></path></svg>';
    }
    if (level === "error") {
      return '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><path d="M12 8v4"></path><path d="M12 16h.01"></path></svg>';
    }
    return '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><path d="M12 16v-4"></path><path d="M12 8h.01"></path></svg>';
  }
  function toast(level, title, detail = "") {
    const root = state.shadow;
    if (!root) return;
    const container = root.querySelector("[data-role='toasts']");
    if (!container) return;
    const key = `${level}:${title}:${detail}`;
    const now = Date.now();
    const cooldown = level === "error" ? 15e3 : 8e3;
    if (now - Number(toastCooldowns.get(key) || 0) < cooldown) return;
    toastCooldowns.set(key, now);
    if (toastCooldowns.size > 80) {
      const first = toastCooldowns.keys().next().value;
      if (first) toastCooldowns.delete(first);
    }
    for (const existing of container.querySelectorAll(".ba-toast")) {
      if (existing.dataset.baToastKey === key) return;
    }
    while (container.children.length >= 5) container.firstElementChild?.remove();
    const node = document.createElement("div");
    node.className = `ba-toast ${level}`;
    node.dataset.baToastKey = key;
    node.setAttribute("role", level === "error" ? "alert" : "status");
    node.innerHTML = `<span class="ba-toast-icon">${toastIcon(level)}</span><div class="ba-toast-copy"><div class="ba-toast-title">${h(title)}</div>${detail ? `<div class="ba-toast-detail">${h(detail)}</div>` : ""}</div><button type="button" class="ba-toast-close" aria-label="Dismiss">\xD7</button>`;
    const close = node.querySelector(".ba-toast-close");
    let timer = null;
    const remove = () => {
      if (timer !== null) {
        window.clearTimeout(timer);
        state.toasts.delete(timer);
      }
      node.remove();
    };
    close?.addEventListener("click", remove);
    container.appendChild(node);
    timer = window.setTimeout(remove, level === "error" ? 7e3 : 4200);
    state.toasts.add(timer);
  }
  async function copyText(text, message = "Copied") {
    try {
      await navigator.clipboard.writeText(text);
      toast("success", message);
    } catch {
      toast("warning", "Clipboard unavailable", "Select and copy the text manually.");
    }
  }
  function downloadJson(event) {
    try {
      const blob = new Blob([JSON.stringify(event, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `nostr-event-${event.id?.slice(0, 12) || "event"}.json`;
      a.click();
      window.setTimeout(() => URL.revokeObjectURL(url), 2e3);
      toast("success", "JSON downloaded");
    } catch (err) {
      toast("error", "Download failed", String(err));
    }
  }
  function renderDiagnostics() {
    const root = state.shadow;
    if (!root) return;
    const el = root.querySelector("[data-role='diagnostics']");
    if (!el) return;
    const status = state.status || {};
    const extensionVersion = api.runtime.getManifest?.().version || VERSION;
    el.innerHTML = `
    <div class="ba-kv"><span>extension</span><span>${h(extensionVersion)}</span></div>
    <div class="ba-kv"><span>page bridge</span><span>${state.pageReady ? "ready" : "waiting"}</span></div>
    <div class="ba-kv"><span>signer</span><span>${status.signerHooked ? h(status.signMode || "attached") : "no"}</span></div>
    <div class="ba-kv"><span>nip-07 rewriter</span><span>${status.nip07Patched ? "yes" : "no"}</span></div>
    <div class="ba-kv"><span>pubkey</span><span>${h(short(status.pubkey || "", 20))}</span></div>
    <div class="ba-kv"><span>glub build</span><span>${h(effectiveBuild(state.settings) || "missing")}</span></div>
    <div class="ba-kv"><span>events in memory</span><span>${state.events.size}</span></div>
    <div class="ba-kv"><span>relay frames</span><span>${state.logs.length}</span></div>
    <div class="ba-kv"><span>review queue</span><span>${state.reviewQueue.length}</span></div>`;
  }
  function copyDiagnostics() {
    const status = state.status || {};
    const text = [
      `Better Agnostr ${api.runtime.getManifest?.().version || VERSION}`,
      `url: ${location.href}`,
      `page bridge: ${state.pageReady}`,
      `signer: ${status.signerHooked ? status.signMode || "attached" : "no"}`,
      `nip07 rewriter: ${status.nip07Patched}`,
      `pubkey: ${status.pubkey}`,
      `glub build: ${effectiveBuild(state.settings)}`,
      `events: ${state.events.size}`,
      `logs: ${state.logs.length}`,
      `build error: ${state.buildError || "none"}`
    ].join("\n");
    copyText(text, "Diagnostics copied");
  }
  function observePage() {
    const relevantSelector = [
      ".ag-msg-row",
      ".ag-msg-actions",
      ".ag-msg-head",
      ".ag-app-rail",
      ".ag-bitchat-drawer",
      ".ag-bitchat-quickbar",
      ".ag-bitchat-globe-stage",
      ".ag-suite-footer",
      ".ag-toast-stack",
      ".ag-toast",
      ".ag-rail-srv",
      ".ag-srv-mobile-rail",
      ".ag-mobile-tabbar",
      ".ag-composer-dock",
      ".ag-composer-right",
      ".ag-suite-popover",
      ".ag-suite-footer",
      ".ag-conv-footer",
      ".ag-conv-header",
      ".ag-conv-pane",
      ".ag-header",
      ".ag-srv-discord-pane",
      ".ag-srv-pane-pane",
      ".ag-srv-mobile-split",
      ".ag-settings-modal",
      ".ag-peer-modal",
      ".ag-sheet",
      ".ag-info-sheet",
      ".ag-quick-profile-popover",
      ".ag-ctx-menu"
    ].join(",");
    const observer = new MutationObserver((records) => {
      if (document.hidden) {
        scheduleEnhance();
        return;
      }
      let relevant = false;
      let urgentCallUi = false;
      for (const record of records) {
        if (record.type === "childList") {
          const target = record.target;
          const row = target instanceof Element ? target.closest(".ag-msg-row") : null;
          if (row) {
            if (!repairRowNow(row)) {
              delete row.dataset.baDecorated;
              relevant = true;
            }
          }
          for (const node of [...record.addedNodes, ...record.removedNodes]) {
            if (!(node instanceof Element)) continue;
            if (node.matches(relevantSelector) || node.querySelector(relevantSelector)) {
              relevant = true;
              if (node.matches(".ag-sheet, .ag-info-sheet, .ag-ctx-menu, .ag-peer-modal") || node.querySelector(".ag-sheet, .ag-info-sheet, .ag-ctx-menu, .ag-peer-modal")) {
                urgentCallUi = true;
              }
              break;
            }
          }
        } else if (record.type === "attributes") {
          const el = record.target;
          if (el instanceof Element) {
            const row = el.closest(".ag-msg-row");
            if (row && repairRowNow(row)) {
              continue;
            }
          }
          if (el === document.documentElement || el === document.body || el instanceof Element && (el.matches(relevantSelector) || el.closest(relevantSelector))) {
            relevant = true;
          }
        }
        if (relevant) break;
      }
      if (!relevant) return;
      if (urgentCallUi) {
        applyCallButtons();
        hideCallUi();
        removeCallMenuItems();
      }
      scheduleEnhance();
      scheduleSettingsSync();
      if (state.settings.privacy.calls.disable && state.settings.privacy.calls.hideUi) removeCallMenuItems();
    });
    state.pageObserver = observer;
    state.pageObserverStart = () => {
      try {
        observer.observe(document.documentElement, {
          childList: true,
          subtree: true,
          attributes: true,
          attributeFilter: ["class"]
        });
      } catch {
      }
    };
    state.pageObserverStart();
    scheduleEnhance();
  }
  async function init() {
    let storedSettings = {};
    let hadStoredSettings = false;
    try {
      const stored = await api.storage.local.get(STORAGE_KEY);
      storedSettings = stored?.[STORAGE_KEY] || {};
      hadStoredSettings = !!stored?.[STORAGE_KEY] && Object.keys(storedSettings).length > 0;
      state.settings = normalizeSettings(storedSettings);
    } catch {
      state.settings = normalizeSettings({});
    }
    const storedKeys = storedSettings && typeof storedSettings === "object" ? Object.keys(storedSettings) : [];
    const storedIsSparse = !hadStoredSettings || storedKeys.every((key) => key === "enabled" || key === "schema");
    if (storedIsSparse) {
      const backup = readSettingsBackup();
      if (backup) {
        try {
          state.settings = normalizeSettings(mergeSettings(backup, storedSettings));
          storedSettings = state.settings;
          await api.storage.local.set({ [STORAGE_KEY]: state.settings });
        } catch {
          state.settings = normalizeSettings({});
        }
      }
    } else {
      writeSettingsBackup(state.settings);
    }
    state.settingsEpoch = 1;
    if (state.settings.enabled !== false) {
      document.documentElement.classList.toggle(
        "ba-hide-notification-button",
        state.settings.appearance.hideNotificationButton === true
      );
    }
    state.activeTab = state.settings.ui.activeTab || "studio";
    state.betterTab = state.settings.ui.betterTab || "line";
    state.settings.ui.panelOpen = false;
    api.storage.onChanged?.addListener((changes, area) => {
      if (area !== "local") return;
      const change = changes[STORAGE_KEY];
      if (!change) return;
      const before = state.settings.enabled !== false;
      const after = change.newValue?.enabled !== false;
      if (before !== after) {
        if (after) overrideNativeSounds();
        else restoreNativeSounds();
        location.reload();
        return;
      }
      if (!change.newValue || typeof change.newValue !== "object") {
        location.reload();
        return;
      }
      const incoming = normalizeSettings(mergeSettings(state.settings, change.newValue));
      incoming.ui = {
        ...incoming.ui,
        activeTab: state.settings.ui.activeTab,
        betterTab: state.settings.ui.betterTab,
        panelOpen: state.settings.ui.panelOpen,
        firstRun: state.settings.ui.firstRun
      };
      if (JSON.stringify(incoming) === JSON.stringify(state.settings)) return;
      state.settings = incoming;
      state.settingsEpoch += 1;
      writeSettingsBackup(state.settings);
      if (!state.enabledReady || state.settings.enabled === false) return;
      syncInputs();
      syncDynamic();
      applyTheme();
      applyCallCss();
      ensureToolbars();
      applyShortcutVisibility();
      scheduleEnhance();
      scheduleSettingsSync();
    });
    state.enabledReady = true;
    if (state.settings.enabled === false) {
      restoreNativeSounds();
      return;
    }
    window.addEventListener("message", handlePageMessage);
    document.documentElement.classList.add("ba-active");
    overrideNativeSounds();
    document.addEventListener("pointerdown", () => {
      if (!state.soundUnlocked) {
        state.soundUnlocked = true;
        unlockAudio();
      }
    }, { capture: true, passive: true });
    document.addEventListener("click", handleGlobalClickSound, true);
    const runSlashAction = (event) => {
      const ta = composerTextarea();
      if (!(ta instanceof HTMLTextAreaElement) || !/^\/me\s+/i.test(ta.value)) return false;
      event.preventDefault();
      event.stopImmediatePropagation();
      return sendSlashAction(ta.value);
    };
    document.addEventListener(
      "keydown",
      (event) => {
        if (event.key !== "Enter" || event.shiftKey || event.isComposing) return;
        const ta = event.target;
        if (!(ta instanceof HTMLTextAreaElement) || !ta.matches(".ag-composer-input")) return;
        if (!/^\/me\s+/i.test(ta.value)) return;
        runSlashAction(event);
      },
      true
    );
    document.addEventListener(
      "click",
      (event) => {
        const target = event.target;
        if (!(target instanceof Element) || !target.closest(".ag-composer-send-btn")) return;
        runSlashAction(event);
      },
      true
    );
    let lastHoverCleanup = 0;
    document.addEventListener(
      "pointermove",
      (event) => {
        const now = Date.now();
        if (now - lastHoverCleanup < 250) return;
        lastHoverCleanup = now;
        const target = event.target;
        const row = target instanceof Element ? target.closest(".ag-msg-row") : null;
        const active = document.activeElement;
        const hasStuckState = !!document.querySelector(".ag-msg-row.actions-open, .ag-msg-actions.picker-open") || active instanceof HTMLElement && !!active.closest(".ag-msg-actions");
        if (!row && !hasStuckState) return;
        clearStuckHoverMenus(row);
      },
      { passive: true, capture: true }
    );
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) {
        state.enhancePending = true;
        state.pageObserver?.disconnect();
        return;
      }
      state.pageObserverStart?.();
      if (state.enhancePending) {
        state.enhancePending = false;
        scheduleEnhance(true);
      }
      replaceBitchatText();
    });
    const titleEl = document.querySelector("title");
    if (titleEl && typeof MutationObserver === "function") {
      new MutationObserver(() => {
        if (/\bbitchat\b/i.test(document.title)) replaceBitchatText();
      }).observe(titleEl, { childList: true, characterData: true, subtree: true });
    }
    window.addEventListener("resize", () => {
      scheduleEnhance();
      if (state.emojiAnchor) positionEmojiPicker(state.emojiAnchor);
    }, { passive: true });
    window.addEventListener(
      "scroll",
      () => {
        if (state.emojiAnchor) positionEmojiPicker(state.emojiAnchor);
      },
      { passive: true, capture: true }
    );
    window.visualViewport?.addEventListener("resize", () => {
      if (state.emojiAnchor) positionEmojiPicker(state.emojiAnchor);
    });
    document.addEventListener(
      "keydown",
      (event) => {
        if (event.key !== "Escape" || state.modalOpen) return;
        const pop = document.querySelector(".ba-emoji-popover");
        if (pop && !pop.hidden) hideEmojiPicker();
      },
      true
    );
    window.addEventListener("pagehide", () => {
      if (state.saveTimer) {
        window.clearTimeout(state.saveTimer);
        state.saveTimer = null;
        persistSettings();
      }
      releaseNativeSounds();
    });
    window.setInterval(tickObfuscation, 100);
    window.setInterval(flairTickerTick, 1500);
    ensureHost();
    observePage();
    observeChatLabels();
    applyShortcutVisibility();
    scheduleSettingsSync();
    hello();
    refreshBuild(false);
    window.setInterval(() => {
      if (state.settings.glub.autoSync) refreshBuild(false);
    }, 4 * 60 * 1e3);
    api.runtime.onMessage.addListener((message) => {
      if (message?.type === "openStudio") {
        openPanel(message.tab || "studio");
        return Promise.resolve({ ok: true });
      }
      if (message?.type === "getPageState") {
        return Promise.resolve({ status: state.status, build: effectiveBuild(state.settings) });
      }
      return void 0;
    });
  }
  init();
})();
