(() => {
  var __defProp = Object.defineProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };

  // node_modules/nostr-tools/node_modules/@noble/curves/node_modules/@noble/hashes/esm/_assert.js
  function number(n) {
    if (!Number.isSafeInteger(n) || n < 0)
      throw new Error(`Wrong positive integer: ${n}`);
  }
  function bytes(b, ...lengths) {
    if (!(b instanceof Uint8Array))
      throw new Error("Expected Uint8Array");
    if (lengths.length > 0 && !lengths.includes(b.length))
      throw new Error(`Expected Uint8Array of length ${lengths}, not of length=${b.length}`);
  }
  function hash(hash3) {
    if (typeof hash3 !== "function" || typeof hash3.create !== "function")
      throw new Error("Hash should be wrapped by utils.wrapConstructor");
    number(hash3.outputLen);
    number(hash3.blockLen);
  }
  function exists(instance, checkFinished = true) {
    if (instance.destroyed)
      throw new Error("Hash instance has been destroyed");
    if (checkFinished && instance.finished)
      throw new Error("Hash#digest() has already been called");
  }
  function output(out, instance) {
    bytes(out);
    const min = instance.outputLen;
    if (out.length < min) {
      throw new Error(`digestInto() expects output buffer of length at least ${min}`);
    }
  }

  // node_modules/nostr-tools/node_modules/@noble/curves/node_modules/@noble/hashes/esm/crypto.js
  var crypto = typeof globalThis === "object" && "crypto" in globalThis ? globalThis.crypto : void 0;

  // node_modules/nostr-tools/node_modules/@noble/curves/node_modules/@noble/hashes/esm/utils.js
  var u8a = (a) => a instanceof Uint8Array;
  var createView = (arr) => new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
  var rotr = (word, shift) => word << 32 - shift | word >>> shift;
  var isLE = new Uint8Array(new Uint32Array([287454020]).buffer)[0] === 68;
  if (!isLE)
    throw new Error("Non little-endian hardware is not supported");
  function utf8ToBytes(str) {
    if (typeof str !== "string")
      throw new Error(`utf8ToBytes expected string, got ${typeof str}`);
    return new Uint8Array(new TextEncoder().encode(str));
  }
  function toBytes(data) {
    if (typeof data === "string")
      data = utf8ToBytes(data);
    if (!u8a(data))
      throw new Error(`expected Uint8Array, got ${typeof data}`);
    return data;
  }
  function concatBytes(...arrays) {
    const r = new Uint8Array(arrays.reduce((sum, a) => sum + a.length, 0));
    let pad = 0;
    arrays.forEach((a) => {
      if (!u8a(a))
        throw new Error("Uint8Array expected");
      r.set(a, pad);
      pad += a.length;
    });
    return r;
  }
  var Hash = class {
    // Safe version that clones internal state
    clone() {
      return this._cloneInto();
    }
  };
  var toStr = {}.toString;
  function wrapConstructor(hashCons) {
    const hashC = (msg) => hashCons().update(toBytes(msg)).digest();
    const tmp = hashCons();
    hashC.outputLen = tmp.outputLen;
    hashC.blockLen = tmp.blockLen;
    hashC.create = () => hashCons();
    return hashC;
  }
  function randomBytes(bytesLength = 32) {
    if (crypto && typeof crypto.getRandomValues === "function") {
      return crypto.getRandomValues(new Uint8Array(bytesLength));
    }
    throw new Error("crypto.getRandomValues must be defined");
  }

  // node_modules/nostr-tools/node_modules/@noble/curves/node_modules/@noble/hashes/esm/_sha2.js
  function setBigUint64(view, byteOffset, value, isLE3) {
    if (typeof view.setBigUint64 === "function")
      return view.setBigUint64(byteOffset, value, isLE3);
    const _32n = BigInt(32);
    const _u32_max = BigInt(4294967295);
    const wh = Number(value >> _32n & _u32_max);
    const wl = Number(value & _u32_max);
    const h = isLE3 ? 4 : 0;
    const l = isLE3 ? 0 : 4;
    view.setUint32(byteOffset + h, wh, isLE3);
    view.setUint32(byteOffset + l, wl, isLE3);
  }
  var SHA2 = class extends Hash {
    constructor(blockLen, outputLen, padOffset, isLE3) {
      super();
      this.blockLen = blockLen;
      this.outputLen = outputLen;
      this.padOffset = padOffset;
      this.isLE = isLE3;
      this.finished = false;
      this.length = 0;
      this.pos = 0;
      this.destroyed = false;
      this.buffer = new Uint8Array(blockLen);
      this.view = createView(this.buffer);
    }
    update(data) {
      exists(this);
      const { view, buffer, blockLen } = this;
      data = toBytes(data);
      const len = data.length;
      for (let pos = 0; pos < len; ) {
        const take = Math.min(blockLen - this.pos, len - pos);
        if (take === blockLen) {
          const dataView = createView(data);
          for (; blockLen <= len - pos; pos += blockLen)
            this.process(dataView, pos);
          continue;
        }
        buffer.set(data.subarray(pos, pos + take), this.pos);
        this.pos += take;
        pos += take;
        if (this.pos === blockLen) {
          this.process(view, 0);
          this.pos = 0;
        }
      }
      this.length += data.length;
      this.roundClean();
      return this;
    }
    digestInto(out) {
      exists(this);
      output(out, this);
      this.finished = true;
      const { buffer, view, blockLen, isLE: isLE3 } = this;
      let { pos } = this;
      buffer[pos++] = 128;
      this.buffer.subarray(pos).fill(0);
      if (this.padOffset > blockLen - pos) {
        this.process(view, 0);
        pos = 0;
      }
      for (let i2 = pos; i2 < blockLen; i2++)
        buffer[i2] = 0;
      setBigUint64(view, blockLen - 8, BigInt(this.length * 8), isLE3);
      this.process(view, 0);
      const oview = createView(out);
      const len = this.outputLen;
      if (len % 4)
        throw new Error("_sha2: outputLen should be aligned to 32bit");
      const outLen = len / 4;
      const state = this.get();
      if (outLen > state.length)
        throw new Error("_sha2: outputLen bigger than state");
      for (let i2 = 0; i2 < outLen; i2++)
        oview.setUint32(4 * i2, state[i2], isLE3);
    }
    digest() {
      const { buffer, outputLen } = this;
      this.digestInto(buffer);
      const res = buffer.slice(0, outputLen);
      this.destroy();
      return res;
    }
    _cloneInto(to) {
      to || (to = new this.constructor());
      to.set(...this.get());
      const { blockLen, buffer, length, finished, destroyed, pos } = this;
      to.length = length;
      to.pos = pos;
      to.finished = finished;
      to.destroyed = destroyed;
      if (length % blockLen)
        to.buffer.set(buffer);
      return to;
    }
  };

  // node_modules/nostr-tools/node_modules/@noble/curves/node_modules/@noble/hashes/esm/sha256.js
  var Chi = (a, b, c) => a & b ^ ~a & c;
  var Maj = (a, b, c) => a & b ^ a & c ^ b & c;
  var SHA256_K = /* @__PURE__ */ new Uint32Array([
    1116352408,
    1899447441,
    3049323471,
    3921009573,
    961987163,
    1508970993,
    2453635748,
    2870763221,
    3624381080,
    310598401,
    607225278,
    1426881987,
    1925078388,
    2162078206,
    2614888103,
    3248222580,
    3835390401,
    4022224774,
    264347078,
    604807628,
    770255983,
    1249150122,
    1555081692,
    1996064986,
    2554220882,
    2821834349,
    2952996808,
    3210313671,
    3336571891,
    3584528711,
    113926993,
    338241895,
    666307205,
    773529912,
    1294757372,
    1396182291,
    1695183700,
    1986661051,
    2177026350,
    2456956037,
    2730485921,
    2820302411,
    3259730800,
    3345764771,
    3516065817,
    3600352804,
    4094571909,
    275423344,
    430227734,
    506948616,
    659060556,
    883997877,
    958139571,
    1322822218,
    1537002063,
    1747873779,
    1955562222,
    2024104815,
    2227730452,
    2361852424,
    2428436474,
    2756734187,
    3204031479,
    3329325298
  ]);
  var IV = /* @__PURE__ */ new Uint32Array([
    1779033703,
    3144134277,
    1013904242,
    2773480762,
    1359893119,
    2600822924,
    528734635,
    1541459225
  ]);
  var SHA256_W = /* @__PURE__ */ new Uint32Array(64);
  var SHA256 = class extends SHA2 {
    constructor() {
      super(64, 32, 8, false);
      this.A = IV[0] | 0;
      this.B = IV[1] | 0;
      this.C = IV[2] | 0;
      this.D = IV[3] | 0;
      this.E = IV[4] | 0;
      this.F = IV[5] | 0;
      this.G = IV[6] | 0;
      this.H = IV[7] | 0;
    }
    get() {
      const { A, B, C, D, E, F, G, H } = this;
      return [A, B, C, D, E, F, G, H];
    }
    // prettier-ignore
    set(A, B, C, D, E, F, G, H) {
      this.A = A | 0;
      this.B = B | 0;
      this.C = C | 0;
      this.D = D | 0;
      this.E = E | 0;
      this.F = F | 0;
      this.G = G | 0;
      this.H = H | 0;
    }
    process(view, offset) {
      for (let i2 = 0; i2 < 16; i2++, offset += 4)
        SHA256_W[i2] = view.getUint32(offset, false);
      for (let i2 = 16; i2 < 64; i2++) {
        const W15 = SHA256_W[i2 - 15];
        const W2 = SHA256_W[i2 - 2];
        const s0 = rotr(W15, 7) ^ rotr(W15, 18) ^ W15 >>> 3;
        const s1 = rotr(W2, 17) ^ rotr(W2, 19) ^ W2 >>> 10;
        SHA256_W[i2] = s1 + SHA256_W[i2 - 7] + s0 + SHA256_W[i2 - 16] | 0;
      }
      let { A, B, C, D, E, F, G, H } = this;
      for (let i2 = 0; i2 < 64; i2++) {
        const sigma1 = rotr(E, 6) ^ rotr(E, 11) ^ rotr(E, 25);
        const T1 = H + sigma1 + Chi(E, F, G) + SHA256_K[i2] + SHA256_W[i2] | 0;
        const sigma0 = rotr(A, 2) ^ rotr(A, 13) ^ rotr(A, 22);
        const T2 = sigma0 + Maj(A, B, C) | 0;
        H = G;
        G = F;
        F = E;
        E = D + T1 | 0;
        D = C;
        C = B;
        B = A;
        A = T1 + T2 | 0;
      }
      A = A + this.A | 0;
      B = B + this.B | 0;
      C = C + this.C | 0;
      D = D + this.D | 0;
      E = E + this.E | 0;
      F = F + this.F | 0;
      G = G + this.G | 0;
      H = H + this.H | 0;
      this.set(A, B, C, D, E, F, G, H);
    }
    roundClean() {
      SHA256_W.fill(0);
    }
    destroy() {
      this.set(0, 0, 0, 0, 0, 0, 0, 0);
      this.buffer.fill(0);
    }
  };
  var sha256 = /* @__PURE__ */ wrapConstructor(() => new SHA256());

  // node_modules/nostr-tools/node_modules/@noble/curves/esm/abstract/utils.js
  var utils_exports = {};
  __export(utils_exports, {
    bitGet: () => bitGet,
    bitLen: () => bitLen,
    bitMask: () => bitMask,
    bitSet: () => bitSet,
    bytesToHex: () => bytesToHex,
    bytesToNumberBE: () => bytesToNumberBE,
    bytesToNumberLE: () => bytesToNumberLE,
    concatBytes: () => concatBytes2,
    createHmacDrbg: () => createHmacDrbg,
    ensureBytes: () => ensureBytes,
    equalBytes: () => equalBytes,
    hexToBytes: () => hexToBytes,
    hexToNumber: () => hexToNumber,
    numberToBytesBE: () => numberToBytesBE,
    numberToBytesLE: () => numberToBytesLE,
    numberToHexUnpadded: () => numberToHexUnpadded,
    numberToVarBytesBE: () => numberToVarBytesBE,
    utf8ToBytes: () => utf8ToBytes2,
    validateObject: () => validateObject
  });
  var _0n = BigInt(0);
  var _1n = BigInt(1);
  var _2n = BigInt(2);
  var u8a2 = (a) => a instanceof Uint8Array;
  var hexes = /* @__PURE__ */ Array.from({ length: 256 }, (_, i2) => i2.toString(16).padStart(2, "0"));
  function bytesToHex(bytes3) {
    if (!u8a2(bytes3))
      throw new Error("Uint8Array expected");
    let hex2 = "";
    for (let i2 = 0; i2 < bytes3.length; i2++) {
      hex2 += hexes[bytes3[i2]];
    }
    return hex2;
  }
  function numberToHexUnpadded(num) {
    const hex2 = num.toString(16);
    return hex2.length & 1 ? `0${hex2}` : hex2;
  }
  function hexToNumber(hex2) {
    if (typeof hex2 !== "string")
      throw new Error("hex string expected, got " + typeof hex2);
    return BigInt(hex2 === "" ? "0" : `0x${hex2}`);
  }
  function hexToBytes(hex2) {
    if (typeof hex2 !== "string")
      throw new Error("hex string expected, got " + typeof hex2);
    const len = hex2.length;
    if (len % 2)
      throw new Error("padded hex string expected, got unpadded hex of length " + len);
    const array = new Uint8Array(len / 2);
    for (let i2 = 0; i2 < array.length; i2++) {
      const j = i2 * 2;
      const hexByte = hex2.slice(j, j + 2);
      const byte = Number.parseInt(hexByte, 16);
      if (Number.isNaN(byte) || byte < 0)
        throw new Error("Invalid byte sequence");
      array[i2] = byte;
    }
    return array;
  }
  function bytesToNumberBE(bytes3) {
    return hexToNumber(bytesToHex(bytes3));
  }
  function bytesToNumberLE(bytes3) {
    if (!u8a2(bytes3))
      throw new Error("Uint8Array expected");
    return hexToNumber(bytesToHex(Uint8Array.from(bytes3).reverse()));
  }
  function numberToBytesBE(n, len) {
    return hexToBytes(n.toString(16).padStart(len * 2, "0"));
  }
  function numberToBytesLE(n, len) {
    return numberToBytesBE(n, len).reverse();
  }
  function numberToVarBytesBE(n) {
    return hexToBytes(numberToHexUnpadded(n));
  }
  function ensureBytes(title, hex2, expectedLength) {
    let res;
    if (typeof hex2 === "string") {
      try {
        res = hexToBytes(hex2);
      } catch (e) {
        throw new Error(`${title} must be valid hex string, got "${hex2}". Cause: ${e}`);
      }
    } else if (u8a2(hex2)) {
      res = Uint8Array.from(hex2);
    } else {
      throw new Error(`${title} must be hex string or Uint8Array`);
    }
    const len = res.length;
    if (typeof expectedLength === "number" && len !== expectedLength)
      throw new Error(`${title} expected ${expectedLength} bytes, got ${len}`);
    return res;
  }
  function concatBytes2(...arrays) {
    const r = new Uint8Array(arrays.reduce((sum, a) => sum + a.length, 0));
    let pad = 0;
    arrays.forEach((a) => {
      if (!u8a2(a))
        throw new Error("Uint8Array expected");
      r.set(a, pad);
      pad += a.length;
    });
    return r;
  }
  function equalBytes(b1, b2) {
    if (b1.length !== b2.length)
      return false;
    for (let i2 = 0; i2 < b1.length; i2++)
      if (b1[i2] !== b2[i2])
        return false;
    return true;
  }
  function utf8ToBytes2(str) {
    if (typeof str !== "string")
      throw new Error(`utf8ToBytes expected string, got ${typeof str}`);
    return new Uint8Array(new TextEncoder().encode(str));
  }
  function bitLen(n) {
    let len;
    for (len = 0; n > _0n; n >>= _1n, len += 1)
      ;
    return len;
  }
  function bitGet(n, pos) {
    return n >> BigInt(pos) & _1n;
  }
  var bitSet = (n, pos, value) => {
    return n | (value ? _1n : _0n) << BigInt(pos);
  };
  var bitMask = (n) => (_2n << BigInt(n - 1)) - _1n;
  var u8n = (data) => new Uint8Array(data);
  var u8fr = (arr) => Uint8Array.from(arr);
  function createHmacDrbg(hashLen, qByteLen, hmacFn) {
    if (typeof hashLen !== "number" || hashLen < 2)
      throw new Error("hashLen must be a number");
    if (typeof qByteLen !== "number" || qByteLen < 2)
      throw new Error("qByteLen must be a number");
    if (typeof hmacFn !== "function")
      throw new Error("hmacFn must be a function");
    let v = u8n(hashLen);
    let k = u8n(hashLen);
    let i2 = 0;
    const reset = () => {
      v.fill(1);
      k.fill(0);
      i2 = 0;
    };
    const h = (...b) => hmacFn(k, v, ...b);
    const reseed = (seed = u8n()) => {
      k = h(u8fr([0]), seed);
      v = h();
      if (seed.length === 0)
        return;
      k = h(u8fr([1]), seed);
      v = h();
    };
    const gen = () => {
      if (i2++ >= 1e3)
        throw new Error("drbg: tried 1000 values");
      let len = 0;
      const out = [];
      while (len < qByteLen) {
        v = h();
        const sl = v.slice();
        out.push(sl);
        len += v.length;
      }
      return concatBytes2(...out);
    };
    const genUntil = (seed, pred) => {
      reset();
      reseed(seed);
      let res = void 0;
      while (!(res = pred(gen())))
        reseed();
      reset();
      return res;
    };
    return genUntil;
  }
  var validatorFns = {
    bigint: (val) => typeof val === "bigint",
    function: (val) => typeof val === "function",
    boolean: (val) => typeof val === "boolean",
    string: (val) => typeof val === "string",
    stringOrUint8Array: (val) => typeof val === "string" || val instanceof Uint8Array,
    isSafeInteger: (val) => Number.isSafeInteger(val),
    array: (val) => Array.isArray(val),
    field: (val, object) => object.Fp.isValid(val),
    hash: (val) => typeof val === "function" && Number.isSafeInteger(val.outputLen)
  };
  function validateObject(object, validators, optValidators = {}) {
    const checkField = (fieldName, type, isOptional) => {
      const checkVal = validatorFns[type];
      if (typeof checkVal !== "function")
        throw new Error(`Invalid validator "${type}", expected function`);
      const val = object[fieldName];
      if (isOptional && val === void 0)
        return;
      if (!checkVal(val, object)) {
        throw new Error(`Invalid param ${String(fieldName)}=${val} (${typeof val}), expected ${type}`);
      }
    };
    for (const [fieldName, type] of Object.entries(validators))
      checkField(fieldName, type, false);
    for (const [fieldName, type] of Object.entries(optValidators))
      checkField(fieldName, type, true);
    return object;
  }

  // node_modules/nostr-tools/node_modules/@noble/curves/esm/abstract/modular.js
  var _0n2 = BigInt(0);
  var _1n2 = BigInt(1);
  var _2n2 = BigInt(2);
  var _3n = BigInt(3);
  var _4n = BigInt(4);
  var _5n = BigInt(5);
  var _8n = BigInt(8);
  var _9n = BigInt(9);
  var _16n = BigInt(16);
  function mod(a, b) {
    const result = a % b;
    return result >= _0n2 ? result : b + result;
  }
  function pow(num, power, modulo) {
    if (modulo <= _0n2 || power < _0n2)
      throw new Error("Expected power/modulo > 0");
    if (modulo === _1n2)
      return _0n2;
    let res = _1n2;
    while (power > _0n2) {
      if (power & _1n2)
        res = res * num % modulo;
      num = num * num % modulo;
      power >>= _1n2;
    }
    return res;
  }
  function pow2(x, power, modulo) {
    let res = x;
    while (power-- > _0n2) {
      res *= res;
      res %= modulo;
    }
    return res;
  }
  function invert(number3, modulo) {
    if (number3 === _0n2 || modulo <= _0n2) {
      throw new Error(`invert: expected positive integers, got n=${number3} mod=${modulo}`);
    }
    let a = mod(number3, modulo);
    let b = modulo;
    let x = _0n2, y = _1n2, u = _1n2, v = _0n2;
    while (a !== _0n2) {
      const q = b / a;
      const r = b % a;
      const m = x - u * q;
      const n = y - v * q;
      b = a, a = r, x = u, y = v, u = m, v = n;
    }
    const gcd2 = b;
    if (gcd2 !== _1n2)
      throw new Error("invert: does not exist");
    return mod(x, modulo);
  }
  function tonelliShanks(P) {
    const legendreC = (P - _1n2) / _2n2;
    let Q, S, Z;
    for (Q = P - _1n2, S = 0; Q % _2n2 === _0n2; Q /= _2n2, S++)
      ;
    for (Z = _2n2; Z < P && pow(Z, legendreC, P) !== P - _1n2; Z++)
      ;
    if (S === 1) {
      const p1div4 = (P + _1n2) / _4n;
      return function tonelliFast(Fp2, n) {
        const root = Fp2.pow(n, p1div4);
        if (!Fp2.eql(Fp2.sqr(root), n))
          throw new Error("Cannot find square root");
        return root;
      };
    }
    const Q1div2 = (Q + _1n2) / _2n2;
    return function tonelliSlow(Fp2, n) {
      if (Fp2.pow(n, legendreC) === Fp2.neg(Fp2.ONE))
        throw new Error("Cannot find square root");
      let r = S;
      let g = Fp2.pow(Fp2.mul(Fp2.ONE, Z), Q);
      let x = Fp2.pow(n, Q1div2);
      let b = Fp2.pow(n, Q);
      while (!Fp2.eql(b, Fp2.ONE)) {
        if (Fp2.eql(b, Fp2.ZERO))
          return Fp2.ZERO;
        let m = 1;
        for (let t2 = Fp2.sqr(b); m < r; m++) {
          if (Fp2.eql(t2, Fp2.ONE))
            break;
          t2 = Fp2.sqr(t2);
        }
        const ge2 = Fp2.pow(g, _1n2 << BigInt(r - m - 1));
        g = Fp2.sqr(ge2);
        x = Fp2.mul(x, ge2);
        b = Fp2.mul(b, g);
        r = m;
      }
      return x;
    };
  }
  function FpSqrt(P) {
    if (P % _4n === _3n) {
      const p1div4 = (P + _1n2) / _4n;
      return function sqrt3mod4(Fp2, n) {
        const root = Fp2.pow(n, p1div4);
        if (!Fp2.eql(Fp2.sqr(root), n))
          throw new Error("Cannot find square root");
        return root;
      };
    }
    if (P % _8n === _5n) {
      const c1 = (P - _5n) / _8n;
      return function sqrt5mod8(Fp2, n) {
        const n2 = Fp2.mul(n, _2n2);
        const v = Fp2.pow(n2, c1);
        const nv = Fp2.mul(n, v);
        const i2 = Fp2.mul(Fp2.mul(nv, _2n2), v);
        const root = Fp2.mul(nv, Fp2.sub(i2, Fp2.ONE));
        if (!Fp2.eql(Fp2.sqr(root), n))
          throw new Error("Cannot find square root");
        return root;
      };
    }
    if (P % _16n === _9n) {
    }
    return tonelliShanks(P);
  }
  var FIELD_FIELDS = [
    "create",
    "isValid",
    "is0",
    "neg",
    "inv",
    "sqrt",
    "sqr",
    "eql",
    "add",
    "sub",
    "mul",
    "pow",
    "div",
    "addN",
    "subN",
    "mulN",
    "sqrN"
  ];
  function validateField(field) {
    const initial = {
      ORDER: "bigint",
      MASK: "bigint",
      BYTES: "isSafeInteger",
      BITS: "isSafeInteger"
    };
    const opts = FIELD_FIELDS.reduce((map, val) => {
      map[val] = "function";
      return map;
    }, initial);
    return validateObject(field, opts);
  }
  function FpPow(f, num, power) {
    if (power < _0n2)
      throw new Error("Expected power > 0");
    if (power === _0n2)
      return f.ONE;
    if (power === _1n2)
      return num;
    let p = f.ONE;
    let d = num;
    while (power > _0n2) {
      if (power & _1n2)
        p = f.mul(p, d);
      d = f.sqr(d);
      power >>= _1n2;
    }
    return p;
  }
  function FpInvertBatch(f, nums) {
    const tmp = new Array(nums.length);
    const lastMultiplied = nums.reduce((acc, num, i2) => {
      if (f.is0(num))
        return acc;
      tmp[i2] = acc;
      return f.mul(acc, num);
    }, f.ONE);
    const inverted = f.inv(lastMultiplied);
    nums.reduceRight((acc, num, i2) => {
      if (f.is0(num))
        return acc;
      tmp[i2] = f.mul(acc, tmp[i2]);
      return f.mul(acc, num);
    }, inverted);
    return tmp;
  }
  function nLength(n, nBitLength) {
    const _nBitLength = nBitLength !== void 0 ? nBitLength : n.toString(2).length;
    const nByteLength = Math.ceil(_nBitLength / 8);
    return { nBitLength: _nBitLength, nByteLength };
  }
  function Field(ORDER, bitLen2, isLE3 = false, redef = {}) {
    if (ORDER <= _0n2)
      throw new Error(`Expected Field ORDER > 0, got ${ORDER}`);
    const { nBitLength: BITS, nByteLength: BYTES } = nLength(ORDER, bitLen2);
    if (BYTES > 2048)
      throw new Error("Field lengths over 2048 bytes are not supported");
    const sqrtP = FpSqrt(ORDER);
    const f = Object.freeze({
      ORDER,
      BITS,
      BYTES,
      MASK: bitMask(BITS),
      ZERO: _0n2,
      ONE: _1n2,
      create: (num) => mod(num, ORDER),
      isValid: (num) => {
        if (typeof num !== "bigint")
          throw new Error(`Invalid field element: expected bigint, got ${typeof num}`);
        return _0n2 <= num && num < ORDER;
      },
      is0: (num) => num === _0n2,
      isOdd: (num) => (num & _1n2) === _1n2,
      neg: (num) => mod(-num, ORDER),
      eql: (lhs, rhs) => lhs === rhs,
      sqr: (num) => mod(num * num, ORDER),
      add: (lhs, rhs) => mod(lhs + rhs, ORDER),
      sub: (lhs, rhs) => mod(lhs - rhs, ORDER),
      mul: (lhs, rhs) => mod(lhs * rhs, ORDER),
      pow: (num, power) => FpPow(f, num, power),
      div: (lhs, rhs) => mod(lhs * invert(rhs, ORDER), ORDER),
      // Same as above, but doesn't normalize
      sqrN: (num) => num * num,
      addN: (lhs, rhs) => lhs + rhs,
      subN: (lhs, rhs) => lhs - rhs,
      mulN: (lhs, rhs) => lhs * rhs,
      inv: (num) => invert(num, ORDER),
      sqrt: redef.sqrt || ((n) => sqrtP(f, n)),
      invertBatch: (lst) => FpInvertBatch(f, lst),
      // TODO: do we really need constant cmov?
      // We don't have const-time bigints anyway, so probably will be not very useful
      cmov: (a, b, c) => c ? b : a,
      toBytes: (num) => isLE3 ? numberToBytesLE(num, BYTES) : numberToBytesBE(num, BYTES),
      fromBytes: (bytes3) => {
        if (bytes3.length !== BYTES)
          throw new Error(`Fp.fromBytes: expected ${BYTES}, got ${bytes3.length}`);
        return isLE3 ? bytesToNumberLE(bytes3) : bytesToNumberBE(bytes3);
      }
    });
    return Object.freeze(f);
  }
  function getFieldBytesLength(fieldOrder) {
    if (typeof fieldOrder !== "bigint")
      throw new Error("field order must be bigint");
    const bitLength = fieldOrder.toString(2).length;
    return Math.ceil(bitLength / 8);
  }
  function getMinHashLength(fieldOrder) {
    const length = getFieldBytesLength(fieldOrder);
    return length + Math.ceil(length / 2);
  }
  function mapHashToField(key, fieldOrder, isLE3 = false) {
    const len = key.length;
    const fieldLen = getFieldBytesLength(fieldOrder);
    const minLen = getMinHashLength(fieldOrder);
    if (len < 16 || len < minLen || len > 1024)
      throw new Error(`expected ${minLen}-1024 bytes of input, got ${len}`);
    const num = isLE3 ? bytesToNumberBE(key) : bytesToNumberLE(key);
    const reduced = mod(num, fieldOrder - _1n2) + _1n2;
    return isLE3 ? numberToBytesLE(reduced, fieldLen) : numberToBytesBE(reduced, fieldLen);
  }

  // node_modules/nostr-tools/node_modules/@noble/curves/esm/abstract/curve.js
  var _0n3 = BigInt(0);
  var _1n3 = BigInt(1);
  function wNAF(c, bits) {
    const constTimeNegate = (condition, item) => {
      const neg = item.negate();
      return condition ? neg : item;
    };
    const opts = (W) => {
      const windows = Math.ceil(bits / W) + 1;
      const windowSize = 2 ** (W - 1);
      return { windows, windowSize };
    };
    return {
      constTimeNegate,
      // non-const time multiplication ladder
      unsafeLadder(elm, n) {
        let p = c.ZERO;
        let d = elm;
        while (n > _0n3) {
          if (n & _1n3)
            p = p.add(d);
          d = d.double();
          n >>= _1n3;
        }
        return p;
      },
      /**
       * Creates a wNAF precomputation window. Used for caching.
       * Default window size is set by `utils.precompute()` and is equal to 8.
       * Number of precomputed points depends on the curve size:
       * 2^(𝑊−1) * (Math.ceil(𝑛 / 𝑊) + 1), where:
       * - 𝑊 is the window size
       * - 𝑛 is the bitlength of the curve order.
       * For a 256-bit curve and window size 8, the number of precomputed points is 128 * 33 = 4224.
       * @returns precomputed point tables flattened to a single array
       */
      precomputeWindow(elm, W) {
        const { windows, windowSize } = opts(W);
        const points = [];
        let p = elm;
        let base = p;
        for (let window2 = 0; window2 < windows; window2++) {
          base = p;
          points.push(base);
          for (let i2 = 1; i2 < windowSize; i2++) {
            base = base.add(p);
            points.push(base);
          }
          p = base.double();
        }
        return points;
      },
      /**
       * Implements ec multiplication using precomputed tables and w-ary non-adjacent form.
       * @param W window size
       * @param precomputes precomputed tables
       * @param n scalar (we don't check here, but should be less than curve order)
       * @returns real and fake (for const-time) points
       */
      wNAF(W, precomputes, n) {
        const { windows, windowSize } = opts(W);
        let p = c.ZERO;
        let f = c.BASE;
        const mask = BigInt(2 ** W - 1);
        const maxNumber = 2 ** W;
        const shiftBy = BigInt(W);
        for (let window2 = 0; window2 < windows; window2++) {
          const offset = window2 * windowSize;
          let wbits = Number(n & mask);
          n >>= shiftBy;
          if (wbits > windowSize) {
            wbits -= maxNumber;
            n += _1n3;
          }
          const offset1 = offset;
          const offset2 = offset + Math.abs(wbits) - 1;
          const cond1 = window2 % 2 !== 0;
          const cond2 = wbits < 0;
          if (wbits === 0) {
            f = f.add(constTimeNegate(cond1, precomputes[offset1]));
          } else {
            p = p.add(constTimeNegate(cond2, precomputes[offset2]));
          }
        }
        return { p, f };
      },
      wNAFCached(P, precomputesMap, n, transform) {
        const W = P._WINDOW_SIZE || 1;
        let comp = precomputesMap.get(P);
        if (!comp) {
          comp = this.precomputeWindow(P, W);
          if (W !== 1) {
            precomputesMap.set(P, transform(comp));
          }
        }
        return this.wNAF(W, comp, n);
      }
    };
  }
  function validateBasic(curve) {
    validateField(curve.Fp);
    validateObject(curve, {
      n: "bigint",
      h: "bigint",
      Gx: "field",
      Gy: "field"
    }, {
      nBitLength: "isSafeInteger",
      nByteLength: "isSafeInteger"
    });
    return Object.freeze({
      ...nLength(curve.n, curve.nBitLength),
      ...curve,
      ...{ p: curve.Fp.ORDER }
    });
  }

  // node_modules/nostr-tools/node_modules/@noble/curves/esm/abstract/weierstrass.js
  function validatePointOpts(curve) {
    const opts = validateBasic(curve);
    validateObject(opts, {
      a: "field",
      b: "field"
    }, {
      allowedPrivateKeyLengths: "array",
      wrapPrivateKey: "boolean",
      isTorsionFree: "function",
      clearCofactor: "function",
      allowInfinityPoint: "boolean",
      fromBytes: "function",
      toBytes: "function"
    });
    const { endo, Fp: Fp2, a } = opts;
    if (endo) {
      if (!Fp2.eql(a, Fp2.ZERO)) {
        throw new Error("Endomorphism can only be defined for Koblitz curves that have a=0");
      }
      if (typeof endo !== "object" || typeof endo.beta !== "bigint" || typeof endo.splitScalar !== "function") {
        throw new Error("Expected endomorphism with beta: bigint and splitScalar: function");
      }
    }
    return Object.freeze({ ...opts });
  }
  var { bytesToNumberBE: b2n, hexToBytes: h2b } = utils_exports;
  var DER = {
    // asn.1 DER encoding utils
    Err: class DERErr extends Error {
      constructor(m = "") {
        super(m);
      }
    },
    _parseInt(data) {
      const { Err: E } = DER;
      if (data.length < 2 || data[0] !== 2)
        throw new E("Invalid signature integer tag");
      const len = data[1];
      const res = data.subarray(2, len + 2);
      if (!len || res.length !== len)
        throw new E("Invalid signature integer: wrong length");
      if (res[0] & 128)
        throw new E("Invalid signature integer: negative");
      if (res[0] === 0 && !(res[1] & 128))
        throw new E("Invalid signature integer: unnecessary leading zero");
      return { d: b2n(res), l: data.subarray(len + 2) };
    },
    toSig(hex2) {
      const { Err: E } = DER;
      const data = typeof hex2 === "string" ? h2b(hex2) : hex2;
      if (!(data instanceof Uint8Array))
        throw new Error("ui8a expected");
      let l = data.length;
      if (l < 2 || data[0] != 48)
        throw new E("Invalid signature tag");
      if (data[1] !== l - 2)
        throw new E("Invalid signature: incorrect length");
      const { d: r, l: sBytes } = DER._parseInt(data.subarray(2));
      const { d: s, l: rBytesLeft } = DER._parseInt(sBytes);
      if (rBytesLeft.length)
        throw new E("Invalid signature: left bytes after parsing");
      return { r, s };
    },
    hexFromSig(sig) {
      const slice = (s2) => Number.parseInt(s2[0], 16) & 8 ? "00" + s2 : s2;
      const h = (num) => {
        const hex2 = num.toString(16);
        return hex2.length & 1 ? `0${hex2}` : hex2;
      };
      const s = slice(h(sig.s));
      const r = slice(h(sig.r));
      const shl = s.length / 2;
      const rhl = r.length / 2;
      const sl = h(shl);
      const rl = h(rhl);
      return `30${h(rhl + shl + 4)}02${rl}${r}02${sl}${s}`;
    }
  };
  var _0n4 = BigInt(0);
  var _1n4 = BigInt(1);
  var _2n3 = BigInt(2);
  var _3n2 = BigInt(3);
  var _4n2 = BigInt(4);
  function weierstrassPoints(opts) {
    const CURVE = validatePointOpts(opts);
    const { Fp: Fp2 } = CURVE;
    const toBytes4 = CURVE.toBytes || ((_c, point, _isCompressed) => {
      const a = point.toAffine();
      return concatBytes2(Uint8Array.from([4]), Fp2.toBytes(a.x), Fp2.toBytes(a.y));
    });
    const fromBytes = CURVE.fromBytes || ((bytes3) => {
      const tail = bytes3.subarray(1);
      const x = Fp2.fromBytes(tail.subarray(0, Fp2.BYTES));
      const y = Fp2.fromBytes(tail.subarray(Fp2.BYTES, 2 * Fp2.BYTES));
      return { x, y };
    });
    function weierstrassEquation(x) {
      const { a, b } = CURVE;
      const x2 = Fp2.sqr(x);
      const x3 = Fp2.mul(x2, x);
      return Fp2.add(Fp2.add(x3, Fp2.mul(x, a)), b);
    }
    if (!Fp2.eql(Fp2.sqr(CURVE.Gy), weierstrassEquation(CURVE.Gx)))
      throw new Error("bad generator point: equation left != right");
    function isWithinCurveOrder(num) {
      return typeof num === "bigint" && _0n4 < num && num < CURVE.n;
    }
    function assertGE(num) {
      if (!isWithinCurveOrder(num))
        throw new Error("Expected valid bigint: 0 < bigint < curve.n");
    }
    function normPrivateKeyToScalar(key) {
      const { allowedPrivateKeyLengths: lengths, nByteLength, wrapPrivateKey, n } = CURVE;
      if (lengths && typeof key !== "bigint") {
        if (key instanceof Uint8Array)
          key = bytesToHex(key);
        if (typeof key !== "string" || !lengths.includes(key.length))
          throw new Error("Invalid key");
        key = key.padStart(nByteLength * 2, "0");
      }
      let num;
      try {
        num = typeof key === "bigint" ? key : bytesToNumberBE(ensureBytes("private key", key, nByteLength));
      } catch (error) {
        throw new Error(`private key must be ${nByteLength} bytes, hex or bigint, not ${typeof key}`);
      }
      if (wrapPrivateKey)
        num = mod(num, n);
      assertGE(num);
      return num;
    }
    const pointPrecomputes = /* @__PURE__ */ new Map();
    function assertPrjPoint(other) {
      if (!(other instanceof Point2))
        throw new Error("ProjectivePoint expected");
    }
    class Point2 {
      constructor(px, py, pz) {
        this.px = px;
        this.py = py;
        this.pz = pz;
        if (px == null || !Fp2.isValid(px))
          throw new Error("x required");
        if (py == null || !Fp2.isValid(py))
          throw new Error("y required");
        if (pz == null || !Fp2.isValid(pz))
          throw new Error("z required");
      }
      // Does not validate if the point is on-curve.
      // Use fromHex instead, or call assertValidity() later.
      static fromAffine(p) {
        const { x, y } = p || {};
        if (!p || !Fp2.isValid(x) || !Fp2.isValid(y))
          throw new Error("invalid affine point");
        if (p instanceof Point2)
          throw new Error("projective point not allowed");
        const is0 = (i2) => Fp2.eql(i2, Fp2.ZERO);
        if (is0(x) && is0(y))
          return Point2.ZERO;
        return new Point2(x, y, Fp2.ONE);
      }
      get x() {
        return this.toAffine().x;
      }
      get y() {
        return this.toAffine().y;
      }
      /**
       * Takes a bunch of Projective Points but executes only one
       * inversion on all of them. Inversion is very slow operation,
       * so this improves performance massively.
       * Optimization: converts a list of projective points to a list of identical points with Z=1.
       */
      static normalizeZ(points) {
        const toInv = Fp2.invertBatch(points.map((p) => p.pz));
        return points.map((p, i2) => p.toAffine(toInv[i2])).map(Point2.fromAffine);
      }
      /**
       * Converts hash string or Uint8Array to Point.
       * @param hex short/long ECDSA hex
       */
      static fromHex(hex2) {
        const P = Point2.fromAffine(fromBytes(ensureBytes("pointHex", hex2)));
        P.assertValidity();
        return P;
      }
      // Multiplies generator point by privateKey.
      static fromPrivateKey(privateKey) {
        return Point2.BASE.multiply(normPrivateKeyToScalar(privateKey));
      }
      // "Private method", don't use it directly
      _setWindowSize(windowSize) {
        this._WINDOW_SIZE = windowSize;
        pointPrecomputes.delete(this);
      }
      // A point on curve is valid if it conforms to equation.
      assertValidity() {
        if (this.is0()) {
          if (CURVE.allowInfinityPoint && !Fp2.is0(this.py))
            return;
          throw new Error("bad point: ZERO");
        }
        const { x, y } = this.toAffine();
        if (!Fp2.isValid(x) || !Fp2.isValid(y))
          throw new Error("bad point: x or y not FE");
        const left = Fp2.sqr(y);
        const right = weierstrassEquation(x);
        if (!Fp2.eql(left, right))
          throw new Error("bad point: equation left != right");
        if (!this.isTorsionFree())
          throw new Error("bad point: not in prime-order subgroup");
      }
      hasEvenY() {
        const { y } = this.toAffine();
        if (Fp2.isOdd)
          return !Fp2.isOdd(y);
        throw new Error("Field doesn't support isOdd");
      }
      /**
       * Compare one point to another.
       */
      equals(other) {
        assertPrjPoint(other);
        const { px: X1, py: Y1, pz: Z1 } = this;
        const { px: X2, py: Y2, pz: Z2 } = other;
        const U1 = Fp2.eql(Fp2.mul(X1, Z2), Fp2.mul(X2, Z1));
        const U2 = Fp2.eql(Fp2.mul(Y1, Z2), Fp2.mul(Y2, Z1));
        return U1 && U2;
      }
      /**
       * Flips point to one corresponding to (x, -y) in Affine coordinates.
       */
      negate() {
        return new Point2(this.px, Fp2.neg(this.py), this.pz);
      }
      // Renes-Costello-Batina exception-free doubling formula.
      // There is 30% faster Jacobian formula, but it is not complete.
      // https://eprint.iacr.org/2015/1060, algorithm 3
      // Cost: 8M + 3S + 3*a + 2*b3 + 15add.
      double() {
        const { a, b } = CURVE;
        const b3 = Fp2.mul(b, _3n2);
        const { px: X1, py: Y1, pz: Z1 } = this;
        let X3 = Fp2.ZERO, Y3 = Fp2.ZERO, Z3 = Fp2.ZERO;
        let t0 = Fp2.mul(X1, X1);
        let t1 = Fp2.mul(Y1, Y1);
        let t2 = Fp2.mul(Z1, Z1);
        let t3 = Fp2.mul(X1, Y1);
        t3 = Fp2.add(t3, t3);
        Z3 = Fp2.mul(X1, Z1);
        Z3 = Fp2.add(Z3, Z3);
        X3 = Fp2.mul(a, Z3);
        Y3 = Fp2.mul(b3, t2);
        Y3 = Fp2.add(X3, Y3);
        X3 = Fp2.sub(t1, Y3);
        Y3 = Fp2.add(t1, Y3);
        Y3 = Fp2.mul(X3, Y3);
        X3 = Fp2.mul(t3, X3);
        Z3 = Fp2.mul(b3, Z3);
        t2 = Fp2.mul(a, t2);
        t3 = Fp2.sub(t0, t2);
        t3 = Fp2.mul(a, t3);
        t3 = Fp2.add(t3, Z3);
        Z3 = Fp2.add(t0, t0);
        t0 = Fp2.add(Z3, t0);
        t0 = Fp2.add(t0, t2);
        t0 = Fp2.mul(t0, t3);
        Y3 = Fp2.add(Y3, t0);
        t2 = Fp2.mul(Y1, Z1);
        t2 = Fp2.add(t2, t2);
        t0 = Fp2.mul(t2, t3);
        X3 = Fp2.sub(X3, t0);
        Z3 = Fp2.mul(t2, t1);
        Z3 = Fp2.add(Z3, Z3);
        Z3 = Fp2.add(Z3, Z3);
        return new Point2(X3, Y3, Z3);
      }
      // Renes-Costello-Batina exception-free addition formula.
      // There is 30% faster Jacobian formula, but it is not complete.
      // https://eprint.iacr.org/2015/1060, algorithm 1
      // Cost: 12M + 0S + 3*a + 3*b3 + 23add.
      add(other) {
        assertPrjPoint(other);
        const { px: X1, py: Y1, pz: Z1 } = this;
        const { px: X2, py: Y2, pz: Z2 } = other;
        let X3 = Fp2.ZERO, Y3 = Fp2.ZERO, Z3 = Fp2.ZERO;
        const a = CURVE.a;
        const b3 = Fp2.mul(CURVE.b, _3n2);
        let t0 = Fp2.mul(X1, X2);
        let t1 = Fp2.mul(Y1, Y2);
        let t2 = Fp2.mul(Z1, Z2);
        let t3 = Fp2.add(X1, Y1);
        let t4 = Fp2.add(X2, Y2);
        t3 = Fp2.mul(t3, t4);
        t4 = Fp2.add(t0, t1);
        t3 = Fp2.sub(t3, t4);
        t4 = Fp2.add(X1, Z1);
        let t5 = Fp2.add(X2, Z2);
        t4 = Fp2.mul(t4, t5);
        t5 = Fp2.add(t0, t2);
        t4 = Fp2.sub(t4, t5);
        t5 = Fp2.add(Y1, Z1);
        X3 = Fp2.add(Y2, Z2);
        t5 = Fp2.mul(t5, X3);
        X3 = Fp2.add(t1, t2);
        t5 = Fp2.sub(t5, X3);
        Z3 = Fp2.mul(a, t4);
        X3 = Fp2.mul(b3, t2);
        Z3 = Fp2.add(X3, Z3);
        X3 = Fp2.sub(t1, Z3);
        Z3 = Fp2.add(t1, Z3);
        Y3 = Fp2.mul(X3, Z3);
        t1 = Fp2.add(t0, t0);
        t1 = Fp2.add(t1, t0);
        t2 = Fp2.mul(a, t2);
        t4 = Fp2.mul(b3, t4);
        t1 = Fp2.add(t1, t2);
        t2 = Fp2.sub(t0, t2);
        t2 = Fp2.mul(a, t2);
        t4 = Fp2.add(t4, t2);
        t0 = Fp2.mul(t1, t4);
        Y3 = Fp2.add(Y3, t0);
        t0 = Fp2.mul(t5, t4);
        X3 = Fp2.mul(t3, X3);
        X3 = Fp2.sub(X3, t0);
        t0 = Fp2.mul(t3, t1);
        Z3 = Fp2.mul(t5, Z3);
        Z3 = Fp2.add(Z3, t0);
        return new Point2(X3, Y3, Z3);
      }
      subtract(other) {
        return this.add(other.negate());
      }
      is0() {
        return this.equals(Point2.ZERO);
      }
      wNAF(n) {
        return wnaf.wNAFCached(this, pointPrecomputes, n, (comp) => {
          const toInv = Fp2.invertBatch(comp.map((p) => p.pz));
          return comp.map((p, i2) => p.toAffine(toInv[i2])).map(Point2.fromAffine);
        });
      }
      /**
       * Non-constant-time multiplication. Uses double-and-add algorithm.
       * It's faster, but should only be used when you don't care about
       * an exposed private key e.g. sig verification, which works over *public* keys.
       */
      multiplyUnsafe(n) {
        const I = Point2.ZERO;
        if (n === _0n4)
          return I;
        assertGE(n);
        if (n === _1n4)
          return this;
        const { endo } = CURVE;
        if (!endo)
          return wnaf.unsafeLadder(this, n);
        let { k1neg, k1, k2neg, k2 } = endo.splitScalar(n);
        let k1p = I;
        let k2p = I;
        let d = this;
        while (k1 > _0n4 || k2 > _0n4) {
          if (k1 & _1n4)
            k1p = k1p.add(d);
          if (k2 & _1n4)
            k2p = k2p.add(d);
          d = d.double();
          k1 >>= _1n4;
          k2 >>= _1n4;
        }
        if (k1neg)
          k1p = k1p.negate();
        if (k2neg)
          k2p = k2p.negate();
        k2p = new Point2(Fp2.mul(k2p.px, endo.beta), k2p.py, k2p.pz);
        return k1p.add(k2p);
      }
      /**
       * Constant time multiplication.
       * Uses wNAF method. Windowed method may be 10% faster,
       * but takes 2x longer to generate and consumes 2x memory.
       * Uses precomputes when available.
       * Uses endomorphism for Koblitz curves.
       * @param scalar by which the point would be multiplied
       * @returns New point
       */
      multiply(scalar) {
        assertGE(scalar);
        let n = scalar;
        let point, fake;
        const { endo } = CURVE;
        if (endo) {
          const { k1neg, k1, k2neg, k2 } = endo.splitScalar(n);
          let { p: k1p, f: f1p } = this.wNAF(k1);
          let { p: k2p, f: f2p } = this.wNAF(k2);
          k1p = wnaf.constTimeNegate(k1neg, k1p);
          k2p = wnaf.constTimeNegate(k2neg, k2p);
          k2p = new Point2(Fp2.mul(k2p.px, endo.beta), k2p.py, k2p.pz);
          point = k1p.add(k2p);
          fake = f1p.add(f2p);
        } else {
          const { p, f } = this.wNAF(n);
          point = p;
          fake = f;
        }
        return Point2.normalizeZ([point, fake])[0];
      }
      /**
       * Efficiently calculate `aP + bQ`. Unsafe, can expose private key, if used incorrectly.
       * Not using Strauss-Shamir trick: precomputation tables are faster.
       * The trick could be useful if both P and Q are not G (not in our case).
       * @returns non-zero affine point
       */
      multiplyAndAddUnsafe(Q, a, b) {
        const G = Point2.BASE;
        const mul = (P, a2) => a2 === _0n4 || a2 === _1n4 || !P.equals(G) ? P.multiplyUnsafe(a2) : P.multiply(a2);
        const sum = mul(this, a).add(mul(Q, b));
        return sum.is0() ? void 0 : sum;
      }
      // Converts Projective point to affine (x, y) coordinates.
      // Can accept precomputed Z^-1 - for example, from invertBatch.
      // (x, y, z) ∋ (x=x/z, y=y/z)
      toAffine(iz) {
        const { px: x, py: y, pz: z } = this;
        const is0 = this.is0();
        if (iz == null)
          iz = is0 ? Fp2.ONE : Fp2.inv(z);
        const ax = Fp2.mul(x, iz);
        const ay = Fp2.mul(y, iz);
        const zz = Fp2.mul(z, iz);
        if (is0)
          return { x: Fp2.ZERO, y: Fp2.ZERO };
        if (!Fp2.eql(zz, Fp2.ONE))
          throw new Error("invZ was invalid");
        return { x: ax, y: ay };
      }
      isTorsionFree() {
        const { h: cofactor, isTorsionFree } = CURVE;
        if (cofactor === _1n4)
          return true;
        if (isTorsionFree)
          return isTorsionFree(Point2, this);
        throw new Error("isTorsionFree() has not been declared for the elliptic curve");
      }
      clearCofactor() {
        const { h: cofactor, clearCofactor } = CURVE;
        if (cofactor === _1n4)
          return this;
        if (clearCofactor)
          return clearCofactor(Point2, this);
        return this.multiplyUnsafe(CURVE.h);
      }
      toRawBytes(isCompressed = true) {
        this.assertValidity();
        return toBytes4(Point2, this, isCompressed);
      }
      toHex(isCompressed = true) {
        return bytesToHex(this.toRawBytes(isCompressed));
      }
    }
    Point2.BASE = new Point2(CURVE.Gx, CURVE.Gy, Fp2.ONE);
    Point2.ZERO = new Point2(Fp2.ZERO, Fp2.ONE, Fp2.ZERO);
    const _bits = CURVE.nBitLength;
    const wnaf = wNAF(Point2, CURVE.endo ? Math.ceil(_bits / 2) : _bits);
    return {
      CURVE,
      ProjectivePoint: Point2,
      normPrivateKeyToScalar,
      weierstrassEquation,
      isWithinCurveOrder
    };
  }
  function validateOpts(curve) {
    const opts = validateBasic(curve);
    validateObject(opts, {
      hash: "hash",
      hmac: "function",
      randomBytes: "function"
    }, {
      bits2int: "function",
      bits2int_modN: "function",
      lowS: "boolean"
    });
    return Object.freeze({ lowS: true, ...opts });
  }
  function weierstrass(curveDef) {
    const CURVE = validateOpts(curveDef);
    const { Fp: Fp2, n: CURVE_ORDER } = CURVE;
    const compressedLen = Fp2.BYTES + 1;
    const uncompressedLen = 2 * Fp2.BYTES + 1;
    function isValidFieldElement(num) {
      return _0n4 < num && num < Fp2.ORDER;
    }
    function modN2(a) {
      return mod(a, CURVE_ORDER);
    }
    function invN(a) {
      return invert(a, CURVE_ORDER);
    }
    const { ProjectivePoint: Point2, normPrivateKeyToScalar, weierstrassEquation, isWithinCurveOrder } = weierstrassPoints({
      ...CURVE,
      toBytes(_c, point, isCompressed) {
        const a = point.toAffine();
        const x = Fp2.toBytes(a.x);
        const cat = concatBytes2;
        if (isCompressed) {
          return cat(Uint8Array.from([point.hasEvenY() ? 2 : 3]), x);
        } else {
          return cat(Uint8Array.from([4]), x, Fp2.toBytes(a.y));
        }
      },
      fromBytes(bytes3) {
        const len = bytes3.length;
        const head = bytes3[0];
        const tail = bytes3.subarray(1);
        if (len === compressedLen && (head === 2 || head === 3)) {
          const x = bytesToNumberBE(tail);
          if (!isValidFieldElement(x))
            throw new Error("Point is not on curve");
          const y2 = weierstrassEquation(x);
          let y = Fp2.sqrt(y2);
          const isYOdd = (y & _1n4) === _1n4;
          const isHeadOdd = (head & 1) === 1;
          if (isHeadOdd !== isYOdd)
            y = Fp2.neg(y);
          return { x, y };
        } else if (len === uncompressedLen && head === 4) {
          const x = Fp2.fromBytes(tail.subarray(0, Fp2.BYTES));
          const y = Fp2.fromBytes(tail.subarray(Fp2.BYTES, 2 * Fp2.BYTES));
          return { x, y };
        } else {
          throw new Error(`Point of length ${len} was invalid. Expected ${compressedLen} compressed bytes or ${uncompressedLen} uncompressed bytes`);
        }
      }
    });
    const numToNByteStr = (num) => bytesToHex(numberToBytesBE(num, CURVE.nByteLength));
    function isBiggerThanHalfOrder(number3) {
      const HALF = CURVE_ORDER >> _1n4;
      return number3 > HALF;
    }
    function normalizeS(s) {
      return isBiggerThanHalfOrder(s) ? modN2(-s) : s;
    }
    const slcNum = (b, from, to) => bytesToNumberBE(b.slice(from, to));
    class Signature {
      constructor(r, s, recovery) {
        this.r = r;
        this.s = s;
        this.recovery = recovery;
        this.assertValidity();
      }
      // pair (bytes of r, bytes of s)
      static fromCompact(hex2) {
        const l = CURVE.nByteLength;
        hex2 = ensureBytes("compactSignature", hex2, l * 2);
        return new Signature(slcNum(hex2, 0, l), slcNum(hex2, l, 2 * l));
      }
      // DER encoded ECDSA signature
      // https://bitcoin.stackexchange.com/questions/57644/what-are-the-parts-of-a-bitcoin-transaction-input-script
      static fromDER(hex2) {
        const { r, s } = DER.toSig(ensureBytes("DER", hex2));
        return new Signature(r, s);
      }
      assertValidity() {
        if (!isWithinCurveOrder(this.r))
          throw new Error("r must be 0 < r < CURVE.n");
        if (!isWithinCurveOrder(this.s))
          throw new Error("s must be 0 < s < CURVE.n");
      }
      addRecoveryBit(recovery) {
        return new Signature(this.r, this.s, recovery);
      }
      recoverPublicKey(msgHash) {
        const { r, s, recovery: rec } = this;
        const h = bits2int_modN(ensureBytes("msgHash", msgHash));
        if (rec == null || ![0, 1, 2, 3].includes(rec))
          throw new Error("recovery id invalid");
        const radj = rec === 2 || rec === 3 ? r + CURVE.n : r;
        if (radj >= Fp2.ORDER)
          throw new Error("recovery id 2 or 3 invalid");
        const prefix = (rec & 1) === 0 ? "02" : "03";
        const R = Point2.fromHex(prefix + numToNByteStr(radj));
        const ir = invN(radj);
        const u1 = modN2(-h * ir);
        const u2 = modN2(s * ir);
        const Q = Point2.BASE.multiplyAndAddUnsafe(R, u1, u2);
        if (!Q)
          throw new Error("point at infinify");
        Q.assertValidity();
        return Q;
      }
      // Signatures should be low-s, to prevent malleability.
      hasHighS() {
        return isBiggerThanHalfOrder(this.s);
      }
      normalizeS() {
        return this.hasHighS() ? new Signature(this.r, modN2(-this.s), this.recovery) : this;
      }
      // DER-encoded
      toDERRawBytes() {
        return hexToBytes(this.toDERHex());
      }
      toDERHex() {
        return DER.hexFromSig({ r: this.r, s: this.s });
      }
      // padded bytes of r, then padded bytes of s
      toCompactRawBytes() {
        return hexToBytes(this.toCompactHex());
      }
      toCompactHex() {
        return numToNByteStr(this.r) + numToNByteStr(this.s);
      }
    }
    const utils = {
      isValidPrivateKey(privateKey) {
        try {
          normPrivateKeyToScalar(privateKey);
          return true;
        } catch (error) {
          return false;
        }
      },
      normPrivateKeyToScalar,
      /**
       * Produces cryptographically secure private key from random of size
       * (groupLen + ceil(groupLen / 2)) with modulo bias being negligible.
       */
      randomPrivateKey: () => {
        const length = getMinHashLength(CURVE.n);
        return mapHashToField(CURVE.randomBytes(length), CURVE.n);
      },
      /**
       * Creates precompute table for an arbitrary EC point. Makes point "cached".
       * Allows to massively speed-up `point.multiply(scalar)`.
       * @returns cached point
       * @example
       * const fast = utils.precompute(8, ProjectivePoint.fromHex(someonesPubKey));
       * fast.multiply(privKey); // much faster ECDH now
       */
      precompute(windowSize = 8, point = Point2.BASE) {
        point._setWindowSize(windowSize);
        point.multiply(BigInt(3));
        return point;
      }
    };
    function getPublicKey2(privateKey, isCompressed = true) {
      return Point2.fromPrivateKey(privateKey).toRawBytes(isCompressed);
    }
    function isProbPub(item) {
      const arr = item instanceof Uint8Array;
      const str = typeof item === "string";
      const len = (arr || str) && item.length;
      if (arr)
        return len === compressedLen || len === uncompressedLen;
      if (str)
        return len === 2 * compressedLen || len === 2 * uncompressedLen;
      if (item instanceof Point2)
        return true;
      return false;
    }
    function getSharedSecret(privateA, publicB, isCompressed = true) {
      if (isProbPub(privateA))
        throw new Error("first arg must be private key");
      if (!isProbPub(publicB))
        throw new Error("second arg must be public key");
      const b = Point2.fromHex(publicB);
      return b.multiply(normPrivateKeyToScalar(privateA)).toRawBytes(isCompressed);
    }
    const bits2int = CURVE.bits2int || function(bytes3) {
      const num = bytesToNumberBE(bytes3);
      const delta = bytes3.length * 8 - CURVE.nBitLength;
      return delta > 0 ? num >> BigInt(delta) : num;
    };
    const bits2int_modN = CURVE.bits2int_modN || function(bytes3) {
      return modN2(bits2int(bytes3));
    };
    const ORDER_MASK = bitMask(CURVE.nBitLength);
    function int2octets(num) {
      if (typeof num !== "bigint")
        throw new Error("bigint expected");
      if (!(_0n4 <= num && num < ORDER_MASK))
        throw new Error(`bigint expected < 2^${CURVE.nBitLength}`);
      return numberToBytesBE(num, CURVE.nByteLength);
    }
    function prepSig(msgHash, privateKey, opts = defaultSigOpts) {
      if (["recovered", "canonical"].some((k) => k in opts))
        throw new Error("sign() legacy options not supported");
      const { hash: hash3, randomBytes: randomBytes2 } = CURVE;
      let { lowS, prehash, extraEntropy: ent } = opts;
      if (lowS == null)
        lowS = true;
      msgHash = ensureBytes("msgHash", msgHash);
      if (prehash)
        msgHash = ensureBytes("prehashed msgHash", hash3(msgHash));
      const h1int = bits2int_modN(msgHash);
      const d = normPrivateKeyToScalar(privateKey);
      const seedArgs = [int2octets(d), int2octets(h1int)];
      if (ent != null) {
        const e = ent === true ? randomBytes2(Fp2.BYTES) : ent;
        seedArgs.push(ensureBytes("extraEntropy", e));
      }
      const seed = concatBytes2(...seedArgs);
      const m = h1int;
      function k2sig(kBytes) {
        const k = bits2int(kBytes);
        if (!isWithinCurveOrder(k))
          return;
        const ik = invN(k);
        const q = Point2.BASE.multiply(k).toAffine();
        const r = modN2(q.x);
        if (r === _0n4)
          return;
        const s = modN2(ik * modN2(m + r * d));
        if (s === _0n4)
          return;
        let recovery = (q.x === r ? 0 : 2) | Number(q.y & _1n4);
        let normS = s;
        if (lowS && isBiggerThanHalfOrder(s)) {
          normS = normalizeS(s);
          recovery ^= 1;
        }
        return new Signature(r, normS, recovery);
      }
      return { seed, k2sig };
    }
    const defaultSigOpts = { lowS: CURVE.lowS, prehash: false };
    const defaultVerOpts = { lowS: CURVE.lowS, prehash: false };
    function sign(msgHash, privKey, opts = defaultSigOpts) {
      const { seed, k2sig } = prepSig(msgHash, privKey, opts);
      const C = CURVE;
      const drbg = createHmacDrbg(C.hash.outputLen, C.nByteLength, C.hmac);
      return drbg(seed, k2sig);
    }
    Point2.BASE._setWindowSize(8);
    function verify(signature, msgHash, publicKey, opts = defaultVerOpts) {
      const sg = signature;
      msgHash = ensureBytes("msgHash", msgHash);
      publicKey = ensureBytes("publicKey", publicKey);
      if ("strict" in opts)
        throw new Error("options.strict was renamed to lowS");
      const { lowS, prehash } = opts;
      let _sig = void 0;
      let P;
      try {
        if (typeof sg === "string" || sg instanceof Uint8Array) {
          try {
            _sig = Signature.fromDER(sg);
          } catch (derError) {
            if (!(derError instanceof DER.Err))
              throw derError;
            _sig = Signature.fromCompact(sg);
          }
        } else if (typeof sg === "object" && typeof sg.r === "bigint" && typeof sg.s === "bigint") {
          const { r: r2, s: s2 } = sg;
          _sig = new Signature(r2, s2);
        } else {
          throw new Error("PARSE");
        }
        P = Point2.fromHex(publicKey);
      } catch (error) {
        if (error.message === "PARSE")
          throw new Error(`signature must be Signature instance, Uint8Array or hex string`);
        return false;
      }
      if (lowS && _sig.hasHighS())
        return false;
      if (prehash)
        msgHash = CURVE.hash(msgHash);
      const { r, s } = _sig;
      const h = bits2int_modN(msgHash);
      const is = invN(s);
      const u1 = modN2(h * is);
      const u2 = modN2(r * is);
      const R = Point2.BASE.multiplyAndAddUnsafe(P, u1, u2)?.toAffine();
      if (!R)
        return false;
      const v = modN2(R.x);
      return v === r;
    }
    return {
      CURVE,
      getPublicKey: getPublicKey2,
      getSharedSecret,
      sign,
      verify,
      ProjectivePoint: Point2,
      Signature,
      utils
    };
  }

  // node_modules/nostr-tools/node_modules/@noble/curves/node_modules/@noble/hashes/esm/hmac.js
  var HMAC = class extends Hash {
    constructor(hash3, _key) {
      super();
      this.finished = false;
      this.destroyed = false;
      hash(hash3);
      const key = toBytes(_key);
      this.iHash = hash3.create();
      if (typeof this.iHash.update !== "function")
        throw new Error("Expected instance of class which extends utils.Hash");
      this.blockLen = this.iHash.blockLen;
      this.outputLen = this.iHash.outputLen;
      const blockLen = this.blockLen;
      const pad = new Uint8Array(blockLen);
      pad.set(key.length > blockLen ? hash3.create().update(key).digest() : key);
      for (let i2 = 0; i2 < pad.length; i2++)
        pad[i2] ^= 54;
      this.iHash.update(pad);
      this.oHash = hash3.create();
      for (let i2 = 0; i2 < pad.length; i2++)
        pad[i2] ^= 54 ^ 92;
      this.oHash.update(pad);
      pad.fill(0);
    }
    update(buf) {
      exists(this);
      this.iHash.update(buf);
      return this;
    }
    digestInto(out) {
      exists(this);
      bytes(out, this.outputLen);
      this.finished = true;
      this.iHash.digestInto(out);
      this.oHash.update(out);
      this.oHash.digestInto(out);
      this.destroy();
    }
    digest() {
      const out = new Uint8Array(this.oHash.outputLen);
      this.digestInto(out);
      return out;
    }
    _cloneInto(to) {
      to || (to = Object.create(Object.getPrototypeOf(this), {}));
      const { oHash, iHash, finished, destroyed, blockLen, outputLen } = this;
      to = to;
      to.finished = finished;
      to.destroyed = destroyed;
      to.blockLen = blockLen;
      to.outputLen = outputLen;
      to.oHash = oHash._cloneInto(to.oHash);
      to.iHash = iHash._cloneInto(to.iHash);
      return to;
    }
    destroy() {
      this.destroyed = true;
      this.oHash.destroy();
      this.iHash.destroy();
    }
  };
  var hmac = (hash3, key, message) => new HMAC(hash3, key).update(message).digest();
  hmac.create = (hash3, key) => new HMAC(hash3, key);

  // node_modules/nostr-tools/node_modules/@noble/curves/esm/_shortw_utils.js
  function getHash(hash3) {
    return {
      hash: hash3,
      hmac: (key, ...msgs) => hmac(hash3, key, concatBytes(...msgs)),
      randomBytes
    };
  }
  function createCurve(curveDef, defHash) {
    const create = (hash3) => weierstrass({ ...curveDef, ...getHash(hash3) });
    return Object.freeze({ ...create(defHash), create });
  }

  // node_modules/nostr-tools/node_modules/@noble/curves/esm/secp256k1.js
  var secp256k1P = BigInt("0xfffffffffffffffffffffffffffffffffffffffffffffffffffffffefffffc2f");
  var secp256k1N = BigInt("0xfffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141");
  var _1n5 = BigInt(1);
  var _2n4 = BigInt(2);
  var divNearest = (a, b) => (a + b / _2n4) / b;
  function sqrtMod(y) {
    const P = secp256k1P;
    const _3n3 = BigInt(3), _6n = BigInt(6), _11n = BigInt(11), _22n = BigInt(22);
    const _23n = BigInt(23), _44n = BigInt(44), _88n = BigInt(88);
    const b2 = y * y * y % P;
    const b3 = b2 * b2 * y % P;
    const b6 = pow2(b3, _3n3, P) * b3 % P;
    const b9 = pow2(b6, _3n3, P) * b3 % P;
    const b11 = pow2(b9, _2n4, P) * b2 % P;
    const b22 = pow2(b11, _11n, P) * b11 % P;
    const b44 = pow2(b22, _22n, P) * b22 % P;
    const b88 = pow2(b44, _44n, P) * b44 % P;
    const b176 = pow2(b88, _88n, P) * b88 % P;
    const b220 = pow2(b176, _44n, P) * b44 % P;
    const b223 = pow2(b220, _3n3, P) * b3 % P;
    const t1 = pow2(b223, _23n, P) * b22 % P;
    const t2 = pow2(t1, _6n, P) * b2 % P;
    const root = pow2(t2, _2n4, P);
    if (!Fp.eql(Fp.sqr(root), y))
      throw new Error("Cannot find square root");
    return root;
  }
  var Fp = Field(secp256k1P, void 0, void 0, { sqrt: sqrtMod });
  var secp256k1 = createCurve({
    a: BigInt(0),
    b: BigInt(7),
    Fp,
    n: secp256k1N,
    // Base point (x, y) aka generator point
    Gx: BigInt("55066263022277343669578718895168534326250603453777594175500187360389116729240"),
    Gy: BigInt("32670510020758816978083085130507043184471273380659243275938904335757337482424"),
    h: BigInt(1),
    lowS: true,
    /**
     * secp256k1 belongs to Koblitz curves: it has efficiently computable endomorphism.
     * Endomorphism uses 2x less RAM, speeds up precomputation by 2x and ECDH / key recovery by 20%.
     * For precomputed wNAF it trades off 1/2 init time & 1/3 ram for 20% perf hit.
     * Explanation: https://gist.github.com/paulmillr/eb670806793e84df628a7c434a873066
     */
    endo: {
      beta: BigInt("0x7ae96a2b657c07106e64479eac3434e99cf0497512f58995c1396c28719501ee"),
      splitScalar: (k) => {
        const n = secp256k1N;
        const a1 = BigInt("0x3086d221a7d46bcde86c90e49284eb15");
        const b1 = -_1n5 * BigInt("0xe4437ed6010e88286f547fa90abfe4c3");
        const a2 = BigInt("0x114ca50f7a8e2f3f657c1108d9d44cfd8");
        const b2 = a1;
        const POW_2_128 = BigInt("0x100000000000000000000000000000000");
        const c1 = divNearest(b2 * k, n);
        const c2 = divNearest(-b1 * k, n);
        let k1 = mod(k - c1 * a1 - c2 * a2, n);
        let k2 = mod(-c1 * b1 - c2 * b2, n);
        const k1neg = k1 > POW_2_128;
        const k2neg = k2 > POW_2_128;
        if (k1neg)
          k1 = n - k1;
        if (k2neg)
          k2 = n - k2;
        if (k1 > POW_2_128 || k2 > POW_2_128) {
          throw new Error("splitScalar: Endomorphism failed, k=" + k);
        }
        return { k1neg, k1, k2neg, k2 };
      }
    }
  }, sha256);
  var _0n5 = BigInt(0);
  var fe = (x) => typeof x === "bigint" && _0n5 < x && x < secp256k1P;
  var ge = (x) => typeof x === "bigint" && _0n5 < x && x < secp256k1N;
  var TAGGED_HASH_PREFIXES = {};
  function taggedHash(tag, ...messages) {
    let tagP = TAGGED_HASH_PREFIXES[tag];
    if (tagP === void 0) {
      const tagH = sha256(Uint8Array.from(tag, (c) => c.charCodeAt(0)));
      tagP = concatBytes2(tagH, tagH);
      TAGGED_HASH_PREFIXES[tag] = tagP;
    }
    return sha256(concatBytes2(tagP, ...messages));
  }
  var pointToBytes = (point) => point.toRawBytes(true).slice(1);
  var numTo32b = (n) => numberToBytesBE(n, 32);
  var modP = (x) => mod(x, secp256k1P);
  var modN = (x) => mod(x, secp256k1N);
  var Point = secp256k1.ProjectivePoint;
  var GmulAdd = (Q, a, b) => Point.BASE.multiplyAndAddUnsafe(Q, a, b);
  function schnorrGetExtPubKey(priv) {
    let d_ = secp256k1.utils.normPrivateKeyToScalar(priv);
    let p = Point.fromPrivateKey(d_);
    const scalar = p.hasEvenY() ? d_ : modN(-d_);
    return { scalar, bytes: pointToBytes(p) };
  }
  function lift_x(x) {
    if (!fe(x))
      throw new Error("bad x: need 0 < x < p");
    const xx = modP(x * x);
    const c = modP(xx * x + BigInt(7));
    let y = sqrtMod(c);
    if (y % _2n4 !== _0n5)
      y = modP(-y);
    const p = new Point(x, y, _1n5);
    p.assertValidity();
    return p;
  }
  function challenge(...args) {
    return modN(bytesToNumberBE(taggedHash("BIP0340/challenge", ...args)));
  }
  function schnorrGetPublicKey(privateKey) {
    return schnorrGetExtPubKey(privateKey).bytes;
  }
  function schnorrSign(message, privateKey, auxRand = randomBytes(32)) {
    const m = ensureBytes("message", message);
    const { bytes: px, scalar: d } = schnorrGetExtPubKey(privateKey);
    const a = ensureBytes("auxRand", auxRand, 32);
    const t = numTo32b(d ^ bytesToNumberBE(taggedHash("BIP0340/aux", a)));
    const rand = taggedHash("BIP0340/nonce", t, px, m);
    const k_ = modN(bytesToNumberBE(rand));
    if (k_ === _0n5)
      throw new Error("sign failed: k is zero");
    const { bytes: rx, scalar: k } = schnorrGetExtPubKey(k_);
    const e = challenge(rx, px, m);
    const sig = new Uint8Array(64);
    sig.set(rx, 0);
    sig.set(numTo32b(modN(k + e * d)), 32);
    if (!schnorrVerify(sig, m, px))
      throw new Error("sign: Invalid signature produced");
    return sig;
  }
  function schnorrVerify(signature, message, publicKey) {
    const sig = ensureBytes("signature", signature, 64);
    const m = ensureBytes("message", message);
    const pub = ensureBytes("publicKey", publicKey, 32);
    try {
      const P = lift_x(bytesToNumberBE(pub));
      const r = bytesToNumberBE(sig.subarray(0, 32));
      if (!fe(r))
        return false;
      const s = bytesToNumberBE(sig.subarray(32, 64));
      if (!ge(s))
        return false;
      const e = challenge(numTo32b(r), pointToBytes(P), m);
      const R = GmulAdd(P, s, modN(-e));
      if (!R || !R.hasEvenY() || R.toAffine().x !== r)
        return false;
      return true;
    } catch (error) {
      return false;
    }
  }
  var schnorr = /* @__PURE__ */ (() => ({
    getPublicKey: schnorrGetPublicKey,
    sign: schnorrSign,
    verify: schnorrVerify,
    utils: {
      randomPrivateKey: secp256k1.utils.randomPrivateKey,
      lift_x,
      pointToBytes,
      numberToBytesBE,
      bytesToNumberBE,
      taggedHash,
      mod
    }
  }))();

  // node_modules/nostr-tools/node_modules/@noble/hashes/esm/crypto.js
  var crypto2 = typeof globalThis === "object" && "crypto" in globalThis ? globalThis.crypto : void 0;

  // node_modules/nostr-tools/node_modules/@noble/hashes/esm/utils.js
  var u8a3 = (a) => a instanceof Uint8Array;
  var createView2 = (arr) => new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
  var rotr2 = (word, shift) => word << 32 - shift | word >>> shift;
  var isLE2 = new Uint8Array(new Uint32Array([287454020]).buffer)[0] === 68;
  if (!isLE2)
    throw new Error("Non little-endian hardware is not supported");
  var hexes2 = Array.from({ length: 256 }, (v, i2) => i2.toString(16).padStart(2, "0"));
  function bytesToHex2(bytes3) {
    if (!u8a3(bytes3))
      throw new Error("Uint8Array expected");
    let hex2 = "";
    for (let i2 = 0; i2 < bytes3.length; i2++) {
      hex2 += hexes2[bytes3[i2]];
    }
    return hex2;
  }
  function hexToBytes2(hex2) {
    if (typeof hex2 !== "string")
      throw new Error("hex string expected, got " + typeof hex2);
    const len = hex2.length;
    if (len % 2)
      throw new Error("padded hex string expected, got unpadded hex of length " + len);
    const array = new Uint8Array(len / 2);
    for (let i2 = 0; i2 < array.length; i2++) {
      const j = i2 * 2;
      const hexByte = hex2.slice(j, j + 2);
      const byte = Number.parseInt(hexByte, 16);
      if (Number.isNaN(byte) || byte < 0)
        throw new Error("Invalid byte sequence");
      array[i2] = byte;
    }
    return array;
  }
  function utf8ToBytes3(str) {
    if (typeof str !== "string")
      throw new Error(`utf8ToBytes expected string, got ${typeof str}`);
    return new Uint8Array(new TextEncoder().encode(str));
  }
  function toBytes2(data) {
    if (typeof data === "string")
      data = utf8ToBytes3(data);
    if (!u8a3(data))
      throw new Error(`expected Uint8Array, got ${typeof data}`);
    return data;
  }
  function concatBytes3(...arrays) {
    const r = new Uint8Array(arrays.reduce((sum, a) => sum + a.length, 0));
    let pad = 0;
    arrays.forEach((a) => {
      if (!u8a3(a))
        throw new Error("Uint8Array expected");
      r.set(a, pad);
      pad += a.length;
    });
    return r;
  }
  var Hash2 = class {
    // Safe version that clones internal state
    clone() {
      return this._cloneInto();
    }
  };
  function wrapConstructor2(hashCons) {
    const hashC = (msg) => hashCons().update(toBytes2(msg)).digest();
    const tmp = hashCons();
    hashC.outputLen = tmp.outputLen;
    hashC.blockLen = tmp.blockLen;
    hashC.create = () => hashCons();
    return hashC;
  }

  // node_modules/nostr-tools/node_modules/@noble/hashes/esm/_assert.js
  function number2(n) {
    if (!Number.isSafeInteger(n) || n < 0)
      throw new Error(`Wrong positive integer: ${n}`);
  }
  function bool(b) {
    if (typeof b !== "boolean")
      throw new Error(`Expected boolean, not ${b}`);
  }
  function bytes2(b, ...lengths) {
    if (!(b instanceof Uint8Array))
      throw new Error("Expected Uint8Array");
    if (lengths.length > 0 && !lengths.includes(b.length))
      throw new Error(`Expected Uint8Array of length ${lengths}, not of length=${b.length}`);
  }
  function hash2(hash3) {
    if (typeof hash3 !== "function" || typeof hash3.create !== "function")
      throw new Error("Hash should be wrapped by utils.wrapConstructor");
    number2(hash3.outputLen);
    number2(hash3.blockLen);
  }
  function exists2(instance, checkFinished = true) {
    if (instance.destroyed)
      throw new Error("Hash instance has been destroyed");
    if (checkFinished && instance.finished)
      throw new Error("Hash#digest() has already been called");
  }
  function output2(out, instance) {
    bytes2(out);
    const min = instance.outputLen;
    if (out.length < min) {
      throw new Error(`digestInto() expects output buffer of length at least ${min}`);
    }
  }
  var assert = {
    number: number2,
    bool,
    bytes: bytes2,
    hash: hash2,
    exists: exists2,
    output: output2
  };
  var assert_default = assert;

  // node_modules/nostr-tools/node_modules/@noble/hashes/esm/_sha2.js
  function setBigUint642(view, byteOffset, value, isLE3) {
    if (typeof view.setBigUint64 === "function")
      return view.setBigUint64(byteOffset, value, isLE3);
    const _32n = BigInt(32);
    const _u32_max = BigInt(4294967295);
    const wh = Number(value >> _32n & _u32_max);
    const wl = Number(value & _u32_max);
    const h = isLE3 ? 4 : 0;
    const l = isLE3 ? 0 : 4;
    view.setUint32(byteOffset + h, wh, isLE3);
    view.setUint32(byteOffset + l, wl, isLE3);
  }
  var SHA22 = class extends Hash2 {
    constructor(blockLen, outputLen, padOffset, isLE3) {
      super();
      this.blockLen = blockLen;
      this.outputLen = outputLen;
      this.padOffset = padOffset;
      this.isLE = isLE3;
      this.finished = false;
      this.length = 0;
      this.pos = 0;
      this.destroyed = false;
      this.buffer = new Uint8Array(blockLen);
      this.view = createView2(this.buffer);
    }
    update(data) {
      assert_default.exists(this);
      const { view, buffer, blockLen } = this;
      data = toBytes2(data);
      const len = data.length;
      for (let pos = 0; pos < len; ) {
        const take = Math.min(blockLen - this.pos, len - pos);
        if (take === blockLen) {
          const dataView = createView2(data);
          for (; blockLen <= len - pos; pos += blockLen)
            this.process(dataView, pos);
          continue;
        }
        buffer.set(data.subarray(pos, pos + take), this.pos);
        this.pos += take;
        pos += take;
        if (this.pos === blockLen) {
          this.process(view, 0);
          this.pos = 0;
        }
      }
      this.length += data.length;
      this.roundClean();
      return this;
    }
    digestInto(out) {
      assert_default.exists(this);
      assert_default.output(out, this);
      this.finished = true;
      const { buffer, view, blockLen, isLE: isLE3 } = this;
      let { pos } = this;
      buffer[pos++] = 128;
      this.buffer.subarray(pos).fill(0);
      if (this.padOffset > blockLen - pos) {
        this.process(view, 0);
        pos = 0;
      }
      for (let i2 = pos; i2 < blockLen; i2++)
        buffer[i2] = 0;
      setBigUint642(view, blockLen - 8, BigInt(this.length * 8), isLE3);
      this.process(view, 0);
      const oview = createView2(out);
      const len = this.outputLen;
      if (len % 4)
        throw new Error("_sha2: outputLen should be aligned to 32bit");
      const outLen = len / 4;
      const state = this.get();
      if (outLen > state.length)
        throw new Error("_sha2: outputLen bigger than state");
      for (let i2 = 0; i2 < outLen; i2++)
        oview.setUint32(4 * i2, state[i2], isLE3);
    }
    digest() {
      const { buffer, outputLen } = this;
      this.digestInto(buffer);
      const res = buffer.slice(0, outputLen);
      this.destroy();
      return res;
    }
    _cloneInto(to) {
      to || (to = new this.constructor());
      to.set(...this.get());
      const { blockLen, buffer, length, finished, destroyed, pos } = this;
      to.length = length;
      to.pos = pos;
      to.finished = finished;
      to.destroyed = destroyed;
      if (length % blockLen)
        to.buffer.set(buffer);
      return to;
    }
  };

  // node_modules/nostr-tools/node_modules/@noble/hashes/esm/sha256.js
  var Chi2 = (a, b, c) => a & b ^ ~a & c;
  var Maj2 = (a, b, c) => a & b ^ a & c ^ b & c;
  var SHA256_K2 = new Uint32Array([
    1116352408,
    1899447441,
    3049323471,
    3921009573,
    961987163,
    1508970993,
    2453635748,
    2870763221,
    3624381080,
    310598401,
    607225278,
    1426881987,
    1925078388,
    2162078206,
    2614888103,
    3248222580,
    3835390401,
    4022224774,
    264347078,
    604807628,
    770255983,
    1249150122,
    1555081692,
    1996064986,
    2554220882,
    2821834349,
    2952996808,
    3210313671,
    3336571891,
    3584528711,
    113926993,
    338241895,
    666307205,
    773529912,
    1294757372,
    1396182291,
    1695183700,
    1986661051,
    2177026350,
    2456956037,
    2730485921,
    2820302411,
    3259730800,
    3345764771,
    3516065817,
    3600352804,
    4094571909,
    275423344,
    430227734,
    506948616,
    659060556,
    883997877,
    958139571,
    1322822218,
    1537002063,
    1747873779,
    1955562222,
    2024104815,
    2227730452,
    2361852424,
    2428436474,
    2756734187,
    3204031479,
    3329325298
  ]);
  var IV2 = new Uint32Array([
    1779033703,
    3144134277,
    1013904242,
    2773480762,
    1359893119,
    2600822924,
    528734635,
    1541459225
  ]);
  var SHA256_W2 = new Uint32Array(64);
  var SHA2562 = class extends SHA22 {
    constructor() {
      super(64, 32, 8, false);
      this.A = IV2[0] | 0;
      this.B = IV2[1] | 0;
      this.C = IV2[2] | 0;
      this.D = IV2[3] | 0;
      this.E = IV2[4] | 0;
      this.F = IV2[5] | 0;
      this.G = IV2[6] | 0;
      this.H = IV2[7] | 0;
    }
    get() {
      const { A, B, C, D, E, F, G, H } = this;
      return [A, B, C, D, E, F, G, H];
    }
    // prettier-ignore
    set(A, B, C, D, E, F, G, H) {
      this.A = A | 0;
      this.B = B | 0;
      this.C = C | 0;
      this.D = D | 0;
      this.E = E | 0;
      this.F = F | 0;
      this.G = G | 0;
      this.H = H | 0;
    }
    process(view, offset) {
      for (let i2 = 0; i2 < 16; i2++, offset += 4)
        SHA256_W2[i2] = view.getUint32(offset, false);
      for (let i2 = 16; i2 < 64; i2++) {
        const W15 = SHA256_W2[i2 - 15];
        const W2 = SHA256_W2[i2 - 2];
        const s0 = rotr2(W15, 7) ^ rotr2(W15, 18) ^ W15 >>> 3;
        const s1 = rotr2(W2, 17) ^ rotr2(W2, 19) ^ W2 >>> 10;
        SHA256_W2[i2] = s1 + SHA256_W2[i2 - 7] + s0 + SHA256_W2[i2 - 16] | 0;
      }
      let { A, B, C, D, E, F, G, H } = this;
      for (let i2 = 0; i2 < 64; i2++) {
        const sigma1 = rotr2(E, 6) ^ rotr2(E, 11) ^ rotr2(E, 25);
        const T1 = H + sigma1 + Chi2(E, F, G) + SHA256_K2[i2] + SHA256_W2[i2] | 0;
        const sigma0 = rotr2(A, 2) ^ rotr2(A, 13) ^ rotr2(A, 22);
        const T2 = sigma0 + Maj2(A, B, C) | 0;
        H = G;
        G = F;
        F = E;
        E = D + T1 | 0;
        D = C;
        C = B;
        B = A;
        A = T1 + T2 | 0;
      }
      A = A + this.A | 0;
      B = B + this.B | 0;
      C = C + this.C | 0;
      D = D + this.D | 0;
      E = E + this.E | 0;
      F = F + this.F | 0;
      G = G + this.G | 0;
      H = H + this.H | 0;
      this.set(A, B, C, D, E, F, G, H);
    }
    roundClean() {
      SHA256_W2.fill(0);
    }
    destroy() {
      this.set(0, 0, 0, 0, 0, 0, 0, 0);
      this.buffer.fill(0);
    }
  };
  var SHA224 = class extends SHA2562 {
    constructor() {
      super();
      this.A = 3238371032 | 0;
      this.B = 914150663 | 0;
      this.C = 812702999 | 0;
      this.D = 4144912697 | 0;
      this.E = 4290775857 | 0;
      this.F = 1750603025 | 0;
      this.G = 1694076839 | 0;
      this.H = 3204075428 | 0;
      this.outputLen = 28;
    }
  };
  var sha2562 = wrapConstructor2(() => new SHA2562());
  var sha224 = wrapConstructor2(() => new SHA224());

  // node_modules/nostr-tools/lib/esm/pure.js
  var verifiedSymbol = Symbol("verified");
  var isRecord = (obj) => obj instanceof Object;
  function validateEvent(event) {
    if (!isRecord(event))
      return false;
    if (typeof event.kind !== "number")
      return false;
    if (typeof event.content !== "string")
      return false;
    if (typeof event.created_at !== "number")
      return false;
    if (typeof event.pubkey !== "string")
      return false;
    if (!event.pubkey.match(/^[a-f0-9]{64}$/))
      return false;
    if (!Array.isArray(event.tags))
      return false;
    for (let i2 = 0; i2 < event.tags.length; i2++) {
      let tag = event.tags[i2];
      if (!Array.isArray(tag))
        return false;
      for (let j = 0; j < tag.length; j++) {
        if (typeof tag[j] !== "string")
          return false;
      }
    }
    return true;
  }
  var utf8Decoder = new TextDecoder("utf-8");
  var utf8Encoder = new TextEncoder();
  var JS = class {
    generateSecretKey() {
      return schnorr.utils.randomPrivateKey();
    }
    getPublicKey(secretKey) {
      return bytesToHex2(schnorr.getPublicKey(secretKey));
    }
    finalizeEvent(t, secretKey) {
      const event = t;
      event.pubkey = bytesToHex2(schnorr.getPublicKey(secretKey));
      event.id = getEventHash(event);
      event.sig = bytesToHex2(schnorr.sign(getEventHash(event), secretKey));
      event[verifiedSymbol] = true;
      return event;
    }
    verifyEvent(event) {
      if (typeof event[verifiedSymbol] === "boolean")
        return event[verifiedSymbol];
      const hash3 = getEventHash(event);
      if (hash3 !== event.id) {
        event[verifiedSymbol] = false;
        return false;
      }
      try {
        const valid = schnorr.verify(event.sig, hash3, event.pubkey);
        event[verifiedSymbol] = valid;
        return valid;
      } catch (err) {
        event[verifiedSymbol] = false;
        return false;
      }
    }
  };
  function serializeEvent(evt) {
    if (!validateEvent(evt))
      throw new Error("can't serialize event with wrong or missing properties");
    return JSON.stringify([0, evt.pubkey, evt.created_at, evt.kind, evt.tags, evt.content]);
  }
  function getEventHash(event) {
    let eventHash = sha2562(utf8Encoder.encode(serializeEvent(event)));
    return bytesToHex2(eventHash);
  }
  var i = new JS();
  var generateSecretKey = i.generateSecretKey;
  var getPublicKey = i.getPublicKey;
  var finalizeEvent = i.finalizeEvent;
  var verifyEvent = i.verifyEvent;

  // node_modules/@scure/base/lib/esm/index.js
  function assertNumber(n) {
    if (!Number.isSafeInteger(n))
      throw new Error(`Wrong integer: ${n}`);
  }
  function chain(...args) {
    const wrap = (a, b) => (c) => a(b(c));
    const encode = Array.from(args).reverse().reduce((acc, i2) => acc ? wrap(acc, i2.encode) : i2.encode, void 0);
    const decode2 = args.reduce((acc, i2) => acc ? wrap(acc, i2.decode) : i2.decode, void 0);
    return { encode, decode: decode2 };
  }
  function alphabet(alphabet2) {
    return {
      encode: (digits) => {
        if (!Array.isArray(digits) || digits.length && typeof digits[0] !== "number")
          throw new Error("alphabet.encode input should be an array of numbers");
        return digits.map((i2) => {
          assertNumber(i2);
          if (i2 < 0 || i2 >= alphabet2.length)
            throw new Error(`Digit index outside alphabet: ${i2} (alphabet: ${alphabet2.length})`);
          return alphabet2[i2];
        });
      },
      decode: (input) => {
        if (!Array.isArray(input) || input.length && typeof input[0] !== "string")
          throw new Error("alphabet.decode input should be array of strings");
        return input.map((letter) => {
          if (typeof letter !== "string")
            throw new Error(`alphabet.decode: not string element=${letter}`);
          const index = alphabet2.indexOf(letter);
          if (index === -1)
            throw new Error(`Unknown letter: "${letter}". Allowed: ${alphabet2}`);
          return index;
        });
      }
    };
  }
  function join(separator = "") {
    if (typeof separator !== "string")
      throw new Error("join separator should be string");
    return {
      encode: (from) => {
        if (!Array.isArray(from) || from.length && typeof from[0] !== "string")
          throw new Error("join.encode input should be array of strings");
        for (let i2 of from)
          if (typeof i2 !== "string")
            throw new Error(`join.encode: non-string input=${i2}`);
        return from.join(separator);
      },
      decode: (to) => {
        if (typeof to !== "string")
          throw new Error("join.decode input should be string");
        return to.split(separator);
      }
    };
  }
  function padding(bits, chr = "=") {
    assertNumber(bits);
    if (typeof chr !== "string")
      throw new Error("padding chr should be string");
    return {
      encode(data) {
        if (!Array.isArray(data) || data.length && typeof data[0] !== "string")
          throw new Error("padding.encode input should be array of strings");
        for (let i2 of data)
          if (typeof i2 !== "string")
            throw new Error(`padding.encode: non-string input=${i2}`);
        while (data.length * bits % 8)
          data.push(chr);
        return data;
      },
      decode(input) {
        if (!Array.isArray(input) || input.length && typeof input[0] !== "string")
          throw new Error("padding.encode input should be array of strings");
        for (let i2 of input)
          if (typeof i2 !== "string")
            throw new Error(`padding.decode: non-string input=${i2}`);
        let end = input.length;
        if (end * bits % 8)
          throw new Error("Invalid padding: string should have whole number of bytes");
        for (; end > 0 && input[end - 1] === chr; end--) {
          if (!((end - 1) * bits % 8))
            throw new Error("Invalid padding: string has too much padding");
        }
        return input.slice(0, end);
      }
    };
  }
  function normalize(fn) {
    if (typeof fn !== "function")
      throw new Error("normalize fn should be function");
    return { encode: (from) => from, decode: (to) => fn(to) };
  }
  function convertRadix(data, from, to) {
    if (from < 2)
      throw new Error(`convertRadix: wrong from=${from}, base cannot be less than 2`);
    if (to < 2)
      throw new Error(`convertRadix: wrong to=${to}, base cannot be less than 2`);
    if (!Array.isArray(data))
      throw new Error("convertRadix: data should be array");
    if (!data.length)
      return [];
    let pos = 0;
    const res = [];
    const digits = Array.from(data);
    digits.forEach((d) => {
      assertNumber(d);
      if (d < 0 || d >= from)
        throw new Error(`Wrong integer: ${d}`);
    });
    while (true) {
      let carry = 0;
      let done = true;
      for (let i2 = pos; i2 < digits.length; i2++) {
        const digit = digits[i2];
        const digitBase = from * carry + digit;
        if (!Number.isSafeInteger(digitBase) || from * carry / from !== carry || digitBase - digit !== from * carry) {
          throw new Error("convertRadix: carry overflow");
        }
        carry = digitBase % to;
        digits[i2] = Math.floor(digitBase / to);
        if (!Number.isSafeInteger(digits[i2]) || digits[i2] * to + carry !== digitBase)
          throw new Error("convertRadix: carry overflow");
        if (!done)
          continue;
        else if (!digits[i2])
          pos = i2;
        else
          done = false;
      }
      res.push(carry);
      if (done)
        break;
    }
    for (let i2 = 0; i2 < data.length - 1 && data[i2] === 0; i2++)
      res.push(0);
    return res.reverse();
  }
  var gcd = (a, b) => !b ? a : gcd(b, a % b);
  var radix2carry = (from, to) => from + (to - gcd(from, to));
  function convertRadix2(data, from, to, padding2) {
    if (!Array.isArray(data))
      throw new Error("convertRadix2: data should be array");
    if (from <= 0 || from > 32)
      throw new Error(`convertRadix2: wrong from=${from}`);
    if (to <= 0 || to > 32)
      throw new Error(`convertRadix2: wrong to=${to}`);
    if (radix2carry(from, to) > 32) {
      throw new Error(`convertRadix2: carry overflow from=${from} to=${to} carryBits=${radix2carry(from, to)}`);
    }
    let carry = 0;
    let pos = 0;
    const mask = 2 ** to - 1;
    const res = [];
    for (const n of data) {
      assertNumber(n);
      if (n >= 2 ** from)
        throw new Error(`convertRadix2: invalid data word=${n} from=${from}`);
      carry = carry << from | n;
      if (pos + from > 32)
        throw new Error(`convertRadix2: carry overflow pos=${pos} from=${from}`);
      pos += from;
      for (; pos >= to; pos -= to)
        res.push((carry >> pos - to & mask) >>> 0);
      carry &= 2 ** pos - 1;
    }
    carry = carry << to - pos & mask;
    if (!padding2 && pos >= from)
      throw new Error("Excess padding");
    if (!padding2 && carry)
      throw new Error(`Non-zero padding: ${carry}`);
    if (padding2 && pos > 0)
      res.push(carry >>> 0);
    return res;
  }
  function radix(num) {
    assertNumber(num);
    return {
      encode: (bytes3) => {
        if (!(bytes3 instanceof Uint8Array))
          throw new Error("radix.encode input should be Uint8Array");
        return convertRadix(Array.from(bytes3), 2 ** 8, num);
      },
      decode: (digits) => {
        if (!Array.isArray(digits) || digits.length && typeof digits[0] !== "number")
          throw new Error("radix.decode input should be array of strings");
        return Uint8Array.from(convertRadix(digits, num, 2 ** 8));
      }
    };
  }
  function radix2(bits, revPadding = false) {
    assertNumber(bits);
    if (bits <= 0 || bits > 32)
      throw new Error("radix2: bits should be in (0..32]");
    if (radix2carry(8, bits) > 32 || radix2carry(bits, 8) > 32)
      throw new Error("radix2: carry overflow");
    return {
      encode: (bytes3) => {
        if (!(bytes3 instanceof Uint8Array))
          throw new Error("radix2.encode input should be Uint8Array");
        return convertRadix2(Array.from(bytes3), 8, bits, !revPadding);
      },
      decode: (digits) => {
        if (!Array.isArray(digits) || digits.length && typeof digits[0] !== "number")
          throw new Error("radix2.decode input should be array of strings");
        return Uint8Array.from(convertRadix2(digits, bits, 8, revPadding));
      }
    };
  }
  function unsafeWrapper(fn) {
    if (typeof fn !== "function")
      throw new Error("unsafeWrapper fn should be function");
    return function(...args) {
      try {
        return fn.apply(null, args);
      } catch (e) {
      }
    };
  }
  var base16 = chain(radix2(4), alphabet("0123456789ABCDEF"), join(""));
  var base32 = chain(radix2(5), alphabet("ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"), padding(5), join(""));
  var base32hex = chain(radix2(5), alphabet("0123456789ABCDEFGHIJKLMNOPQRSTUV"), padding(5), join(""));
  var base32crockford = chain(radix2(5), alphabet("0123456789ABCDEFGHJKMNPQRSTVWXYZ"), join(""), normalize((s) => s.toUpperCase().replace(/O/g, "0").replace(/[IL]/g, "1")));
  var base64 = chain(radix2(6), alphabet("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"), padding(6), join(""));
  var base64url = chain(radix2(6), alphabet("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"), padding(6), join(""));
  var genBase58 = (abc) => chain(radix(58), alphabet(abc), join(""));
  var base58 = genBase58("123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz");
  var base58flickr = genBase58("123456789abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ");
  var base58xrp = genBase58("rpshnaf39wBUDNEGHJKLM4PQRST7VWXYZ2bcdeCg65jkm8oFqi1tuvAxyz");
  var XMR_BLOCK_LEN = [0, 2, 3, 5, 6, 7, 9, 10, 11];
  var base58xmr = {
    encode(data) {
      let res = "";
      for (let i2 = 0; i2 < data.length; i2 += 8) {
        const block = data.subarray(i2, i2 + 8);
        res += base58.encode(block).padStart(XMR_BLOCK_LEN[block.length], "1");
      }
      return res;
    },
    decode(str) {
      let res = [];
      for (let i2 = 0; i2 < str.length; i2 += 11) {
        const slice = str.slice(i2, i2 + 11);
        const blockLen = XMR_BLOCK_LEN.indexOf(slice.length);
        const block = base58.decode(slice);
        for (let j = 0; j < block.length - blockLen; j++) {
          if (block[j] !== 0)
            throw new Error("base58xmr: wrong padding");
        }
        res = res.concat(Array.from(block.slice(block.length - blockLen)));
      }
      return Uint8Array.from(res);
    }
  };
  var BECH_ALPHABET = chain(alphabet("qpzry9x8gf2tvdw0s3jn54khce6mua7l"), join(""));
  var POLYMOD_GENERATORS = [996825010, 642813549, 513874426, 1027748829, 705979059];
  function bech32Polymod(pre) {
    const b = pre >> 25;
    let chk = (pre & 33554431) << 5;
    for (let i2 = 0; i2 < POLYMOD_GENERATORS.length; i2++) {
      if ((b >> i2 & 1) === 1)
        chk ^= POLYMOD_GENERATORS[i2];
    }
    return chk;
  }
  function bechChecksum(prefix, words, encodingConst = 1) {
    const len = prefix.length;
    let chk = 1;
    for (let i2 = 0; i2 < len; i2++) {
      const c = prefix.charCodeAt(i2);
      if (c < 33 || c > 126)
        throw new Error(`Invalid prefix (${prefix})`);
      chk = bech32Polymod(chk) ^ c >> 5;
    }
    chk = bech32Polymod(chk);
    for (let i2 = 0; i2 < len; i2++)
      chk = bech32Polymod(chk) ^ prefix.charCodeAt(i2) & 31;
    for (let v of words)
      chk = bech32Polymod(chk) ^ v;
    for (let i2 = 0; i2 < 6; i2++)
      chk = bech32Polymod(chk);
    chk ^= encodingConst;
    return BECH_ALPHABET.encode(convertRadix2([chk % 2 ** 30], 30, 5, false));
  }
  function genBech32(encoding) {
    const ENCODING_CONST = encoding === "bech32" ? 1 : 734539939;
    const _words = radix2(5);
    const fromWords = _words.decode;
    const toWords = _words.encode;
    const fromWordsUnsafe = unsafeWrapper(fromWords);
    function encode(prefix, words, limit = 90) {
      if (typeof prefix !== "string")
        throw new Error(`bech32.encode prefix should be string, not ${typeof prefix}`);
      if (!Array.isArray(words) || words.length && typeof words[0] !== "number")
        throw new Error(`bech32.encode words should be array of numbers, not ${typeof words}`);
      const actualLength = prefix.length + 7 + words.length;
      if (limit !== false && actualLength > limit)
        throw new TypeError(`Length ${actualLength} exceeds limit ${limit}`);
      prefix = prefix.toLowerCase();
      return `${prefix}1${BECH_ALPHABET.encode(words)}${bechChecksum(prefix, words, ENCODING_CONST)}`;
    }
    function decode2(str, limit = 90) {
      if (typeof str !== "string")
        throw new Error(`bech32.decode input should be string, not ${typeof str}`);
      if (str.length < 8 || limit !== false && str.length > limit)
        throw new TypeError(`Wrong string length: ${str.length} (${str}). Expected (8..${limit})`);
      const lowered = str.toLowerCase();
      if (str !== lowered && str !== str.toUpperCase())
        throw new Error(`String must be lowercase or uppercase`);
      str = lowered;
      const sepIndex = str.lastIndexOf("1");
      if (sepIndex === 0 || sepIndex === -1)
        throw new Error(`Letter "1" must be present between prefix and data only`);
      const prefix = str.slice(0, sepIndex);
      const _words2 = str.slice(sepIndex + 1);
      if (_words2.length < 6)
        throw new Error("Data must be at least 6 characters long");
      const words = BECH_ALPHABET.decode(_words2).slice(0, -6);
      const sum = bechChecksum(prefix, words, ENCODING_CONST);
      if (!_words2.endsWith(sum))
        throw new Error(`Invalid checksum in ${str}: expected "${sum}"`);
      return { prefix, words };
    }
    const decodeUnsafe = unsafeWrapper(decode2);
    function decodeToBytes(str) {
      const { prefix, words } = decode2(str, false);
      return { prefix, words, bytes: fromWords(words) };
    }
    return { encode, decode: decode2, decodeToBytes, decodeUnsafe, fromWords, fromWordsUnsafe, toWords };
  }
  var bech32 = genBech32("bech32");
  var bech32m = genBech32("bech32m");
  var utf8 = {
    encode: (data) => new TextDecoder().decode(data),
    decode: (str) => new TextEncoder().encode(str)
  };
  var hex = chain(radix2(4), alphabet("0123456789abcdef"), join(""), normalize((s) => {
    if (typeof s !== "string" || s.length % 2)
      throw new TypeError(`hex.decode: expected string, got ${typeof s} with length ${s.length}`);
    return s.toLowerCase();
  }));
  var CODERS = {
    utf8,
    hex,
    base16,
    base32,
    base64,
    base64url,
    base58,
    base58xmr
  };
  var coderTypeError = `Invalid encoding type. Available types: ${Object.keys(CODERS).join(", ")}`;

  // node_modules/nostr-tools/lib/esm/nip19.js
  var utf8Decoder2 = new TextDecoder("utf-8");
  var utf8Encoder2 = new TextEncoder();
  var Bech32MaxSize = 5e3;
  function integerToUint8Array(number3) {
    const uint8Array = new Uint8Array(4);
    uint8Array[0] = number3 >> 24 & 255;
    uint8Array[1] = number3 >> 16 & 255;
    uint8Array[2] = number3 >> 8 & 255;
    uint8Array[3] = number3 & 255;
    return uint8Array;
  }
  function decode(code) {
    let { prefix, words } = bech32.decode(code, Bech32MaxSize);
    let data = new Uint8Array(bech32.fromWords(words));
    switch (prefix) {
      case "nprofile": {
        let tlv = parseTLV(data);
        if (!tlv[0]?.[0])
          throw new Error("missing TLV 0 for nprofile");
        if (tlv[0][0].length !== 32)
          throw new Error("TLV 0 should be 32 bytes");
        return {
          type: "nprofile",
          data: {
            pubkey: bytesToHex2(tlv[0][0]),
            relays: tlv[1] ? tlv[1].map((d) => utf8Decoder2.decode(d)) : []
          }
        };
      }
      case "nevent": {
        let tlv = parseTLV(data);
        if (!tlv[0]?.[0])
          throw new Error("missing TLV 0 for nevent");
        if (tlv[0][0].length !== 32)
          throw new Error("TLV 0 should be 32 bytes");
        if (tlv[2] && tlv[2][0].length !== 32)
          throw new Error("TLV 2 should be 32 bytes");
        if (tlv[3] && tlv[3][0].length !== 4)
          throw new Error("TLV 3 should be 4 bytes");
        return {
          type: "nevent",
          data: {
            id: bytesToHex2(tlv[0][0]),
            relays: tlv[1] ? tlv[1].map((d) => utf8Decoder2.decode(d)) : [],
            author: tlv[2]?.[0] ? bytesToHex2(tlv[2][0]) : void 0,
            kind: tlv[3]?.[0] ? parseInt(bytesToHex2(tlv[3][0]), 16) : void 0
          }
        };
      }
      case "naddr": {
        let tlv = parseTLV(data);
        if (!tlv[0]?.[0])
          throw new Error("missing TLV 0 for naddr");
        if (!tlv[2]?.[0])
          throw new Error("missing TLV 2 for naddr");
        if (tlv[2][0].length !== 32)
          throw new Error("TLV 2 should be 32 bytes");
        if (!tlv[3]?.[0])
          throw new Error("missing TLV 3 for naddr");
        if (tlv[3][0].length !== 4)
          throw new Error("TLV 3 should be 4 bytes");
        return {
          type: "naddr",
          data: {
            identifier: utf8Decoder2.decode(tlv[0][0]),
            pubkey: bytesToHex2(tlv[2][0]),
            kind: parseInt(bytesToHex2(tlv[3][0]), 16),
            relays: tlv[1] ? tlv[1].map((d) => utf8Decoder2.decode(d)) : []
          }
        };
      }
      case "nsec":
        return { type: prefix, data };
      case "npub":
      case "note":
        return { type: prefix, data: bytesToHex2(data) };
      default:
        throw new Error(`unknown prefix ${prefix}`);
    }
  }
  function parseTLV(data) {
    let result = {};
    let rest = data;
    while (rest.length > 0) {
      let t = rest[0];
      let l = rest[1];
      let v = rest.slice(2, 2 + l);
      rest = rest.slice(2 + l);
      if (v.length < l)
        throw new Error(`not enough data to read on TLV ${t}`);
      result[t] = result[t] || [];
      result[t].push(v);
    }
    return result;
  }
  function npubEncode(hex2) {
    return encodeBytes("npub", hexToBytes2(hex2));
  }
  function noteEncode(hex2) {
    return encodeBytes("note", hexToBytes2(hex2));
  }
  function encodeBech32(prefix, data) {
    let words = bech32.toWords(data);
    return bech32.encode(prefix, words, Bech32MaxSize);
  }
  function encodeBytes(prefix, bytes3) {
    return encodeBech32(prefix, bytes3);
  }
  function neventEncode(event) {
    let kindArray;
    if (event.kind !== void 0) {
      kindArray = integerToUint8Array(event.kind);
    }
    let data = encodeTLV({
      0: [hexToBytes2(event.id)],
      1: (event.relays || []).map((url) => utf8Encoder2.encode(url)),
      2: event.author ? [hexToBytes2(event.author)] : [],
      3: kindArray ? [new Uint8Array(kindArray)] : []
    });
    return encodeBech32("nevent", data);
  }
  function encodeTLV(tlv) {
    let entries = [];
    Object.entries(tlv).reverse().forEach(([t, vs]) => {
      vs.forEach((v) => {
        let entry = new Uint8Array(v.length + 2);
        entry.set([parseInt(t)], 0);
        entry.set([v.length], 1);
        entry.set(v, 2);
        entries.push(entry);
      });
    });
    return concatBytes3(...entries);
  }

  // node_modules/@noble/hashes/esm/utils.js
  function isBytes(a) {
    return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array";
  }
  function anumber(n) {
    if (!Number.isSafeInteger(n) || n < 0)
      throw new Error("positive integer expected, got " + n);
  }
  function abytes(b, ...lengths) {
    if (!isBytes(b))
      throw new Error("Uint8Array expected");
    if (lengths.length > 0 && !lengths.includes(b.length))
      throw new Error("Uint8Array expected of length " + lengths + ", got length=" + b.length);
  }
  function ahash(h) {
    if (typeof h !== "function" || typeof h.create !== "function")
      throw new Error("Hash should be wrapped by utils.createHasher");
    anumber(h.outputLen);
    anumber(h.blockLen);
  }
  function aexists(instance, checkFinished = true) {
    if (instance.destroyed)
      throw new Error("Hash instance has been destroyed");
    if (checkFinished && instance.finished)
      throw new Error("Hash#digest() has already been called");
  }
  function aoutput(out, instance) {
    abytes(out);
    const min = instance.outputLen;
    if (out.length < min) {
      throw new Error("digestInto() expects output buffer of length at least " + min);
    }
  }
  function clean(...arrays) {
    for (let i2 = 0; i2 < arrays.length; i2++) {
      arrays[i2].fill(0);
    }
  }
  function createView3(arr) {
    return new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
  }
  function rotr3(word, shift) {
    return word << 32 - shift | word >>> shift;
  }
  var hasHexBuiltin = /* @__PURE__ */ (() => (
    // @ts-ignore
    typeof Uint8Array.from([]).toHex === "function" && typeof Uint8Array.fromHex === "function"
  ))();
  var asciis = { _0: 48, _9: 57, A: 65, F: 70, a: 97, f: 102 };
  function asciiToBase16(ch) {
    if (ch >= asciis._0 && ch <= asciis._9)
      return ch - asciis._0;
    if (ch >= asciis.A && ch <= asciis.F)
      return ch - (asciis.A - 10);
    if (ch >= asciis.a && ch <= asciis.f)
      return ch - (asciis.a - 10);
    return;
  }
  function hexToBytes3(hex2) {
    if (typeof hex2 !== "string")
      throw new Error("hex string expected, got " + typeof hex2);
    if (hasHexBuiltin)
      return Uint8Array.fromHex(hex2);
    const hl = hex2.length;
    const al = hl / 2;
    if (hl % 2)
      throw new Error("hex string expected, got unpadded hex of length " + hl);
    const array = new Uint8Array(al);
    for (let ai = 0, hi = 0; ai < al; ai++, hi += 2) {
      const n1 = asciiToBase16(hex2.charCodeAt(hi));
      const n2 = asciiToBase16(hex2.charCodeAt(hi + 1));
      if (n1 === void 0 || n2 === void 0) {
        const char = hex2[hi] + hex2[hi + 1];
        throw new Error('hex string expected, got non-hex character "' + char + '" at index ' + hi);
      }
      array[ai] = n1 * 16 + n2;
    }
    return array;
  }
  function utf8ToBytes4(str) {
    if (typeof str !== "string")
      throw new Error("string expected");
    return new Uint8Array(new TextEncoder().encode(str));
  }
  function toBytes3(data) {
    if (typeof data === "string")
      data = utf8ToBytes4(data);
    abytes(data);
    return data;
  }
  function concatBytes4(...arrays) {
    let sum = 0;
    for (let i2 = 0; i2 < arrays.length; i2++) {
      const a = arrays[i2];
      abytes(a);
      sum += a.length;
    }
    const res = new Uint8Array(sum);
    for (let i2 = 0, pad = 0; i2 < arrays.length; i2++) {
      const a = arrays[i2];
      res.set(a, pad);
      pad += a.length;
    }
    return res;
  }
  var Hash3 = class {
  };
  function createHasher(hashCons) {
    const hashC = (msg) => hashCons().update(toBytes3(msg)).digest();
    const tmp = hashCons();
    hashC.outputLen = tmp.outputLen;
    hashC.blockLen = tmp.blockLen;
    hashC.create = () => hashCons();
    return hashC;
  }

  // node_modules/@noble/hashes/esm/hmac.js
  var HMAC2 = class extends Hash3 {
    constructor(hash3, _key) {
      super();
      this.finished = false;
      this.destroyed = false;
      ahash(hash3);
      const key = toBytes3(_key);
      this.iHash = hash3.create();
      if (typeof this.iHash.update !== "function")
        throw new Error("Expected instance of class which extends utils.Hash");
      this.blockLen = this.iHash.blockLen;
      this.outputLen = this.iHash.outputLen;
      const blockLen = this.blockLen;
      const pad = new Uint8Array(blockLen);
      pad.set(key.length > blockLen ? hash3.create().update(key).digest() : key);
      for (let i2 = 0; i2 < pad.length; i2++)
        pad[i2] ^= 54;
      this.iHash.update(pad);
      this.oHash = hash3.create();
      for (let i2 = 0; i2 < pad.length; i2++)
        pad[i2] ^= 54 ^ 92;
      this.oHash.update(pad);
      clean(pad);
    }
    update(buf) {
      aexists(this);
      this.iHash.update(buf);
      return this;
    }
    digestInto(out) {
      aexists(this);
      abytes(out, this.outputLen);
      this.finished = true;
      this.iHash.digestInto(out);
      this.oHash.update(out);
      this.oHash.digestInto(out);
      this.destroy();
    }
    digest() {
      const out = new Uint8Array(this.oHash.outputLen);
      this.digestInto(out);
      return out;
    }
    _cloneInto(to) {
      to || (to = Object.create(Object.getPrototypeOf(this), {}));
      const { oHash, iHash, finished, destroyed, blockLen, outputLen } = this;
      to = to;
      to.finished = finished;
      to.destroyed = destroyed;
      to.blockLen = blockLen;
      to.outputLen = outputLen;
      to.oHash = oHash._cloneInto(to.oHash);
      to.iHash = iHash._cloneInto(to.iHash);
      return to;
    }
    clone() {
      return this._cloneInto();
    }
    destroy() {
      this.destroyed = true;
      this.oHash.destroy();
      this.iHash.destroy();
    }
  };
  var hmac2 = (hash3, key, message) => new HMAC2(hash3, key).update(message).digest();
  hmac2.create = (hash3, key) => new HMAC2(hash3, key);

  // node_modules/@noble/hashes/esm/_md.js
  function setBigUint643(view, byteOffset, value, isLE3) {
    if (typeof view.setBigUint64 === "function")
      return view.setBigUint64(byteOffset, value, isLE3);
    const _32n = BigInt(32);
    const _u32_max = BigInt(4294967295);
    const wh = Number(value >> _32n & _u32_max);
    const wl = Number(value & _u32_max);
    const h = isLE3 ? 4 : 0;
    const l = isLE3 ? 0 : 4;
    view.setUint32(byteOffset + h, wh, isLE3);
    view.setUint32(byteOffset + l, wl, isLE3);
  }
  function Chi3(a, b, c) {
    return a & b ^ ~a & c;
  }
  function Maj3(a, b, c) {
    return a & b ^ a & c ^ b & c;
  }
  var HashMD = class extends Hash3 {
    constructor(blockLen, outputLen, padOffset, isLE3) {
      super();
      this.finished = false;
      this.length = 0;
      this.pos = 0;
      this.destroyed = false;
      this.blockLen = blockLen;
      this.outputLen = outputLen;
      this.padOffset = padOffset;
      this.isLE = isLE3;
      this.buffer = new Uint8Array(blockLen);
      this.view = createView3(this.buffer);
    }
    update(data) {
      aexists(this);
      data = toBytes3(data);
      abytes(data);
      const { view, buffer, blockLen } = this;
      const len = data.length;
      for (let pos = 0; pos < len; ) {
        const take = Math.min(blockLen - this.pos, len - pos);
        if (take === blockLen) {
          const dataView = createView3(data);
          for (; blockLen <= len - pos; pos += blockLen)
            this.process(dataView, pos);
          continue;
        }
        buffer.set(data.subarray(pos, pos + take), this.pos);
        this.pos += take;
        pos += take;
        if (this.pos === blockLen) {
          this.process(view, 0);
          this.pos = 0;
        }
      }
      this.length += data.length;
      this.roundClean();
      return this;
    }
    digestInto(out) {
      aexists(this);
      aoutput(out, this);
      this.finished = true;
      const { buffer, view, blockLen, isLE: isLE3 } = this;
      let { pos } = this;
      buffer[pos++] = 128;
      clean(this.buffer.subarray(pos));
      if (this.padOffset > blockLen - pos) {
        this.process(view, 0);
        pos = 0;
      }
      for (let i2 = pos; i2 < blockLen; i2++)
        buffer[i2] = 0;
      setBigUint643(view, blockLen - 8, BigInt(this.length * 8), isLE3);
      this.process(view, 0);
      const oview = createView3(out);
      const len = this.outputLen;
      if (len % 4)
        throw new Error("_sha2: outputLen should be aligned to 32bit");
      const outLen = len / 4;
      const state = this.get();
      if (outLen > state.length)
        throw new Error("_sha2: outputLen bigger than state");
      for (let i2 = 0; i2 < outLen; i2++)
        oview.setUint32(4 * i2, state[i2], isLE3);
    }
    digest() {
      const { buffer, outputLen } = this;
      this.digestInto(buffer);
      const res = buffer.slice(0, outputLen);
      this.destroy();
      return res;
    }
    _cloneInto(to) {
      to || (to = new this.constructor());
      to.set(...this.get());
      const { blockLen, buffer, length, finished, destroyed, pos } = this;
      to.destroyed = destroyed;
      to.finished = finished;
      to.length = length;
      to.pos = pos;
      if (length % blockLen)
        to.buffer.set(buffer);
      return to;
    }
    clone() {
      return this._cloneInto();
    }
  };
  var SHA256_IV = /* @__PURE__ */ Uint32Array.from([
    1779033703,
    3144134277,
    1013904242,
    2773480762,
    1359893119,
    2600822924,
    528734635,
    1541459225
  ]);

  // node_modules/@noble/hashes/esm/sha2.js
  var SHA256_K3 = /* @__PURE__ */ Uint32Array.from([
    1116352408,
    1899447441,
    3049323471,
    3921009573,
    961987163,
    1508970993,
    2453635748,
    2870763221,
    3624381080,
    310598401,
    607225278,
    1426881987,
    1925078388,
    2162078206,
    2614888103,
    3248222580,
    3835390401,
    4022224774,
    264347078,
    604807628,
    770255983,
    1249150122,
    1555081692,
    1996064986,
    2554220882,
    2821834349,
    2952996808,
    3210313671,
    3336571891,
    3584528711,
    113926993,
    338241895,
    666307205,
    773529912,
    1294757372,
    1396182291,
    1695183700,
    1986661051,
    2177026350,
    2456956037,
    2730485921,
    2820302411,
    3259730800,
    3345764771,
    3516065817,
    3600352804,
    4094571909,
    275423344,
    430227734,
    506948616,
    659060556,
    883997877,
    958139571,
    1322822218,
    1537002063,
    1747873779,
    1955562222,
    2024104815,
    2227730452,
    2361852424,
    2428436474,
    2756734187,
    3204031479,
    3329325298
  ]);
  var SHA256_W3 = /* @__PURE__ */ new Uint32Array(64);
  var SHA2563 = class extends HashMD {
    constructor(outputLen = 32) {
      super(64, outputLen, 8, false);
      this.A = SHA256_IV[0] | 0;
      this.B = SHA256_IV[1] | 0;
      this.C = SHA256_IV[2] | 0;
      this.D = SHA256_IV[3] | 0;
      this.E = SHA256_IV[4] | 0;
      this.F = SHA256_IV[5] | 0;
      this.G = SHA256_IV[6] | 0;
      this.H = SHA256_IV[7] | 0;
    }
    get() {
      const { A, B, C, D, E, F, G, H } = this;
      return [A, B, C, D, E, F, G, H];
    }
    // prettier-ignore
    set(A, B, C, D, E, F, G, H) {
      this.A = A | 0;
      this.B = B | 0;
      this.C = C | 0;
      this.D = D | 0;
      this.E = E | 0;
      this.F = F | 0;
      this.G = G | 0;
      this.H = H | 0;
    }
    process(view, offset) {
      for (let i2 = 0; i2 < 16; i2++, offset += 4)
        SHA256_W3[i2] = view.getUint32(offset, false);
      for (let i2 = 16; i2 < 64; i2++) {
        const W15 = SHA256_W3[i2 - 15];
        const W2 = SHA256_W3[i2 - 2];
        const s0 = rotr3(W15, 7) ^ rotr3(W15, 18) ^ W15 >>> 3;
        const s1 = rotr3(W2, 17) ^ rotr3(W2, 19) ^ W2 >>> 10;
        SHA256_W3[i2] = s1 + SHA256_W3[i2 - 7] + s0 + SHA256_W3[i2 - 16] | 0;
      }
      let { A, B, C, D, E, F, G, H } = this;
      for (let i2 = 0; i2 < 64; i2++) {
        const sigma1 = rotr3(E, 6) ^ rotr3(E, 11) ^ rotr3(E, 25);
        const T1 = H + sigma1 + Chi3(E, F, G) + SHA256_K3[i2] + SHA256_W3[i2] | 0;
        const sigma0 = rotr3(A, 2) ^ rotr3(A, 13) ^ rotr3(A, 22);
        const T2 = sigma0 + Maj3(A, B, C) | 0;
        H = G;
        G = F;
        F = E;
        E = D + T1 | 0;
        D = C;
        C = B;
        B = A;
        A = T1 + T2 | 0;
      }
      A = A + this.A | 0;
      B = B + this.B | 0;
      C = C + this.C | 0;
      D = D + this.D | 0;
      E = E + this.E | 0;
      F = F + this.F | 0;
      G = G + this.G | 0;
      H = H + this.H | 0;
      this.set(A, B, C, D, E, F, G, H);
    }
    roundClean() {
      clean(SHA256_W3);
    }
    destroy() {
      this.set(0, 0, 0, 0, 0, 0, 0, 0);
      clean(this.buffer);
    }
  };
  var sha2563 = /* @__PURE__ */ createHasher(() => new SHA2563());

  // node_modules/@noble/hashes/esm/sha256.js
  var sha2564 = sha2563;

  // src/lib/glub.js
  var GLUB_TAG = "glub";
  var GLUB_VERSION_FIELD = "v";
  var CHAT_KINDS = /* @__PURE__ */ new Set([2e4, 23333]);
  var NOTE_KINDS = /* @__PURE__ */ new Set([1]);
  var COLORS = {
    "0": "#48484f",
    "1": "#4a5bd6",
    "2": "#3fb950",
    "3": "#2dd4bf",
    "4": "#e5484d",
    "5": "#c74ddb",
    "6": "#f0a020",
    "7": "#a0a0a8",
    "8": "#6e6e78",
    "9": "#5b8dff",
    a: "#55ff77",
    b: "#55ffff",
    c: "#ff6a6a",
    d: "#ff77ff",
    e: "#ffe45e",
    f: "#ffffff"
  };
  var FORMATS = /* @__PURE__ */ new Set(["l", "m", "n", "o"]);
  var OBFUSCATE = "k";
  var RAINBOW = "g";
  var RESET = "r";
  var FMT_MAX = 200;
  var RICH_MAX = 8e3;
  var FLAIRS = [
    { name: "fire", label: "fire", description: "rising embers and a warm glow" },
    { name: "lightning", label: "lightning", description: "electric arcs across the line" },
    { name: "stars", label: "stars", description: "a slow twinkling starfield" },
    { name: "rain", label: "rain", description: "falling drops and a cool wash" },
    { name: "plume", label: "plume", description: "soft smoke plumes drifting upward" },
    { name: "neon", label: "neon", description: "a pulsing neon frame" },
    { name: "matrix", label: "matrix", description: "falling green glyph columns" },
    { name: "sonar", label: "sonar", description: "expanding radar rings" },
    { name: "fireflies", label: "fireflies", description: "drifting glowing motes" },
    { name: "bubbles", label: "bubbles", description: "bright bubbles floating up" },
    { name: "aurora", label: "aurora", description: "flowing polar light" },
    { name: "bitcoin", label: "bitcoin", description: "orange coins and sparks" },
    { name: "glitch", label: "glitch", description: "RGB tears and screen noise" },
    { name: "sol", label: "sol", description: "golden solar rays (glub.chat NIP-05 only)", gated: true }
  ];
  var FLAIR_NAMES = new Set(FLAIRS.map((f) => f.name));
  function isCodeChar(ch) {
    return Object.prototype.hasOwnProperty.call(COLORS, ch) || FORMATS.has(ch) || ch === OBFUSCATE || ch === RAINBOW || ch === RESET;
  }
  function tokenize(raw) {
    const s = String(raw || "");
    const tokens = [];
    let text = "";
    const flush = () => {
      if (text) {
        tokens.push({ t: "text", v: text });
        text = "";
      }
    };
    let i2 = 0;
    while (i2 < s.length) {
      const ch = s[i2];
      if (ch === "&" && i2 + 1 < s.length) {
        const next = s[i2 + 1];
        if (next === "&") {
          text += "&";
          i2 += 2;
          continue;
        }
        if (isCodeChar(next)) {
          flush();
          tokens.push({ t: "code", c: next });
          i2 += 2;
          continue;
        }
      }
      text += ch;
      i2++;
    }
    flush();
    return tokens;
  }
  function stripFormat(raw) {
    let out = "";
    for (const tok of tokenize(raw)) if (tok.t === "text") out += tok.v;
    return out;
  }
  function hasFormat(raw) {
    return stripFormat(raw) !== String(raw || "");
  }
  var EMOJI_RE = new RegExp("(?:[\\u{1F1E6}-\\u{1F1FF}]{2}|[#*0-9]\\uFE0F?\\u20E3|\\p{Extended_Pictographic}(?:\\uFE0F|\\u20E3|[\\u{1F3FB}-\\u{1F3FF}])?(?:\\u200D\\p{Extended_Pictographic}(?:\\uFE0F|[\\u{1F3FB}-\\u{1F3FF}])?)*)", "gu");
  function sanitizeTemplate(raw) {
    const s = String(raw || "").replace(/[\r\n\t]+/g, " ").trim();
    return s && s.length <= FMT_MAX ? s : "";
  }
  function parseGlubMeta(eventOrTags) {
    const tags = Array.isArray(eventOrTags) ? eventOrTags : eventOrTags?.tags || [];
    const out = {};
    for (const tag of tags) {
      if (!Array.isArray(tag) || tag[0] !== GLUB_TAG) continue;
      for (let i2 = 1; i2 + 1 < tag.length; i2 += 2) {
        const k = tag[i2];
        const v = tag[i2 + 1];
        if (typeof k === "string" && typeof v === "string" && !(k in out)) out[k] = v;
      }
    }
    return out;
  }
  function buildGlubTag(meta, build) {
    const fields = ["rich", "fmt", "flair"];
    const tag = [GLUB_TAG];
    for (const field of fields) {
      const v = meta?.[field];
      if (typeof v === "string" && v) tag.push(field, v);
    }
    if (typeof build === "string" && build) tag.push(GLUB_VERSION_FIELD, build);
    return tag.length > 1 ? tag : null;
  }
  function getTag(tags, name) {
    if (!Array.isArray(tags)) return void 0;
    for (const t of tags) {
      if (Array.isArray(t) && t[0] === name) return t;
    }
    return void 0;
  }
  function getTagValue(tags, name) {
    return getTag(tags, name)?.[1];
  }
  function isValidFlair(name) {
    return FLAIR_NAMES.has(name);
  }
  function kindGroup(kind) {
    if (kind === 2e4 || kind === 20001 || kind === 23333) return "chat";
    if (kind === 1) return "note";
    if (kind === 5 || kind === 7) return "reaction";
    if (kind === 4 || kind === 13 || kind === 14 || kind === 1059) return "dm";
    if (kind === 0 || kind === 3) return "profile";
    return "other";
  }
  var TRACKING_PARAMS = /* @__PURE__ */ new Set([
    "fbclid",
    "gclid",
    "dclid",
    "msclkid",
    "yclid",
    "si",
    "spm",
    "igshid",
    "mc_cid",
    "mc_eid",
    "ref_src",
    "ref_url",
    "vero_id",
    "oly_anon_id",
    "oly_enc_id",
    "_hsenc",
    "_hsmi",
    "mkt_tok"
  ]);
  function stripTrackingParams(text) {
    return String(text || "").replace(/https?:\/\/[^\s<>()]+/g, (url) => {
      try {
        const u = new URL(url);
        let changed = false;
        for (const key of [...u.searchParams.keys()]) {
          const lower = key.toLowerCase();
          if (lower.startsWith("utm_") || TRACKING_PARAMS.has(lower)) {
            u.searchParams.delete(key);
            changed = true;
          }
        }
        return changed ? u.toString() : url;
      } catch {
        return url;
      }
    });
  }

  // src/lib/themes.js
  var GLUB_THEMES = [
    {
      id: "bitchat",
      label: "Chat",
      description: "black phosphor green, blue channels",
      bg: "#000000",
      fg: "#8fe89c",
      muted: "#7a828c",
      geo: "#5cb3ff",
      accent: "#30d158",
      danger: "#ff7b72"
    },
    {
      id: "cyberpunk-2077",
      label: "Cyberpunk 2077",
      description: "cyan readouts & hot-pink chrome",
      bg: "#000000",
      fg: "#d7d7dc",
      muted: "#7e7e88",
      geo: "#2de2e6",
      accent: "#ff2a6d",
      danger: "#ff5a5a"
    },
    {
      id: "blade-runner-blossom",
      label: "Blade Runner",
      description: "blossom pink on violet haze",
      bg: "#0a0712",
      fg: "#e4d9f2",
      muted: "#857a9e",
      geo: "#b48cff",
      accent: "#ff6ac2",
      danger: "#ff7b72"
    },
    {
      id: "ex-machina",
      label: "Ex Machina",
      description: "emergency red & amber alarm",
      bg: "#0b0507",
      fg: "#f2d9d9",
      muted: "#93706e",
      geo: "#ff8a5c",
      accent: "#ff3b30",
      danger: "#ffd60a"
    },
    {
      id: "giedi-prime",
      label: "Giedi Prime",
      description: "infrared monochrome",
      bg: "#050505",
      fg: "#ededed",
      muted: "#878787",
      geo: "#bdbdbd",
      accent: "#e6e6e6",
      danger: "#ff7b72"
    },
    {
      id: "matrix-neo",
      label: "Matrix Neo",
      description: "code-rain green on true black",
      bg: "#000000",
      fg: "#a8ffdf",
      muted: "#567b70",
      geo: "#80fffb",
      accent: "#00ffa1",
      danger: "#ff7b72"
    },
    {
      id: "star-lord",
      label: "Star-Lord",
      description: "amber-gold & engine cyan",
      bg: "#0c0806",
      fg: "#f2ddb8",
      muted: "#8e7d67",
      geo: "#ff8c42",
      accent: "#3fd8ff",
      danger: "#ff7b72"
    },
    {
      id: "time-variance-amber",
      label: "Time Variance",
      description: "mid-century CRT amber",
      bg: "#0b0906",
      fg: "#ffd98c",
      muted: "#97845f",
      geo: "#ffc861",
      accent: "#ff9e1f",
      danger: "#ff6b5e"
    },
    {
      id: "tron-legacy",
      label: "Tron Legacy",
      description: "grid ice blue & disc cyan",
      bg: "#04070c",
      fg: "#cdeeff",
      muted: "#5f7f8e",
      geo: "#5ce1ff",
      accent: "#00b8ff",
      danger: "#ff7b72"
    },
    {
      id: "lumon-light",
      label: "Lumon Light",
      description: "milky office light & teal",
      bg: "#eef0ea",
      fg: "#24424a",
      muted: "#6c8189",
      geo: "#2f7d97",
      accent: "#106a74",
      danger: "#b3362b",
      light: true
    },
    {
      id: "her-light",
      label: "Her Light",
      description: "coral & cream",
      bg: "#f7efe6",
      fg: "#6b4a3f",
      muted: "#a2867a",
      geo: "#b04a36",
      accent: "#e0654f",
      danger: "#a63324",
      light: true
    },
    {
      id: "iced-matcha-latte",
      label: "Iced Matcha Latte",
      description: "oat cream, iced matcha, cold green lift",
      bg: "#f1f0e7",
      fg: "#29382f",
      muted: "#778578",
      geo: "#5b8b6e",
      accent: "#4c8a5f",
      danger: "#b04a3c",
      light: true
    }
  ];
  var THEME_BY_ID = new Map(GLUB_THEMES.map((t) => [t.id, t]));
  var AGNOSTR_THEME = {
    id: "agnostr",
    label: "Agnostr",
    description: "use Agnostr's own theme setting",
    css: ""
  };
  var ALL_THEMES = [AGNOSTR_THEME, ...GLUB_THEMES];

  // src/lib/sounds.js
  var MESSAGE_SOUNDS = [
    { id: "off", label: "off" },
    { id: "macintosh", label: "Macintosh" },
    { id: "sun", label: "Sun Sparc" },
    { id: "sgi", label: "SGI IRIX" },
    { id: "msn", label: "MSN Messenger" },
    { id: "aol", label: "AOL Mail" },
    { id: "icq", label: "ICQ" },
    { id: "palm", label: "Palm PDA" },
    { id: "blackberry", label: "BlackBerry" },
    { id: "blade-runner", label: "Blade Runner" },
    { id: "tron", label: "Tron" },
    { id: "c64", label: "Commodore 64" },
    { id: "amiga", label: "Amiga" }
  ];
  var CLICK_SOUNDS = [
    { id: "off", label: "off" },
    { id: "model-m", label: "Model M" },
    { id: "mac-click", label: "Mac mouse" },
    { id: "sun-type", label: "Sun keyboard" },
    { id: "sgi-beep", label: "SGI blip" },
    { id: "msn-nudge", label: "MSN nudge" },
    { id: "aol-ok", label: "AOL chime" },
    { id: "palm-tap", label: "Palm tap" },
    { id: "blackberry-key", label: "BlackBerry key" },
    { id: "blade-runner-ui", label: "Blade Runner UI" },
    { id: "tron-disc", label: "Tron disc" },
    { id: "c64-key", label: "C64 key" },
    { id: "amiga-click", label: "Amiga click" }
  ];

  // src/lib/settings.js
  var KIND_POLICIES = ["leave", "spoof", "strip"];
  var DEFAULT_SETTINGS = {
    schema: 4,
    enabled: true,
    studio: {
      enabled: true,
      template: "&b&l<{name}> &r{msg}",
      flair: "aurora",
      applyRich: true,
      showComposerToolbar: false,
      renderInAgnostr: true,
      renderRichInAgnostr: true,
      reduceMotion: false,
      rainbowStyle: "glub"
    },
    client: {
      name: "BetterAgnostr",
      policies: {
        chat: "spoof",
        note: "leave",
        reaction: "leave",
        dm: "leave",
        profile: "leave",
        other: "leave"
      }
    },
    privacy: {
      stripTags: [],
      stripTracking: true,
      hideLocate: true,
      hideTimestamps: false,
      omitTeleport: true,
      removeVoiceMemo: true,
      reviewEnabled: false,
      reviewGroups: ["chat"],
      calls: {
        disable: true,
        hideUi: true,
        blockSignals: true,
        blockOutgoing: true
      }
    },
    theme: {
      preset: "agnostr",
      customCss: ""
    },
    appearance: {
      hideNotificationButton: false
    },
    sounds: {
      message: "macintosh",
      click: "model-m",
      volume: 0.55,
      messageEnabled: true,
      clickEnabled: true,
      events: {
        chat: true,
        mentionOnly: false,
        dm: true,
        calls: true
      }
    },
    font: {
      family: "default",
      customFamily: "",
      customUrl: ""
    },
    actions: {
      custom: "boops"
    },
    glub: {
      build: "",
      buildFetchedAt: 0,
      manualBuild: "",
      autoSync: true
    },
    inspector: {
      paused: false,
      maxEvents: 1500
    },
    ui: {
      activeTab: "studio",
      betterTab: "line",
      firstRun: true,
      panelOpen: false
    }
  };
  var PRESET_IDS = /* @__PURE__ */ new Set(["agnostr", ...GLUB_THEMES.map((t) => t.id)]);
  var MESSAGE_IDS = new Set(MESSAGE_SOUNDS.map((s) => s.id));
  var CLICK_IDS = new Set(CLICK_SOUNDS.map((s) => s.id));
  function clone(value) {
    return JSON.parse(JSON.stringify(value));
  }
  function isObject(v) {
    return v && typeof v === "object" && !Array.isArray(v);
  }
  function mergeSettings(base, patch) {
    if (!isObject(base)) return clone(patch);
    const out = clone(base);
    if (!isObject(patch)) return out;
    for (const [key, value] of Object.entries(patch)) {
      if (isObject(value) && isObject(out[key])) out[key] = mergeSettings(out[key], value);
      else out[key] = value;
    }
    return out;
  }
  function normalizeSettings(raw) {
    const legacyClient = !raw || typeof raw.schema !== "number" || raw.schema < 2;
    const legacyToolbar = !raw || typeof raw.schema !== "number" || raw.schema < 3;
    const legacyPrivacy = !raw || typeof raw.schema !== "number" || raw.schema < 4;
    const s = mergeSettings(DEFAULT_SETTINGS, raw || {});
    if (legacyClient && s.client.name === "glub.chat") s.client.name = "BetterAgnostr";
    if (legacyToolbar) s.studio.showComposerToolbar = false;
    if (legacyPrivacy) s.privacy.omitTeleport = true;
    s.schema = 4;
    s.enabled = s.enabled !== false;
    s.studio.enabled = s.studio.enabled !== false;
    s.studio.applyRich = s.studio.applyRich !== false;
    s.studio.showComposerToolbar = s.studio.showComposerToolbar !== false;
    s.studio.renderInAgnostr = s.studio.renderInAgnostr !== false;
    s.studio.renderRichInAgnostr = s.studio.renderRichInAgnostr !== false;
    s.studio.reduceMotion = s.studio.reduceMotion === true;
    s.studio.rainbowStyle = s.studio.rainbowStyle === "bright" ? "bright" : "glub";
    s.studio.template = String(s.studio.template || "").replace(/[\r\n\t]+/g, " ").slice(0, FMT_MAX);
    if (typeof s.studio.flair !== "string" || s.studio.flair && !FLAIR_NAMES.has(s.studio.flair)) {
      s.studio.flair = "";
    }
    s.client.name = String(s.client.name || "").trim().slice(0, 64);
    if (!s.client.policies || typeof s.client.policies !== "object") s.client.policies = {};
    for (const group of ["chat", "note", "reaction", "dm", "profile", "other"]) {
      if (!KIND_POLICIES.includes(s.client.policies[group])) s.client.policies[group] = "leave";
    }
    if (!Array.isArray(s.privacy.stripTags)) s.privacy.stripTags = [];
    s.privacy.stripTags = [...new Set(s.privacy.stripTags.filter((t) => typeof t === "string" && /^[a-zA-Z0-9_-]+$/.test(t)))];
    s.privacy.stripTracking = s.privacy.stripTracking !== false;
    s.privacy.hideLocate = s.privacy.hideLocate !== false;
    s.privacy.hideTimestamps = s.privacy.hideTimestamps === true;
    s.privacy.omitTeleport = s.privacy.omitTeleport === true;
    s.privacy.removeVoiceMemo = s.privacy.removeVoiceMemo !== false;
    s.privacy.reviewEnabled = s.privacy.reviewEnabled === true;
    if (!Array.isArray(s.privacy.reviewGroups)) s.privacy.reviewGroups = [];
    s.privacy.reviewGroups = [...new Set(s.privacy.reviewGroups.filter((g) => ["chat", "note", "reaction", "dm", "profile", "other"].includes(g)))];
    const calls = s.privacy.calls || {};
    s.privacy.calls = {
      disable: calls.disable !== false,
      hideUi: calls.hideUi !== false,
      blockSignals: calls.blockSignals !== false,
      blockOutgoing: calls.blockOutgoing !== false
    };
    s.glub.build = String(s.glub.build || "").trim().slice(0, 32);
    s.glub.manualBuild = String(s.glub.manualBuild || "").trim().slice(0, 32);
    s.glub.buildFetchedAt = Number.isFinite(s.glub.buildFetchedAt) ? s.glub.buildFetchedAt : 0;
    s.glub.autoSync = s.glub.autoSync !== false;
    if (!PRESET_IDS.has(s.theme.preset)) s.theme.preset = "agnostr";
    s.theme.customCss = String(s.theme.customCss || "").slice(0, 4e4);
    if (!s.appearance || typeof s.appearance !== "object") s.appearance = {};
    s.appearance.hideNotificationButton = s.appearance.hideNotificationButton === true;
    s.sounds.message = MESSAGE_IDS.has(s.sounds.message) ? s.sounds.message : "macintosh";
    s.sounds.click = CLICK_IDS.has(s.sounds.click) ? s.sounds.click : "model-m";
    {
      const volume = Number(s.sounds.volume);
      s.sounds.volume = Number.isFinite(volume) ? Math.max(0, Math.min(1, volume)) : 0.55;
    }
    s.sounds.messageEnabled = s.sounds.messageEnabled !== false;
    s.sounds.clickEnabled = s.sounds.clickEnabled !== false;
    if (!s.sounds.events || typeof s.sounds.events !== "object") s.sounds.events = {};
    s.sounds.events.chat = s.sounds.events.chat !== false;
    s.sounds.events.mentionOnly = s.sounds.events.mentionOnly === true;
    s.sounds.events.dm = s.sounds.events.dm !== false;
    s.sounds.events.calls = s.sounds.events.calls === true;
    const fontIds = /* @__PURE__ */ new Set([
      "default",
      "inter",
      "jetbrains",
      "plex",
      "atkinson",
      "lexend",
      "source-serif",
      "plex-serif",
      "merriweather",
      "crimson",
      "spectral",
      "noto-serif",
      "baskerville",
      "noto",
      "source",
      "fira",
      "ubuntu",
      "custom"
    ]);
    s.font.family = fontIds.has(s.font.family) ? s.font.family : "default";
    s.font.customFamily = String(s.font.customFamily || "").trim().slice(0, 80);
    s.font.customUrl = String(s.font.customUrl || "").trim().slice(0, 500);
    s.actions.custom = String(s.actions.custom || "boops").trim().slice(0, 60) || "boops";
    s.inspector.maxEvents = Math.max(100, Math.min(5e3, Number(s.inspector.maxEvents) || 1500));
    s.inspector.paused = s.inspector.paused === true;
    s.ui.firstRun = s.ui.firstRun === true;
    s.ui.panelOpen = s.ui.panelOpen === true;
    delete s.ui.showVoiceMemo;
    if (!["line", "client"].includes(s.ui.betterTab)) s.ui.betterTab = "line";
    return s;
  }
  function effectiveBuild(settings) {
    return settings?.glub?.manualBuild || settings?.glub?.build || "";
  }
  function policyForKind(settings, kind) {
    const group = kindGroup(kind);
    return settings?.client?.policies?.[group] || "leave";
  }
  function isReviewKind(settings, kind) {
    if (!settings?.privacy?.reviewEnabled) return false;
    return settings.privacy.reviewGroups.includes(kindGroup(kind));
  }

  // src/page.js
  (() => {
    if (window.__betterAgnostrPage) return;
    Object.defineProperty(window, "__betterAgnostrPage", { value: true, configurable: false });
    const MAX_EVENTS = 2e3;
    const MAX_LOGS = 300;
    const state = {
      token: null,
      configReady: false,
      configWaiters: [],
      active: false,
      callObserver: null,
      settings: normalizeSettings({}),
      events: /* @__PURE__ */ new Map(),
      eventOrder: [],
      aliases: /* @__PURE__ */ new Map(),
      aliasReverse: /* @__PURE__ */ new Map(),
      logs: [],
      logBatch: [],
      logTimer: null,
      sockets: /* @__PURE__ */ new Map(),
      relays: /* @__PURE__ */ new Map(),
      signerHooked: false,
      signerInstance: null,
      nip07Patched: false,
      signMode: "auto",
      pubkey: "",
      npub: "",
      signerScanTimer: null,
      statusTimer: null,
      pending: /* @__PURE__ */ new Map(),
      requestSeq: 0,
      reviewSeq: 0,
      screenshotMode: false,
      buildPromise: null,
      buildRequestedAt: 0,
      startedAt: Date.now(),
      callDrops: 0,
      preparedCount: 0,
      postSeq: 0
    };
    const NATIVE_NOTIFICATIONS_KEY = "agnostr:v2:notifications";
    const NATIVE_SETTINGS_KEY = "agnostr:v2:settings";
    const nativeStorageSetItem = globalThis.Storage.prototype.setItem;
    function forceNativeSoundOff(raw) {
      try {
        const value = typeof raw === "string" ? JSON.parse(raw) : raw;
        if (!value || typeof value !== "object") return raw;
        return JSON.stringify({ ...value, soundEnabled: false });
      } catch {
        return raw;
      }
    }
    globalThis.Storage.prototype.setItem = function setItem(key, value) {
      if (state.active && (key === NATIVE_NOTIFICATIONS_KEY || key === NATIVE_SETTINGS_KEY)) {
        value = forceNativeSoundOff(value);
      }
      return nativeStorageSetItem.call(this, key, value);
    };
    const NativeWebSocket = window.WebSocket;
    const nativeAdd = NativeWebSocket.prototype.addEventListener;
    const nativeRemove = NativeWebSocket.prototype.removeEventListener;
    const nativeSend = NativeWebSocket.prototype.send;
    const onMessageDescriptor = Object.getOwnPropertyDescriptor(NativeWebSocket.prototype, "onmessage");
    function uid() {
      state.requestSeq += 1;
      return `ba-${Date.now().toString(36)}-${state.requestSeq.toString(36)}`;
    }
    function post(type, payload = {}, id) {
      if (!state.token) return;
      state.postSeq += 1;
      const envelope = { __ba: true, dir: "page", token: state.token, seq: state.postSeq, type, payload, id };
      try {
        window.postMessage(envelope, "*");
      } catch {
      }
      try {
        document.dispatchEvent(new CustomEvent("ba-page", { detail: JSON.stringify(envelope) }));
      } catch {
      }
    }
    function notice(level, title, detail = "") {
      post("notice", { level, title, detail });
    }
    function setConfig(settings) {
      const old = state.settings;
      state.settings = normalizeSettings(mergeSettings(state.settings, settings || {}));
      const enabled = state.settings.enabled !== false;
      const wasActive = state.active;
      state.active = enabled;
      if (enabled) {
        window.WebSocket = BetterWebSocket;
      } else {
        window.WebSocket = NativeWebSocket;
        if (wasActive) stopActiveWork();
      }
      if (!state.configReady) {
        state.configReady = true;
        const waiters = state.configWaiters.splice(0);
        for (const w of waiters) w();
      }
      applyCallPolicy();
      if (old?.glub?.build !== state.settings.glub.build) publishStatus();
    }
    function waitForConfig(timeoutMs = 1800) {
      if (state.configReady) return Promise.resolve();
      return new Promise((resolve) => {
        let done = false;
        const finish = () => {
          if (done) return;
          done = true;
          resolve();
        };
        state.configWaiters.push(finish);
        window.setTimeout(finish, timeoutMs);
      });
    }
    function askUi(type, payload, timeoutMs = 1e4) {
      return new Promise((resolve) => {
        const id = uid();
        const timer = window.setTimeout(() => {
          state.pending.delete(id);
          resolve(null);
        }, timeoutMs);
        state.pending.set(id, (value) => {
          window.clearTimeout(timer);
          resolve(value);
        });
        post(type, payload, id);
      });
    }
    function resolvePending(id, payload) {
      const fn = state.pending.get(id);
      if (!fn) return;
      state.pending.delete(id);
      fn(payload);
    }
    function parseSettingsPayload(value) {
      if (typeof value === "string") {
        try {
          return JSON.parse(value);
        } catch {
          return null;
        }
      }
      return value;
    }
    async function handleUiData(data) {
      if (!data || data.__ba !== true || data.dir !== "ui") return;
      if (data.type === "hello") {
        state.token = data.token || state.token;
        setConfig(parseSettingsPayload(data.payload?.settings));
        publishStatus();
        post("ready", { version: "1.2.1" });
        if (state.active) start();
        return;
      }
      if (data.token && state.token && data.token !== state.token) return;
      if (data.type === "config") {
        setConfig(parseSettingsPayload(data.payload?.settings));
        return;
      }
      if (data.type === "response" && data.id) {
        resolvePending(data.id, data.payload);
        return;
      }
      if (data.type === "getEvent") {
        const ev = findEvent(data.payload?.id);
        const result = ev || reconstructEvent(data.payload?.id) || null;
        post("event", { event: result, reconstructed: !ev && !!result }, data.id);
        return;
      }
      if (data.type === "getRecent") {
        const limit = Math.min(500, Math.max(1, Number(data.payload?.limit) || 100));
        post("recent", { events: state.eventOrder.slice(-limit).map((id) => state.events.get(id)).filter(Boolean) }, data.id);
        return;
      }
      if (data.type === "inspectPeer") {
        const payload = data.payload || {};
        let pubkey = String(payload.pubkey || "").toLowerCase();
        let npub = String(payload.npub || "");
        if (!pubkey && npub) {
          try {
            const decoded = decode(npub);
            if (decoded?.type === "npub" && typeof decoded.data === "string") pubkey = decoded.data.toLowerCase();
          } catch {
          }
        }
        if (!pubkey) {
          if (data.id) post("response", { ok: false, error: "Invalid npub." }, data.id);
          return;
        }
        if (!npub) {
          try {
            npub = npubEncode(pubkey);
          } catch {
          }
        }
        const fn = findInspectPeerFn();
        if (!fn) {
          if (data.id) post("response", { ok: false, error: "Profile opener not found." }, data.id);
          return;
        }
        const context = findAppContext();
        let peer = null;
        try {
          peer = context?.getPeerByPubkey?.(pubkey) || null;
        } catch {
        }
        if (!peer) {
          peer = context?.peers?.find?.((p) => String(p?.pubkey || "").toLowerCase() === pubkey) || null;
        }
        if (!peer) {
          peer = context?.servers?.members?.find?.((p) => String(p?.pubkey || "").toLowerCase() === pubkey) || null;
        }
        const nickname = String(payload.nickname || peer?.nickname || "").trim();
        const displayHandle = peer?.displayHandle || (nickname ? `@${nickname}#${pubkey.slice(-4)}` : `@anon${pubkey.slice(-4)}#${pubkey.slice(-4)}`);
        const safePeer = {
          ...peer || {},
          pubkey,
          npub,
          nickname: nickname || peer?.nickname || "",
          displayHandle,
          lastSeenAt: Number(peer?.lastSeenAt) || Math.floor(Date.now() / 1e3),
          isOnline: !!peer?.isOnline,
          isSelf: false,
          isTeleported: !!peer?.isTeleported,
          isMeshBridge: !!peer?.isMeshBridge,
          isBlocked: !!peer?.isBlocked,
          isTrusted: !!peer?.isTrusted,
          messageCount: Number(peer?.messageCount) || 0,
          channels: Array.isArray(peer?.channels) ? peer.channels : []
        };
        try {
          fn(safePeer);
          if (data.id) post("response", { ok: true }, data.id);
          else post("notice", { level: "success", title: "Profile opened", detail: displayHandle });
        } catch (err) {
          if (data.id) post("response", { ok: false, error: err instanceof Error ? err.message : String(err) }, data.id);
        }
        return;
      }
      if (data.type === "getLogs") {
        const limit = Math.min(600, Math.max(1, Number(data.payload?.limit) || 300));
        post("logs", { logs: state.logs.slice(-limit) }, data.id);
        return;
      }
      if (data.type === "verify") {
        const ev = data.payload?.event;
        let ok = false;
        let error = "";
        try {
          ok = verifyEvent(ev);
          if (!ok) error = "Signature or id does not verify.";
        } catch (err) {
          error = err instanceof Error ? err.message : String(err);
        }
        post("verified", { ok, error, eventId: ev?.id }, data.id);
        return;
      }
      if (data.type === "entities") {
        const payload = data.payload || {};
        const out = {};
        try {
          if (payload.pubkey) out.npub = npubEncode(payload.pubkey);
          if (payload.id) {
            out.note = noteEncode(payload.id);
            out.nevent = neventEncode({ id: payload.id, author: payload.pubkey, kind: payload.kind });
          }
        } catch {
        }
        post("entities", out, data.id);
        return;
      }
      if (data.type === "reconstruct") {
        post("reconstructed", { event: reconstructEvent(data.payload?.id) }, data.id);
        return;
      }
      if (data.type === "ping") {
        post("pong", { now: Date.now() }, data.id);
      }
    }
    const uiSeen = /* @__PURE__ */ new Set();
    function handleUiEnvelope(data) {
      if (!data || data.__ba !== true || data.dir !== "ui") return;
      const key = data.seq != null ? `seq:${data.seq}` : null;
      if (key) {
        if (uiSeen.has(key)) return;
        uiSeen.add(key);
        if (uiSeen.size > 200) {
          const first = uiSeen.values().next().value;
          if (first) uiSeen.delete(first);
        }
      }
      handleUiData(data);
    }
    window.addEventListener("message", (event) => {
      const data = event.data;
      if (!data || data.__ba !== true || data.dir !== "ui") return;
      handleUiEnvelope(data);
    });
    document.addEventListener("ba-ui", (event) => {
      try {
        const data = typeof event.detail === "string" ? JSON.parse(event.detail) : event.detail;
        handleUiEnvelope(data);
      } catch {
      }
    });
    function isValidEvent(ev) {
      return ev && typeof ev === "object" && typeof ev.id === "string" && /^[0-9a-f]{64}$/i.test(ev.id) && typeof ev.pubkey === "string" && /^[0-9a-f]{64}$/i.test(ev.pubkey) && Number.isFinite(ev.kind) && Number.isFinite(ev.created_at) && typeof ev.content === "string" && Array.isArray(ev.tags);
    }
    function rememberEvent(ev) {
      if (!isValidEvent(ev)) return;
      const existing = state.events.get(ev.id);
      if (!existing) {
        state.events.set(ev.id, ev);
        state.eventOrder.push(ev.id);
        while (state.eventOrder.length > MAX_EVENTS) {
          const old = state.eventOrder.shift();
          if (old) state.events.delete(old);
        }
      }
    }
    function findEvent(id) {
      if (!id) return null;
      const direct = state.events.get(id);
      if (direct) return direct;
      const alias = state.aliases.get(id);
      if (alias) return state.events.get(alias) || null;
      return null;
    }
    function cloneEventForStorage(ev) {
      return {
        ...ev,
        tags: (ev.tags || []).map((t) => [...t])
      };
    }
    function reconstructEvent(id) {
      if (!id || !/^[0-9a-f]{64}$/i.test(id)) return null;
      const out = { id, pubkey: "", created_at: 0, kind: 0, tags: [], content: "", sig: "", _reconstructed: true };
      try {
        const idx = JSON.parse(localStorage.getItem("agnostr:v2:msg_index") || "[]");
        if (Array.isArray(idx)) {
          for (const geo of idx) {
            const key = `agnostr:v2:msgs:${geo}`;
            const list = JSON.parse(localStorage.getItem(key) || "[]");
            if (!Array.isArray(list)) continue;
            const hit = list.find((m) => m && m.id === id);
            if (!hit) continue;
            out.pubkey = String(hit.pubkey || hit.senderPubkey || "").toLowerCase();
            out.created_at = Number(hit.createdAt) || 0;
            out.kind = 2e4;
            out.content = String(hit.content || "");
            const stored = Array.isArray(hit.tags) ? hit.tags.filter(Array.isArray).map((t) => t.map(String)) : [];
            out.tags = stored;
            const has = (name) => stored.some((t) => t[0] === name);
            if (!has("g")) out.tags.push(["g", geo]);
            if (hit.nickname && !has("n")) out.tags.push(["n", String(hit.nickname)]);
            if (hit.clientName && !has("client")) out.tags.push(["client", String(hit.clientName)]);
            if (hit.replyTo?.id && !has("e")) {
              out.tags.push(["e", String(hit.replyTo.id), "", "reply"]);
              if (hit.replyTo.pubkey) out.tags.push(["p", String(hit.replyTo.pubkey)]);
            }
            if (hit.imageAttachment?.url) out.tags.push(["imeta", `url ${hit.imageAttachment.url}`]);
            if (hit.voiceMemo?.url) out.tags.push(["imeta", `url ${hit.voiceMemo.url}`, "m audio/webm"]);
            return out;
          }
        }
        const threads = JSON.parse(localStorage.getItem("agnostr:v2:dm_threads") || "[]");
        if (Array.isArray(threads)) {
          for (const thread of threads) {
            if (!thread || !Array.isArray(thread.messages)) continue;
            const hit = thread.messages.find((m) => m && m.id === id);
            if (!hit) continue;
            out.pubkey = String(hit.senderPubkey || hit.pubkey || "").toLowerCase();
            out.created_at = Number(hit.createdAt) || Math.floor(Number(hit.orderMs || 0) / 1e3);
            out.kind = 4;
            out.content = String(hit.content || "");
            out.tags = Array.isArray(hit.tags) ? hit.tags.filter(Array.isArray).map((t) => t.map(String)) : [];
            if (!out.tags.some((t) => t[0] === "p")) out.tags.push(["p", String(thread.peerPubkey || "")]);
            if (hit.protocol && !out.tags.some((t) => t[0] === "t")) out.tags.push(["t", `agnostr-${hit.protocol}`]);
            return out;
          }
        }
      } catch {
        return null;
      }
      return null;
    }
    function scheduleLogFlush() {
      if (state.logTimer !== null) return;
      state.logTimer = window.setTimeout(flushLogs, 120);
    }
    function flushLogs() {
      state.logTimer = null;
      if (!state.logBatch.length) return;
      const batch = state.logBatch.splice(0, state.logBatch.length);
      if (state.settings.inspector.paused) {
        state.logs.push(...batch);
        trimLogs();
        return;
      }
      state.logs.push(...batch);
      trimLogs();
      post("logs", { logs: batch.slice(-200) });
    }
    function trimLogs() {
      if (state.logs.length > MAX_LOGS) state.logs.splice(0, state.logs.length - MAX_LOGS);
    }
    function pushFrameLog(entry) {
      state.logBatch.push({ ts: Date.now(), ...entry });
      scheduleLogFlush();
    }
    function summarizeEvent(ev) {
      return `kind ${ev.kind} \xB7 ${ev.id.slice(0, 8)}\u2026 \xB7 ${ev.content.slice(0, 48).replace(/\s+/g, " ")}`;
    }
    function handleIncomingFrame(data, url) {
      if (!state.active) return;
      if (typeof data !== "string") return;
      let frame;
      try {
        frame = JSON.parse(data);
      } catch {
        return;
      }
      if (!Array.isArray(frame)) return;
      const type = frame[0];
      if (type === "EVENT") {
        const ev = frame[2];
        if (isValidEvent(ev)) {
          rememberEvent(ev, { dir: "in", relay: url });
          pushFrameLog({ dir: "in", relay: url, type, eventId: ev.id, kind: ev.kind, event: ev, summary: summarizeEvent(ev) });
        }
        return;
      }
      if (type === "OK" || type === "NOTICE" || type === "EOSE" || type === "CLOSED" || type === "AUTH") {
        pushFrameLog({
          dir: "in",
          relay: url,
          type,
          eventId: type === "OK" ? frame[1] : void 0,
          summary: type === "OK" ? `${frame[2] ? "accepted" : "rejected"} ${String(frame[1] || "").slice(0, 10)}\u2026 ${frame[3] || ""}`.trim() : type === "NOTICE" ? String(frame[1] || "").slice(0, 180) : String(frame[1] || "").slice(0, 120),
          data: frame
        });
      }
    }
    function handleOutgoingFrame(data, url) {
      if (typeof data !== "string") return;
      let frame;
      try {
        frame = JSON.parse(data);
      } catch {
        return;
      }
      if (!Array.isArray(frame)) return;
      if (frame[0] === "EVENT" && isValidEvent(frame[1])) {
        const ev = frame[1];
        rememberEvent(ev, { dir: "out", relay: url });
        pushFrameLog({ dir: "out", relay: url, type: "EVENT", eventId: ev.id, kind: ev.kind, event: ev, summary: summarizeEvent(ev) });
        return;
      }
      pushFrameLog({
        dir: "out",
        relay: url,
        type: String(frame[0] || "?"),
        summary: frame[0] === "REQ" ? `${frame[1]} \xB7 ${JSON.stringify(frame[2] || []).slice(0, 140)}` : frame[0] === "AUTH" ? `AUTH kind ${frame[1]?.kind ?? "?"}` : JSON.stringify(frame).slice(0, 160),
        data: frame
      });
    }
    function isCallEvent(ev) {
      if (!ev || typeof ev !== "object") return false;
      if (ev.kind === 25050) return true;
      const t = getTagValue(ev.tags, "t");
      return typeof t === "string" && t.toLowerCase().startsWith("agnostr-call");
    }
    function translateOkFrame(frame) {
      if (!Array.isArray(frame) || frame[0] !== "OK") return frame;
      const newId = frame[1];
      const oldId = state.aliasReverse.get(newId);
      if (!oldId) return frame;
      return ["OK", oldId, frame[2], frame[3]];
    }
    function prepareIncomingData(data) {
      if (!state.active) return { drop: false, data, translated: false };
      if (typeof data !== "string") return { drop: false, data, translated: false };
      let frame;
      try {
        frame = JSON.parse(data);
      } catch {
        return { drop: false, data, translated: false };
      }
      if (!Array.isArray(frame)) return { drop: false, data, translated: false };
      const calls = state.settings.privacy.calls;
      if (calls.disable && calls.blockSignals && frame[0] === "EVENT" && isCallEvent(frame[2])) {
        state.callDrops += 1;
        pushFrameLog({
          dir: "in",
          relay: "filtered",
          type: "BLOCKED_CALL",
          eventId: frame[2]?.id,
          kind: frame[2]?.kind,
          summary: "incoming call signal blocked by Better Agnostr"
        });
        return { drop: true, data, translated: false };
      }
      const translated = translateOkFrame(frame);
      if (translated !== frame) {
        return { drop: false, data: JSON.stringify(translated), translated: true };
      }
      return { drop: false, data, translated: false };
    }
    function wrapListener(fn, ws, url, seenFrames) {
      if (typeof fn !== "function") return fn;
      const wrapped = function(event) {
        let data = event?.data;
        let translated = false;
        const prepared = prepareIncomingData(data);
        if (prepared.drop) return;
        if (!seenFrames.has(event)) {
          seenFrames.add(event);
          handleIncomingFrame(data, url);
        }
        if (prepared.translated) {
          data = prepared.data;
          translated = true;
        }
        if (translated) {
          let copy;
          try {
            copy = new MessageEvent("message", {
              data,
              origin: event.origin || "",
              lastEventId: event.lastEventId || "",
              source: event.source || null,
              ports: event.ports ? [...event.ports] : []
            });
          } catch {
            copy = event;
          }
          return fn.call(this, copy);
        }
        return fn.call(this, event);
      };
      return wrapped;
    }
    function instrumentSocket(ws, url) {
      if (!ws || state.sockets.has(ws)) return;
      state.sockets.set(ws, { url, status: "connecting", openedAt: 0, lastMessageAt: 0 });
      state.relays.set(url, { url, status: "connecting", lastMessageAt: 0, error: "" });
      const seenFrames = /* @__PURE__ */ new WeakSet();
      nativeAdd.call(ws, "message", (event) => {
        if (!seenFrames.has(event)) {
          seenFrames.add(event);
          handleIncomingFrame(event?.data, url);
        }
      });
      nativeAdd.call(ws, "open", () => {
        const s = state.sockets.get(ws);
        if (s) s.status = "open";
        state.relays.set(url, { ...state.relays.get(url) || {}, url, status: "open", lastMessageAt: Date.now(), error: "" });
        pushFrameLog({ dir: "sys", relay: url, type: "OPEN", summary: "socket open" });
        publishStatus();
      });
      nativeAdd.call(ws, "close", (event) => {
        const s = state.sockets.get(ws);
        if (s) s.status = "closed";
        state.relays.set(url, {
          ...state.relays.get(url) || {},
          url,
          status: "closed",
          error: `closed ${event?.code ?? ""} ${event?.reason || ""}`.trim()
        });
        pushFrameLog({ dir: "sys", relay: url, type: "CLOSE", summary: `${event?.code ?? ""} ${event?.reason || ""}`.trim() });
        publishStatus();
      });
      nativeAdd.call(ws, "error", () => {
        state.relays.set(url, { ...state.relays.get(url) || {}, url, status: "error", error: "socket error" });
        pushFrameLog({ dir: "sys", relay: url, type: "ERROR", summary: "socket error" });
        publishStatus();
      });
      const listenerMap = /* @__PURE__ */ new WeakMap();
      ws.addEventListener = function(type, listener, options) {
        if (type !== "message" || !listener) return nativeAdd.call(this, type, listener, options);
        let wrapped = listenerMap.get(listener);
        if (!wrapped) {
          wrapped = wrapListener(listener, this, url, seenFrames);
          listenerMap.set(listener, wrapped);
        }
        return nativeAdd.call(this, type, wrapped, options);
      };
      ws.removeEventListener = function(type, listener, options) {
        if (type === "message" && listener) {
          const wrapped = listenerMap.get(listener);
          if (wrapped) return nativeRemove.call(this, type, wrapped, options);
        }
        return nativeRemove.call(this, type, listener, options);
      };
      if (onMessageDescriptor?.set) {
        let current = null;
        Object.defineProperty(ws, "onmessage", {
          configurable: true,
          enumerable: true,
          get() {
            return current;
          },
          set(fn) {
            current = typeof fn === "function" ? fn : null;
            onMessageDescriptor.set.call(ws, current ? wrapListener(current, ws, url, seenFrames) : null);
          }
        });
      }
      ws.send = function(data) {
        handleSend(this, data, url);
      };
    }
    function BetterWebSocket(url, protocols) {
      const ws = protocols === void 0 ? new NativeWebSocket(url) : new NativeWebSocket(url, protocols);
      instrumentSocket(ws, String(url));
      return ws;
    }
    BetterWebSocket.prototype = NativeWebSocket.prototype;
    Object.setPrototypeOf(BetterWebSocket, NativeWebSocket);
    for (const key of ["CONNECTING", "OPEN", "CLOSING", "CLOSED"]) {
      try {
        Object.defineProperty(BetterWebSocket, key, { value: NativeWebSocket[key], enumerable: true });
      } catch {
      }
    }
    window.WebSocket = BetterWebSocket;
    function sendRaw(ws, data) {
      try {
        nativeSend.call(ws, data);
      } catch (err) {
        pushFrameLog({ dir: "sys", relay: state.sockets.get(ws)?.url || "", type: "SEND_ERROR", summary: String(err?.message || err) });
      }
    }
    function handleSend(ws, data, url) {
      if (typeof data !== "string") {
        sendRaw(ws, data);
        return;
      }
      let frame;
      try {
        frame = JSON.parse(data);
      } catch {
        sendRaw(ws, data);
        return;
      }
      if (!Array.isArray(frame) || frame[0] !== "EVENT" || !isValidEvent(frame[1])) {
        handleOutgoingFrame(data, url);
        sendRaw(ws, data);
        return;
      }
      const ev = frame[1];
      const calls = state.settings.privacy.calls;
      if (calls.disable && calls.blockOutgoing && isCallEvent(ev)) {
        state.callDrops += 1;
        pushFrameLog({
          dir: "out",
          relay: url,
          type: "BLOCKED_CALL",
          eventId: ev.id,
          kind: ev.kind,
          summary: "outgoing call signal blocked by Better Agnostr"
        });
        notice("warning", "Call blocked", "Calling is disabled in Better Agnostr privacy settings.");
        return;
      }
      if (state.settings.privacy.omitTeleport && hasTeleportTag(ev.tags)) {
        const cleaned = { ...ev, tags: stripTeleportTags(ev.tags) };
        const resigned = resignEvent(cleaned);
        if (resigned) {
          state.aliases.set(ev.id, resigned.id);
          state.aliasReverse.set(resigned.id, ev.id);
          sendRaw(ws, JSON.stringify(["EVENT", resigned]));
          rememberEvent(resigned, { dir: "out", relay: url });
          pushFrameLog({
            dir: "out",
            relay: url,
            type: "EVENT",
            eventId: resigned.id,
            kind: resigned.kind,
            event: resigned,
            aliasOf: ev.id,
            summary: summarizeEvent(resigned)
          });
          post("alias", { from: ev.id, to: resigned.id });
          return;
        }
        pushFrameLog({
          dir: "out",
          relay: url,
          type: "BLOCKED_TELEPORT",
          eventId: ev.id,
          kind: ev.kind,
          summary: "outgoing teleport tag blocked by Better Agnostr"
        });
        notice("warning", "Teleport tag blocked", "The message was not sent because the teleport tag could not be removed before signing.");
        return;
      }
      handleOutgoingFrame(data, url);
      if (state.signerHooked) {
        rememberEvent(ev, { dir: "out", relay: url });
        sendRaw(ws, data);
        return;
      }
      (async () => {
        let prepared;
        let signed = ev;
        try {
          prepared = await prepareOutgoing(ev, { source: "socket-fallback" });
          if (prepared !== ev) {
            signed = resignEvent(prepared);
            if (signed) {
              state.aliases.set(ev.id, signed.id);
              state.aliasReverse.set(signed.id, ev.id);
              sendRaw(ws, JSON.stringify(["EVENT", signed]));
              rememberEvent(signed, { dir: "out", relay: url });
              pushFrameLog({
                dir: "out",
                relay: url,
                type: "EVENT",
                eventId: signed.id,
                kind: signed.kind,
                event: signed,
                aliasOf: ev.id,
                summary: summarizeEvent(signed)
              });
              post("alias", { from: ev.id, to: signed.id });
              return;
            }
          }
        } catch (err) {
          notice("error", "Outgoing event blocked", err instanceof Error ? err.message : String(err));
          return;
        }
        sendRaw(ws, JSON.stringify(["EVENT", signed]));
      })();
    }
    function objectLooksLikeIdentityManager(obj) {
      if (!obj || typeof obj !== "object") return false;
      try {
        return typeof obj.signEvent === "function" && typeof obj.signEventWithMaterial === "function" && typeof obj.getMasterKeyMaterial === "function";
      } catch {
        return false;
      }
    }
    function deepFindIdentityManager(root, depth = 4, seen = /* @__PURE__ */ new Set()) {
      if (!root || typeof root !== "object" && typeof root !== "function") return null;
      if (depth < 0 || seen.has(root)) return null;
      seen.add(root);
      if (objectLooksLikeIdentityManager(root)) return root;
      if (root instanceof Node || root === window || root === document) return null;
      if (root instanceof Map) {
        let i2 = 0;
        for (const value of root.values()) {
          if (i2++ > 40) break;
          const found = deepFindIdentityManager(value, depth - 1, seen);
          if (found) return found;
        }
        return null;
      }
      if (root instanceof Set) {
        let i2 = 0;
        for (const value of root.values()) {
          if (i2++ > 40) break;
          const found = deepFindIdentityManager(value, depth - 1, seen);
          if (found) return found;
        }
        return null;
      }
      let keys = [];
      try {
        keys = Object.keys(root).slice(0, 80);
      } catch {
        return null;
      }
      for (const key of keys) {
        if (key.startsWith("__") || key === "window" || key === "document" || key === "parent" || key === "ownerDocument") continue;
        let value;
        try {
          value = root[key];
        } catch {
          continue;
        }
        const found = deepFindIdentityManager(value, depth - 1, seen);
        if (found) return found;
      }
      return null;
    }
    function inspectFiber(fiber, seen, depth) {
      if (!fiber || seen.has(fiber) || depth > 24) return null;
      seen.add(fiber);
      const props = fiber.memoizedProps;
      if (props && typeof props === "object") {
        for (const value of Object.values(props)) {
          if (objectLooksLikeIdentityManager(value)) return value;
          if (value && typeof value === "object") {
            const nested = deepFindIdentityManager(value, 3, /* @__PURE__ */ new Set());
            if (nested) return nested;
          }
        }
      }
      const stateNode = fiber.stateNode;
      if (stateNode && typeof stateNode === "object") {
        if (objectLooksLikeIdentityManager(stateNode)) return stateNode;
        const nested = deepFindIdentityManager(stateNode, 3, /* @__PURE__ */ new Set());
        if (nested) return nested;
      }
      let hook = fiber.memoizedState;
      let guard = 0;
      while (hook && guard < 80) {
        guard += 1;
        const value = hook.memoizedState;
        const found = deepFindIdentityManager(value, 5, /* @__PURE__ */ new Set());
        if (found) return found;
        hook = hook.next;
      }
      const child = inspectFiber(fiber.child, seen, depth + 1);
      if (child) return child;
      return inspectFiber(fiber.sibling, seen, depth + 1);
    }
    function findIdentityManager() {
      if (state.signerInstance && objectLooksLikeIdentityManager(state.signerInstance)) return state.signerInstance;
      const containers = [];
      const root = document.getElementById("root");
      if (root) containers.push(root);
      const nodes = document.querySelectorAll("body > div, body > main");
      for (const n of nodes) {
        if (containers.length > 6) break;
        containers.push(n);
      }
      for (const container of containers) {
        try {
          const keys = Object.keys(container);
          for (const key of keys) {
            if (key.startsWith("__reactContainer$")) {
              const found = inspectFiber(container[key], /* @__PURE__ */ new Set(), 0);
              if (found) return found;
            }
            if (key.startsWith("__reactFiber$")) {
              let f = container[key];
              let guard = 0;
              while (f && guard++ < 200) {
                if (f.return === null) {
                  const found = inspectFiber(f, /* @__PURE__ */ new Set(), 0);
                  if (found) return found;
                }
                f = f.return;
              }
            }
          }
        } catch {
        }
      }
      return null;
    }
    function objectLooksLikeAppContext(obj) {
      if (!obj || typeof obj !== "object") return false;
      try {
        return typeof obj.sendReaction === "function" && (Array.isArray(obj.messages) || !!obj.servers);
      } catch {
        return false;
      }
    }
    function deepFindAppContext(root, depth = 4, seen = /* @__PURE__ */ new Set()) {
      if (!root || typeof root !== "object" && typeof root !== "function") return null;
      if (depth < 0 || seen.has(root)) return null;
      seen.add(root);
      if (objectLooksLikeAppContext(root)) return root;
      if (root instanceof Node || root === window || root === document) return null;
      if (root instanceof Map) {
        let i2 = 0;
        for (const value of root.values()) {
          if (i2++ > 40) break;
          const found = deepFindAppContext(value, depth - 1, seen);
          if (found) return found;
        }
        return null;
      }
      if (root instanceof Set) {
        let i2 = 0;
        for (const value of root.values()) {
          if (i2++ > 40) break;
          const found = deepFindAppContext(value, depth - 1, seen);
          if (found) return found;
        }
        return null;
      }
      let keys = [];
      try {
        keys = Object.keys(root).slice(0, 80);
      } catch {
        return null;
      }
      for (const key of keys) {
        if (key.startsWith("__") || key === "window" || key === "document" || key === "parent" || key === "ownerDocument") continue;
        let value;
        try {
          value = root[key];
        } catch {
          continue;
        }
        const found = deepFindAppContext(value, depth - 1, seen);
        if (found) return found;
      }
      return null;
    }
    function inspectFiberForApp(fiber, seen, depth) {
      if (!fiber || seen.has(fiber) || depth > 24) return null;
      seen.add(fiber);
      const props = fiber.memoizedProps;
      if (props && typeof props === "object") {
        for (const value of Object.values(props)) {
          if (objectLooksLikeAppContext(value)) return value;
          if (value && typeof value === "object") {
            const nested = deepFindAppContext(value, 4, /* @__PURE__ */ new Set());
            if (nested) return nested;
          }
        }
      }
      const stateNode = fiber.stateNode;
      if (stateNode && typeof stateNode === "object") {
        if (objectLooksLikeAppContext(stateNode)) return stateNode;
        const nested = deepFindAppContext(stateNode, 4, /* @__PURE__ */ new Set());
        if (nested) return nested;
      }
      let hook = fiber.memoizedState;
      let guard = 0;
      while (hook && guard < 80) {
        guard += 1;
        const value = hook.memoizedState;
        const found = deepFindAppContext(value, 5, /* @__PURE__ */ new Set());
        if (found) return found;
        hook = hook.next;
      }
      const child = inspectFiberForApp(fiber.child, seen, depth + 1);
      if (child) return child;
      return inspectFiberForApp(fiber.sibling, seen, depth + 1);
    }
    function findAppContext() {
      const containers = [];
      const root = document.getElementById("root");
      if (root) containers.push(root);
      const nodes = document.querySelectorAll("body > div, body > main");
      for (const n of nodes) {
        if (containers.length > 6) break;
        containers.push(n);
      }
      for (const container of containers) {
        try {
          for (const key of Object.keys(container)) {
            if (key.startsWith("__reactContainer$")) {
              const found = inspectFiberForApp(container[key], /* @__PURE__ */ new Set(), 0);
              if (found) return found;
            }
            if (key.startsWith("__reactFiber$")) {
              let f = container[key];
              let guard = 0;
              while (f && guard++ < 200) {
                if (f.return === null) {
                  const found = inspectFiberForApp(f, /* @__PURE__ */ new Set(), 0);
                  if (found) return found;
                }
                f = f.return;
              }
            }
          }
        } catch {
        }
      }
      return null;
    }
    function findInspectPeerFn() {
      const containers = [];
      const root = document.getElementById("root");
      if (root) containers.push(root);
      for (const n of document.querySelectorAll("body > div, body > main")) {
        if (containers.length > 6) break;
        containers.push(n);
      }
      const search = (fiber, seen, depth) => {
        if (!fiber || seen.has(fiber) || depth > 26) return null;
        seen.add(fiber);
        const props = fiber.memoizedProps;
        if (props && typeof props === "object") {
          if (typeof props.onInspectPeer === "function") return props.onInspectPeer;
          if (typeof props.onInspectAuthor === "function") return props.onInspectAuthor;
          if (typeof props.onInspectSender === "function") return props.onInspectSender;
        }
        return search(fiber.child, seen, depth + 1) || search(fiber.sibling, seen, depth + 1);
      };
      for (const container of containers) {
        try {
          for (const key of Object.keys(container)) {
            if (key.startsWith("__reactContainer$")) {
              const found = search(container[key], /* @__PURE__ */ new Set(), 0);
              if (found) return found;
            }
            if (key.startsWith("__reactFiber$")) {
              let f = container[key];
              let guard = 0;
              while (f && guard++ < 200) {
                if (f.return === null) {
                  const found = search(f, /* @__PURE__ */ new Set(), 0);
                  if (found) return found;
                }
                f = f.return;
              }
            }
          }
        } catch {
        }
      }
      return null;
    }
    function currentSignMode(instance) {
      if (instance?.getSignMode) {
        try {
          return instance.getSignMode();
        } catch {
        }
      }
      try {
        const raw = localStorage.getItem("agnostr:v2:sign_mode");
        if (raw === "auto" || raw === "local" || raw === "extension") return raw;
      } catch {
      }
      return "auto";
    }
    function signerPubkey(instance) {
      try {
        const material = instance?.getMasterKeyMaterial?.();
        return material?.pubkey || "";
      } catch {
        return "";
      }
    }
    function patchIdentityManager(instance) {
      if (!instance) return false;
      const proto = Object.getPrototypeOf(instance);
      if (!proto || typeof proto.signEventWithMaterial !== "function") return false;
      state.signerInstance = instance;
      state.signMode = currentSignMode(instance);
      state.pubkey = signerPubkey(instance);
      try {
        state.npub = state.pubkey ? npubEncode(state.pubkey) : "";
      } catch {
        state.npub = "";
      }
      if (proto.__baBetterAgnostrPatched) {
        state.signerHooked = true;
        publishStatus();
        return true;
      }
      const original = proto.signEventWithMaterial;
      try {
        Object.defineProperty(proto, "__baBetterAgnostrPatched", {
          value: true,
          configurable: true,
          enumerable: false
        });
        proto.signEventWithMaterial = async function(event, material) {
          const prepared = await prepareOutgoing(event, { source: "signer" });
          const signed = await original.call(this, prepared, material);
          if (isValidEvent(signed)) rememberEvent(signed, { dir: "signed", relay: "signer" });
          return signed;
        };
        state.signerHooked = true;
        publishStatus();
        notice("success", "Signer attached", "Outgoing event tools are active.");
        return true;
      } catch (err) {
        notice("warning", "Could not attach to signer", err instanceof Error ? err.message : String(err));
        return false;
      }
    }
    function patchNip07() {
      if (!window.nostr || typeof window.nostr.signEvent !== "function") return false;
      if (window.nostr.__baBetterAgnostrPatched) return true;
      const original = window.nostr.signEvent;
      try {
        Object.defineProperty(window.nostr, "__baBetterAgnostrPatched", { value: true, configurable: true });
        window.nostr.signEvent = async function(event) {
          const prepared = await prepareOutgoing(event, { source: "nip07" });
          return original.call(this, prepared);
        };
        state.nip07Patched = true;
        publishStatus();
        return true;
      } catch {
        return false;
      }
    }
    function scanSigner() {
      if (!state.signerHooked) {
        const found = findIdentityManager();
        if (found) patchIdentityManager(found);
      }
      patchNip07();
    }
    function startSignerWatch() {
      if (state.signerScanTimer !== null) return;
      state.signerScanTimer = window.setInterval(scanSigner, state.signerHooked ? 5e3 : 900);
      scanSigner();
    }
    function cloneTags(tags) {
      return Array.isArray(tags) ? tags.map((t) => Array.isArray(t) ? [...t] : t) : [];
    }
    function markPrepared(ev) {
      try {
        Object.defineProperty(ev, "__baPrepared", { value: true, enumerable: false, configurable: true });
      } catch {
      }
      return ev;
    }
    function isPrepared(ev) {
      return !!ev && ev.__baPrepared === true;
    }
    async function ensureBuild(force = false) {
      const manual = state.settings.glub.manualBuild;
      if (manual) return manual;
      const cached = state.settings.glub.build;
      const age = Date.now() - Number(state.settings.glub.buildFetchedAt || 0);
      if (!force && cached && age < 2 * 60 * 1e3) return cached;
      if (state.buildPromise) return state.buildPromise;
      state.buildRequestedAt = Date.now();
      state.buildPromise = (async () => {
        const res = await askUi("build", { force, current: cached }, 4500);
        if (res && res.build) {
          state.settings.glub.build = String(res.build);
          state.settings.glub.buildFetchedAt = Number(res.fetchedAt) || Date.now();
          publishStatus();
          return state.settings.glub.build;
        }
        if (res?.error) notice("warning", "Glub build sync failed", String(res.error));
        return state.settings.glub.build || "";
      })();
      try {
        return await state.buildPromise;
      } finally {
        state.buildPromise = null;
      }
    }
    function removeTagsByName(tags, names) {
      return tags.filter((t) => !Array.isArray(t) || !names.has(t[0]));
    }
    function isTeleportTag(tag) {
      return Array.isArray(tag) && tag[0] === "t" && String(tag[1] || "").trim().toLowerCase() === "teleport";
    }
    function hasTeleportTag(tags) {
      return Array.isArray(tags) && tags.some(isTeleportTag);
    }
    function stripTeleportTags(tags) {
      return tags.filter((tag) => !isTeleportTag(tag));
    }
    function applyClientPolicy(ev) {
      const settings = state.settings;
      let policy = policyForKind(settings, ev.kind);
      if (settings.privacy.stripTags.includes("client")) policy = "strip";
      if (policy === "leave") return;
      if (policy === "spoof" && !settings.client.name.trim()) return;
      if (policy === "spoof" && settings.client.name.trim().toLowerCase() === "glub.chat" && !effectiveBuild(settings)) {
        return;
      }
      ev.tags = removeTagsByName(ev.tags, /* @__PURE__ */ new Set(["client"]));
      if (policy === "strip" || !settings.client.name) return;
      ev.tags.push(["client", settings.client.name.slice(0, 64)]);
    }
    function applyPrivacyTags(ev) {
      if (state.settings.privacy.omitTeleport) {
        ev.tags = stripTeleportTags(ev.tags);
      }
      const strip = new Set(state.settings.privacy.stripTags);
      if (!strip.size) return;
      for (const critical of ["g", "d", "e", "p", "k", "h", "a", "q"]) strip.delete(critical);
      ev.tags = removeTagsByName(ev.tags, strip);
    }
    function applyTrackingStrip(ev) {
      if (!state.settings.privacy.stripTracking) return;
      if (typeof ev.content !== "string" || !ev.content) return;
      if (!/https?:\/\//i.test(ev.content)) return;
      ev.content = stripTrackingParams(ev.content);
    }
    async function applyGlub(ev, group) {
      const settings = state.settings;
      const groupPolicy = policyForKind(settings, ev.kind);
      const wantsGlubClient = groupPolicy === "spoof" && settings.client.name.trim().toLowerCase() === "glub.chat" && !settings.privacy.stripTags.includes("client");
      if (!CHAT_KINDS.has(ev.kind) && !NOTE_KINDS.has(ev.kind) && group !== "chat" && !wantsGlubClient) return;
      const existing = parseGlubMeta(ev.tags);
      const isChat = group === "chat" && ev.kind !== 20001;
      let rich = typeof existing.rich === "string" ? existing.rich : "";
      let fmt = typeof existing.fmt === "string" ? sanitizeTemplate(existing.fmt) : "";
      let flair = typeof existing.flair === "string" && isValidFlair(existing.flair) ? existing.flair : "";
      if (settings.studio.applyRich && typeof ev.content === "string" && hasFormat(ev.content)) {
        const stripped = stripFormat(ev.content);
        if (ev.content.length <= RICH_MAX) {
          rich = ev.content;
          ev.content = stripped;
        } else {
          ev.content = stripped;
          rich = "";
          notice("warning", "Formatting skipped", "The message is too long for glub rich formatting; codes were removed.");
        }
      }
      if (settings.studio.enabled && isChat) {
        const tpl = sanitizeTemplate(settings.studio.template);
        if (tpl) fmt = tpl;
        if (settings.studio.flair && isValidFlair(settings.studio.flair)) flair = settings.studio.flair;
      }
      const needsGlub = !!(rich || fmt || flair);
      if (!needsGlub && !wantsGlubClient) return;
      const build = await ensureBuild();
      ev.tags = removeTagsByName(ev.tags, /* @__PURE__ */ new Set(["glub"]));
      if (!build) {
        notice("warning", "Glub metadata skipped", "No live glub.chat build stamp is available yet. The message will still send, but glub.chat users will see plain text.");
        return;
      }
      const tag = buildGlubTag({ rich, fmt, flair }, build);
      if (tag) ev.tags.push(tag);
      else if (wantsGlubClient) ev.tags.push(["glub", "v", build]);
    }
    async function prepareOutgoing(original, opts = {}) {
      if (!original || typeof original !== "object") return original;
      if (!state.active) return original;
      if (isPrepared(original)) return original;
      await waitForConfig();
      const settings = state.settings;
      if (!settings.studio.enabled && !settings.privacy.reviewEnabled && !settings.privacy.stripTracking) {
      }
      const ev = {
        kind: original.kind,
        created_at: original.created_at,
        tags: cloneTags(original.tags),
        content: typeof original.content === "string" ? original.content : String(original.content ?? "")
      };
      if (original.pubkey) ev.pubkey = original.pubkey;
      const group = kindGroup(ev.kind);
      const calls = settings.privacy.calls;
      if (calls.disable && calls.blockOutgoing && isCallEvent(ev)) {
        throw new Error("Calling is disabled in Better Agnostr privacy settings.");
      }
      applyTrackingStrip(ev);
      await applyGlub(ev, group);
      applyPrivacyTags(ev);
      applyClientPolicy(ev, group);
      if (isReviewKind(settings, ev.kind)) {
        const decision = await askUi(
          "review",
          {
            original: cloneEventForStorage(original),
            proposed: cloneEventForStorage(ev),
            group,
            source: opts.source || "signer"
          },
          18e4
        );
        if (!decision || decision.action !== "send") {
          throw new Error("Outgoing event cancelled in the Better Agnostr review dialog.");
        }
        if (Array.isArray(decision.stripTags) && decision.stripTags.length) {
          const strip = new Set(decision.stripTags);
          for (const critical of ["g", "d", "e", "p", "k", "h", "a", "q"]) strip.delete(critical);
          ev.tags = removeTagsByName(ev.tags, strip);
        }
      }
      state.preparedCount += 1;
      return markPrepared(ev);
    }
    function readJson(key, fallback) {
      try {
        const raw = localStorage.getItem(key);
        return raw ? JSON.parse(raw) : fallback;
      } catch {
        return fallback;
      }
    }
    function secretFromRaw(raw) {
      if (!raw || typeof raw !== "string") return null;
      const trimmed = raw.trim();
      try {
        if (trimmed.toLowerCase().startsWith("nsec1")) {
          const decoded = decode(trimmed);
          return decoded?.type === "nsec" && decoded.data instanceof Uint8Array ? decoded.data : null;
        }
        if (/^[0-9a-f]{64}$/i.test(trimmed)) {
          const bytes3 = hexToBytes3(trimmed.toLowerCase());
          getPublicKey(bytes3);
          return bytes3;
        }
      } catch {
      }
      return null;
    }
    function localKeys() {
      const signModeRaw = localStorage.getItem("agnostr:v2:sign_mode");
      const signMode = signModeRaw === "local" || signModeRaw === "extension" || signModeRaw === "auto" ? signModeRaw : "auto";
      const settings = readJson("agnostr:v2:settings", {});
      const perGeohashIdentity = !!settings.perGeohashIdentity;
      let master = null;
      if (signMode === "local") {
        master = secretFromRaw(localStorage.getItem("agnostr:v2:local_secret") || "");
      } else if (signMode === "auto") {
        master = secretFromRaw(localStorage.getItem("agnostr:v2:device_seed") || "");
      }
      return { signMode, perGeohashIdentity, master };
    }
    function deriveGeohashSecret(seed, geohash) {
      const normalized = String(geohash || "").trim().replace(/^#+/, "").toLowerCase();
      const geo = utf8ToBytes4(normalized);
      for (let counter = 0; counter < 10; counter++) {
        const info = new Uint8Array(geo.length + 4);
        info.set(geo, 0);
        new DataView(info.buffer).setUint32(geo.length, counter, false);
        const candidate = hmac2(sha2564, seed, info);
        try {
          getPublicKey(candidate);
          return candidate;
        } catch {
        }
      }
      return sha2564(concatBytes4(seed, geo));
    }
    function keyForEvent(ev) {
      const { signMode, perGeohashIdentity, master } = localKeys();
      if (signMode === "extension" || !master) return null;
      const geohash = getTagValue(ev.tags, "g");
      if (signMode === "auto" && perGeohashIdentity && geohash) {
        const derived = deriveGeohashSecret(master, geohash);
        try {
          if (getPublicKey(derived) === ev.pubkey) return derived;
        } catch {
        }
      }
      try {
        if (getPublicKey(master) === ev.pubkey) return master;
      } catch {
      }
      return null;
    }
    function resignEvent(ev) {
      if (!ev || typeof ev !== "object") return null;
      const key = keyForEvent(ev);
      if (!key) return null;
      try {
        const unsigned = {
          kind: ev.kind,
          created_at: ev.created_at || Math.floor(Date.now() / 1e3),
          tags: cloneTags(ev.tags),
          content: ev.content
        };
        return finalizeEvent(unsigned, key);
      } catch {
        return null;
      }
    }
    function relaySnapshot() {
      return [...state.relays.values()].map((r) => ({ ...r }));
    }
    function publishStatus() {
      const build = effectiveBuild(state.settings);
      let nickname = "";
      try {
        nickname = localStorage.getItem("agnostr:v2:nickname") || "";
      } catch {
      }
      post("status", {
        signerHooked: state.signerHooked,
        nip07Patched: state.nip07Patched,
        signMode: state.signMode,
        pubkey: state.pubkey,
        npub: state.npub,
        nickname,
        build,
        buildFetchedAt: state.settings.glub.buildFetchedAt,
        eventCount: state.events.size,
        logCount: state.logs.length,
        socketCount: state.sockets.size,
        relays: relaySnapshot(),
        callDrops: state.callDrops,
        preparedCount: state.preparedCount,
        startedAt: state.startedAt,
        callsDisabled: state.settings.privacy.calls.disable
      });
    }
    function applyCallPolicy() {
      if (!state.active) return;
      const calls = state.settings.privacy.calls;
      if (!calls.disable) return;
      try {
        for (const label of document.querySelectorAll(".ag-ctx-item-label")) {
          if (/^(voice|video) call$/i.test(label.textContent?.trim() || "")) {
            label.closest(".ag-ctx-item")?.remove();
          }
        }
      } catch {
      }
    }
    function stopActiveWork() {
      if (state.statusTimer !== null) {
        window.clearInterval(state.statusTimer);
        state.statusTimer = null;
      }
      if (state.signerScanTimer !== null) {
        window.clearInterval(state.signerScanTimer);
        state.signerScanTimer = null;
      }
      state.callObserver?.disconnect();
      state.callObserver = null;
      state.started = false;
    }
    function start() {
      if (state.started || !state.active) return;
      state.started = true;
      startSignerWatch();
      if (state.statusTimer === null) {
        state.statusTimer = window.setInterval(publishStatus, 2500);
      }
      state.callObserver = new MutationObserver(() => applyCallPolicy());
      try {
        state.callObserver.observe(document.documentElement, { childList: true, subtree: true });
      } catch {
      }
      publishStatus();
    }
    try {
      Object.defineProperty(window, "__betterAgnostr", {
        value: {
          state,
          findIdentityManager,
          findAppContext,
          findInspectPeerFn,
          prepareOutgoing,
          ensureBuild,
          reconstructEvent
        },
        configurable: true
      });
    } catch {
    }
  })();
})();
